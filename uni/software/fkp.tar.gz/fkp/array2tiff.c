/* Laver et 2d-array om til et tiff billede */

#include "main.h"

void array2tiff(sammenligning *info, char *file) {
  TIFF *output;
  uint32 size_in_mem;
  int j, i, counter = 0;
  char *raster_image_data;

  /* �bner file for skrivening */
  output = gTIFFopen(file, "w");

  size_in_mem =  info->width * info->height;
  
  if((raster_image_data = (char*) calloc(size_in_mem, sizeof(char))) == NULL){
    fprintf(stderr, "Kunne ikke finde hukommelse nok\n");
    exit(42);
  }

  /* Omformer array til char via unsigned int to char */
  for(j = 0; j < info->height; j++) {
    for(i = 0; i < info->width; i++) {
      raster_image_data[counter] = (unsigned int) info->komp[i][j];
      counter++;
    }
  }
  
  /* S�tter de forskellige tags til tif filen */
  TIFFSetField(output, TIFFTAG_IMAGEWIDTH, info->width);
  TIFFSetField(output, TIFFTAG_IMAGELENGTH, info->height);
  TIFFSetField(output, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG);
  TIFFSetField(output, TIFFTAG_PHOTOMETRIC, 0);
  TIFFSetField(output, TIFFTAG_BITSPERSAMPLE, 8);
  TIFFSetField(output, TIFFTAG_SAMPLESPERPIXEL, 1);

  /* Skriver data til selve filen */
  if(TIFFWriteEncodedStrip(output, 0, raster_image_data, size_in_mem) == 0){
    fprintf(stderr, "Kunne ikke skrive til billedet\n");
    exit(42);
  }

  /* Lukker tif filen */
  TIFFClose(output);
}
