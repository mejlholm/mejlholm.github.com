/* Wavlets tranformation til  komprimering og dekomprimering */

#include "main.h"

/*Interfacen til resten af programmet, dvs. hovedfunktionen til komprimeringen*/
billede* komprimering(int** gammel_billede, int bredde, int hoejde, int skalering, int tresh){
  billede* bil;

  bil = array_opret(gammel_billede, bredde, hoejde, skalering, tresh);
  h_udvid(bil);
  v_udvid(bil);
  d_udvid(bil);
  analyse_image(bil);
  if (bil->tresholding>1) {
    tresholding(bil);
  }
  return bil;
}

/*Interfacen til resten af programmet, dvs. hovedfunktionen til dekomprimeringen*/
int** dekomprimering(billede* bil){
  int **dekomp;

  syntese_image(bil);
  dekomp = bil_trans(bil);

  free(bil);
  return dekomp;
}

/*Opret en ny array med struct punkt for indgangene til vores
  array. V�rdierne for det gamle billede kopieres ind i det nye
  billede. Derefter udvideres den nye array ved kanterne, ved hj�lp af
  spejling*/
billede* array_opret(int** gammel_billede, int bred, int hoej,
		     int skalering, int tresholding){
  billede* bil;
  int bb, hh;
  
  bil = (billede*) calloc(1,sizeof(billede));
  bil->bred = bred; /*Gemmer de n�dvendig oplysningser i struct'en*/
  bil->hoej = hoej;
  bil->skal = skalering;
  bil->tresholding = tresholding;

  /*Opretter lagerplads til kopring af det tilf�rte billede. lagerpladsen bliver
    3*bredden og 3*h�jden af det tilf�rte billede, dvs. 3 gange s�
    store som det tilf�rte billede*/
  bil -> p = (punkt**) calloc(hoej + 2 * hoej, sizeof(punkt*));
  for(hh = 0; hh < hoej + 2 * hoej; hh++)
    bil->p[hh] = (punkt*) calloc(bred + 2 * bred, sizeof(punkt));

  /*overf�rer v�rdiern, for punkterne for det tilf�rte billede til
    vores ny oprettet lagerplads. Data'erne er nu placeret i midten af
    2D arrayet.

    000
    0d0
    000

    hvor d er vores data.
  */

  for(bb = 0; bb < bred; bb++)
    for(hh = 0; hh < hoej; hh++)
      bil->p[hh + hoej][bb + bred].vaerdi = gammel_billede[hh][bb];
   
  return bil;
}


/* horizontal udvidelse ved at spejling for bredderne */
void h_udvid(billede* bil) {
  int m,n;


  /*kopier data ved hj�lp af spejling
    
  000
  sds
  000
  
  hvor d er vores nuv�rende data og s er spejlingen af data
  */

  for(n = 0; n < bil->bred; n++) {
    for(m = 0; m < bil->hoej; m++){
      bil->p[m + bil->hoej][bil->bred * 3 -1 - n].vaerdi = 
	bil->p[m + bil->hoej][bil->bred-1 - n].vaerdi = 
	bil->p[m + bil->hoej][n + bil->bred].vaerdi;
    }
  }
}

/*vertical udvidelse ved at spejling for hoejderne*/

void v_udvid(billede* bil){
  int m,n;

  /*kopier data ved hj�lp af spejling
    
   0s0
   0d0
   0s0
  
  hvor d er vores nuv�rende data og s er spejlingen af data
  */


  for(m = 0; m < bil-> hoej; m++ ) {
    for(n = 0 ; n < bil->bred; n++)
      bil->p[bil->hoej * 3 -1 - m][n + bil->bred].vaerdi =
	bil->p[bil->hoej -1 - m][n + bil->bred].vaerdi=
	bil->p[m + bil->hoej][n + bil->bred].vaerdi;
  }
}

/* diagonal udvidelse ved at spejling for bredderne */
void d_udvid(billede* bil) {
  int m,n;


  /*kopier data ved hj�lp af spejling
    
  sds
  000
  000
  
  hvor d er vores nuv�rende data og s er spejlingen af data
  */


  for(n = 0; n < bil -> bred; n++) {
    for(m = 0; m < bil ->hoej; m++) {
      bil->p[m][bil->bred * 3 -1 - n].vaerdi =
	bil->p[m][bil->bred -1 - n].vaerdi =
	bil->p[m][n + bil->bred].vaerdi;
    }
  }

  /*kopier data ved hj�lp af spejling
    
  000
  sds
  000
    
  hvor d er vores nuv�rende data og s er spejlingen af data*/

  for(n = 0; n < bil -> bred; n++) {
    for( m = 0; m < bil ->hoej; m++) {
      bil->p[m + 2 * bil->hoej][bil->bred * 3 -1 - n].vaerdi =
	bil->p[m + 2 * bil->hoej][bil->bred -1 - n].vaerdi =
	bil->p[m + 2 * bil->hoej][n + bil->bred].vaerdi;
    }
  }
}

/* funktionen til at komprimere data med*/
void analyse_image(billede* bil){
  int nu_skal;
  int m,n;



  /*Resetter vores farver*/
  for(m = 0; m < bil -> hoej*3; m++)
    for(n = 0; n < bil -> bred*3; n++){
      bil->p[m][n].farve = BLANK;
    }
    /*Vores billedet er farve l�s, s� vi starter med at farve billedet
    hvidt.*/

  for(m = 0; m < bil -> hoej; m++)
    for(n = 0; n < bil -> bred; n++)
      bil->p[m + bil->hoej][n+bil->bred].farve = HVID;


  /* Her bliver vi n�dt til at opstille to m�der at transformere
     vores data p�. Den nuv�rende scale_current bestemmer hvilken en
     vi skal v�lge. For ulige transformation taler vi om en "vinkelret"
     matrix. For lige transformation taler vi om en fordrejet matrix*/
 
 /*Udf�rer prediction operationen*/
  for(nu_skal = 1; nu_skal <= bil->skal; nu_skal++){
    if(nu_skal % 2 == 1){ /*ulige skalering, dvs. de skalering der
			    vender det vandrette billede om til 45*
			    (grader)*/
      /*Vi finder de steder der skal males for sorte og maler dem sort*/
      /*for ulige r�kker, for den nuv�rende skalering*/
      for(m  = (int)pow(2,(nu_skal+1)/2-1)-1; m < bil -> hoej; m+=(int)pow(2,(nu_skal-1)/2+1))
	for(n = 0; n < bil -> bred; n+=(int)pow(2,(nu_skal-1)/2+1))
	  bil -> p[m + bil->hoej][n + bil->bred].farve = SORT;
      
      /*Og for lige r�kker, for den nuv�rende skalering*/
      for(m  = (int) pow(2,(nu_skal+1)/2)-1; m < bil -> hoej; m += (int)pow(2,(nu_skal-1)/2+1))
	for(n = (int) pow(2,(nu_skal-1)/2); n < bil -> bred; n += (int)pow(2,(nu_skal-1)/2+1))
	  bil -> p[m + bil->hoej][n + bil->bred].farve = SORT;
      
      /*Finder alle de sorte felter og udf�rer transformationen med
	nedenst�ende formel.*/
      for(m  = 0; m < bil -> hoej; m++){
	for(n = 0; n < bil -> bred; n++){
	  if(bil -> p[m + bil->hoej][n + bil->bred].farve == SORT){
	    bil->p[m + bil->hoej][n + bil->bred].vaerdi = bil->p[m + bil->hoej][n + bil->bred].vaerdi -
	      (bil->p[(m + bil -> hoej) - (int)pow(2,(nu_skal-1)/2)][n + bil -> bred].vaerdi +
	       bil->p[(m + bil -> hoej) + (int)pow(2,(nu_skal-1)/2)][n + bil->bred].vaerdi +
	       bil->p[m + bil -> hoej][n + bil -> bred + (int)pow(2,(nu_skal-1)/2)].vaerdi +
	       bil->p[m + bil -> hoej][(n + bil -> bred) - (int)pow(2,(nu_skal-1)/2)].vaerdi) / 4;

	    /*Farver de puntkter udenfor vores rammer roede*/
	    if (bil->p[(m + bil -> hoej) - (int)pow(2,(nu_skal-1)/2)][n + bil -> bred].farve == BLANK)
	      bil->p[(m + bil -> hoej) - (int)pow(2,(nu_skal-1)/2)][n + bil -> bred].farve=GUL;
	    if (bil->p[(m + bil -> hoej) + (int)pow(2,(nu_skal-1)/2)][n + bil->bred].farve == BLANK)
	      bil->p[(m + bil -> hoej) + (int)pow(2,(nu_skal-1)/2)][n+ bil->bred].farve = GUL;
	    if (bil->p[m + bil -> hoej][n + bil -> bred + (int)pow(2,(nu_skal-1)/2)].farve==BLANK)
	      bil->p[m + bil -> hoej][n + bil -> bred + (int)pow(2,(nu_skal-1)/2)].farve=GUL;
	    if (bil->p[m + bil -> hoej][(n + bil -> bred) - (int)pow(2,(nu_skal-1)/2)].farve==BLANK)
	      bil->p[m + bil -> hoej][(n + bil -> bred) - (int)pow(2,(nu_skal-1)/2)].farve=GUL;
	  }	  
	}
      }

      /*Nu tager vi alle de hvide felter og udf�rer en transformation*/
      
      for(m = 0 ; m < bil -> hoej; m++) {
	for(n = 0; n < bil -> bred; n++) {
	  if(bil->p[m+bil->hoej][n+bil->bred].farve == HVID){
	    bil->p[m + bil->hoej][n + bil -> bred].vaerdi = bil->p[m + bil->hoej][n + bil->bred].vaerdi +
	      (bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal-1)/2)][n + bil->bred].vaerdi +
	       bil->p[(m + bil->hoej) + (int)pow(2,(nu_skal-1)/2)][n + bil->bred].vaerdi +
	       bil->p[m + bil->hoej][(n + bil->bred) + (int)pow(2,(nu_skal-1)/2)].vaerdi +
	       bil->p[m + bil->hoej][(n + bil->bred) - (int)pow(2,(nu_skal-1)/2)].vaerdi) / 8;
	    
	    /*Farver de punkter undenfor vores rammer roede*/
	    if (bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal-1)/2)][n + bil->bred].farve==BLANK)
	      bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal-1)/2)][n + bil->bred].farve=GUL;
	    if (bil->p[(m + bil->hoej) + (int)pow(2,(nu_skal-1)/2)][n + bil->bred].farve==BLANK)
	      bil->p[(m + bil->hoej) + (int)pow(2,(nu_skal-1)/2)][n + bil->bred].farve=GUL;
	    if (bil->p[m + bil->hoej][(n + bil->bred) + (int)pow(2,(nu_skal-1)/2)].farve==BLANK)
	      bil->p[m + bil->hoej][(n + bil->bred) + (int)pow(2,(nu_skal-1)/2)].farve=GUL;
	    if (bil->p[m + bil->hoej][(n + bil->bred) - (int)pow(2,(nu_skal-1)/2)].farve==BLANK)
	      bil->p[m + bil->hoej][(n + bil->bred) - (int)pow(2,(nu_skal-1)/2)].farve=GUL;
	  }
	}
      }
    }
    else { /*Her starter de lige skalering, dvs. de skalering der
	     vender billedet p� 45* om til 0* */
      
      /*Finder punkterne og farver dem sorte samt udf�rer transforeringen*/
      for(m = (int)pow(2,nu_skal/2-1)-1; m < bil -> hoej; m+=(int)pow(2,nu_skal/2)){
	for(n = (int) pow(2,nu_skal/2-1); n < bil -> bred; n+=(int)pow(2,nu_skal/2)){
	    (bil->p[m+bil->hoej][n+bil->bred].farve=SORT);

	    bil-> p[m + bil->hoej][n + bil->bred].vaerdi = bil->p[m +bil->hoej][n + bil->bred].vaerdi -
	      (bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal)/2-1)][n + bil->bred - (int)pow(2,(nu_skal)/2-1)].vaerdi +
	       bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal)/2-1)][n + bil->bred + (int)pow(2,(nu_skal)/2-1)].vaerdi +
	       bil->p[m + bil->hoej + (int)pow(2,(nu_skal)/2-1)][n + bil->bred + (int)pow(2,(nu_skal)/2-1)].vaerdi +
	       bil->p[m + bil->hoej + (int)pow(2,(nu_skal)/2-1)][(n + bil->bred) - (int)pow(2,(nu_skal)/2-1)].vaerdi)/ 4;
	}
      }

      /*Udf�rer transformering for alle hvide felter*/

      for(m = 0 ; m < bil -> hoej; m++){
	for(n = 0; n < bil -> bred; n++){
	  if(bil->p[m+bil->hoej][n+bil->bred].farve == HVID){
	    bil->p[m + bil->hoej][n + bil->bred].vaerdi = bil->p[m + bil->hoej][n + bil->bred].vaerdi +
	      (bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal)/2-1)][n + bil->bred - (int)pow(2,(nu_skal)/2-1)].vaerdi +
	       bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal)/2-1)][n + bil->bred + (int)pow(2,(nu_skal)/2-1)].vaerdi +
	       bil->p[m + bil->hoej + (int)pow(2,(nu_skal)/2-1)][n + bil->bred + (int)pow(2,(nu_skal)/2-1)].vaerdi +
	       bil->p[m + bil->hoej + (int)pow(2,(nu_skal)/2-1)][(n + bil->bred) - (int)pow(2,(nu_skal)/2-1)].vaerdi) / 8;
	  }
	}
      }
    }

    /*Finder alle sorte farvede felter og farver dem r�de og derefter
      udf�res algoritmen en gang til, hvis det ikke allerede er den
      sideste gang.*/

    for(m = 0 ; m < bil -> hoej; m++)
      for(n = 0; n < bil -> bred; n++)
	if (bil->p[m+bil->hoej][n+bil->bred].farve == SORT)
	  bil->p[m+bil->hoej][n+bil->bred].farve = ROED; 
  }
}



/*Tresholding funktionen til wavelet komprimering*/
void tresholding(billede* bil){
  int m, n;
  
  for(m = 0; m < bil->hoej*3; m++){
    for(n = 0; n < bil->bred*3; n++){
      if(bil->p[m][n].farve == ROED){
	if(abs(bil->p[m][n].vaerdi) < bil -> tresholding)
	  bil->p[m][n].vaerdi = 0;   
	if(abs(bil->p[m][n].vaerdi) > 255)
	  bil->p[m][n].vaerdi=0;	
      }      
      if(bil->p[m][n].farve == GUL){
	if(abs(bil->p[m][n].vaerdi)< bil -> tresholding)
	  bil->p[m][n].vaerdi=0;
	if(abs(bil->p[m][n].vaerdi) > 255)
	  bil->p[m][n].vaerdi=0;
      }
    }
  }
}


/*funktionen til at dekomprimere data med*/
void syntese_image(billede* bil){
  int nu_skal;
  int m,n;  

  for(nu_skal = bil->skal; nu_skal >=1; nu_skal--) {
    if(nu_skal % 2 == 0) {

      /*for alle de lige, dvs. de dekomprimeringer der vender billedet
	p� 0* om til 45*. For hver fundne hvid felt udf�res, udf�res
	transformationen, samt farver de omliggende felter til sorte */

      for(m = 0; m < bil -> hoej; m++) {
	for(n = 0; n < bil -> bred;n++) {
	  if(bil->p[m+bil->hoej][n+bil->bred].farve == HVID) { 
	    bil->p[m + bil->hoej][n + bil->bred].vaerdi = bil->p[m + bil->hoej][n + bil->bred].vaerdi -
	      (bil->p[m + bil->hoej - (int)pow(2,(nu_skal)/2-1)][n + bil->bred - (int)pow(2,(nu_skal)/2-1)].vaerdi +
	       bil->p[m + bil->hoej - (int)pow(2,(nu_skal)/2-1)][n + bil->bred + (int)pow(2,(nu_skal)/2-1)].vaerdi +
	       bil->p[m + bil->hoej + (int)pow(2,(nu_skal)/2-1)][n + bil->bred + (int)pow(2,(nu_skal)/2-1)].vaerdi +
	       bil->p[m + bil->hoej + (int)pow(2,(nu_skal)/2-1)][n + bil->bred - (int)pow(2,(nu_skal)/2-1)].vaerdi) /8;

	    bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal)/2-1)][n + bil->bred - (int)pow(2,(nu_skal)/2-1)].farve = SORT;
	    bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal)/2-1)][n + bil->bred + (int)pow(2,(nu_skal)/2-1)].farve = SORT;
	    bil->p[m + bil->hoej + (int)pow(2,(nu_skal)/2-1)][n +bil->bred + (int)pow(2,(nu_skal)/2-1)].farve = SORT;
	    bil->p[m + bil->hoej + (int)pow(2,(nu_skal)/2-1)][(n + bil->bred) - (int)pow(2,(nu_skal)/2-1)].farve = SORT;
	  }
	}
      }

      /*Finder alle sorte felter og udf�rer en transformation, samt
	farve dem til hvide*/

      for(m = 0 ; m < bil -> hoej; m++){
	for(n = 0; n < bil -> bred; n++){
	  if(bil->p[m+bil->hoej][n+bil->bred].farve == SORT){
	    bil-> p[m + bil->hoej][n + bil->bred].vaerdi = bil->p[m +bil->hoej][n + bil->bred].vaerdi +
	      (bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal)/2-1)][n + bil->bred - (int)pow(2,(nu_skal)/2-1)].vaerdi +
	       bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal)/2-1)][n + bil->bred + (int)pow(2,(nu_skal)/2-1)].vaerdi +
	       bil->p[m + bil->hoej + (int)pow(2,(nu_skal)/2-1)][n + bil->bred + (int)pow(2,(nu_skal)/2-1)].vaerdi +
	       bil->p[m + bil->hoej + (int)pow(2,(nu_skal)/2-1)][(n + bil->bred) - (int)pow(2,(nu_skal)/2-1)].vaerdi) / 4;

	    bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal)/2-1)][n + bil->bred - (int)pow(2,(nu_skal)/2-1)].farve = HVID;
	    bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal)/2-1)][n + bil->bred + (int)pow(2,(nu_skal)/2-1)].farve = HVID;
	    bil->p[m + bil->hoej + (int)pow(2,(nu_skal)/2-1)][n + bil->bred + (int)pow(2,(nu_skal)/2-1)].farve = HVID;
	    bil->p[m + bil->hoej + (int)pow(2,(nu_skal)/2-1)][(n + bil->bred) - (int)pow(2,(nu_skal)/2-1)].farve = HVID;
	  }
	}
      }
    }
    else{ /*ulige skalering*/


      /*Dekomprimering for ulige skalering, dvs. hvor den vender 45*
	om til 0*, finder alle hvide felter og udf�rer
	transformationen, samt farve de tilh�rende sorte.*/

      for(m = 0; m < bil->hoej; m++) {
	for(n = 0; n <bil->bred; n++) {
	  if(bil->p[m+bil->hoej][n+bil->bred].farve == HVID) {
	    bil->p[m + bil->hoej][n + bil -> bred].vaerdi = bil->p[m + bil->hoej][n + bil->bred].vaerdi -
	      (bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal-1)/2)][n + bil->bred].vaerdi +
	       bil->p[(m + bil->hoej) + (int)pow(2,(nu_skal-1)/2)][n + bil->bred].vaerdi +
	       bil->p[m + bil->hoej][(n + bil->bred) + (int)pow(2,(nu_skal-1)/2)].vaerdi +
	       bil->p[m + bil->hoej][(n + bil->bred) - (int)pow(2,(nu_skal-1)/2)].vaerdi) /8 ;
	    
	    bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal-1)/2)][n + bil->bred].farve = SORT;
	    bil->p[(m + bil->hoej) + (int)pow(2,(nu_skal-1)/2)][n + bil->bred].farve = SORT;
	    bil->p[m + bil->hoej][(n + bil->bred) + (int)pow(2,(nu_skal-1)/2)].farve= SORT;
	    bil->p[m + bil->hoej][(n + bil->bred) - (int)pow(2,(nu_skal-1)/2)].farve = SORT;
	  }
	}
      }

      /*Find alle de sorte felter og udf�rer transformationen samt de
	tilh�rende punkter*/

      for(m = 0 ; m < bil -> hoej; m++){
	for(n = 0; n < bil -> bred; n++){
	  if(bil->p[ m + bil->hoej][n + bil->bred].farve == SORT){
	    bil->p[m + bil->hoej][n + bil->bred].vaerdi = bil->p[m + bil->hoej][n + bil->bred].vaerdi +
	      (bil->p[(m + bil -> hoej) - (int)pow(2,(nu_skal-1)/2)][n + bil -> bred].vaerdi +
	       bil->p[(m + bil -> hoej) + (int)pow(2,(nu_skal-1)/2)][n + bil->bred].vaerdi +
	       bil->p[m + bil -> hoej][n + bil -> bred + (int)pow(2,(nu_skal-1)/2)].vaerdi +
	       bil->p[m + bil -> hoej][(n + bil -> bred) - (int)pow(2,(nu_skal-1)/2)].vaerdi) /4;

	    bil->p[(m + bil->hoej) - (int)pow(2,(nu_skal-1)/2)][n + bil->bred].farve = HVID;
	    bil->p[(m + bil->hoej) + (int)pow(2,(nu_skal-1)/2)][n + bil->bred].farve = HVID;
	    bil->p[m + bil->hoej][n + bil->bred + (int)pow(2,(nu_skal-1)/2)].farve = HVID;
	    bil->p[m + bil->hoej][(n + bil->bred) - (int)pow(2,(nu_skal-1)/2)].farve = HVID;	   
	  }
	}
      }
    }

    /*Find alle de sorte felter og farver dem hvide f�r vi starter
      algorimen igen*/

    for(m = 0 ; m < bil -> hoej; m++)
      for(n = 0; n < bil -> bred; n++)
	if (bil->p[m+bil->hoej][n+bil->bred].farve == SORT)
	  bil->p[m+bil->hoej][n+bil->bred].farve = HVID;
  }
}



/*Kopierer data fra det store billede, dvs. giver de n�dvendige informationer
  tilbage til omverden*/

int** bil_trans(billede* bil){
  int m;
  int n;
  int** nyt_bil;

  /*Allokerer lagerplads til kopiering*/
  nyt_bil = (int**) calloc( sizeof(int*), bil->hoej);
  for(m = 0; m < bil->hoej ; m ++)
    nyt_bil[m] = (int*) calloc( sizeof(int), bil->bred);


  /*udf�rer kopieringen*/
  for(m = 0; m < bil->bred; m++)
    for(n = 0; n < bil->hoej; n++)
      nyt_bil[m][n] = bil->p[m + bil->hoej][n + bil->bred].vaerdi;
  
  return nyt_bil;
}

void write_out_file(billede* bil, char* file){
  FILE* wf;
  int m,n;

  /* aabner filen*/
  if((wf = fopen(file, "w")) == NULL) {
    fprintf(stderr, "Kunne ikke �bne filen %s.\n", file);
    exit(1);
  }
  fprintf(wf,"%d %d %d %d", bil->hoej, bil->bred, bil->skal, bil->tresholding);
  for(m = 0; m < bil->bred; m++){
    for(n = 0; n < bil->hoej; n++){
      /*Finder alle de felter der er roede og er lig med 0 og gemmer
	det som A*/
      if(bil->p[m + bil->hoej][n+bil->bred].farve == ROED && bil->p[m + bil->hoej][n+bil->bred].vaerdi == 0)
	fprintf(wf,"%c",'A');
      /*Ellers gemmer den de roede felter med 'R' og vaerdien eller
	med 'H' og vaerdien*/
      else if (bil->p[m + bil->hoej][n+bil->bred].farve == ROED){
	fprintf(wf,"%c",'R');
	fprintf(wf ,"%d", (bil->p[m+bil->hoej][n+bil->bred].vaerdi));
      }
      else{
	fprintf(wf,"%c",'H');
	fprintf(wf ,"%d", (bil->p[m+bil->hoej][n+bil->bred].vaerdi));
      }
    }
  }
    /*Finder de gule felter uden om omraadet 5 og gemmer det.*/
  for(m = 0; m < bil->bred*3; m++){
    for(n = 0; n < bil->hoej*3; n++){
      if(bil->p[m][n].farve == GUL)
	fprintf(wf," %d %d %d", m, n, bil->p[m][n].vaerdi);
    }
  }
  fprintf(wf," %c %c %c", 'R', 'R', 'R');
  /*Lukker filen*/
  fclose(wf);

}


billede* read_in_file(char* file){
  FILE* rf;
  billede* bil;
  int m, n, vaerdi;
  int hoej, bred, skal, tresholding;
  int c;

  /*Aabner filen for lasesning*/
  if((rf = fopen(file, "r")) == NULL) {
    fprintf(stderr, "Kunne ikke �bne filen %s.\n", file);
    exit(1);
  }

  fscanf(rf,"%d %d %d %d", &hoej, &bred, &skal, &tresholding);
  bil = (billede*) malloc(sizeof(billede));

  /*Opretter lagerplads til kopring af det tilf�rte billede. lagerpladsen bliver
    3*bredden og 3*h�jden af det tilf�rte billede, dvs. 3 gange s�
    store som det tilf�rte billede*/
  bil -> p = (punkt**) calloc(hoej + 2 * hoej, sizeof(punkt*));
  for(m = 0; m < hoej + 2 * hoej; m++)
    bil->p[m] = (punkt*) calloc(bred + 2 * bred, sizeof(punkt));

  /*Henter informationen omkring billedet*/
  bil->hoej = hoej;
  bil->bred = bred;
  bil->skal = skal;
  bil->tresholding = tresholding;

  /*Initialiserer arrayet*/
  for(m = 0; m < 3*bil->bred; m++){
    for(n = 0; n < 3*bil->hoej; n++){
      bil->p[m][n].vaerdi = 0;
      bil->p[m][n].farve=BLANK;
    }
  }

  /*Henter informationerne ind til arrayet igen, dvs. omraadet 5*/
  for(m = 0; m < bil->bred; m++){
    for(n = 0; n < bil->hoej; n++){
      c = fgetc(rf);
      if (c=='A'){
	bil->p[m+bil->hoej][n+bil->bred].farve = ROED;
	bil->p[m+bil->hoej][n+bil->bred].vaerdi = 0;

      }
      else if(c == 'R'){
	bil->p[m+bil->hoej][n+bil->bred].farve = ROED;
	fscanf(rf,"%d", &(bil->p[m+bil->hoej][n+bil->bred].vaerdi));
      }
      else if (c == 'H'){
	bil->p[m+bil->hoej][n+bil->bred].farve = HVID;
	fscanf(rf,"%d", &(bil->p[m+bil->hoej][n+bil->bred].vaerdi));
      }
    }
  }
  
  /*Henter informationerne udenfor omraadet 5*/ 
  while(fscanf(rf,"%d%d%d", &m, &n, &vaerdi)!=0){
      bil->p[m][n].vaerdi = vaerdi;
      bil->p[m][n].farve = GUL;
  }
    
  fclose(rf);
  return bil;
}

