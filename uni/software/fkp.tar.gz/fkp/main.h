/* Dette er hovedfilen som binder de forskellige moduler sammen */

#include <stdio.h>    /* std lib til io funkctioner*/
#include <stdlib.h>   /* Henter stdlib s� vi kan bruge calloc */
#include <tiffio.h>   /* LibTiff.org for nyest lib med tiff ext.*/
#include <math.h>     /* Loader matamatik in i C, til abs v�rdier mm. */
#include <ctype.h>    /* Loader char funktion ind i programmet */
#include <string.h>   /* Henter string manipulations funktioner */
#include <sys/stat.h> /* Henter file st�rrelse ind i programmet */

/* Farverne er til vores farvning af billedet */
#define BLANK 0
#define SORT  1
#define HVID  2
#define ROED  3
#define GUL   4

/*************** De forskellige strukturer der bliver brugt *****************/
typedef struct sammenligning {
  int **t2a;
  int **komp;
  char *filenavn;
  char *filenavn_komp;
  int height;
  int width;
} sammenligning; /* bliver brugt i sammenligningsprocesen*/

/*Strukturen til de punkter til vores array*/
typedef struct punkt {
  int vaerdi;  /*farve v�rdien for punktet, 0 - 255, dvs. 256 kombinationer*/
  int farve;   /*skal bruges til farvning af vores algoritme*/
} punkt;

/*Strukturen til vores1 billede*/
typedef struct billede {
  struct punkt** p;  /* selve billedet som best�r af 2D-array */
  int hoej;          /* hoejden p� billedet */
  int bred;          /* bredden p� billledet */
  int skal;          /* Skalering for komprimering */
  int tresholding;   /* bruges efter komrimering for minimering af v�rdier */
} billede;

/***************** De forskellige funktioner i programmet *******************/

/* ui */
void ui(void); /* User Interface */
void huffman_denc(char*);
void huffman_enc(char*);
void normaliz(sammenligning*); /* Normeliser det dekomprimerede array */
void prn_resultat(int, int, double*, int, int, double, int, int, double, sammenligning*); /* Printer resutater af sammeligningen */
 
/* Tiff2arrya */
int** tiff2array(char*, int*, int*); /* Return a[][] tager filenavn */

/* Array2tiff */
void array2tiff(sammenligning*, char*);

/* Wavelets */
billede* komprimering(int**, int, int, int, int);
billede* array_opret(int**, int, int, int, int);
billede* read_in_file(char*);
int** dekomprimering(billede*);
void v_udvid(billede*);
void h_udvid(billede*);
void d_udvid(billede*);
void analyse_image(billede*);
void tresholding(billede*);
void syntese_image(billede*);
int** bil_trans(billede*);
void write_out_file(billede*, char*);

/* Sammenlignings procesen */
void read_in_string (char*);
void total_match(sammenligning*, int*, int*);
double* px_match(sammenligning*, double*);
void vektor_match(sammenligning*, int*, int*, double*);

/* Init sleep funktion, brokker sig hvis denne ikke er her */
void sleep(int);

/* Behandler fejl koder og smarte funktioner, som tjekker deres status */
FILE *gopen(char*,char*);
TIFF *gTIFFopen(char*, char*);
