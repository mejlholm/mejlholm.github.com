/* Sammelignings processen - to arrays med pixel information for at finde forskel i forhold til en hvis tolerangce  */

#include "main.h"

/* Sammenligner hver pixel mellem de to arrays */
void total_match (sammenligning* billede_info, int *matched, int *not_matched)
{	
  int i, j;

  for (j = 0; j < billede_info->height; j++)
    {
      for (i = 0; i < billede_info->width; i++)
	{
	  if (billede_info->t2a[j][i] == billede_info->komp[j][i])
	    {
	      (*matched)++;
	    }
	  else
	    {
	      (*not_matched)++;
	    }
	}
    }
}

/* Laver en sammenligning med x omr�de af pixel, billede skal v�re pow(x) */
double * px_match (sammenligning* billede_info, double *x)
{
  int j, i, k, x_coor, y_coor, haf_width;
  int pixel_index = 0, *pixel_hold, pixel_hold_t2a, pixel_hold_komp;
  int gennemsnit_index = 0; 
  double *gennemsnit, tmp, gennemsnit_hold = 0, pixel_jump;

  printf("\t\t\t  Tal som er gode til sammmenligningen:");

  /* Finder ud af hvilke tal der er gode til pow off x */
  haf_width = billede_info->width / 2;
  for(j = 1; j <= haf_width; j++) {
    if((billede_info->width % j) == 0) {
      if((billede_info->height % j) == 0) {
	printf(",%d ", j);
      }
    }
  }
  
  /* V�lg tal */
  printf("\n\t\t\t  V�lg et af disse tal: ");
  scanf("%lf", &pixel_jump);
  *x = pixel_jump;

  /* Frig�r ram til array'et, som skal hold styre p� gennemsnit v�rdier  */
  pixel_hold = calloc(pixel_jump * pixel_jump, sizeof(int));

  /* laver ram til array'et, som skal return */
  tmp = (billede_info->width/pixel_jump)*(billede_info->width/pixel_jump);
  gennemsnit = calloc(tmp, sizeof(double));

  /* Selve sammenlignings procesen af de to arrays */
  for(j = 0; j < billede_info->height; j += pixel_jump){ /* Finder n�ste start pos for h�jden */
    for(i = 0; i < billede_info->width; i += pixel_jump){ /* Finer n�ste start pos for bredden*/
      /* Her forg�r udregn nger for gennemsnit i udsnittet */
      for(y_coor = j; y_coor <= (j + pixel_jump - 1); y_coor++){ /* Holder styre p� r�kker i y */
	for(x_coor = i; x_coor <= (i + pixel_jump - 1); x_coor++){ /* Holder styre p� col i x */

	  pixel_hold_t2a = billede_info->t2a[y_coor][x_coor];
	  pixel_hold_komp = billede_info->komp[y_coor][x_coor];
	  /* lave et array til at holde p� forskellen mellem de to */
	  pixel_hold[pixel_index] = pixel_hold_t2a - pixel_hold_komp;
	  pixel_index++;
	}
      }
      /* her skal gennemsnittet regnes ud for et omr�de */
      for(k = 0; k < pixel_index; k++) {
	gennemsnit_hold += pixel_hold[k];
      }
      /* Gemmer gennemsnit i array */
      tmp = gennemsnit_hold/(pixel_jump * pixel_jump);
      gennemsnit[gennemsnit_index] = fabs(tmp);
      gennemsnit_index++;
      /* reseter vigtig variabler */
      gennemsnit_hold = 0;
      pixel_index = 0;
    }
  }
  /* Frig�r ram igen */
  free(pixel_hold);

  /* Her skal gennemsnit array'et return */
  return gennemsnit;
}

/* Laver sammeligning med norm vektor beregninger */
void vektor_match(sammenligning* billede_info, int *max_norm, int *first_norm, double *sec_norm) {
  int **forskel, j, i, pixel1, pixel2, tmp;

  /* null stiller var */
  *max_norm = 0;
  *first_norm = 0;
  *sec_norm = 0;

  /* Finder ram til array'et, som skal indhold forskellen*/
  forskel = (int**) calloc (billede_info->width + 1, sizeof (int));
  for (i = 0; i < billede_info->width; i++)
    {
      forskel[i] = (int*) calloc (billede_info->height + 1, sizeof (int));
    }
  
  /* Vi start med at beregn forskellen mellem de to array's */
  for(j = 0; j < billede_info->height; j++){
    for(i = 0; i < billede_info->width; i++){
      pixel1 = billede_info->t2a[j][i];
      pixel2 = billede_info->komp[j][i];
      forskel[j][i] = abs(pixel1 - pixel2);
    }
  }

  /******** Beregn max norm vektoren ********/
  for(j = 0; j < billede_info->height; j++){
    for(i = 0; i < billede_info->width; i++){
      if(*max_norm < forskel[j][i]) {
	*max_norm = forskel[j][i];
      }
    }
  }
  
  /******** Bereng ||norm||_1 verktor ********/
  for(j = 0; j < billede_info->height; j++){
    for(i = 0; i < billede_info->width; i++) {
      *first_norm = *first_norm + forskel[j][i];
    }
  }

  /******** Bereng ||norm||_2 verktor ********/
  for(j = 0; j < billede_info->height; j++){
    for(i = 0; i < billede_info->width; i++) {
      tmp = tmp + (forskel[j][i] * forskel[j][i]);
      *sec_norm = sqrt(tmp);
    }
  }

  /* fri giver ram */
  free(forskel);
}
