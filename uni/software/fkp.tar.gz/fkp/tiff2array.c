/* Dette module indl�ser et tiff billede og laver et 2d array som output */
/* For at kompile brug gcc <file.c> -o <out file> -ltiff -lm */

#include "main.h"

int** tiff2array (char *file, int *w, int *h)
{
  TIFF *image;
  uint16 photo;
  uint32 width, height;
  tsize_t stripSize;
  unsigned long imagesize, bufferSize, count, imageOffset, result;
  int i, j, stripMax, stripCount, **a;
  char *buffer;

  /* �bner tiff billedet */
  if ((image = TIFFOpen(file, "r")) == NULL) {
    fprintf (stderr, "Billede filen findes ikke\n");
    exit(42);
  }

  /* Indl�s billede st�relse og antal pixel */
  TIFFGetField (image, TIFFTAG_IMAGEWIDTH, &width);
  TIFFGetField (image, TIFFTAG_IMAGELENGTH, &height);
  imagesize = width * height + 1;

  /* Finder ram til 2d array ved at bruge boubble pointer */
  a = (int **) calloc (width + 1, sizeof (int));
  for (i = 0; i < width; i++)
    {
      a[i] = (int *) calloc (height + 1, sizeof (int));
    }

  /* Checker for mutil stripe i billedet */
  stripSize = TIFFStripSize (image);
  stripMax = TIFFNumberOfStrips (image);
  imageOffset = 0;

  /* Finder hukommelse til billede data */
  bufferSize = TIFFNumberOfStrips (image) * stripSize;
  buffer = (char *) malloc(bufferSize); /* bruger vores gmalloc til at finde mem */

  /* Indl�s information omkring stripsize */
  for (stripCount = 0; stripCount < stripMax; stripCount++)
    {
      if ((result = TIFFReadEncodedStrip (image, stripCount, buffer + imageOffset, stripSize)) == -1)
	{
	  fprintf (stderr, "Fejl i l�sningen af input strip nummer: %d\n", stripCount);
	  exit (42);
	}

      imageOffset += result;
    }

  /* Tjekker photometric interpretations */
  if (TIFFGetField (image, TIFFTAG_PHOTOMETRIC, &photo) == 0)
    {
      fprintf (stderr, "Billede har ingen photometric interpretation\n");
      exit (42);
    }

  if (photo != PHOTOMETRIC_MINISWHITE)
    {
      for (count = 0; count < bufferSize; count++)
	buffer[count] = ~buffer[count];
    }

  /* Skal fylde array med information */
  i = 0;
  j = 0;
  for (count = 0; count < bufferSize; count++)
    {
      a[i][j] = (unsigned char) buffer[count];
      if (i == width - 1)
	{
	  j++;
	  i = -1;
	}
      i++;
    }

  /* Lukker billedet */
  TIFFClose (image);

  /* Return information om billedet */
  *w = width;
  *h = height;
  free(buffer);
  return (a);
}
