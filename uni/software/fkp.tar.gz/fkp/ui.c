/* User intergace til vores program */

#include "main.h"

/* Indl�ser EN char fra stdin og smider resten v�k */
int get_char(void){
  int c, dump;

  c = getchar();
  for(dump = getchar(); ((dump != '\n') && (c != EOF)); dump = getchar());

  return c;
}

/* Laver en enc med huffman */
void huffman_enc(char *filenavn) {
  char command[350] = "./huffman -c -i ", cmd[256] = "rm ";

  strcat(command, filenavn);
  strcat(command, " -o ");
  strcat(command, filenavn);
  strcat(command, ".fpd");
  system(command);
  strcat(cmd, filenavn);
  system(cmd);
}		
    
/* Laver udpakning med huffman */
void huffman_denc(char *filenavn) {
  char command[350] = "./huffman -d -i ";
  
  strcat(command, filenavn);
  strcat(command, " -o ");
  strcat(command, "fpdfile");
  system(command);
}

/* Udskriver resultater af sammenlignings procesen */
void prn_resultat(int ok, int not_ok, double *gm, int max_norm, int first_norm, double sec_norm, int w, int h, double x, sammenligning *info) {
  int j, i, tmp = 0, fs_org = 0, fs_komp = 0;
  double min = 0.0, fsp = 0.0;
  FILE *stream;
  char filenavn_komp[256];
  struct stat statbuf;

  system("clear");

  printf("Statestik for sammelignings processen af billederne.\n\n");
  printf("Til module sammenligning skal vi bruge en min fejl v�rdi.\n"
	 "Indtast en min v�rdi: ");
  scanf("%lf", &min);
  
  /* pixel vs. pixel*/
  printf("\n\nPixel vs Pixel");
  printf("\nOk pixels: %d", ok);
  printf("\nNot ok pixels: %d", not_ok);

  /* moduls */
  printf("\n\nModulus\n");
  i = 0;
  for(j = 0; j < ((w/x)*(w/x)); j++){
    tmp++;
    /* Holder styre p� hvor n�r vi n�r billedes kant */
    if(tmp == (w/x)){ 
      i++; 
      tmp = 0;
    }
    if((gm[j] != 0) && (gm[j] > min)){
      printf("Omr�de [%d][%d] indholder en fejl p� %.4f\n", i, tmp, gm[j]);
    }
  }

  /* norm vektor */
  printf("\n\nNorm vektor");
  printf("\nNorm max: %d", max_norm);
  printf("\nNorm 1: %d", first_norm);
  printf("\nNorm 2: %f\n\n", sec_norm);
  
  /* Henter file st�rrelse fra filende */
  stream = fopen(info->filenavn, "r");
  stat(info->filenavn, &statbuf);
  fs_org = (int) statbuf.st_size;
  fclose(stream);

  /* Overf�r filenavn til en costa array */
  for(j = 0; j < (strlen(info->filenavn_komp) + 1); j++) {
    filenavn_komp[j] = info->filenavn_komp[j];
  }

  strcat(filenavn_komp, ".fpd");
  if ((stream = fopen(filenavn_komp, "r")) == NULL) {
    fprintf(stderr, "Kunne ikke �bne filen: |%s|\n\n", filenavn_komp);
  } else {
    stat(filenavn_komp, &statbuf);
    fs_komp = (int) statbuf.st_size;
    fclose(stream);
  }

  /* Forskel i procent*/
  fsp = (fs_org - fs_komp);
  fsp = fsp/fs_org;
  fsp = fsp*100;

  /* Udprinter de forskellige fil st�rrelser */
  printf("Den orignale: %d%s%d%s%s%.4f%s\n", fs_org/1024, 
	 "Kb\tDet komprimerede:", fs_komp/1024, "Kb",
	 "\tKomprimering: ", fsp, "%");

  sleep(15);
}

/* Normalizer */
void normaliz(sammenligning* norm_info) {
  int j, i;

  for(j = 0; j < norm_info->height; j++) {
    for(i = 0; i < norm_info->width; i++) {
      if(norm_info->komp[j][i] > 256) {
	norm_info->komp[j][i] = 255;
      }
      if(norm_info->komp[j][i] < 0) {
	norm_info->komp[j][i] = 0;
      }
    }
  }
}

/* Selv user interfacet */
void ui(void) {
  int valg, w, h;
  char *filenavn, *kon_string, *filenavn_komp;
  int ok = 0, not_ok = 0, skalering, tresh;
  int max_norm, first_norm;
  double sec_norm = 0, *gm, x = 0.0;
  sammenligning *info;
  billede *komp_billede;

  /* Finder hukommelse til de to stukturer, som benyttes i programmet */
  info = (sammenligning*) calloc(1,sizeof(sammenligning));
  komp_billede = (billede*) calloc(1,sizeof(billede));
  
  /* init kontrol variable til menuen */
  kon_string = "\t\t\t  *                                *\n";

  /* Begyndelse p� hovdemenuen, vi bruger en while l�kke til at opdater menuen */
  while (valg != '8') {
    system("clear"); /* renser sk�rmmen */
    printf("\n\n\n\n%s",
	   "\t\t\t  **********************************\n"
	   "\t\t\t  *   Fingeraftryks Komprimering   *\n"
	   "\t\t\t  *               med              *\n"
	   "\t\t\t  *            Wavelets            *\n"
	   "\t\t\t  **********************************\n"
	   "\t\t\t  **********************************\n"
	   "\t\t\t  *                                *\n"
	   "\t\t\t  *                                *\n"
	   "\t\t\t  *      1. Indl�s billede         *\n"
	   "\t\t\t  *      2. Komprimering           *\n");
    printf("%s%s%s",
	   "\t\t\t  *      3. Gem billedet           *\n"
	   "\t\t\t  *      4. Indl�s komp. billede   *\n"
	   "\t\t\t  *      5. Dekomprimering         *\n"
	   "\t\t\t  *      6. Sammenligning          *\n"
	   "\t\t\t  *      7. Gem billedet som tiff  *\n"	   
	   "\t\t\t  *      8. Exit                   *\n"
	   "\t\t\t  *                                *\n"
	   ,kon_string,
	   "\t\t\t  *                                *\n"
	   "\t\t\t  **********************************\n"
	   );
    printf("\t\t\t  Menu valg: ");
    valg = get_char(); /* Indl�ser filenavn*/

    switch (valg) {
    case '1':
      printf ("\t\t\t  Indtast et filenavn: ");
      scanf("%s", filenavn); /* Indl�ser filenavn*/
      info->filenavn = filenavn;
      info->t2a = tiff2array(filenavn, &w, &h); /* Konventer file til 2d array */
      info->width = w; /* Ligger bredden ind i vore strukt*/
      info->height = h; /* Ligger h�jden ind i vore strukt*/
      kon_string = "\t\t\t  *   TIFF filen er blevt �bnet    *\n";
      break;
    case '2':
      printf("\t\t\t  Indtast treshold: ");
      scanf("%d", &tresh);
      skalering = (int) (log10(info->width)/log10(2))*2; /* Beregner max skalering, j^2 */
      komp_billede =  komprimering(info->t2a, info->width, info->height, skalering, tresh);
      kon_string = "\t\t\t  *  Billede er blevt komprimeret  *\n";
      break;
    case '3':
      printf ("\t\t\t  Indtast et filenavn uden endelse: ");
      scanf("%s", filenavn_komp); /* Indl�ser filenavn*/
      info->filenavn_komp = filenavn_komp;
      write_out_file(komp_billede, filenavn_komp);
      /* Laver en huffman gemmning */
      huffman_enc(info->filenavn_komp);
      /* Laver commando til huffman komprimering */
      kon_string = "\t\t\t  *      Billede er blevt gemt     *\n";
      break;
    case '4':
      printf ("\t\t\t  Indtast et filenavn: ");
      scanf("%s", filenavn); /* Indl�ser filenavn*/
      huffman_denc(filenavn);
      komp_billede = read_in_file("fpdfile"); /* indl�ser file */
      /* Overf�r v�rdier fra filen til info */
      info->width = komp_billede->bred;
      info->height = komp_billede->hoej;
      kon_string = "\t\t\t  *  Billede er blevt hentet ind   *\n";
      break;
    case '5':
      info->komp = dekomprimering(komp_billede);
      normaliz(info);
      kon_string = "\t\t\t  * Billede er blevt dekomprimeret *\n";
      break;
    case '6':
      /* Sender de to billeder til sammenligningen */
      total_match(info, &ok, &not_ok);
      gm = px_match(info, &x);
      vektor_match(info, &max_norm, &first_norm, &sec_norm);
      
      /* Udskriver resultater fra sammenligningen SKAL LAVES ET FILTER TIL MODULS */
      prn_resultat(ok, not_ok, gm, max_norm, first_norm, sec_norm, info->width, info->height, x, info);
      break;
    case '7':
      printf ("\t\t\t  Indtast et filenavn: ");
      scanf("%s", filenavn); /* Indl�ser filenavn*/
      array2tiff(info, filenavn);
      kon_string = "\t\t\t  *     Billede er gemt i tiff     *\n";
      break;
    case '8':
      system("clear"); /* renser sk�rmmen */
      printf("\n\n\n\n%s",
	     "\t\t\t  **********************************\n"
	     "\t\t\t  *   Fingeraftryks Komprimering   *\n"
	     "\t\t\t  *               med              *\n"
	     "\t\t\t  *            Wavelets            *\n"
	     "\t\t\t  **********************************\n");
      printf("%s\n",
	     "\t\t\t  **********************************\n"
	     "\t\t\t  *         Lavet af C224          *\n"
	     "\t\t\t  *                                *\n"
 	     "\t\t\t  *               p�               *\n"
	     "\t\t\t  *                                *\n"
	     "\t\t\t  *       Aalborg Universitet      *\n"
	     "\t\t\t  *                                *\n"
	     "\t\t\t  **********************************\n"
	   );
      sleep(2);
      system("clear"); /* renser sk�rmmen */
      free(info);
      free(komp_billede);
    }
  }
}
