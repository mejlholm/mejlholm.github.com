/* Behandlig af errors og funktioner, som checker for fejl inde de f.eks �bner en fil */

#include "main.h"

/* Smart open funktion, til at �bne filer */
FILE *gopen(char *file, char *mode) {
  FILE *fp;

  if((fp = fopen(file, mode)) == NULL) {
    fprintf(stderr, "Kunne ikke �bne filen %s.\n", file);
    exit(1);
  }
  return fp;
}

/* Smart TIFFopen funktion, til at �bne tiff billeder */
TIFF *gTIFFopen(char *file, char *mode) {
  TIFF *pt;
  
  if ((pt = TIFFOpen(file, mode)) == NULL) {
      fprintf (stderr, "Billede filen findes ikke\n");
      exit(42);
    }

  return pt;
}
