package dk.auc.cs.dogs.compiler.optimiser;

import java.util.ArrayList;

import dk.auc.cs.dogs.compiler.contextual.ErrorList;
import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.optimiser.probers.*;

/**
 * ArithmeticOptimiser.java
 *
 *
 * Created: Fri Apr 30 14:19:00 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class ArithmeticOptimiser extends TypeOptimiser {

    private boolean debug = false;

    public ArithmeticOptimiser() {

    } // ArithmeticOptimiser constructor


    public void outAPlusPlusMinusExpr(APlusPlusMinusExpr node){
	ArithmeticProber a = new ArithmeticProber();
	node.apply(a);
	if (a.size() == 3){
	    AConcatinationExprMultiplicationExpr aceme = optimise(a);
	    if (aceme != null){
		node.setPlusMinusExpr(null);
		node.setPlus(null);
		node.setMultiplicationExpr(aceme);
	    }
	}
    }

    public void outAMinusPlusMinusExpr(AMinusPlusMinusExpr node){
	ArithmeticProber a = new ArithmeticProber();
	node.apply(a);
	if (a.size() == 3){
	    AConcatinationExprMultiplicationExpr aceme = optimise(a);
	    if (aceme != null){
		node.setPlusMinusExpr(null);
		node.setMinus(null);
		node.setMultiplicationExpr(aceme);
	    }
	}
    }

    public void outAStarMultiplicationExpr(AStarMultiplicationExpr node){
	ArithmeticProber a = new ArithmeticProber();
	node.apply(a);
	if (a.size() == 3){
	    AConcatinationExprMultiplicationExpr aceme = optimise(a);
	    if (aceme != null){
		node.setMultiplicationExpr(aceme);
		node.setStar(null);
		node.setConcatinationExpr(null);
	    }
	}
    }

    public void outADivMultiplicationExpr(ADivMultiplicationExpr node){
	ArithmeticProber a = new ArithmeticProber();
	node.apply(a);
	if (a.size() == 3){
	    AConcatinationExprMultiplicationExpr aceme = optimise(a);
	    if (aceme != null){
		node.setMultiplicationExpr(aceme);
		node.setDiv(null);
		node.setConcatinationExpr(null);
	    }
	}
    }


    public void outAModMultiplicationExpr(AModMultiplicationExpr node){
	ArithmeticProber a = new ArithmeticProber();
	node.apply(a);
	if (a.size() == 3){
	    AConcatinationExprMultiplicationExpr aceme = optimise(a);
	    if (aceme != null){
		node.setMultiplicationExpr(aceme);
		node.setMod(null);
		node.setConcatinationExpr(null);
	    }
	}
    }


    public void outAIntDivMultiplicationExpr(AIntDivMultiplicationExpr node){
	ArithmeticProber a = new ArithmeticProber();
	node.apply(a);
	if (a.size() == 3){
	    AConcatinationExprMultiplicationExpr aceme = optimise(a);
	    if (aceme != null){
		node.setMultiplicationExpr(aceme);
		node.setIntDiv(null);
		node.setConcatinationExpr(null);
	    }
	}
    }

    public void outAParPrimaryExpression(AParPrimaryExpression node){
	ArithmeticProber a = new ArithmeticProber();
	InftyProber ip = new InftyProber();
	node.apply(a);
	node.apply(ip);
	if (a.size() == 3 && !ip.isInfty()){
	    	    Node n;
	    if (debug) System.out.println("Removing ()");
	    if (debug) a.print();
	    if (a.getType(1).equals("i")) {
		n = new AIntegerPrimaryExpression(new TIntegerLiteral(a.getExpression(1)));
		node.replaceBy(n);
	    } else if (a.getType(1).equals("f")) {
		n= new AFloatPrimaryExpression(new TFloatLiteral(a.getExpression(1)));
		node.replaceBy(n);
	    } else {
		;
	    }

	}
    }

    private AConcatinationExprMultiplicationExpr optimise(ArithmeticProber a){
	String s1, s2, s3, s4;
	String t1, t2, t3;
	s4 = "";

       	s1 = a.getExpression(0);
       	s2 = a.getExpression(1);
       	s3 = a.getExpression(2);

       	t1 = a.getType(0);
       	t2 = a.getType(1);
       	t3 = a.getType(2);

	//if we are dealing with ints
	if (t1 == "i" && t2 == "" && t3 == "i"){
	    Long i = new Long(s1);
	    Long j = new Long(s3);
	    long k = i.longValue();
	    long l = j.longValue();
	    if (s2.equals("+")){
		s4 = "" + (k + l);
	    }
	    if (s2.equals("-")){
		s4 = "" + (k - l);
	    }
	    if (s2.equals("/")){
		if (l == 0) {
		    AIntegerPrimaryExpression in = (AIntegerPrimaryExpression) a.getNode(0);
		    ErrorList.add(in.getIntegerLiteral(), "Division by zero");
		    s4 = "0.0";
		} else {
		    s4 = "" + ((0.0 + k) / l);
		}
		return makeFloat(s4);
	    }
	    if (s2.equals("*")){
		s4 = "" + (k * l);
	    }
	    if (s2.equals("mod")){
		if (l == 0) {
		    AIntegerPrimaryExpression in = (AIntegerPrimaryExpression) a.getNode(0);
		    ErrorList.add(in.getIntegerLiteral(), "Mod by zero");
		} else {
		    s4 = "" + (k % l);
		}
	    }
	    if (s2.equals("div")){
		if (l == 0) {
		    AIntegerPrimaryExpression in = (AIntegerPrimaryExpression) a.getNode(0);
		    ErrorList.add(in.getIntegerLiteral(), "Division by zero");
		} else {
		    s4 = "" + (k / l);
		}
	    }

	    if (debug) System.out.println("" + s1 +s2 +s3+ " optimised to: " + s4);

	    return makeInteger(s4);
	}

	//if we are dealing with floats
	if ((t1 == "f" && t2 == "" && t3 == "f") || (t1 == "i" && t2 == "" && t3 == "f") || (t1 == "f" && t2 == "" && t3 == "i")){
	    Double i = new Double(s1);
	    Double j = new Double(s3);
	    double k = i.doubleValue();
	    double l = j.doubleValue();
	    if (s2.equals("+")){
		s4 = "" + (k + l);
	    }
	    if (s2.equals("-")){
		s4 = "" + (k - l);
	    }
	    if (s2.equals("/")){
		if (l == 0) {
		    int m = 0;
		    if (!(a.getNode(m) instanceof AFloatPrimaryExpression)) {
			m = 2;
		    }
		    AFloatPrimaryExpression f = (AFloatPrimaryExpression) a.getNode(m);
		    ErrorList.add(f.getFloatLiteral(), "Division by zero");
		} else {
		    s4 = "" + ((k) / l);
		}
	    }
	    if (s2.equals("*")){
		s4 = "" + (k * l);
	    }

	    if (debug) System.out.println("" + s1 +s2 +s3+ " optimised to: " + s4);

	    return makeFloat(s4);
	}

	return null;
    }

    private AConcatinationExprMultiplicationExpr makeInteger(String newText){
	AConcatinationExprMultiplicationExpr aceme = new AConcatinationExprMultiplicationExpr();
	AUnaryPpMmConcatinationExpr aexp = new AUnaryPpMmConcatinationExpr();
	AIntegerPrimaryExpression ipe = new AIntegerPrimaryExpression(new TIntegerLiteral(newText));
	aceme.setConcatinationExpr(aexp);
	aexp.setPrimaryExpression(ipe);

	return aceme;
    }

    private AConcatinationExprMultiplicationExpr makeFloat(String newText){
	AConcatinationExprMultiplicationExpr aceme = new AConcatinationExprMultiplicationExpr();
	AUnaryPpMmConcatinationExpr aexp = new AUnaryPpMmConcatinationExpr();
	AFloatPrimaryExpression fpe = new AFloatPrimaryExpression(new TFloatLiteral(newText));
	aceme.setConcatinationExpr(aexp);
	aexp.setPrimaryExpression(fpe);

	return aceme;
    }

} // ArithmeticOptimiser
