package dk.auc.cs.dogs.environment.types;

import java.util.*;

public class Label extends GraphProperty implements LabelInteger, LabelFloat, LabelString, LabelBoolean, LabelEdge, LabelVertex, LabelInterface {

    //    private LinkedList list = new LinkedList();
    private LinkedList labels = new LinkedList();
    private GraphComposite graph;
    private java.lang.String type;

    public Label(java.lang.String type, GraphComposite g) {
	super();
	graph = g;
	this.type = type;
	g.addLabel(this);
	Iterator it = g.getVertexIterator();
	while (it.hasNext()) {
	    notifyAdd((Vertex)it.next());
	}
    }

    public Primitive getLabel(Vertex v) {
	//	int i = list.indexOf(v);
	int i = graph.getIndex(v);
	Object o;
	if (v.getGraph().equals(graph) && i != -1) {
	    o = labels.get(i);
	    if (o instanceof java.lang.String) {
		throw new RuntimeException("Fatal error: label value not set for vertex");
	    } else {
		return (Primitive)o;
	    }
	} else {
	    throw new RuntimeException("Fatal error: label value not set for vertex");
	}
    }

    public GraphComposite getGraph() {
	return graph;
    }

    public void setLabel(Vertex v, Primitive label) {
	java.lang.String name = label.getType();
	if (((type.equals("Integer") || type.equals("Float")) && name.equals("Infty")) || type.equals(name)) {
	    int index;
	    if ((index = graph.getIndex(v)) != -1) {
		//	    if (list.contains(v)) {
//		if (!(label instanceof Edge || label instanceof Vertex)) {
		    //		    int i = list.indexOf(v);
		    if (index != -1) {
			labels.remove(index);
			labels.add(index, label);
		    } else {
			throw new RuntimeException("Fatal error: cannot find label for vertex");
		    }
// 		} else {
// 		    throw new RuntimeException("Fatal error: cannot add vertex and edge as label");
// 		}
	    } else {
		throw new RuntimeException("Cannot set label for vertex: vertex not in correct graph");
	    }
	} else {
	    throw new RuntimeException("Cannot add label of different type");
	}
    }

    public void notifyRemove(Vertex v) {
       	if (v.getGraph().equals(graph)) {
	    labels.remove(graph.getIndex(v));
	    //	    labels.remove(list.indexOf(v));
	    //	    list.remove(v);
	} else {
	    throw new RuntimeException("Cannot remove vertex from label: vertex not in correct graph");
	}
    }

    public void notifyAdd(Vertex v) {
	if (v.getGraph().equals(graph)) {
	    //	    list.addLast(v);
	    labels.addLast("");
	} else {
	    throw new RuntimeException("Cannot add vertex to label: vertex not in correct graph");
	}
    }
}
