package dk.auc.cs.dogs.environment.types;

public abstract class GraphType extends Primitive {

    public GraphType() {
	super();
    }

    public java.lang.String toString() {
	return "GraphType";
    }
}
