package dk.auc.cs.dogs.compiler.libraryhandler;

import java.lang.Exception;



/**
 * ClassFileNotKnownException.java
 *
 *
 * Created: Mon May 10 14:50:31 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class ClassFileNotKnownException extends Exception {
    public ClassFileNotKnownException() {
	super("Unknown exception");
    } // ClassFileNotKnownException constructor
    
    public ClassFileNotKnownException(String msg) {
	super(msg);
    }

    public ClassFileNotKnownException(String msg, Throwable cause) {
	super(msg, cause);
    }
} // ClassFileNotKnownException
