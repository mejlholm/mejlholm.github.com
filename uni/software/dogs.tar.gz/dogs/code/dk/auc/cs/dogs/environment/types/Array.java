package dk.auc.cs.dogs.environment.types;

import java.util.LinkedList;
import java.util.Iterator;
import java.lang.Integer;

public class Array extends Composite implements CompositeIterable, ArrayInteger, ArrayFloat, ArrayEdge, ArrayVertex, ArrayString, ArrayBoolean, ArrayInterface {

    private boolean debug = false;
    private java.lang.String type;
    private Object[] pList;
    private int size = 0; // st�rrelsen af alle dimensionernes samlede st�rrelse

    public Array(java.lang.String[] values) {
	super();
	if (debug) System.out.println("Importing string array...");
	type = "String";
	pList = new Object[2 + values.length];
	pList[0] = new Integer(1);
	pList[1] = new Integer(1);
	size = values.length;
	for (int i = 0; i < values.length; i++) {
	    // Importing string values
	    if (debug) System.out.println("Adding " + values[i] + " to string array");
	    pList[2 + i] = new String(values[i]);
	}
    }

    public Array(java.lang.String type, java.lang.String patternSize) {
        super();
        this.type = type;
        LinkedList dim = explodePattern(patternSize);
	size = ((java.lang.Integer)dim.get(0)).intValue();
	if (debug) System.out.println("New array with size " + size + " of type " + type + " created (" + patternSize + ")");
	pList = new Object[dim.size() + size];
	//this.size = dim.size() + size;
	if (debug) System.out.println("Internal array created with size " + this.size);
	pList[0] = new java.lang.Integer(dim.size() - 1);
	if (debug) System.out.println(pList[0] + " dimensions created");
	for (int i = 1; i < dim.size(); i++) {
	    pList[i] = dim.get(i);
	    if (debug) System.out.println("Dimension " + i + " added with size " + pList[i]);
	}
    }

    public Iterator getIterator(java.lang.String type) {
	if (!type.equals(this.type)) {
	    throw new RuntimeException("Cannot extract " + type + " from array");
	}
	LinkedList tmpList = new LinkedList();
	int start = dimSize() + 1;
	for (int i = 0; i < size; i++) {
	    tmpList.addLast(pList[start + i]);
	    if (debug) System.out.println("Adding " + tmpList.getLast() + " to iterator");
	}
	return tmpList.iterator();
    }

    public void setValue(java.lang.String pattern, Primitive value) {
	LinkedList dim = explodePattern(pattern);
	if (debug) System.out.println("Setting element at " + pattern);
	for (int i = 1; i < dim.size(); i++) {
	    if (((java.lang.Integer)dim.get(i)).intValue() > dimSize(i)) {
		throw new RuntimeException("Cannot access element: index out of bounds");
	    }
	}
	pList[getInternalIndex(dim)] = value;
    }

    public Primitive getValue(java.lang.String pattern) {
	LinkedList dim = explodePattern(pattern);
	if (debug) System.out.println("Getting element at " + pattern);
	for (int i = 1; i < dim.size(); i++) {
	    if (((java.lang.Integer)dim.get(i)).intValue() > dimSize(i)) {
		if (debug) System.out.println("Size in pattern: " + ((java.lang.Integer)dim.get(i)).intValue() + " - size in dimension: " + dimSize(i));
		if (debug) System.out.println("Pattern: " + pattern);
		throw new RuntimeException("Cannot access element: index out of bounds");
	    }
	}
	return (Primitive)pList[getInternalIndex(dim)];
    }

    // Returnerer st�rrelsen p� den givne dimension
    public int dimSize(long l) {
	int i = (int)l;
	if (i > dimSize() || i < 1) {
	    throw new RuntimeException("Dimension index out of bound");
	} else {
	    return ((java.lang.Integer)pList[i]).intValue();
	}
    }
    
    // Returnerer antal dimensioner i array
    public int dimSize() {
	return ((java.lang.Integer)pList[0]).intValue();
    }

    public int size() {
	return size;
    }

    private int getInternalIndex(java.lang.String pattern) {
	LinkedList list = explodePattern(pattern);
	return getInternalIndex(list);
    }

    private int getInternalIndex(LinkedList list) {
	int tmp, dimCounter = 1, index, internalIndex = 0;
	int tmpSize;
	for (int j = 1; j < list.size(); j++) {
	    tmp = ((java.lang.Integer)list.get(j)).intValue();

	    tmpSize = 1;
	    if (dimCounter < dimSize()) {
		for (int i = dimCounter; i < dimSize(); i++) {
		    tmpSize *= dimSize(i + 1);
		}
	    } else {
		tmp += 1;
	    }
	    internalIndex += (tmp - 1) * tmpSize;
	    dimCounter++;	    
	}

	return (internalIndex + dimSize());
    }
    
    private LinkedList explodePattern(java.lang.String pattern) {
        LinkedList tmpList = new LinkedList();
	int size = 1;
        // d = digit [d] one or more times
        if (pattern.matches("[\\[\\d\\]]+")) {
            int index = 0, tmp = 0;
            while ((index = pattern.indexOf("]")) != -1) {
		tmp = new java.lang.Integer(pattern.substring(1, index)).intValue();
                tmpList.addLast(new java.lang.Integer(tmp));
		size *= tmp;
		if (tmp <= 0) {
		    throw new RuntimeException("Size of dimension in array cannot be zero or negative");
		}
		pattern = pattern.substring(index + 1);
            }
	    tmpList.addFirst(new java.lang.Integer(size));
        } else {
            // There was no match, throw error!
            if (debug) System.out.println("No match!");
            throw new RuntimeException("Invalid arguments for creating array");
        }
        return tmpList;
    }
}
