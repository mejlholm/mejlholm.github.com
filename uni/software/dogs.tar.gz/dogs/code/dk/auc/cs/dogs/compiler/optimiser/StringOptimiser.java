package dk.auc.cs.dogs.compiler.optimiser;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.optimiser.probers.*;

/**
 * StringOptimiser.java
 *
 *
 * Created: Fri Apr 30 21:35:24 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class StringOptimiser extends TypeOptimiser {

    private boolean debug = false;

    public StringOptimiser() {

    } // StringOptimiser constructor
    
    public void outAConcatinationExpr(AConcatinationExpr node){
	StringProber s = new StringProber();
	node.apply(s);
	if (s.size() > 2){
	    AUnaryPpMmConcatinationExpr aexp = optimise(s);
	    if (aexp != null){
		node.replaceBy(aexp);
	    }
	}
    }

    private AUnaryPpMmConcatinationExpr optimise(StringProber s){
	String returnString = "\"\"";
	boolean p = false;
	for (int i = 0; i < s.size(); i++) {
	    if ((i % 2) == 0) {
		if (returnString.length() > 2 && debug) {
		    System.out.print(returnString + " and " + s.getExpression(i) + " concat to ");
		    p = true;
		}
		returnString = returnString.substring(0, returnString.length() - 1) + s.getExpression(i).substring(1);
		if (p) System.out.println(returnString);
	    } else {
		if (!s.getExpression(i).equals("&")) {
		    return null;
		}
	    }
	}
	return makeString(returnString);
    }

    private AUnaryPpMmConcatinationExpr makeString(String newText){
	AUnaryPpMmConcatinationExpr aexp = new AUnaryPpMmConcatinationExpr();
	AStringPrimaryExpression fpe = new AStringPrimaryExpression(new TStringLiteral(newText));
	aexp.setPrimaryExpression(fpe);

	return aexp;
    }

} // StringOptimiser
