package dk.auc.cs.dogs.environment.types;

public interface LabelString extends LabelInterface {
}