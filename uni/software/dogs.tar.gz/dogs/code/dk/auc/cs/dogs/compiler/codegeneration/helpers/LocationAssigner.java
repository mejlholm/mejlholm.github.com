package dk.auc.cs.dogs.compiler.codegeneration.helpers;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.codegeneration.VariableMap;


/**
 * LocationAssigner.java
 *
 *
 * Created: Wed May 19 20:26:51 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class LocationAssigner extends DepthFirstAdapter {

    private VariableMap vmap;
    private int loopLevel = 0;
    private int loopCurrentLevel = 0;

    public LocationAssigner(VariableMap vmap) {
	this.vmap = vmap;
    } // LocationAssigner constructor
    
    public void inAVariableDeclaration(AVariableDeclaration node){
	vmap.enterNew(node.getName().getText());
    }

    public void inASetDeclaration(ASetDeclaration node){
	vmap.enterNew(node.getName().getText());
    }

    public void inAArrayDeclaration(AArrayDeclaration node){
	vmap.enterNew(node.getName().getText());
    }

    public void inAWeightWeightLabelDeclaration(AWeightWeightLabelDeclaration node){
	vmap.enterNew(node.getName().getText());
    }

    public void inALabelWeightLabelDeclaration(ALabelWeightLabelDeclaration node){
	vmap.enterNew(node.getName().getText());
    }



    //looping stuff....
    public void caseAForeachInDoLoopHeaders(AForeachInDoLoopHeaders node) {
    }

    public void caseAForeachInWhereDoLoopHeaders(AForeachInWhereDoLoopHeaders node) {
    }

    public void inALoopOpenCommand(ALoopOpenCommand node) {
	loopCurrentLevel++;
	if (loopLevel < loopCurrentLevel) {
	    loopLevel = loopCurrentLevel;
	}
	
    }

    public void outALoopOpenCommand(ALoopOpenCommand node) {
	loopCurrentLevel--;
    }



    public void inALoopClosedCommand(ALoopClosedCommand node) {
	loopCurrentLevel++;
	if (loopLevel < loopCurrentLevel) {
	    loopLevel = loopCurrentLevel;
	}
	
    }

    public void outAClosedOpenCommand(ALoopClosedCommand node) {
	loopCurrentLevel--;
    }




    public int size() {
	return (vmap.size() + (2 * loopLevel));
    }

} // LocationAssigner
