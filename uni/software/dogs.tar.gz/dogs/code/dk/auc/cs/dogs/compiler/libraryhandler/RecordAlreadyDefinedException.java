package dk.auc.cs.dogs.compiler.libraryhandler;

import java.lang.Exception;



/**
 * RecordAlreadyDefinedException.java
 *
 *
 * Created: Mon May 10 22:02:32 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class RecordAlreadyDefinedException extends Exception {
    public RecordAlreadyDefinedException() {
	super("Unknown Error");
    } // RecordAlreadyDefinedException constructor

    public RecordAlreadyDefinedException(String msg) {
	super(msg);
    } // RecordAlreadyDefinedException constructor

    public RecordAlreadyDefinedException(String msg, Throwable cause) {
	super(msg, cause);
    } // RecordAlreadyDefinedException constructor
    
} // RecordAlreadyDefinedException
