package dk.auc.cs.dogs.environment.types;

import java.util.LinkedList;
import java.util.Iterator;

public interface ArrayInterface extends CompositeIterable {

    public Iterator getIterator(java.lang.String type);
    public void setValue(java.lang.String pattern, Primitive value);
    public Primitive getValue(java.lang.String pattern);
    public int dimSize(long i);
    public int dimSize();
    
    
}
