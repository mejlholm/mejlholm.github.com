package dk.auc.cs.dogs.environment.types;

public abstract class Number extends Primitive implements NumberNumber {
    
    public Number() {
	super();
    }

    public abstract Type duplicate();
    public abstract java.lang.String toString();

    /***********************
     * Boolean expressions *
     ***********************/
    public final Boolean isLess(NumberNumber n) {
	Boolean result = new Boolean(false);
	if (n instanceof Integer) {
	    Integer i = (Integer)n;
	    result = this.isLess(i);
	} else if (n instanceof Float) {
	    Float f = (Float)n;
	    result = this.isLess(f);
	} else if (n instanceof Infty) {
	    Infty i = (Infty)n;
	    result = this.isLess(i);
	}
	return result;
    }
    public abstract Boolean isLess(Integer i);
    public abstract Boolean isLess(Float f);
    public abstract Boolean isLess(Infty i);

    public final Boolean isGreater(NumberNumber n) {
	Boolean result = new Boolean(false);
	if (n instanceof Integer) {
	    Integer i = (Integer)n;
	    result = this.isGreater(i);
	} else if (n instanceof Float) {
	    Float f = (Float)n;
	    result = this.isGreater(f);
	} else if (n instanceof Infty) {
	    Infty i = (Infty)n;
	    result = this.isGreater(i);
	}
	return result;
    }
    public abstract Boolean isGreater(Integer i);
    public abstract Boolean isGreater(Float f);
    public abstract Boolean isGreater(Infty i);

    public final Boolean isLessOrEqual(NumberNumber n) {
	Boolean result = new Boolean(false);
	if (n instanceof Integer) {
	    Integer i = (Integer)n;
	    result = this.isLessOrEqual(i);
	} else if (n instanceof Float) {
	    Float f = (Float)n;
	    result = this.isLessOrEqual(f);
	} else if (n instanceof Infty) {
	    Infty i = (Infty)n;
	    result = this.isLessOrEqual(i);
	}
	return result;
    }
    public abstract Boolean isLessOrEqual(Integer i);
    public abstract Boolean isLessOrEqual(Float f);
    public abstract Boolean isLessOrEqual(Infty i);

    public final Boolean isGreaterOrEqual(NumberNumber n) {
	Boolean result = new Boolean(false);
	if (n instanceof Integer) {
	    Integer i = (Integer)n;
	    result = this.isGreaterOrEqual(i);
	} else if (n instanceof Float) {
	    Float f = (Float)n;
	    result = this.isGreaterOrEqual(f);
	} else if (n instanceof Infty) {
	    Infty i = (Infty)n;
	    result = this.isGreaterOrEqual(i);
	}
	return result;
    }
    public abstract Boolean isGreaterOrEqual(Integer i);
    public abstract Boolean isGreaterOrEqual(Float f);
    public abstract Boolean isGreaterOrEqual(Infty i);

    public final Boolean isEqual(Primitive n) {
	Boolean result = new Boolean(false);
	if (n instanceof Integer) {
	    Integer i = (Integer)n;
	    result = this.isEqual(i);
	} else if (n instanceof Float) {
	    Float f = (Float)n;
	    result = this.isEqual(f);
	} else if (n instanceof Infty) {
	    Infty i = (Infty)n;
	    result = this.isEqual(i);
	} else {
	    throw new RuntimeException("Cannot compare incompatible types");
	}
	return result;
    }
    public final Boolean isEqual(NumberNumber n) {
	return isEqual((Primitive)n);
    }
    public abstract Boolean isEqual(Integer i);
    public abstract Boolean isEqual(Float f);
    public abstract Boolean isEqual(Infty i);

    public final Boolean isDifferent(NumberNumber n) {
	Boolean result = new Boolean(false);
	if (n instanceof Integer) {
	    Integer i = (Integer)n;
	    result = this.isDifferent(i);
	} else if (n instanceof Float) {
	    Float f = (Float)n;
	    result = this.isDifferent(f);
	} else if (n instanceof Infty) {
	    Infty i = (Infty)n;
	    result = this.isDifferent(i);
	}
	return result;
    }
    public abstract Boolean isDifferent(Integer i);
    public abstract Boolean isDifferent(Float f);
    public abstract Boolean isDifferent(Infty i);

    /*************************
     * Arithmetic operations *
     *************************/
    public NumberNumber modulus(NumberNumber n) {
	if (n instanceof Integer && this instanceof Integer) {
	    return ((Integer)this).modulus((Integer)n);
	} else {
	    throw new RuntimeException("Modulus only allowed for two integers");
	}
    }
    public NumberNumber integerDivision(NumberNumber n) {
	if (n instanceof Integer && this instanceof Integer) {
	    return ((Integer)this).integerDivision((Integer)n);
	} else {
	    throw new RuntimeException("Integer division only allowed for two integers");
	}
    }

    public abstract void increment();
    public abstract void decrement();

    public final NumberNumber addition(NumberNumber n) {
	NumberNumber result = null;
	if (n instanceof Integer) {
	    Integer i = (Integer)n;
	    result = this.addition(i);
	} else if (n instanceof Float) {
	    Float f = (Float)n;
	    result = this.addition(f);
	} else if (n instanceof Infty) {
	    inftyError();
	    return new Integer(0);
	}
	return result;
    }
    public abstract NumberNumber addition(Integer i);
    public abstract Float addition(Float f);

    public final NumberNumber subtraction(NumberNumber n) {
	NumberNumber result = null;
	if (n instanceof Integer) {
	    Integer i = (Integer)n;
	    result = this.subtraction(i);
	} else if (n instanceof Float) {
	    Float f = (Float)n;
	    result = this.subtraction(f);
	} else if (n instanceof Infty) {
	    inftyError();
	    return new Integer(0);
	}
	return result;
    }
    public abstract NumberNumber subtraction(Integer i);
    public abstract Float subtraction(Float f);

    public final NumberNumber multiplication(NumberNumber n) {
	NumberNumber result = null;
	if (n instanceof Integer) {
	    Integer i = (Integer)n;
	    result = this.multiplication(i);
	} else if (n instanceof Float) {
	    Float f = (Float)n;
	    result = this.multiplication(f);
	} else if (n instanceof Infty) {
	    inftyError();
	    return new Integer(0);
	}
	return result;
    }
    public abstract NumberNumber multiplication(Integer i);
    public abstract Float multiplication(Float f);

    public final NumberNumber division(NumberNumber n) {
	NumberNumber result = null;
	if (n instanceof Integer) {
	    Integer i = (Integer)n;
	    result = this.division(i);
	} else if (n instanceof Float) {
	    Float f = (Float)n;
	    result = this.division(f);
	} else if (n instanceof Infty) {
	    inftyError();
	    return new Integer(0);
	}
	return result;
    }
    public abstract Float division(Integer i);
    public abstract Float division(Float f);


    /*  */
    public abstract double getValue();
    public final java.lang.String getName() {
	return this.getClass().getName().substring(33);
    }

    private void inftyError() {
	throw new RuntimeException("Arithmetic operations not allowed on infty");
    }

}
