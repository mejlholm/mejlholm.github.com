package dk.auc.cs.dogs.environment.types;

public abstract class Composite extends Type {
    public Composite() {
	super();
    }
}
