package dk.auc.cs.dogs.compiler.optimiser;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import dk.auc.cs.dogs.compiler.node.*;

/**
 * Optimizer.java
 *
 *
 * Created: Fri Apr 30 14:16:52 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class Optimiser extends DepthFirstAdapter {
    public Optimiser() {
	super();
    } // Optimizer constructor
    
    public void caseAExpression(AExpression node){
        inAExpression(node);
        if(node.getAssignExpr() != null)
        {
	    node.apply(new StringOptimiser());
	    node.apply(new ArithmeticOptimiser());
	    node.apply(new BooleanOptimiser());
        }
        outAExpression(node);
    }

    public void caseAClosedSingleCommand(AClosedSingleCommand node)
    {
        inAClosedSingleCommand(node);
        if(node.getClosedCommand() != null)
        {
	    node.getClosedCommand().apply(this);
            node.getClosedCommand().apply(new BranchingOptimiser());
        }
        outAClosedSingleCommand(node);
    }

    public void caseAOpenSingleCommand(AOpenSingleCommand node)
    {
        inAOpenSingleCommand(node);
        if(node.getOpenCommand() != null)
        {
            node.getOpenCommand().apply(this);
            node.getOpenCommand().apply(new BranchingOptimiser());
        }
        outAOpenSingleCommand(node);
    }

} // Optimizer
