package dk.auc.cs.dogs.compiler.codegeneration;

import java.util.LinkedList;
import java.util.HashMap;

/**
 * VariableMap.java
 *
 *
 * Created: Thu May 13 16:29:42 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class VariableMap {

    private boolean debug = false;
    private HashMap variables = new HashMap();
    private LinkedList locations = new LinkedList();
    private int nextNewLocation = 0;

    public VariableMap() {

    } // VariableMap constructor

    public int getNext(){
	return nextNewLocation;
    }

    public String getVariable(int location){
	return (String)locations.get(location);
    }

    public int getLocation(String variable){
	variable = variable.trim();
	if (variables.containsKey(variable)) {
	    if (debug) System.out.println("getting location for " + variable + ": " + ((Integer)variables.get(variable)).intValue());
	    return ((Integer)variables.get(variable)).intValue();
	} else {
	    return -1;
	}
    }

    public int enterNew(String variable){
	variable = variable.trim();
	locations.add(nextNewLocation, variable);
	variables.put(variable, new Integer(nextNewLocation));
	if (debug) System.out.println(variable + " saved on location " + nextNewLocation);
	return nextNewLocation++;
    }

    // Removes the given amount from the end of the list
    public void remove(int amount) {
	int j;
	String str;
	for (int i = 0; i < amount; i++) {
	    j = locations.size() - 1;
	    str = getVariable(j);
	    if (debug) System.out.println(str + " removed from location " + j);
	    locations.removeLast();
	    variables.remove(str);
	    nextNewLocation--;
	}
    }

    public int size(){
	return locations.size();
    }
    
    void print(){
	System.out.println("Locations:");
	for (int i = 0; i < locations.size(); i++){
	    String s = (String)locations.get(i);
	    System.out.println(s + " " + variables.get(s));
	}
	System.out.println("");
    }

} // VariableMap
