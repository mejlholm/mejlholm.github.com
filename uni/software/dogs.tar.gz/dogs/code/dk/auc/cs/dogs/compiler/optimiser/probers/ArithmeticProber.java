package dk.auc.cs.dogs.compiler.optimiser.probers;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.optimiser.InftyProber;

import java.util.ArrayList;

public class ArithmeticProber extends TypeProber {

    private boolean debug = false;

    private ArrayList expressions = new ArrayList();
    private ArrayList types = new ArrayList();
    private ArrayList nodes = new ArrayList();

    public ArithmeticProber() {
	super();
    } // ArithmeticProber constructor

    public void caseAPlusPlusMinusExpr(APlusPlusMinusExpr node){
        inAPlusPlusMinusExpr(node);
        if(node.getPlusMinusExpr() != null)
	    {
		node.getPlusMinusExpr().apply(this);
	    }
        if(node.getPlus() != null)
	    {
		node.getPlus().apply(this);
		nodes.add(node);
		types.add("");
		expressions.add(node.getPlus().getText());
	    }
        if(node.getMultiplicationExpr() != null)
	    {
		node.getMultiplicationExpr().apply(this);
	    }

        outAPlusPlusMinusExpr(node);
    }

    public void caseAMinusPlusMinusExpr(AMinusPlusMinusExpr node){
        inAMinusPlusMinusExpr(node);
        if(node.getPlusMinusExpr() != null)
	    {
		node.getPlusMinusExpr().apply(this);
	    }
        if(node.getMinus() != null)
	    {
		node.getMinus().apply(this);
		nodes.add(node);
		types.add("");
		expressions.add(node.getMinus().getText());
	    }
        if(node.getMultiplicationExpr() != null)
	    {
		node.getMultiplicationExpr().apply(this);
	    }
        outAMinusPlusMinusExpr(node);
    }

    public void caseAStarMultiplicationExpr(AStarMultiplicationExpr node){
        inAStarMultiplicationExpr(node);
        if(node.getMultiplicationExpr() != null)
	    {
		node.getMultiplicationExpr().apply(this);
	    }
        if(node.getStar() != null)
	    {
		node.getStar().apply(this);
		nodes.add(node);
		types.add("");
		expressions.add(node.getStar().getText());
	    }
        if(node.getConcatinationExpr() != null)
	    {
		node.getConcatinationExpr().apply(this);
	    }

        outAStarMultiplicationExpr(node);
    }

    public void caseADivMultiplicationExpr(ADivMultiplicationExpr node)
    {
        inADivMultiplicationExpr(node);
        if(node.getMultiplicationExpr() != null)
	    {
		node.getMultiplicationExpr().apply(this);
	    }
        if(node.getDiv() != null)
	    {
		node.getDiv().apply(this);
		nodes.add(node);
		types.add("");
		expressions.add(node.getDiv().getText());
	    }
        if(node.getConcatinationExpr() != null)
	    {
		node.getConcatinationExpr().apply(this);
	    }

        outADivMultiplicationExpr(node);
    }

    public void caseAModMultiplicationExpr(AModMultiplicationExpr node)
    {
        inAModMultiplicationExpr(node);
        if(node.getMultiplicationExpr() != null)
	    {
		node.getMultiplicationExpr().apply(this);
	    }
        if(node.getMod() != null)
	    {
		node.getMod().apply(this);
		nodes.add(node);
		types.add("");
		expressions.add(node.getMod().getText());
	    }
        if(node.getConcatinationExpr() != null)
	    {
		node.getConcatinationExpr().apply(this);
	    }

        outAModMultiplicationExpr(node);
    }

    public void caseAIntDivMultiplicationExpr(AIntDivMultiplicationExpr node)
    {
        inAIntDivMultiplicationExpr(node);
        if(node.getMultiplicationExpr() != null)
	    {
		node.getMultiplicationExpr().apply(this);
	    }
        if(node.getIntDiv() != null)
	    {
		node.getIntDiv().apply(this);
		nodes.add(node);
		types.add("");
		expressions.add(node.getIntDiv().getText());
	    }
        if(node.getConcatinationExpr() != null)
	    {
		node.getConcatinationExpr().apply(this);
	    }

        outAIntDivMultiplicationExpr(node);
    }



    public void outAUnaryMinusPlusMinusExpr(AUnaryMinusPlusMinusExpr node) {
	InftyProber ip = new InftyProber();
	node.apply(ip);
	if (!ip.isInfty()) {
	    int index = expressions.size() - 1;
	    String tmp = (String)expressions.get(index);
	    if (debug) System.out.println("changing " + tmp + " to -" + tmp);
	    expressions.set(index, "-" + tmp);
	}
    }


    public void inAIntegerPrimaryExpression(AIntegerPrimaryExpression node){
	nodes.add(node);
	types.add("i");
	expressions.add(node.getIntegerLiteral().getText());
    }

    public void inAFloatPrimaryExpression(AFloatPrimaryExpression node){
	nodes.add(node);
	types.add("f");
	expressions.add(node.getFloatLiteral().getText());
    }

    
    public void caseAParPrimaryExpression(AParPrimaryExpression node){
        inAParPrimaryExpression(node);
        if(node.getLPar() != null)
        {
            node.getLPar().apply(this);
	    nodes.add(node);
	    types.add("ps");
	    expressions.add(node.getLPar().getText());
        }
        if(node.getExpression() != null)
        {
            node.getExpression().apply(this);
        }
        if(node.getRPar() != null)
        {
            node.getRPar().apply(this);
	    nodes.add(node);
	    types.add("pe");
	    expressions.add(node.getRPar().getText());
        }
        outAParPrimaryExpression(node);

    }

    public void inAExpression(AExpression node){
	cleanLists();
    }

    public void print(){
	System.out.println("Left in the list:");
	for (int i=0; i < expressions.size(); i++){
	    System.out.print("" + expressions.get(i));
	    System.out.println(" " + types.get(i));
	}
    }

    public int size(){
	return expressions.size();
    }

    public void cleanLists(){
	nodes.clear();
	expressions.clear();
	types.clear();
    }


    /**
     * Gets the value of expressions
     *
     * @return the value of expressions
     */
    public String getExpression(int i)  {
	return (String)expressions.get(i);
    }

    /**
     * Gets the value of types
     *
     * @return the value of types
     */
    public String getType(int i)  {
	return (String)types.get(i);
    }

    /**
     * Gets the value of nodes
     *
     * @return the value of nodes
     */
    public Node getNode(int i)  {
	return (Node) nodes.get(i);
    }

}
