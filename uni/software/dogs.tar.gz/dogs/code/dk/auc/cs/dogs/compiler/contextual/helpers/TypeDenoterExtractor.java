package dk.auc.cs.dogs.compiler.contextual.helpers;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.node.*;

import java.util.*;

public class TypeDenoterExtractor extends DepthFirstAdapter {

    ArrayList al = new ArrayList();

    public void inAIdentifierTypeDenoter(AIdentifierTypeDenoter node) {
	al.add(node.getIdentifier().getText());
	al.add("variable");
    }

    public void inAArrayTypeDenoter(AArrayTypeDenoter node) {
	al.add(node.getType().getText());
	al.add("array");
    }

    public void inAWeightTypeDenoter(AWeightTypeDenoter node) {
	al.add(node.getType().getText());
	al.add("weight");
    }

    public void inALabelTypeDenoter(ALabelTypeDenoter node) {
	al.add(node.getType().getText());
	al.add("label");
    }

    public void inASetTypeDenoter(ASetTypeDenoter node) {
	al.add(node.getType().getText());
	al.add("set");
    }

    public ArrayList getType() {
	return al;
    }
}
