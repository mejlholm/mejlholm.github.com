package dk.auc.cs.dogs.environment.types;

public interface ArrayInteger extends ArrayInterface {
}