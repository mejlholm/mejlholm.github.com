package dk.auc.cs.dogs.compiler.contextual;

import java.lang.Exception;

/**
 * StandardEnvironmentException.java
 *
 *
 * Created: Fri Apr 30 11:09:43 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class StandardEnvironmentException extends Exception {
    public StandardEnvironmentException() {
	super("unknown exception");
    } // StandardEnvironmentException constructor

    public StandardEnvironmentException(String msg) {
	super(msg);
    } // StandardEnvironmentException constructor

    public StandardEnvironmentException(String msg, Throwable cause) {
	super(msg, cause);
    } // StandardEnvironmentException constructor
    
} // StandardEnvironmentException
