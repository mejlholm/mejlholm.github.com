package dk.auc.cs.dogs.compiler.optimiser;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;

public abstract class TypeOptimiser extends DepthFirstAdapter{

    protected int length;

}
