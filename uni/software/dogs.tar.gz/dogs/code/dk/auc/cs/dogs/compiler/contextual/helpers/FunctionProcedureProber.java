package dk.auc.cs.dogs.compiler.contextual.helpers;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.node.*;

import java.util.*;

public class FunctionProcedureProber extends DepthFirstAdapter {

    private HashMap names = new HashMap();;
    private HashMap types = new HashMap();;
    private HashMap flags = new HashMap();;
    private HashMap returnValues = new HashMap();
    private FunctionProcedureProberFps fppfps= null;
    private TypeDenoterExtractor tde = null; 
    private boolean debug = false;

    public void caseAProcedureSingleSecondaryDeclaration(AProcedureSingleSecondaryDeclaration node) {
	ArrayList voidReturn = new ArrayList();
	fppfps = new FunctionProcedureProberFps();

	if(node.getFormalParameterSequence() != null) {
            node.getFormalParameterSequence().apply(fppfps);

	    names.put(node.getIdentifier().getText(), fppfps.getNames());
	    types.put(node.getIdentifier().getText(), fppfps.getTypes());
	    flags.put(node.getIdentifier().getText(), fppfps.getFlags());

	    if (debug) {
		System.out.println("Names: " + fppfps.getNames());
		System.out.println("Types: " + fppfps.getTypes());
		System.out.println("Flags: " + fppfps.getFlags());
	    }
        }
	// void hack
	voidReturn.add("void");
	voidReturn.add("void");
	returnValues.put(node.getIdentifier().getText(), voidReturn);
    }

    public void caseAFunctionSingleSecondaryDeclaration(AFunctionSingleSecondaryDeclaration node) {
	fppfps = new FunctionProcedureProberFps();

        if(node.getTypeDenoter() != null) {
            tde = new TypeDenoterExtractor();
	    node.getTypeDenoter().apply(tde);
	    returnValues.put(node.getIdentifier().getText(), tde.getType());
        }

	if(node.getFormalParameterSequence() != null) {
            node.getFormalParameterSequence().apply(fppfps);
	    names.put(node.getIdentifier().getText(), fppfps.getNames());
	    types.put(node.getIdentifier().getText(), fppfps.getTypes());
	    flags.put(node.getIdentifier().getText(), fppfps.getFlags());
        }
    }

    public ArrayList getNames(String procOrFuncName) throws FunctionProcedureProberException {
	if (names.containsKey(procOrFuncName)) {
	    return (ArrayList)names.get(procOrFuncName);
	} else {
	    throw new FunctionProcedureProberException("Function or Procedure not defined");
	}
    }

    public ArrayList getTypes(String procOrFuncName) throws FunctionProcedureProberException {
	if (types.containsKey(procOrFuncName)) {
	    return (ArrayList)types.get(procOrFuncName);	
	} else {
	    throw new FunctionProcedureProberException("Function or Procedure not defined");
	}
    }

    public ArrayList getFlags(String procOrFuncName) throws FunctionProcedureProberException {
	if (flags.containsKey(procOrFuncName)) {
	    return (ArrayList)flags.get(procOrFuncName);
	} else {
	    throw new FunctionProcedureProberException("Function or Procedure not defined");
	}
    }
    
    public ArrayList getReturnType(String funcName) throws FunctionProcedureProberException {
	if (returnValues.containsKey(funcName)) {
	    return (ArrayList)returnValues.get(funcName);
	} else {
	    throw new FunctionProcedureProberException("Function or Procedure not defined");
	}
    }

    public void setNames(String procOrFuncName, ArrayList data) throws FunctionProcedureProberException {
	if (!names.containsKey(procOrFuncName)) {
	    names.put(procOrFuncName, data);
	} else {
	    throw new FunctionProcedureProberException("Function or Procedure already defined");
	}
    }

    public void setTypes(String procOrFuncName, ArrayList data) throws FunctionProcedureProberException {
	if (!types.containsKey(procOrFuncName)) {
	    types.put(procOrFuncName, data);
	} else {
	    throw new FunctionProcedureProberException("Function or Procedure already defined");
	}
    }

    public void setFlags(String procOrFuncName, ArrayList data) throws FunctionProcedureProberException {
	if (!flags.containsKey(procOrFuncName)) {
	    flags.put(procOrFuncName, data);
	} else {
	    throw new FunctionProcedureProberException("Function or Procedure already defined");
	}
    }
    
    public void setReturnType(String funcName, ArrayList data) throws FunctionProcedureProberException {
	if (!returnValues.containsKey(funcName)) {
	    returnValues.put(funcName, data);
	} else {
	    throw new FunctionProcedureProberException("Function or Procedure already defined");
	}
    }

    public boolean isInTable(String funcName) {
	if (returnValues.containsKey(funcName)) {
	    return true;
	} else {
	    return false;
	}
    }
}
