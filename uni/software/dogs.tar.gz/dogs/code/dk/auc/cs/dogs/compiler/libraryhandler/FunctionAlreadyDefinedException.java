package dk.auc.cs.dogs.compiler.libraryhandler;

import java.lang.Exception;



/**
 * FunctionAlreadyDefinedException.java
 *
 *
 * Created: Mon May 10 21:57:23 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class FunctionAlreadyDefinedException extends Exception {
    public FunctionAlreadyDefinedException() {
	super("Unknown Exception");
    } // FunctionAlreadyDefinedException constructor

    public FunctionAlreadyDefinedException(String msg) {
	super(msg);
    } // FunctionAlreadyDefinedException constructor


    public FunctionAlreadyDefinedException(String msg, Throwable cause) {
	super(msg, cause);
    } // FunctionAlreadyDefinedException constructor
    


} // FunctionAlreadyDefinedException
