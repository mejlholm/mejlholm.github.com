package dk.auc.cs.dogs.environment.types;

public interface WeightInteger extends WeightInterface {
}