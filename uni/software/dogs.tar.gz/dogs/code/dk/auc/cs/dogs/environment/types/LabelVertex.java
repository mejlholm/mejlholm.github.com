package dk.auc.cs.dogs.environment.types;

public interface LabelVertex extends LabelInterface {
}