package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.contextual.helpers.*;
/**
 * This exception class is used by the identification table
 *
 */
public class IdRecordTableException extends Exception {
    
    public IdRecordTableException(){
	super("Unknown exception");
    }

    public IdRecordTableException(String msg){
	super(msg);
    }

    public IdRecordTableException(String msg, Throwable cause){
	super(msg, cause);
    }
}
