package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.node.*;

public abstract class Checker extends DepthFirstAdapter{

    public Checker(){
	super();
    }

}
