package dk.auc.cs.dogs.environment.types;

public interface SetInteger extends SetInterface {
}