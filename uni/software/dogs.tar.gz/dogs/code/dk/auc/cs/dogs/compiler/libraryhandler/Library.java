package dk.auc.cs.dogs.compiler.libraryhandler;

import dk.auc.cs.dogs.environment.*;

import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Library {

    private HashMap methods = new HashMap();//key String methodname, field ArrayList IFaces on method
    private HashMap records = new HashMap();//key String recordname, field String classname

    public Library() {
	init();
    } // Library constructor
    
    private void init(){
	try{
	    //importFilename("dk.auc.cs.dogs.environment.Io");
	    importFilename("dk.auc.cs.dogs.environment.Standard");
	    //importFilename("dk.auc.cs.dogs.environment.Graph");
	}
	catch(Exception e){
	    throw new RuntimeException("Library: Fatal error, std. environment cannot be intialised");
	}

    }

    public boolean isRecordKnown(String name){
	boolean returnValue = false;

	if (records.containsKey(name)){
	    returnValue = true;
	}

	return returnValue;
    }

    public boolean isFunctionKnown(String name){
	boolean returnValue = false;

	if (methods.containsKey(name)){
	    returnValue = true;
	}
	return returnValue;
    }

    public String getPackageNameFromFunctionname(String name) {
	return ((IFace)methods.get(name)).getPackageName();
    }

    public IFace getInterfaceFromFunctionname(String name){
	//	if (debug)System.out.println("getting interface: " + (IFace)methods.get(name));
	return (IFace)methods.get(name);
    }

    public ArrayList getInterfacesFromFilename(String name){
	ArrayList al = new ArrayList();

	try{
	    al = getDetails(load(name));
	} catch (ClassFileNotKnownException e){
	    return null;
	}
	
	return al;
    }

    public boolean importFilename(String filename) throws RecordAlreadyDefinedException, FunctionAlreadyDefinedException, ClassFileNotKnownException {
	boolean succesful = true;
	ArrayList al = getDetails(load(filename));

	//if record
	String type = (String)al.get(0);
	if (type.equals("Record")){
	    IFace tmp = (IFace)al.get(1);
	    int where = tmp.getName().lastIndexOf(".") +1;
	    String lastPart = tmp.getName().substring(where);
	    
	    if (records.containsKey(lastPart)){
		throw new RecordAlreadyDefinedException("Library: Recordname<" + lastPart + "> is already defined");
	    }
		
	    records.put(lastPart, tmp.getPackageName());
	} else {
	    //if function 
	    if (type.equals("Function")){
		for (int i = 1; i < al.size(); i++){
		    
		    IFace tmp = (IFace)al.get(i);
		    
		    if (methods.containsKey(tmp.getName())){
			throw new FunctionAlreadyDefinedException("Library: Functionname<" + 
								  tmp.getName() + "> is already defined");
		    }
		    //		    System.out.println("adding " + tmp.getName());
		    methods.put(tmp.getName(), tmp);
		}		
	    } else {
		//		    System.out.println("Unknown Error");
		throw new RuntimeException("Unknown Error in Library");
	    }
	}
	return succesful;
    }

    private String getPackageName(Class c) {
	String n = c.getName();
	return n;
    }

    private ArrayList getDetails(Class c){
	ArrayList al = new ArrayList();

	Method[] m = c.getDeclaredMethods();
	//System.out.println(m.length);
	if (m.length < 1){
	    al.add("Record");

	    IFace ifa = new IFace();

	    ifa.setName(c.getName());
      	    ifa.setPackageName(getPackageName(c));

	    ifa.setReturnValue("None");

	    ArrayList a = new ArrayList();
	    a.add("None");
	    ifa.setFormalParameterSequence(a);
	    al.add(ifa);


	} else {
	    al.add("Function");

	    for (int i = 0; i < m.length; i++){
		IFace ifa = new IFace();
		ifa.setPackageName(getPackageName(c));
		ifa.setName(m[i].getName());
		ifa.setReturnValue(m[i].getReturnType().getName());

		ArrayList a = new ArrayList();
		Class[] cl = m[i].getParameterTypes();
		for (int j = 0; j < cl.length; j++){
		    a.add(cl[j].getName());
		}
		ifa.setFormalParameterSequence(a);
		
		
		al.add(ifa);//arraylist with IFaces	}
	    }	    
	}

	return al;
    }

    private Class load(String className) throws ClassFileNotKnownException{
	ClassLoader cl = this.getClass().getClassLoader();
	Class c = null;
	try{
	    c = cl.loadClass(className);
	} catch (Exception e){
	    throw new ClassFileNotKnownException("Library: Class file<" + className + "> not known");
	}
	return c;
    }

    private void printFunctionsInClassfile(String fileName){
	ArrayList al = new ArrayList();
	al = getInterfacesFromFilename(fileName);
	if (al != null && al.size() > 2){
	    System.out.println("Package:\t\t\tMethod:\t\tFPS:\t\t\tReturnValue:");
	    for (int i = 1; i < al.size(); i++){//0 is type indicator
		IFace ifa = (IFace)al.get(i);
		System.out.println(ifa.toString());
	    }
	} else {
	    System.out.println("Unknown filename or record file");
	}
    }

} // Library

