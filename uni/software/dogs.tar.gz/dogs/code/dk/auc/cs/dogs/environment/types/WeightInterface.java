package dk.auc.cs.dogs.environment.types;

public interface WeightInterface {

    public Primitive getWeight(Edge e);
    public GraphComposite getGraph();
    public void setWeight(Edge e, Primitive weight);
    public void notifyAdd(Vertex v);
    public void notifyRemove(Vertex v);
    public void notifyRemove(Edge e);
    public void notifyAdd(Edge e);
}