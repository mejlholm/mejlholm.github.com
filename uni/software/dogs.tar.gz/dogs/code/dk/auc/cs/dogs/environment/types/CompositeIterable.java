package dk.auc.cs.dogs.environment.types;

import java.util.*;

public interface CompositeIterable {
    public Iterator getIterator(java.lang.String type);
}
