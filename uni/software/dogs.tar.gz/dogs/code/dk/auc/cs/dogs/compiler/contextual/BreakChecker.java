package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.node.*;

public class BreakChecker extends Checker{

    private int level = 0;

    //empty default constructor
    public BreakChecker(){
	super();
    }

    private void inLoop(Node node) {
	level++;
    }

    private void outLoop(Node node) {
	level--;
    }

    public void inALoopClosedCommand(ALoopClosedCommand node){
	inLoop(node);
    }

    public void outALoopClosedCommand(ALoopClosedCommand node){
	outLoop(node);
    }

    public void inALoopOpenCommand(ALoopOpenCommand node){
	inLoop(node);
    }

    public void outALoopOpenCommand(ALoopOpenCommand node){
	outLoop(node);
    }

    public void inAWhileDoOpenCommand(AWhileDoOpenCommand node)
    {
        inLoop(node);
    }

    public void outAWhileDoOpenCommand(AWhileDoOpenCommand node)
    {
        outLoop(node);
    }

    public void inADoWhileOpenCommand(ADoWhileOpenCommand node)
    {
        inLoop(node);
    }

    public void outADoWhileOpenCommand(ADoWhileOpenCommand node)
    {
        outLoop(node);
    }

    public void inAWhileDoClosedCommand(AWhileDoClosedCommand node)
    {
        inLoop(node);
    }

    public void outAWhileDoClosedCommand(AWhileDoClosedCommand node)
    {
        outLoop(node);
    }

    public void inADoWhileClosedCommand(ADoWhileClosedCommand node)
    {
        inLoop(node);
    }

    public void outADoWhileClosedCommand(ADoWhileClosedCommand node)
    {
        outLoop(node);
    }


    public void caseABreakBasicCommands(ABreakBasicCommands node) {
        if (level < 1){
	    ErrorList.add(node.getBreak(), "break placed illegal");
	} else{
	    inABreakBasicCommands(node);
	    if(node.getBreak() != null)
		{
		    node.getBreak().apply(this);
		}
	    if(node.getSemicolon() != null)
		{
		    node.getSemicolon().apply(this);
		}
	    outABreakBasicCommands(node);
	}
    }


}
