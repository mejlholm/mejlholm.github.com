package dk.auc.cs.dogs.environment.types;

public abstract class Record extends Type {

    public Record() {
	super();
    }
}
