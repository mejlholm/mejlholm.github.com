package dk.auc.cs.dogs.compiler.codegeneration;

import dk.auc.cs.dogs.compiler.codegeneration.StatementEncoder;
import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.libraryhandler.Library;

import java.util.LinkedList;

/**
 * BranchingEncoder.java
 *
 *
 * Created: Mon May 17 16:55:41 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public abstract class BranchingEncoder extends StatementEncoder {

    private int branchLabelCounter = 1;
    private LinkedList branchLabels = new LinkedList();
    private LinkedList elseIfLabels = new LinkedList();
    private int elseIfCounter = 1;

    public BranchingEncoder(Library lib, StandardEnvironment std, String sourcefile, String objectfile, IdentificationTableRecord idRecord, FunctionProcedureProber prober,  IdentitiesAndTypesTable idTypeTable) {
	super(lib, std, sourcefile, objectfile, idRecord, prober, idTypeTable);
    } // BranchingEncoder constructor

    public final void caseAIfOpenElseClosedCommand(AIfOpenElseClosedCommand node) {
	cw.addIndentScope();
	makeBranchLabel();
	makeIfElseLabel();
	cw.codePrintln("; If-else (closed) starting");
        inAIfOpenElseClosedCommand(node);
        if(node.getExpression() != null) {
	    assign = true;
            node.getExpression().apply(this);
	    assign = false;
 	    boolEval();
	    cw.codePrintln("ifeq " + topBranchLabel());
        }
        if(node.getTrue() != null) {
	    // Executing command
            node.getTrue().apply(this);
	    cw.codePrintln("goto " + topIfElseLabel());
        }
	popBranchLabel();
        if(node.getFalse() != null) {
	    // Executing command
            node.getFalse().apply(this);
        }
        outAIfOpenElseClosedCommand(node);
	popIfElseLabel();
	cw.codePrintln("; If-else (closed) ended");
	cw.removeIndentScope();
    }


    public final void caseAIfElseOpenCommand(AIfElseOpenCommand node) {
	cw.addIndentScope();
	makeBranchLabel();
	makeIfElseLabel();
	cw.codePrintln("; If-else (open) starting");
	inAIfElseOpenCommand(node);
        if (node.getExpression() != null) {
	    assign = true;
            node.getExpression().apply(this);
	    assign = false;
 	    boolEval();
	    cw.codePrintln("ifeq " + topBranchLabel());
       }
        if (node.getClosedCommand() != null) {
            node.getClosedCommand().apply(this);
	    cw.codePrintln("goto " + topIfElseLabel());
        }
	popBranchLabel();
        if (node.getOpenCommand() != null) {
            node.getOpenCommand().apply(this);
        }
        outAIfElseOpenCommand(node);
	popIfElseLabel();
	cw.codePrintln("; If-else (open) ended");
	cw.removeIndentScope();
    }


    public final void caseAIfThenOpenCommand(AIfThenOpenCommand node) {
	cw.addIndentScope();
	makeBranchLabel();
	cw.codePrintln("; If-then (open) starting");
        inAIfThenOpenCommand(node);
        if(node.getExpression() != null) {
	    assign = true;
	    node.getExpression().apply(this);
	    assign = false;
	    boolEval();
	    cw.codePrintln("ifeq " + topBranchLabel());
	}
        if(node.getSingleCommand() != null) {
            node.getSingleCommand().apply(this);
        }
        outAIfThenOpenCommand(node);
	cw.codePrintln("; If-then (open) ended");
	popBranchLabel();
	cw.removeIndentScope();
    }


       public void caseASwitchBasicCommands(ASwitchBasicCommands node) {
	   System.err.println("Unfortunately the switch-statement has not yet been implemented");
	   throw new RuntimeException("Statement not implemented");
       }

//     public final void caseASwitchBasicCommands(ASwitchBasicCommands node) {
// 	cw.addIndentScope();
// 	makeBranchLabel();
// 	cw.codePrintln("; Switch starting");
//         inASwitchBasicCommands(node);
	
// 	int varLocation = vmap.getLocation(node.getVName().toString());
// 	System.out.println(node.getVName() + " - " + varLocation);

//         {
//             Object temp[] = node.getCaseItem().toArray();
//             for(int i = 0; i < temp.length; i++) {
// 		cw.codePrintln("; Evaulating " + ((PCaseItem) temp[i]).toString());
//                 ((PCaseItem) temp[i]).apply(this);
		
//             }
//         }
//         if(node.getDefaultItem() != null) {
//             node.getDefaultItem().apply(this);
//         }
// 	node.getEndswitch().apply(this);
//         outASwitchBasicCommands(node);
// 	cw.codePrintln("; Switch ended");
// 	popBranchLabel();
// 	cw.removeIndentScope();
//     }

//     public final void caseASingleCaseItem(ASingleCaseItem node) {
// 	cw.addIndentScope();
// 	cw.codePrintln("; Case item");
//         inASingleCaseItem(node);
//         if(node.getCase() != null) {
//             node.getCase().apply(this);
//         }
//         if(node.getIntegerLiteral() != null) {
//             node.getIntegerLiteral().apply(this);
//         }
//         if(node.getColon() != null) {
//             node.getColon().apply(this);
//         }
//         if(node.getSingleCommand() != null) {
//             node.getSingleCommand().apply(this);
//         }
//         outASingleCaseItem(node);
// 	cw.removeIndentScope();
//     }

//     public void caseARangeCaseItem(ARangeCaseItem node) {
// 	cw.addIndentScope();
// 	cw.codePrintln("; Case range item");
//         inARangeCaseItem(node);
//         if(node.getCase() != null) {
//             node.getCase().apply(this);
//         }
//         if(node.getFrom() != null) {
//             node.getFrom().apply(this);
//         }
//         if(node.getRange() != null) {
//             node.getRange().apply(this);
//         }
//         if(node.getTo() != null) {
//             node.getTo().apply(this);
//         }
//         if(node.getColon() != null) {
//             node.getColon().apply(this);
//         }
//         if(node.getSingleCommand() != null) {
//             node.getSingleCommand().apply(this);
//         }
//         outARangeCaseItem(node);
// 	cw.removeIndentScope();
//     }

//     public final void caseACaseDefaultItem(ACaseDefaultItem node) {
// 	cw.addIndentScope();
// 	cw.codePrintln("; Case default item");
//         inACaseDefaultItem(node);
//         if(node.getDefault() != null) {
//             node.getDefault().apply(this);
//         }
//         if(node.getColon() != null) {
//             node.getColon().apply(this);
//         }
//         if(node.getSingleCommand() != null) {
//             node.getSingleCommand().apply(this);
//         }
//         outACaseDefaultItem(node);
// 	cw.removeIndentScope();
//     }


    private String topBranchLabel() {
	int i = branchLabels.size() - 1;
	String str = (String)branchLabels.get(i);
	return str;
    }

    private String popBranchLabel() {
	int i = branchLabels.size() - 1;
	String str = (String)branchLabels.get(i);
	branchLabels.remove(i);
	cw.codePrintln(str + ":");
	return str;
    }

    private String makeBranchLabel() {
	String str = "BRANCHLABEL" + branchLabelCounter++;
	branchLabels.add(str);
	return str;
    }

    private String topIfElseLabel() {
	int i = elseIfLabels.size() - 1;
	String str = (String)elseIfLabels.get(i);
	return str;
    }

    private String popIfElseLabel() {
	int i = elseIfLabels.size() - 1;
	String str = (String)elseIfLabels.get(i);
	elseIfLabels.remove(i);
	cw.codePrintln(str + ":");
	return str;
    }

    private String makeIfElseLabel() {
	String str = "IFELSELABEL" + elseIfCounter++;
	elseIfLabels.add(str);
	return str;
    }

} // BranchingEncoder
