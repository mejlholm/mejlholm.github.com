package dk.auc.cs.dogs.environment.types;

/**
 * FloatNumber.java
 *
 *
 * Created: Sat May 22 17:05:52 2004
 *
 * @author <a href="mailto:volstrup@homer.cs.auc.dk">Jacob Volstrup Pedersen</a>
 * @version 1.0
 */

public interface FloatNumber extends NumberNumber{

    public Type duplicate();
    public java.lang.String toString();

    public IntegerNumber round();

 //    /*
//       BOOLEAN EXPRESSIONS
//     */

//     public Boolean isLess(Number n);
//     public Boolean isGreater(Number n);
//     public Boolean isLessOrEqual(Number n);
//     public Boolean isGreaterOrEqual(Number n);
//     public Boolean isEqual(Number n);
//     public Boolean isDifferent(Number n);

//     /*
//       ARITHMETIC OPERATIONS
//     */

//     public void increment();
//     public void decrement();

//     public Number modulus(Number n);
//     public Number integerDivision(Number n);

//     public Number addition(Number n);
//     public Number subtraction(Number n);
//     public Number multiplication(Number n);
//     public Number division(Number n);

//     public double getValue();
//     public java.lang.String getName();


}// FloatNumber
