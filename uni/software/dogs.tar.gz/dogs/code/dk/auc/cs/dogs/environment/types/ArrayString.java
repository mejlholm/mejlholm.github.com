package dk.auc.cs.dogs.environment.types;

public interface ArrayString extends ArrayInterface{
}