package dk.auc.cs.dogs.environment.types;

public interface LabelInterface {

    public Primitive getLabel(Vertex v);
    public GraphComposite getGraph();
    public void setLabel(Vertex v, Primitive label);
    public void notifyRemove(Vertex v);
    public void notifyAdd(Vertex v);
}