package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;

import java.util.*;

public class IdentificationTableRecord {

    private HashMap records = new HashMap();
    private HashMap elements = new HashMap();
    private boolean constant = false;
    private ArrayList recordNames = new ArrayList();
    private RecordTableElement rte = null;

    public IdentificationTableRecord() {

    }

    public void insert(String element, Node node, boolean constant) throws IdRecordTableException {
	if (!elements.containsKey(element)) {
	    elements.put(element, new RecordTableElement(node, constant));
	} else {
	    throw new IdRecordTableException("Duplicate element in record");
	}
    }

    public void saveRecord(String record) throws IdRecordTableException {
	if (!records.containsKey(record)) {
	    records.put(record, elements);
	    recordNames.add(record);
	    elements = new HashMap();
	} else {
	    throw new IdRecordTableException("Duplicate record declaration");
	}
    }

    public void loadRecord(String record) throws IdRecordTableException {
	if (records.containsKey(record)) {
	    elements = (HashMap)records.get(record);
	} else {
	    throw new IdRecordTableException("No such record in table");
	}
    }

    public Node retrieve(String element) throws IdRecordTableException {
	if (elements.containsKey(element)) {
	    rte = (RecordTableElement)elements.get(element);
	    constant = rte.getConstant();
	    return rte.getNode();
	} else {
	    throw new IdRecordTableException("No such element in the record");
	}
    }

    public ArrayList retrieveKeys(String record) throws IdRecordTableException {
	Set keys = null;
	ArrayList al = new ArrayList();
	Iterator it = null;
	loadRecord(record);
	keys = elements.keySet();
	it = keys.iterator();
	while (it.hasNext()) {

	    //System.out.println((String)it.next());

	    al.add(it.next());
	}
	return al;
    }

    public void remove(String record) throws IdRecordTableException {
	if (records.containsKey(record)) {
	    records.remove(record);
	} else {
	    throw new IdRecordTableException("No such record in table");
	}
    }

    public boolean isInTable(String recordName) {
	if (records.containsKey(recordName)) {
	    return true;
	} else {
	    return false;
	}
    }
    
    public ArrayList getRecordNames() {
	return recordNames;
    }
    
    public boolean isEmpty() {
	return records.isEmpty();
    }
    
    public boolean isAConstant() {
	return constant;
    }
}
