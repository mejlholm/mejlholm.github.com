package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;

import java.util.*;

public class RecordTableElement {

    private Node node = null;
    private boolean constant;;

    public RecordTableElement(Node node, boolean constant) {
	this.node = node;
	this.constant = constant;
    }

    public Node getNode() {
	return node;
    }

    public boolean getConstant() {
	return constant;
    }
}
