package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.node.*;
import java.util.*;

public class IdentitiesAndTypesTableElements {

    private String type;
    private String flag;
    private String castType;
    private boolean constant;
    private Node node;
    
    public IdentitiesAndTypesTableElements(String type, String flag, boolean constant, Node node, String castType) {
	this.type = type;
	this.flag = flag;
	this.constant = constant;
	this.node = node;
	this.castType = castType;
    }

    public String getType() {
	return type;
    }

    public String getFlag() {
	return flag;
    }

    public boolean isConstant() {
	return constant;
    }

    public Node getNode() {
	return node;
    }

    public String getCastType() {
	return castType;
    }
}
