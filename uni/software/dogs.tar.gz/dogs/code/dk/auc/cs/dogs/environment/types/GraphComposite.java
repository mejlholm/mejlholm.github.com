package dk.auc.cs.dogs.environment.types;

import java.util.Iterator;

public abstract class GraphComposite extends Composite {

    public GraphComposite() {
	super();
    }

    public abstract boolean isEdge(Vertex v1, Vertex v2);
    public abstract boolean isEdge(int i1, int i2);
    public abstract int getIndex(Vertex v);
    public abstract void removeEdge(Vertex v1, Vertex v2);
    public abstract void removeEdge(Edge e);
    public abstract void addLabel(LabelInterface l);
    public abstract void addWeight(WeightInterface w);
    public abstract void removeVertex(Vertex v);
    public abstract void removeVertex(java.lang.String name);
    public abstract Set getAdjacents(Vertex v);
    public abstract boolean addEdge(Vertex v1, Vertex v2);
    public abstract boolean addEdge(Edge e);
    public abstract boolean hasEdge(Vertex v1, Vertex v2);
    public abstract Edge getEdge(Vertex v1, Vertex v2);
    public abstract Set getVertices();
    public abstract Iterator getVertexIterator();
    public abstract Iterator getEdgeIterator();
    public abstract Set getEdges();
    public abstract Set getEdges(Vertex v);
    public abstract Set getEdges(String name);
    public abstract Set getEdges(java.lang.String name);
    public abstract Vertex addVertex(String name);
    public abstract Vertex addVertex(java.lang.String name);
    public abstract Vertex getVertex(String name);
    public abstract Vertex getVertex(java.lang.String name);
}
