package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.node.*;
import java.util.*;

/**
 * This class is used to represent the identification table used in the
 * Contextual Analysis. It contains mettods for creating a new table and
 * manipulating these.
 *  
 */
public class IdentificationTable {
    
    private LinkedList levelTable;
    private HashMap levelMap;
    private ArrayList info;
    private boolean isConstant;
    private IdentitiesAndTypesTable idTypeTable;
    private String type;
    private String flag;

    /**
     * Constructor for the identification table. 
     *
     */
    public IdentificationTable(IdentitiesAndTypesTable idatt) {
	levelTable = new LinkedList();
	isConstant = false;
	idTypeTable = idatt;
        idTypeTable.openScope();
	openScope();
    }

    /**
     * Inserting a new identification into the table in the current level.
     * 
     * @param id a <code>String</code> value
     * @param attr a <code>Node</code> value
     */
    public void enter(String id, Node attr, boolean constant) throws IdTableException {
	
	info = new ArrayList();
	info.add(attr);
	info.add(new Boolean(constant));

	if (getIdentifier(id) == null) {
	    levelMap.put(id, info);
	    
	    // put in table later used under codegeneration
	    try {
		idTypeTable.enter(id, findNodeType(attr), flag, constant, attr);
		flag = null;
	    } catch (IdentitiesAndTypesTableException ex) {
		throw new IdTableException(ex.getMessage());
	    }
	} else {
	    throw new IdTableException("Duplicated entry of variable");
	}

    }
    
    /**
     * Returns an attribute from the identification table in relation to the id
     * 
     * @param id a <code>String</code> value
     * @return a <code>Node</code> value
     */
    public Node retrieve(String id) throws IdTableException {
	Node node = null;

	node = getIdentifier(id);

	if (node != null) {
	    return node;
	} else {
	    throw new IdTableException("No such variable name");
	}
    }

    private Node getIdentifier(String id) {
	HashMap lm = levelMap;
	Node node = null;

	for (int i = levelTable.size() - 1; i >= 0; i--) {
	    lm = (HashMap) levelTable.get(i);
	    if (lm.containsKey(id)) {
		info = (ArrayList)lm.get(id);
		node = (Node)info.get(0);
		isConstant = ((Boolean)info.get(1)).booleanValue();
		break;
	    }
	}

	return node;
    }

    /**
     * Checke if there are a variable in the table in relation to the
     * key
     *
     * @param id a <code>String</code> value
     * @return a <code>boolean</code> value
     */
    public boolean isInTable(String id) {
	HashMap lm = levelMap;
	Node node = null;

	for (int i = levelTable.size() - 1; i >= 0; i--) {
	    lm = (HashMap) levelTable.get(i);
	    if (lm.containsKey(id)) {
		node = (Node)((ArrayList)lm.get(id)).get(0);
		break;
	    }
	}
	
	if (node != null) {
	    return true;
	} else {
	    return false;
	}
    }
    
    /**
     * Check if the last variable retrieved from the identification
     * table was a contanst variable
     *
     * @return a <code>boolean</code> value
     */
    public boolean isConstant() {
	return isConstant;
    }

    /**
     * Adds a new level to the table and update the other metodes to work on
     * this level
     *  
     */
    public void openScope() {
	levelMap = new HashMap();
	levelTable.add(levelMap);
    }
    
    /**
     * Removes the current level from the table and makes the other methods
     * work on the new current level
     *  
     */
    public void closeScope() throws IdTableException {
	if (levelTable.size() != 0) {
	    levelTable.removeLast();
	    levelMap = (HashMap) levelTable.getLast();
	} else {
	    throw new IdTableException("Scope index out of bound");
	}
    }

    private String findNodeType(Node typeNode) {
	String castType = null;
	
	castType = typeNode.getClass().getName().substring(29);
	if (castType.equals("AVariableDeclaration")) {
	    type = ((AVariableDeclaration)typeNode).getType().getText();
	    flag = "variable";
	} else if (castType.equals("AArrayDeclaration")) {
	    type = ((AArrayDeclaration)typeNode).getType().getText();
	    flag = "array";
	} else if (castType.equals("ASetDeclaration")) {
	    type = ((ASetDeclaration)typeNode).getType().getText();
	    flag = "set";
	} else if (castType.equals("AWeightWeightLabelDeclaration")) {
	    type = ((AWeightWeightLabelDeclaration)typeNode).getType().getText();
	    flag = "weight";
	} else if (castType.equals("ALabelWeightLabelDeclaration")) {
	    type = ((ALabelWeightLabelDeclaration)typeNode).getType().getText();
	    flag = "label";
	} else if (castType.equals("ARecordDeclaration")) {
	    type = ((ARecordDeclaration)typeNode).getType().getText();
	    flag = "record";
	} else if (castType.equals("AIdentifierTypeDenoter")) {
	    type = ((AIdentifierTypeDenoter)typeNode).getIdentifier().getText();
	    flag = "variable";
	} else if (castType.equals("AArrayTypeDenoter")) {
	    type = ((AArrayTypeDenoter)typeNode).getType().getText();
	    flag = "array";
	} else if (castType.equals("AWeightTypeDenoter")) {
	    type = ((AWeightTypeDenoter)typeNode).getType().getText();
	    flag = "weight";
	} else if (castType.equals("ALabelTypeDenoter")) {
	    type = ((ALabelTypeDenoter)typeNode).getType().getText();
	    flag = "label";
	} else if (castType.equals("AForToLoopHeaders")) {
	    type = "integer";
	    flag = "variable";
	} else if (castType.equals("ASetTypeDenoter")) {
	    type = ((ASetTypeDenoter)typeNode).getType().getText();
	    flag = "set";
	} else {
	    
	}
	return type;
    }
}
