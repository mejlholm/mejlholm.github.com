package dk.auc.cs.dogs.compiler.contextual.helpers;

import dk.auc.cs.dogs.compiler.contextual.*;
/**
 * This exception class is used by the Function/Procedure prober
 *
 */
public class FunctionProcedureProberException extends Exception {
    
    public FunctionProcedureProberException(){
	super("Unknown exception");
    }

    public FunctionProcedureProberException(String msg){
	super(msg);
    }

    public FunctionProcedureProberException(String msg, Throwable cause){
	super(msg, cause);
    }
}
