package dk.auc.cs.dogs.environment.types;

public class String extends Primitive {
    
    private java.lang.String value;

    public String(java.lang.String str) {
	super();
	value = str;
    }

    public java.lang.String toString() {
	return value;
    }

    public Type duplicate() {
	return new String(value);
    }

    public boolean equals(java.lang.String str) {
	return str.equals(value);
    }

    public int length() {
	return value.length();
    }

    public void setValue(java.lang.String str) {
	value = str;
    }

    public java.lang.String getValue() {
	return value;
    }

    public boolean isEqual(String s) {
	return getValue().equals(s.getValue());
    }

    public String append(String s) {
	java.lang.String ret = value + s.getValue();
	return new String(ret);
    }
}
