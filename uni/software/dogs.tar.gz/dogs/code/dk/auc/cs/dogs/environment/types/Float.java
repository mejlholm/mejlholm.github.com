package dk.auc.cs.dogs.environment.types;

public class Float extends Reading implements FloatNumber {
    
    private double value;

    public Float(double f) {
	super();
	value = f;
    }

    public java.lang.String toString() {
	return "" + value;
    }

    public IntegerNumber round() {
	return new Integer((long)value);
    }

    public Type duplicate() {
	return new Float(value);
    }

    /*************************
     * Arithmetic operations *
     *************************/

    public void increment() {
	value = value + 1;
    }

    public void decrement() {
	value = value - 1;
    }

    public NumberNumber addition(Integer i) {
	return new Float(value + i.getValue());
    }

    public Float addition(Float f) {
	return new Float(value + f.getValue());
    }

    public NumberNumber subtraction(Integer i) {
	return new Float(value - i.getValue());
    }

    public Float subtraction(Float f) {
	return new Float(value - f.getValue());
    }

    public NumberNumber multiplication(Integer i) {
	return new Float(value * i.getValue());
    }

    public Float multiplication(Float f) {
	return new Float(value * f.getValue());
    }

    public Float division(Integer i) {
	return new Float(value / i.getValue());
    }

    public Float division(Float f) {
	return new Float(value / f.getValue());
    }


    /*  */
    public double getValue() {
	return value;
    }
}
