package dk.auc.cs.dogs.compiler.codegeneration;

import dk.auc.cs.dogs.compiler.codegeneration.Encoder;
import dk.auc.cs.dogs.compiler.codegeneration.helpers.*;
import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.libraryhandler.Library;

import java.util.ArrayList;

/**
 * DeclarationEncoder.java
 *
 *
 * Created: Mon May 17 16:59:55 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public abstract class DeclarationEncoder extends ExpressionEncoder {

    private boolean debug = false;

    public DeclarationEncoder(Library lib, StandardEnvironment std, String sourcefile, String objectfile, IdentificationTableRecord idRecord, FunctionProcedureProber prober, IdentitiesAndTypesTable idTypeTable) {
	super(lib, std, sourcefile, objectfile, idRecord, prober, idTypeTable);
    } // DeclarationEncoder constructor


    public final void outAVariableDeclaration(AVariableDeclaration node){
	String type = node.getType().toString().trim();
	if (type.equals("graph")) {
	    cw.codePrintln("; " + node);
	    cw.codePrintln("new dk/auc/cs/dogs/environment/types/Graph");
	    cw.codePrintln("dup");
	    cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Graph/<init>()V");
	    cw.codePrintln("astore " + vmap.getLocation(node.getName().toString()));
	} else if (((ASetArrayVarSingleDeclaration)((AVariableSavHelpDeclarations)node.parent()).parent()).getDeclarationAssignment() != null) {
	    cw.codePrintln("astore " + vmap.getLocation(node.getName().getText()) + "\n");
	}
    }

    public final void outASetDeclaration(ASetDeclaration node){
	Node par = ((ASetArrayVarSingleDeclaration)((ASetSavHelpDeclarations)node.parent()).parent()).getDeclarationAssignment();
	if(debug)cw.codePrintln(";" + node);
	cw.codePrintln("new dk/auc/cs/dogs/environment/types/Set");
	cw.codePrintln("dup");
	cw.codePrintln("ldc \"" + upperify(node.getType().getText().trim()) + "\"");
	if (par != null){
	    //cw.codePrintln("ldc \"" + arrayify(par.toString()) + "\"");
	    //cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Set/<init>(Ljava/lang/String;Ljava/lang/String;)V\n");
	} //else{
	//}
	cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Set/<init>(Ljava/lang/String;)V\n");
	cw.codePrintln("astore " + vmap.getLocation(node.getName().getText()));	
    }

    
    public final void outAArrayDeclaration(AArrayDeclaration node){
	if(node.getArraySizeDenoter() != null){
	    cw.codePrintln("new dk/auc/cs/dogs/environment/types/Array");
	    cw.codePrintln("dup");
	    cw.codePrintln("ldc \"" + upperify(node.getType().getText().trim()) + "\"");

	    String size = node.getArraySizeDenoter().toString().replaceAll(" ", "");;
	    cw.codePrintln("ldc \""+ size +  "\"");//FIXME
	    cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Array/<init>(Ljava/lang/String;Ljava/lang/String;)V");
	} else {
	    cw.codePrintln("aconst_null");
	}
	
	cw.codePrintln("astore " + vmap.getLocation(node.getName().getText()));	
    }

    public final void caseAWeightWeightLabelDeclaration(AWeightWeightLabelDeclaration node) {
	addWeight(node.getName().toString(), makeType(node.getType().toString()));
	//	System.out.println(node.getName().toString() + " declared as weight");
	cw.codePrintln("; Declaration of weight");
        inAWeightWeightLabelDeclaration(node);
	
	cw.codePrintln("new dk/auc/cs/dogs/environment/types/Weight");
	cw.codePrintln("dup");
	cw.codePrintln("ldc \"" + makeType(node.getType().toString()) + "\"");
	cw.codePrintln("; Loading graph for weight");
	cw.codePrintln("aload " + vmap.getLocation(node.getGraph().toString()));
	//cw.println("");
	cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Weight/<init>(Ljava/lang/String;Ldk/auc/cs/dogs/environment/types/GraphComposite;)V");
        cw.codePrintln("astore " + vmap.getLocation(node.getName().toString()));
        outAWeightWeightLabelDeclaration(node);

    }


    public void caseALabelWeightLabelDeclaration(ALabelWeightLabelDeclaration node) {
	addLabel(node.getName().toString(), makeType(node.getType().toString()));
	//	System.out.println(node.getName().toString() + " declared as label");
	cw.codePrintln("; Declaration of label");
        inALabelWeightLabelDeclaration(node);

	cw.codePrintln("new dk/auc/cs/dogs/environment/types/Label");
	cw.codePrintln("dup");
	cw.codePrintln("ldc \"" + makeType(node.getType().toString()) + "\"");
	cw.codePrintln("; Loading graph for label");
	cw.codePrintln("aload " + vmap.getLocation(node.getGraph().toString()));
	//cw.println("");
	cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Label/<init>(Ljava/lang/String;Ldk/auc/cs/dogs/environment/types/GraphComposite;)V");
        cw.codePrintln("astore " + vmap.getLocation(node.getName().toString()));

        outALabelWeightLabelDeclaration(node);
    }


    //flips the normal evaluation order of a declaration, that all ;-)
    public final void caseAConstSingleDeclarationConstType(AConstSingleDeclarationConstType node){
        inAConstSingleDeclarationConstType(node);
	if(debug) cw.codePrintln(";constant");
        if(node.getDeclarationAssignment() != null)
        {
            node.getDeclarationAssignment().apply(this);
        }
        if(node.getConstDeclaration() != null)
        {
            node.getConstDeclaration().apply(this);
        }
        if(node.getSemicolon() != null)
        {
            node.getSemicolon().apply(this);
        }
        outAConstSingleDeclarationConstType(node);
	}

    //flips the normal evaluation order of a declaration, that all ;-)
    public final void caseASetArrayVarSingleDeclaration(ASetArrayVarSingleDeclaration node){
	inASetArrayVarSingleDeclaration(node);
	if (!(node.getSavHelpDeclarations().getClass().getName().substring(29).equals("ASetSavHelpDeclarations") || 
	    node.getSavHelpDeclarations().getClass().getName().substring(29).equals("AArraySavHelpDeclarations"))){
	    if(node.getDeclarationAssignment() != null) {
		node.getDeclarationAssignment().apply(this);
	    } else {
		AVariableDeclaration n = ((AVariableDeclaration)((AVariableSavHelpDeclarations)node.getSavHelpDeclarations()).getVariableDeclaration());
		//		System.out.println("debug: '" + n.getName().toString().trim() + "'");
		cw.codePrintln("aconst_null");
		cw.codePrintln("astore " + vmap.getLocation(n.getName().toString().trim()));
	    }
	}
        if(node.getSavHelpDeclarations() != null){
	    node.getSavHelpDeclarations().apply(this);
	}
        outASetArrayVarSingleDeclaration(node);
    }



    /*                                        FUNCTIONS AND PROCEDURES            */

    //procedure
    public final void inAProcedureSingleSecondaryDeclaration(AProcedureSingleSecondaryDeclaration node){
	//flushWL();
	vmap = new VariableMap();
	String vname = node.getIdentifier().getText().trim();
	//	System.out.println("Procedure (" + vname + "): " + parameterify(vname));
	idTypeTable.loadScope(vname);
	ArrayList parameters = new ArrayList();
	try{
	    parameters = prober.getNames(vname);
	} catch (Exception e){

	}
	for (int i = 0; i < parameters.size(); i++){
	    //	    System.out.println("adding parameter: " + parameters.get(i));
	    vmap.enterNew((String)parameters.get(i));
	}
	LocationAssigner la = new LocationAssigner(vmap);
	node.apply(la);
	if (vname.equals("main")){
	    cw.codePrintln(".method public static " + vname + "([Ljava/lang/String;)V");
	} else{
	    cw.codePrintln(".method public static " + vname + "(" + parameterify(vname) + ")V");
	}
	    cw.addIndentScope();
	    cw.codePrintln(".limit stack 20");
	    cw.codePrintln(".limit locals " + la.size());
	if (vname.equals("main")){
	    cw.codePrintln("new dk/auc/cs/dogs/environment/types/Array");
	    cw.codePrintln("dup");
	    cw.codePrintln("aload_0");
	    cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Array/<init>([Ljava/lang/String;)V");
	    cw.codePrintln("astore_0");
	    cw.codePrintln("");
	} 

    }

    public final void outAProcedureSingleSecondaryDeclaration(AProcedureSingleSecondaryDeclaration node){
	cw.codePrintln("return");
	cw.removeIndentScope();
	cw.codePrintln(".end method\n");
    }

    //function
    public final void inAFunctionSingleSecondaryDeclaration(AFunctionSingleSecondaryDeclaration node){
	//flushWL();
	vmap = new VariableMap();
	String vname = node.getIdentifier().getText().trim();
	//	System.out.println("Function (" + vname + "): " + parameterify(vname));
	idTypeTable.loadScope(vname);
	ArrayList parameters = new ArrayList();
	try{
	    parameters = prober.getNames(vname);
	} catch (Exception e){
	    throw new RuntimeException("DE: exception: " + e.getMessage());
	}
	String flag, identifier;
	for (int i = 0; i < parameters.size(); i++){
	    identifier = (String)parameters.get(i);
	    flag = idTypeTable.getIdentifier(identifier).getFlag();
	    //	    System.out.println("adding parameter: " + parameters.get(i) + " - " + idTypeTable.getIdentifier(identifier).getType() + " (" + flag + ")");

	    addWeight(identifier, idTypeTable.getIdentifier(identifier).getType());
	    vmap.enterNew(identifier);
	}
	LocationAssigner la = new LocationAssigner(vmap);
	node.apply(la);
	//       	System.out.println("Parameters: " + parameterify(vname));
	cw.codePrintln(".method public static " + vname + "("+ parameterify(vname)+ ")" + returnerify(vname));
	cw.addIndentScope();
	cw.codePrintln(".limit stack 20");
	cw.codePrintln(".limit locals " + la.size());
    }

    public final void outAFunctionSingleSecondaryDeclaration(AFunctionSingleSecondaryDeclaration node){
	String vname = node.getIdentifier().getText().trim();
	cw.codePrintln("RETURNLABEL:");
	cw.codePrintln("checkcast " + returnerify(vname).substring(1).replace(';', ' ').trim());
	cw.codePrintln("areturn");
	cw.removeIndentScope();
	cw.codePrintln(".end method\n");
    }

    

} // DeclarationEncoder
