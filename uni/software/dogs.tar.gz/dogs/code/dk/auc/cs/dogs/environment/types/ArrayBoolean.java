package dk.auc.cs.dogs.environment.types;

public interface ArrayBoolean extends ArrayInterface {
}