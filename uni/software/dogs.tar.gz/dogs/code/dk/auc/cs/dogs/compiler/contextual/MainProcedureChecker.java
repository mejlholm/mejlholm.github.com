package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;

/*
 * <code>MainProcedureChecker</code> checks the AST for dublicate main
 * procedure entries.
 *
 * @author <a href="mailto:aaby@gentoo.org"></a>
 * @version 1.0
 */
public class MainProcedureChecker extends Checker{

    private boolean inProgram = false;
    private int counter = 0;
    private boolean insideMain = false;

    //empty default constructor
    public MainProcedureChecker(){
	super();
    }

    public void inAProgram(AProgram node) {
	inProgram = true;
    }

    public void inAFunctionSingleSecondaryDeclaration(AFunctionSingleSecondaryDeclaration node) {
	if (node.getIdentifier().getText().equals("main")) {
	    ErrorList.add(node.getIdentifier(), "main keyword only allowed for main procedure");
	}
    }

    public void caseAProcedureSingleSecondaryDeclaration(AProcedureSingleSecondaryDeclaration node) {

	String array = "";
	String type = "";
	AFormalParameterSequence fps = new AFormalParameterSequence();

	if (node.getIdentifier().getText().equals("main")) {
	    if (inProgram) {
		insideMain = true;
		counter++;
		if (counter > 1){
		    ErrorList.add(node.getIdentifier(), "more than one main procedure");
		}
	    } else {
		ErrorList.add(node.getIdentifier(), "main procedure in package not allowed");
	    }
	}

        if(node.getLPar() != null) {
            node.getLPar().apply(this);
        }
        if(node.getFormalParameterSequence() != null) {
            node.getFormalParameterSequence().apply(this);

	    // Check that it has the right parameters, if it is a main
	    // Check that the parameter is an array of strings
	    fps = (AFormalParameterSequence)node.getFormalParameterSequence();
	    if (fps.getFormalTypeDenoter().size() > 0 && insideMain) {
		ErrorList.add(node.getIdentifier(), "main procedure with more than one parameter");
	    }
	    if ((fps.getTypeDenoter() != null) && (insideMain)) {
		MainArrayTypeChecker atc = new MainArrayTypeChecker();
		fps.getTypeDenoter().apply(atc);
		if (!atc.getType().equals("string")) {
		    ErrorList.add(node.getIdentifier(), "main procedure without array of strings");
		}
		insideMain = false;
	    }
        } else {
	    if(insideMain) {
		ErrorList.add(node.getIdentifier(), "main procedure without array of strings");
		insideMain = false;
	    }
	}
        if(node.getRPar() != null) {
            node.getRPar().apply(this);
        }
    }
}


