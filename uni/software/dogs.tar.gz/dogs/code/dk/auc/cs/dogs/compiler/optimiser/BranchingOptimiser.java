package dk.auc.cs.dogs.compiler.optimiser;

import dk.auc.cs.dogs.compiler.optimiser.TypeOptimiser;
import dk.auc.cs.dogs.compiler.optimiser.probers.BranchingProber;
import dk.auc.cs.dogs.compiler.node.*;

/**
 * BranchingOptimiser.java
 *
 *
 * Created: Wed May 12 10:15:45 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class BranchingOptimiser extends TypeOptimiser {

    boolean debug = false;

    public BranchingOptimiser() {
	
    } // BranchingOptimiser constructor
    
    public void outAIfOpenElseClosedCommand(AIfOpenElseClosedCommand node){
	BranchingProber bp = new BranchingProber();
	node.apply(bp);
	if (bp.size() == 4){
	    int i = optimise4(bp);
	    if (i == 1){
		if(debug)System.out.println(node.getTrue() + " true");
		if(debug)System.out.println("Node " + node.getClass().getName() + node);
		if(debug)System.out.println("should be replaced with: " + node.getTrue().getClass().getName());
		node.replaceBy(node.getTrue());
		if(debug)System.out.println("Done");
	    } else{
		if (i == 2){
		    if(debug)System.out.println(node.getFalse() + " false");
		    if(debug)System.out.println("Node " + node.getClass().getName() + node);
		    if(debug)System.out.println("should be replaced with: " + node.getFalse().getClass().getName());
		    node.replaceBy(node.getFalse());
		    if(debug)System.out.println("Done");
		}
	    }
	}
    }

    public void outAIfThenOpenCommand(AIfThenOpenCommand node){
	BranchingProber bp = new BranchingProber();
	node.apply(bp);
	if (bp.size() == 3){
	    int i = optimise3(bp);
	    if (i == 1){
		if(debug)System.out.println(node.getSingleCommand() + " true");
		if(debug)System.out.println("Node " + node.parent().getClass().getName());
		if(debug)System.out.println("should be replaced with: " + node.getSingleCommand().getClass().getName());
		node.parent().replaceBy(node.getSingleCommand());
		if(debug)System.out.println("Done");
	    }
	    if (i == 2){
		if(debug)System.out.println("Dead code, remove it");
		if(debug)System.out.println(node.getClass().getName());
		if(debug)System.out.println(node.parent().getClass().getName());
		node.parent().replaceBy(null);
		if(debug)System.out.println("Done");
	    }
	}
    }

    private int optimise4(BranchingProber bp){

	String s1, s2, s3, s4;
	String t1, t2, t3, t4;
	int b = 0;

       	s1 = bp.getExpression(0);
       	s2 = bp.getExpression(1);
       	s3 = bp.getExpression(2);
       	s4 = bp.getExpression(3);

       	t1 = bp.getType(0);
       	t2 = bp.getType(1);
       	t3 = bp.getType(2);
       	t4 = bp.getType(3);

	if (t1.equals("branch") && t2.equals("bool") && t3.equals("branch") && t4.equals("branch")){

	    if (s2.equals("true")){
		if(debug)System.out.print(s1 + " with " + s2 + " optimised to: " );
		b = 1;//signal replace with first statement

	    }
	    if (s2.equals("false")){
		if(debug)System.out.print(s1 + " with " + s2 + " optimised to: " );
		b = 2;//signal replace with second statement

	    }
	}
	return b;

    }

    private int optimise3(BranchingProber bp){

	String s1, s2, s3;
	String t1, t2, t3;
	int b = 0;

       	s1 = bp.getExpression(0);
       	s2 = bp.getExpression(1);
       	s3 = bp.getExpression(2);

       	t1 = bp.getType(0);
       	t2 = bp.getType(1);
       	t3 = bp.getType(2);


	if (t1.equals("branch") && t2.equals("bool") && t3.equals("branch")){

	    if (s2.equals("true")){
		if(debug)System.out.print(s1 + " with " + s2 + " optimised to: " );
		b = 1;//signal replace with first statement
	    }
	    if (s2.equals("false")){
	    if(debug)System.out.print(s1 + " with " + s2 + " optimised to: " );
	    b = 2;//signal replace with second statement
	    }
	}
	return b;

    }

} // BranchingOptimiser
