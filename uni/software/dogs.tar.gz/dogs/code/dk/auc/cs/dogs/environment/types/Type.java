package dk.auc.cs.dogs.environment.types;

public abstract class Type implements Cloneable {

    public Type() {
	super();
    }

    public java.lang.String getName() {
	return this.getClass().getName().substring(33);
    }
    
    public Type duplicate() {
	System.out.println("duplicating type...");
	return this;
    }
}
