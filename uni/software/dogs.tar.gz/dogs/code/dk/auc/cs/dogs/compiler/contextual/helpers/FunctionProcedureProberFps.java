package dk.auc.cs.dogs.compiler.contextual.helpers;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.node.*;

import java.util.*;

public class FunctionProcedureProberFps extends DepthFirstAdapter {

    private StandardEnvironment stdEnv = new StandardEnvironment();
    private ArrayList types = new ArrayList();
    private ArrayList names = new ArrayList();
    private ArrayList flags = new ArrayList();

    public void caseAFormalParameterSequence(AFormalParameterSequence node) {
	if(node.getTypeDenoter() != null) {
            node.getTypeDenoter().apply(this);
        }
        if(node.getIdentifier() != null) {
	    names.add(node.getIdentifier().getText());
        }
        {
            Object temp[] = node.getFormalTypeDenoter().toArray();
            for(int i = 0; i < temp.length; i++)
		{
		    ((PFormalTypeDenoter) temp[i]).apply(this);
		}
        }
    }
    
    public void caseAFormalTypeDenoter(AFormalTypeDenoter node) {
        if(node.getTypeDenoter() != null) {
            node.getTypeDenoter().apply(this);
        }
        if(node.getIdentifier() != null) {
	    names.add(node.getIdentifier().getText());
        }
    }


    // Declaration of arrays
    public void inAArrayTypeDenoter(AArrayTypeDenoter node) {
	if (stdEnv.knownType(node.getType().getText())) {
	    types.add(node.getType().getText());
	    flags.add("array");
	} else {
	    ErrorList.add(node.getType(), "unknown type");
	}
    }

    public void inAWeightTypeDenoter(AWeightTypeDenoter node) {
	if (stdEnv.knownType(node.getType().getText())) {
	    types.add(node.getType().getText());
	    flags.add("weight");
	} else {
	    ErrorList.add(node.getType(), "unknown type");
	}
    }

    public void inASetTypeDenoter(ASetTypeDenoter node) {
	if (stdEnv.knownType(node.getType().getText())) {
	    types.add(node.getType().getText());
	    flags.add("set");
	} else {
	    ErrorList.add(node.getType(), "unknown type");
	}
    }

    public void inALabelTypeDenoter(ALabelTypeDenoter node) {
	if (stdEnv.knownType(node.getType().getText())) {
	    types.add(node.getType().getText());
	    flags.add("label");
	} else {
	    ErrorList.add(node.getType(), "unknown type");
	}
    }

    public void caseAIdentifierTypeDenoter(AIdentifierTypeDenoter node) {
	types.add(node.getIdentifier().getText());
	flags.add("variable");
    }

    public ArrayList getNames() {
	return names;
    }

    public ArrayList getTypes() {
	return types;
    }

    public ArrayList getFlags() {
	return flags;
    }
}
