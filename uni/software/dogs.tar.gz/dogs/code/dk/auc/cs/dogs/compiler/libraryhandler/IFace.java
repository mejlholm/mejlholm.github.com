package dk.auc.cs.dogs.compiler.libraryhandler;

import java.util.ArrayList;

/**
 * IFace.java
 *
 *
 * Created: Thu May  6 13:56:24 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class IFace {

    private String returnValue;//
    private String name;//
    private ArrayList formalParameterSequence = new ArrayList();//
    private int counter = -1;
    private String packageName;

    public IFace() {
	
    } // IFace constructor
    
    public int sizeFPS(){
	return formalParameterSequence.size();
    }

    public String getNextFP(){
	counter++;
	return (String)formalParameterSequence.get(counter);
    }

    public void resetFPS(){
	counter = -1;
    }
    
    public String toString(){
	String str = new String();

	str = str + getPackageName() + "\t";
	str = str + getName() + "\t";
	ArrayList a = getFormalParameterSequence();
	for (int j = 0; j < a.size(); j++){
	    str= str + (String)a.get(j) + ",\t\t";
	}
	str = str + "\t";
	str = str + getReturnValue();
	return str;
   }

    /**
     * Gets the value of returnValue
     *
     * @return the value of returnValue
     */
    public String getReturnValue() {
	return this.returnValue;
    }

    /**
     * Sets the value of returnValue
     *
     * @param argReturnValue Value to assign to this.returnValue
     */
    protected void setReturnValue(String argReturnValue) {
	this.returnValue = argReturnValue;
    }

    /**
     * Gets the value of name
     *
     * @return the value of name
     */
    public String getName()  {
	return this.name;
    }

    /**
     * Sets the value of name
     *
     * @param argName Value to assign to this.name
     */
    protected void setName(String argName) {
	this.name = argName;
    }

    /**
     * Gets the value of formalParameterSequence
     *
     * @return the value of formalParameterSequence
     */
    public ArrayList getFormalParameterSequence()  {
	return this.formalParameterSequence;
    }

    /**
     * Sets the value of formalParameterSequence
     *
     * @param argFormalParameterSequence Value to assign to this.formalParameterSequence
     */
    protected void setFormalParameterSequence(ArrayList argFormalParameterSequence) {
	this.formalParameterSequence = argFormalParameterSequence;
    }

    /**
     * Gets the value of packageName
     *
     * @return the value of packageName
     */
    public String getPackageName()  {
	return this.packageName;
    }

    /**
     * Sets the value of packageName
     *
     * @param argPackageName Value to assign to this.packageName
     */
    protected void setPackageName(String argPackageName) {
	this.packageName = argPackageName;
    }

} // IFace
