package dk.auc.cs.dogs.environment.types;

public interface TypeInterface {

    public Type duplicate();
    public java.lang.String toString();


}