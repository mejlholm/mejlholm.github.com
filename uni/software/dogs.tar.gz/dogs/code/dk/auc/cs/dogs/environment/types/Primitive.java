package dk.auc.cs.dogs.environment.types;

public abstract class Primitive extends Type {
    public Primitive() {
	super();
    }

    public abstract Type duplicate();

    public abstract java.lang.String toString();

    //    public abstract Boolean isEqual(Primitive p);
    public Boolean isEqual(Primitive p) {
    	throw new RuntimeException("Cannot compare incompatible types");
    }

    public Boolean isDifferent(Primitive p) {
	return this.isEqual(p).invert();
    }

    public final java.lang.String getType() {
	return this.getClass().getName().substring(33);
    }
}
