package dk.auc.cs.dogs.compiler.contextual.helpers;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import dk.auc.cs.dogs.compiler.libraryhandler.*;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.node.*;

import java.util.regex.*;
import java.util.*;

public class PackageImporterChecker extends DepthFirstAdapter {

    private Library lib = new Library();
    private IdentificationTableRecord idRecord = null;
    private FunctionProcedureProber prober = null;
    private String libName = null;
    private String flag = null;
    private boolean labelWeightFound = false;

    public PackageImporterChecker() {
	// Empty constructor
    }
    
    public PackageImporterChecker(IdentificationTableRecord idRecord, FunctionProcedureProber prober, Library lib) {
	this.idRecord = idRecord;
	this.prober = prober;
	this.lib = lib;
    }
    
    ////////////////////////// LOAD PACKAGES //////////////////////////
    public void caseAPackageImport(APackageImport node) {
	boolean loaded = false;
	ArrayList al = null;
	
        if(node.getPackageName() != null) {
	    libName = ((AVName)node.getPackageName()).getIdentifier().getText();
            node.getPackageName().apply(this);
	}
	try {
	    loaded = lib.importFilename(libName);
	} catch (RecordAlreadyDefinedException e) {
	    ErrorList.add(node.getImport(), e.getMessage());
	} catch (FunctionAlreadyDefinedException e) {
	    ErrorList.add(node.getImport(), e.getMessage());
	} catch (ClassFileNotKnownException e) {
	    ErrorList.add(node.getImport(), "Unknown package, can not resolve package: " + libName);
	}
    }    
    
    public void inAIdentifierRecordVNameExtension(AIdentifierRecordVNameExtension node) {
	libName = libName + "." + ((AVName)node.getVName()).getIdentifier().getText();
    }
    //////////////////////// LOAD PACKAGES END ////////////////////////

    //////////////////////// RESOLVE CALL TO PACKAGE ////////////////////////
    public void inALwAssBasicCommands(ALwAssBasicCommands node) {
	labelWeightFound = true;
    }

    public void inAParameterCall(AParameterCall node) {
	String functionName = node.getName().getText();
	if (!labelWeightFound) {
	    checkType(functionName, node);
	} else {
	    labelWeightFound = false;
	}
    }
    
    private void checkType(String functionName, AParameterCall node) {
	IFace iface = null;
	String type = null;
	ArrayList types = new ArrayList();
	ArrayList flags = new ArrayList();
	ArrayList returnValues = new ArrayList();	
	
	if (!prober.isInTable(functionName)) {
	    if (lib.isFunctionKnown(functionName)) {
		iface = lib.getInterfaceFromFunctionname(functionName);
		for (int i = 0; i < iface.sizeFPS(); i++) {
		    type = convertToDogType(iface.getNextFP());
		    types.add(type);
		    flags.add(flag);
		}
		// Set return type if it is there
		type = convertToDogType(iface.getReturnValue());
		returnValues.add(type);
		returnValues.add(flag);

		try {
		    prober.setTypes(functionName, types);
		    prober.setFlags(functionName, flags);
		    prober.setReturnType(functionName, returnValues);
		} catch(FunctionProcedureProberException e) {
		    ErrorList.add(node.getName(), e.getMessage());
		}
	    } else {
		// Will be add to error list in a later check
	    }
	}
    }

    private String convertToDogType(String javaType) {
	String type = "UNKOWN";
	Matcher matcher = null;
	Pattern pattern = null;

	javaType = javaType.substring(javaType.lastIndexOf(".") + 1).trim();

	pattern = Pattern.compile("^Set");
	matcher = pattern.matcher(javaType);
	if (matcher.find()) {
	    if (javaType.equals("SetInterface")) {
		type = "stdSet";
	    } else {
		type = javaType.substring(3, 4).toLowerCase() + javaType.substring(4);
	    }
	    flag = "set";
	    return type;
	}

	pattern = Pattern.compile("^Array");
	matcher = pattern.matcher(javaType);
	if (matcher.find()) {
	    if (javaType.equals("ArrayInterface")) {
		type = "stdArray";
	    } else {
		type = javaType.substring(5, 6).toLowerCase() + javaType.substring(6);
	    }
	    flag = "array";
	    return type;
	}

	pattern = Pattern.compile("^Label");
	matcher = pattern.matcher(javaType);
	if (matcher.find()) {
	    if (javaType.equals("LabelInterface")) {
		type = "StdLabel";
	    } else {
		type = javaType.substring(5, 6).toLowerCase() + javaType.substring(6);
	    }
	    flag = "label";
	    return type;
	}
	
	pattern = Pattern.compile("^Weight");
	matcher = pattern.matcher(javaType);
	if (matcher.find()) {
	    if (javaType.equals("WeightInterface")) {
		type = "stdWeight";
	    } else {
		type = javaType.substring(6, 7).toLowerCase() + javaType.substring(7);
	    }
	    flag = "Weight";
	    return type;
	}

	if (javaType.equals("IntegerNumber")) {
	    type = "integer";
	    flag = "variable";
	} else if (javaType.equals("Integer")) {
	    type = "integer";
	    flag = "variable";
	} else if (javaType.equals("String")) {
	    type = "string";
	    flag = "variable";
	} else if (javaType.equals("FloatNumber")) {
	    type = "float";
	    flag = "variable";
	} else if (javaType.equals("Float")) {
	    type = "float";
	    flag = "variable";
	} else if (javaType.equals("Boolean")) {
	    type = "boolean";
	    flag = "variable";
	} else if (javaType.equals("Infty")) {
	    type = "infty";
	    flag = "variable";
	} else if (javaType.equals("Vertex")) {
	    type = "vertex";
	    flag = "variable";
	} else if (javaType.equals("Edge")) {
	    type = "edge";
	    flag = "variable";
	} else if (javaType.equals("Primitive")) {
	    type = "primitive";
	    flag = "variable";
	} else if (javaType.equals("GraphComposite")) {
	    type = "GraphComposite";
	    flag = "variable";
	} else if (javaType.equals("DiGraph")) {
	    type = "diGraph";
	    flag = "variable";
	} else if (javaType.equals("Graph")) {
	    type = "graph";
	    flag = "variable";
	} else if(javaType.equals("void")) {
	    type = "void";
	} else {
	    System.out.println("UNKNOWN found in " + javaType);
	}
	return type;
    }
}
