package dk.auc.cs.dogs.environment.types;

public interface IntegerNumber extends NumberNumber{

    public Type duplicate();
    public java.lang.String toString();


//     /*
//       BOOLEAN EXPRESSIONS
//     */

//     public Boolean isLess(Number n);
//     public Boolean isGreater(Number n);
//     public Boolean isLessOrEqual(Number n);
//     public Boolean isGreaterOrEqual(Number n);
//     public Boolean isEqual(Number n);
//     public Boolean isDifferent(Number n);

//     /*
//       ARITHMETIC OPERATIONS
//     */

//     public void increment();
//     public void decrement();

//     public Number modulus(Number n);
//     public Number integerDivision(Number n);

//     public Number addition(Number n);
//     public Number subtraction(Number n);
//     public Number multiplication(Number n);
//     public Number division(Number n);

//     public double getValue();
//     public java.lang.String getName();


}// IntegerNumber
