package dk.auc.cs.dogs.environment.types;

import java.util.*;

public class Test {
    public static void main(java.lang.String[] arguments){
	Number n = new Integer(4);
	Number t = new Float(4.4);
	Integer i = (Integer)n;
	Number g = (Number)i;
    }
}
