package dk.auc.cs.dogs.compiler.codegeneration;

import dk.auc.cs.dogs.compiler.codegeneration.TypeEncoder;
import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.libraryhandler.Library;


/**
 * ExpressionEncoder.java
 *
 *
 * Created: Wed May 19 12:51:26 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public abstract class ExpressionEncoder extends TypeEncoder {

    private boolean debug = false;
    private int counter = 1;
    private int exprCounter = 1;
    
    public ExpressionEncoder(Library lib, StandardEnvironment std, String sourcefile, String objectfile, IdentificationTableRecord idRecord, FunctionProcedureProber prober, IdentitiesAndTypesTable idTypeTable) {
	super(lib, std, sourcefile, objectfile, idRecord, prober, idTypeTable);
    } // ExpressionEncoder constructor
    

    //arithmetic

    public final void caseAPlusPlusMinusExpr(APlusPlusMinusExpr node)
    {
	if(debug)cw.codePrintln("; " + node);
        inAPlusPlusMinusExpr(node);
        if(node.getPlusMinusExpr() != null)
        {
            node.getPlusMinusExpr().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
        }
        if(node.getMultiplicationExpr() != null)
        {
            node.getMultiplicationExpr().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
        }
        if(node.getPlus() != null)
        {
            node.getPlus().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/addition(Ldk/auc/cs/dogs/environment/types/NumberNumber;)Ldk/auc/cs/dogs/environment/types/NumberNumber; 2");
        }
        outAPlusPlusMinusExpr(node);
    }

    public final void caseAMinusPlusMinusExpr(AMinusPlusMinusExpr node)
    {
	if(debug)cw.codePrintln("; " + node);
        inAMinusPlusMinusExpr(node);
        if(node.getPlusMinusExpr() != null)
        {
            node.getPlusMinusExpr().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
        }
        if(node.getMultiplicationExpr() != null)
        {
            node.getMultiplicationExpr().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
        }
        if(node.getMinus() != null)
        {
            node.getMinus().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/subtraction(Ldk/auc/cs/dogs/environment/types/NumberNumber;)Ldk/auc/cs/dogs/environment/types/NumberNumber; 2");
        }
        outAMinusPlusMinusExpr(node);
    }


   public final void caseAStarMultiplicationExpr(AStarMultiplicationExpr node){
	if(debug)cw.codePrintln("; " + node);
        inAStarMultiplicationExpr(node);
        if(node.getMultiplicationExpr() != null)
	    {
		node.getMultiplicationExpr().apply(this);
		//cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    }
        if(node.getStar() != null)
	    {
		node.getStar().apply(this);
		//cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    }
        if(node.getConcatinationExpr() != null)
	    {
		node.getConcatinationExpr().apply(this);
		//cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
		cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/multiplication(Ldk/auc/cs/dogs/environment/types/NumberNumber;)Ldk/auc/cs/dogs/environment/types/NumberNumber; 2");
	    }

        outAStarMultiplicationExpr(node);
    }

    public final void caseADivMultiplicationExpr(ADivMultiplicationExpr node)
    {
	if(debug)cw.codePrintln("; " + node);
        inADivMultiplicationExpr(node);
        if(node.getMultiplicationExpr() != null)
	    {
		node.getMultiplicationExpr().apply(this);
		//cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    }
        if(node.getConcatinationExpr() != null)
	    {
		node.getConcatinationExpr().apply(this);
		//cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    }
        if(node.getDiv() != null)
	    {
		node.getDiv().apply(this);
		//cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/division(Ldk/auc/cs/dogs/environment/types/NumberNumber;)Ldk/auc/cs/dogs/environment/types/NumberNumber; 2");
	    }

        outADivMultiplicationExpr(node);
    }


    public final void caseAModMultiplicationExpr(AModMultiplicationExpr node)
    {
	if(debug)cw.codePrintln("; " + node);
        inAModMultiplicationExpr(node);
        if(node.getMultiplicationExpr() != null)
	    {
		node.getMultiplicationExpr().apply(this);
		//cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    }
        if(node.getConcatinationExpr() != null)
	    {
		node.getConcatinationExpr().apply(this);
		//cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    }
        if(node.getMod() != null)
	    {
		node.getMod().apply(this);
		//cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/modulus(Ldk/auc/cs/dogs/environment/types/NumberNumber;)Ldk/auc/cs/dogs/environment/types/NumberNumber; 2");
	    }
        outAModMultiplicationExpr(node);
    }

    public final void caseAIntDivMultiplicationExpr(AIntDivMultiplicationExpr node)
    {
	if(debug)cw.codePrintln("; " + node);
        inAIntDivMultiplicationExpr(node);
        if(node.getMultiplicationExpr() != null)
	    {
		node.getMultiplicationExpr().apply(this);
		//cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    }
        if(node.getConcatinationExpr() != null)
	    {
		node.getConcatinationExpr().apply(this);
		//cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    }
        if(node.getIntDiv() != null)
	    {
		node.getIntDiv().apply(this);
		//cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/integerDivision(Ldk/auc/cs/dogs/environment/types/NumberNumber;)Ldk/auc/cs/dogs/environment/types/NumberNumber; 2");
	    }
        outAIntDivMultiplicationExpr(node);
    }




    //Boolean
    public final void caseALtLessGreaterExpr(ALtLessGreaterExpr node)
    {
	if(debug)cw.codePrintln("; " + node);
        inALtLessGreaterExpr(node);
        if(node.getLessGreaterExpr() != null)
        {
            node.getLessGreaterExpr().apply(this);
 	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
       }
        if(node.getPlusMinusExpr() != null)
        {
            node.getPlusMinusExpr().apply(this);
 	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
       }
        if(node.getLt() != null)
        {
            node.getLt().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/isLess(Ldk/auc/cs/dogs/environment/types/NumberNumber;)Ldk/auc/cs/dogs/environment/types/Boolean; 2");
        }
        outALtLessGreaterExpr(node);
    }

    public final void caseALteqLessGreaterExpr(ALteqLessGreaterExpr node){
	if(debug)cw.codePrintln("; " + node);
        inALteqLessGreaterExpr(node);
        if(node.getLessGreaterExpr() != null)
        {
            node.getLessGreaterExpr().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
        }
        if(node.getPlusMinusExpr() != null)
        {
            node.getPlusMinusExpr().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
        }
        if(node.getLteq() != null)
        {
            node.getLteq().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/isLessOrEqual(Ldk/auc/cs/dogs/environment/types/NumberNumber;)Ldk/auc/cs/dogs/environment/types/Boolean; 2");
        }
        outALteqLessGreaterExpr(node);
    }

    public final void caseAGteqLessGreaterExpr(AGteqLessGreaterExpr node){
	if(debug)cw.codePrintln("; " + node);
        inAGteqLessGreaterExpr(node);
        if(node.getLessGreaterExpr() != null)
        {
            node.getLessGreaterExpr().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
        }
        if(node.getPlusMinusExpr() != null)
        {
            node.getPlusMinusExpr().apply(this);
 	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
       }
        if(node.getGteq() != null)
        {
            node.getGteq().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/isGreaterOrEqual(Ldk/auc/cs/dogs/environment/types/NumberNumber;)Ldk/auc/cs/dogs/environment/types/Boolean; 2");
        }
        outAGteqLessGreaterExpr(node);
    }

    public final void caseAGtLessGreaterExpr(AGtLessGreaterExpr node){
	if(debug)cw.codePrintln("; " + node);
        inAGtLessGreaterExpr(node);
        if(node.getLessGreaterExpr() != null)
        {
            node.getLessGreaterExpr().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
        }
        if(node.getPlusMinusExpr() != null)
        {
            node.getPlusMinusExpr().apply(this);
 	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
       }
        if(node.getGt() != null)
        {
            node.getGt().apply(this);
	    //cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/isGreater(Ldk/auc/cs/dogs/environment/types/NumberNumber;)Ldk/auc/cs/dogs/environment/types/Boolean; 2");
        }
        outAGtLessGreaterExpr(node);
    }




    public final void caseAEqualCompareExpr(AEqualCompareExpr node){
	if(debug)cw.codePrintln("; " + node);
        inAEqualCompareExpr(node);
        if(node.getCompareExpr() != null)
        {
            node.getCompareExpr().apply(this);
 	    cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/Primitive");
       }
        if(node.getLessGreaterExpr() != null)
        {
            node.getLessGreaterExpr().apply(this);
 	    cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/Primitive");
       }
        if(node.getEqual() != null)
        {
            node.getEqual().apply(this);
	    cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/Primitive");
	    cw.codePrintln("invokevirtual dk/auc/cs/dogs/environment/types/Primitive/isEqual(Ldk/auc/cs/dogs/environment/types/Primitive;)Ldk/auc/cs/dogs/environment/types/Boolean;");
        }
        outAEqualCompareExpr(node);
    }

    public final void caseANotEqualCompareExpr(ANotEqualCompareExpr node)
    {
	if(debug)cw.codePrintln("; " + node);
        inANotEqualCompareExpr(node);
        if(node.getCompareExpr() != null)
        {
            node.getCompareExpr().apply(this);
 	    cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/Primitive");
       }
        if(node.getLessGreaterExpr() != null)
        {
            node.getLessGreaterExpr().apply(this);
 	    cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/Primitive");
       }
        if(node.getNeq() != null)
        {
            node.getNeq().apply(this);
	    cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/Primitive");
	    cw.codePrintln("invokevirtual dk/auc/cs/dogs/environment/types/Primitive/isDifferent(Ldk/auc/cs/dogs/environment/types/Primitive;)Ldk/auc/cs/dogs/environment/types/Boolean;");
        }
        outANotEqualCompareExpr(node);
    }


    //// words ////
    public final void caseANotNotExpr(ANotNotExpr node){
	if(debug)cw.codePrintln("; " + node);
        inANotNotExpr(node);
        if(node.getNotExpr() != null)
        {
            node.getNotExpr().apply(this);
        }
        if(node.getNot() != null)
        {
            node.getNot().apply(this);
	    cw.codePrintln("invokevirtual dk/auc/cs/dogs/environment/types/Boolean/invert()Ldk/auc/cs/dogs/environment/types/Boolean;");
        }
        outANotNotExpr(node);
    }

    public final void caseAAndAndExpr(AAndAndExpr node)
    {
	//	exprCounter;
	    
	if(debug)cw.codePrintln("; " + node);
        inAAndAndExpr(node);
        if(node.getAndExpr() != null)
        {
            node.getAndExpr().apply(this);
	    boolEval();
	    cw.codePrintln("ifgt EXPRESSION" + exprCounter);
	    cw.codePrintln("new dk/auc/cs/dogs/environment/types/Boolean");
	    cw.codePrintln("dup");
	    cw.codePrintln("bipush 0");
	    cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Boolean/<init>(Z)V");
	    cw.codePrintln("goto EXPRESSION" + (exprCounter + 1));
        }
	cw.codePrintln("EXPRESSION" + exprCounter++ + ":");
        if(node.getNotExpr() != null)
        {
            node.getNotExpr().apply(this);
        }
        if(node.getAnd() != null)
        {
            node.getAnd().apply(this);
	    //boolEval();
	    
	    //cw.codePrintln("invokevirtual dk/auc/cs/dogs/environment/types/Boolean/and(Ldk/auc/cs/dogs/environment/types/Boolean;)Ldk/auc/cs/dogs/environment/types/Boolean;");
        }
	cw.codePrintln("EXPRESSION" + exprCounter++ + ":");
        outAAndAndExpr(node);
    }

    public final void caseAXorOrExpr(AXorOrExpr node)
    {
	if(debug)cw.codePrintln("; " + node);
        inAXorOrExpr(node);
        if(node.getOrExpr() != null)
        {
            node.getOrExpr().apply(this);
        }
        if(node.getAndExpr() != null)
        {
            node.getAndExpr().apply(this);
        }
        if(node.getXor() != null)
        {
            node.getXor().apply(this);
	    cw.codePrintln("invokevirtual dk/auc/cs/dogs/environment/types/Boolean/xor(Ldk/auc/cs/dogs/environment/types/Boolean;)Ldk/auc/cs/dogs/environment/types/Boolean;");
        }
        outAXorOrExpr(node);
    }

    public final void caseAOrOrExpr(AOrOrExpr node)
    {
	if(debug)cw.codePrintln("; " + node);
        inAOrOrExpr(node);

        if(node.getOrExpr() != null)
        {
            node.getOrExpr().apply(this);
	    cw.codePrintln("");
	    cw.codePrintln("invokevirtual dk/auc/cs/dogs/environment/types/Boolean/getValue()Z");
	    cw.codePrintln("ifgt LBL" + counter);
        }
        if(node.getAndExpr() != null)
        {
            node.getAndExpr().apply(this);
	    cw.codePrintln("invokevirtual dk/auc/cs/dogs/environment/types/Boolean/getValue()Z");
	    cw.codePrintln("ifgt LBL" + counter);
        }
        if(node.getOr() != null)
        {
            node.getOr().apply(this);
	    cw.codePrintln("new dk/auc/cs/dogs/environment/types/Boolean");
	    cw.codePrintln("dup");		    
	    cw.codePrintln("bipush 0 ; false");
	    cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Boolean/<init>(Z)V");
	    cw.codePrintln("goto LBL" + (counter+1));

	    cw.codePrintln("LBL" + counter++ + ":");
	    cw.codePrintln("new dk/auc/cs/dogs/environment/types/Boolean");
	    cw.codePrintln("dup");
	    cw.codePrintln("bipush 1 ;true");
	    cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Boolean/<init>(Z)V");

	    cw.codePrintln("LBL" + counter++ + ":");
	    //cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Boolean/<init>(Z)V");
	    cw.codePrintln("");
        }
        outAOrOrExpr(node);
    }

    //String

    public final void caseAConcatinationExpr(AConcatinationExpr node){
	if(debug)cw.codePrintln("; " + node);
        inAConcatinationExpr(node);
        if(node.getPrimaryExpression() != null)
        {
            node.getPrimaryExpression().apply(this);
        }
        if(node.getConcatinationExpr() != null)
        {
            node.getConcatinationExpr().apply(this);
        if(node.getConcat() != null)
        {
            node.getConcat().apply(this);
	    cw.codePrintln("invokevirtual dk/auc/cs/dogs/environment/types/String/append(Ldk/auc/cs/dogs/environment/types/String;)Ldk/auc/cs/dogs/environment/types/String;");        }
        }
        outAConcatinationExpr(node);
    }


} // ExpressionEncoder
