package dk.auc.cs.dogs.environment.types;

public class Infty extends Number implements IntegerNumber, FloatNumber {
    
    private boolean positive;

    public Infty(boolean b) {
	super();
	positive = b;
    }

    public java.lang.String toString() {
	java.lang.String str = "infty";
	if (!positive) {
	    str = "-" + str;
	}
	return str;
    }

    public IntegerNumber round() {
	return this;
    }

    public Type duplicate() {
	System.out.println("Duplicating infty");
	return new Infty(positive);
    }

    public Boolean isPositive() {
	return new Boolean(positive);
    }

    /***********************
     * Boolean expressions *
     ***********************/

    public final Boolean isLess(Integer i) {
	return new Boolean(!positive);
    }

    public final Boolean isLess(Float f) {
	return new Boolean(!positive);
    }

    public final Boolean isLess(Infty i) {
// 	System.out.println("comparing 2 x infty");
// 	System.out.println("b1: " + positive);
// 	System.out.println("b2: " + i.positive);
// 	System.out.println("b1 < b2 : " + (i.positive==false && positive));
	//	return new Boolean(!i.isPositive().getValue() && positive);
	//	return new Boolean(i.positive && !positive);
	return new Boolean(i.positive==false && positive);
    }

    public final Boolean isGreater(Integer i) {
	return new Boolean(positive);
    }

    public final Boolean isGreater(Float f) {
	return new Boolean(positive);
    }

    public final Boolean isGreater(Infty i) {
	return new Boolean(i.isPositive().getValue() && !positive);
    }

    public final Boolean isLessOrEqual(Integer i) {
	return isLess(i);
    }

    public final Boolean isLessOrEqual(Float f) {
	return isLess(f);
    }

    public final Boolean isLessOrEqual(Infty i) {
	return isLess(i);
    }

    public final Boolean isGreaterOrEqual(Integer i) {
	return isGreater(i);
    }

    public final Boolean isGreaterOrEqual(Float f) {
	return isGreater(f);
    }

    public final Boolean isGreaterOrEqual(Infty i) {
	return isGreater(i);
    }

    public final Boolean isEqual(Integer i) {
	return new Boolean(false);
    }

    public final Boolean isEqual(Float f) {
	return new Boolean(false);
    }

    public final Boolean isEqual(Infty i) {
	return new Boolean((i.isPositive().getValue() && positive) || !(i.isPositive().getValue() && positive));
    }

    public final Boolean isDifferent(Float f) {
	return new Boolean(true);
    }

    public final Boolean isDifferent(Integer i) {
	return new Boolean(true);
    }

    public final Boolean isDifferent(Infty i) {
	return isEqual(i).invert();
    }

    /*************************
     * Arithmetic operations *
     *************************/

    public void increment() {
	arithmeticError();
    }

    public void decrement() {
	arithmeticError();
    }

    public NumberNumber addition(Integer i) {
	arithmeticError();
	return this;
    }

    public Float addition(Float f) {
	arithmeticError();
	return f;
    }
    
    public NumberNumber subtraction(Integer i) {
	arithmeticError();
	return this;
    }

    public Float subtraction(Float f) {
	arithmeticError();
	return f;
    }

    public NumberNumber multiplication(Integer i) {
	arithmeticError();
	return this;
    }

    public Float multiplication(Float f) {
	arithmeticError();
	return f;
    }

    public Float division(Integer i) {
	arithmeticError();
	return new Float(0);
    }

    public Float division(Float f) {
	arithmeticError();
	return f;
    }

    public double getValue() {
	arithmeticError();
	return 1F;
    }

    private void arithmeticError() {
	throw new RuntimeException("Arithmetic operations not allowed on infty");
    }
}
