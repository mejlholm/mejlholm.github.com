package dk.auc.cs.dogs.environment.types;

public interface LabelInteger extends LabelInterface {
}