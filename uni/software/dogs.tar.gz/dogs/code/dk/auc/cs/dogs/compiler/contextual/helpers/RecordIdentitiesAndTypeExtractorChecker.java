package dk.auc.cs.dogs.compiler.contextual.helpers;

import java.util.HashMap;
import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;

public class RecordIdentitiesAndTypeExtractorChecker extends DepthFirstAdapter {

    private IdentificationTable idTable = null;
    private IdentificationTableRecord idRecord = null;
    private StandardEnvironment stdEnv = new StandardEnvironment();
    private boolean isAConstant = false;
    private String lastType = new String();
    private String mainRecordName = new String();
    private boolean isRecord =  false;
    private RecordTypeChecker recordTypeChecker = null;
    private FunctionProcedureProber prober = null;

    public RecordIdentitiesAndTypeExtractorChecker(StandardEnvironment stdEnv, IdentificationTable idTable, IdentificationTableRecord idRecord, String mainRecordName, FunctionProcedureProber prober) {
	this.stdEnv = stdEnv;
	this.idTable = idTable;
	this.idRecord = idRecord;
	this.prober = prober;
	this.mainRecordName = mainRecordName;
    }

    public void inAConstDeclaration(AConstDeclaration node) {
	isAConstant = true;
    }

    public void outAConstDeclaration(AConstDeclaration node) {
	isAConstant = false;
    }
    
    public void inAVariableDeclaration(AVariableDeclaration node) {

	isRecord = false; // rested record flag

	try {
	    if (stdEnv.knownType(node.getType().getText())) {
		if (stdEnv.isRecord(node.getType().getText())) {
		    idTable.enter(node.getName().getText(), stdEnv.getRecord(node.getType().getText()), isAConstant);
		    idRecord.insert(node.getName().getText(), stdEnv.getRecord(node.getType().getText()), isAConstant);
		    lastType = node.getType().getText();
		    isRecord = true;
		} else {
		    idTable.enter(node.getName().getText(), node, isAConstant);
		    idRecord.insert(node.getName().getText(), node, isAConstant);
		    lastType = node.getType().getText();
		}
	    } else {
		ErrorList.add(node.getType(), "unknown type");
	    }
	} catch(IdRecordTableException e) {
	    ErrorList.add(node.getName(), e.getMessage());
	} catch(StandardEnvironmentException e) {
	    ErrorList.add(node.getName(), e.getMessage());
	} catch(IdTableException e) {
	    ErrorList.add(node.getName(), e.getMessage());
	}
    }

    // Declaration of arrays
    public void inAArrayDeclaration(AArrayDeclaration node) {
	try {
	    if (stdEnv.knownType(node.getType().getText())) {
		idTable.enter(node.getName().getText(), node, isAConstant);
		idRecord.insert(node.getName().getText(), node, isAConstant);
		lastType = node.getType().getText();
	    } else {
		ErrorList.add(node.getName(), "unknown type");
	    }
	} catch (IdTableException e) {
	    ErrorList.add(node.getName(), e.getMessage());
	} catch (IdRecordTableException e) {
	    ErrorList.add(node.getName(), e.getMessage());
	}
    }

    public void inASetDeclaration(ASetDeclaration node) {
	try {
	    if (stdEnv.knownType(node.getType().getText())) {
		idTable.enter(node.getName().getText(), node, isAConstant);
		idRecord.insert(node.getName().getText(), node, isAConstant);
		lastType = node.getType().getText();

	    } else {
		ErrorList.add(node.getName(), "unknown type");
	    }
	} catch(IdTableException e) {
	    ErrorList.add(node.getName(), e.getMessage());
	} catch (IdRecordTableException e) {
	    ErrorList.add(node.getName(), e.getMessage());
	}
    }

    public void caseADeclarationAssignment(ADeclarationAssignment node) {

	MultiTypeChecker multiTypeChecker = null;
	ARecordDeclaration recordNode = null;
	String type = lastType;
	HashMap typesInTheRecord = null;

	// Evaluate the expresion, first the new record types
	if (type.equals("boolean")) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "boolean");
	    node.getExpression().apply(multiTypeChecker);
	    if(!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getAssign(), "illegal type, boolean expected on rigth side of expression");
	    }
	} else if (type.equals("edge")) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "edge");
	    node.getExpression().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getAssign(), "illegal type, vertex expected on rigth side of expression");
	    }
	} else if (type.equals("string")) { 
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "string");
	    node.getExpression().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getAssign(), "illegal string expression on rigth side of expression");
	    }
	} else if (type.equals("integer")) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "integer");
	    node.getExpression().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getAssign(), "illegal integer expression on rigth side of expression");
	    }	    
	} else if (type.equals("float")) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "float");
	    node.getExpression().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getAssign(), "illegal float expression on rigth side of expression");
	    }
	} else if (type.equals("graph")) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "graph");
	    node.getExpression().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getAssign(), "illegal type on rigth side of assignment expected graph");
	    }
	} else if (type.equals("diGraph")) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "diGraph");
	    node.getExpression().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getAssign(), "illegal type on rigth side of assignment expected diGraph");
	    }
	} else if (isRecord) {
	    try {
		idRecord.saveRecord(mainRecordName); // tmp save
		idRecord.loadRecord(lastType);
		recordTypeChecker = new RecordTypeChecker(idTable, stdEnv, idRecord, lastType, prober);
		node.getExpression().apply(recordTypeChecker);
		idRecord.loadRecord(mainRecordName);
		idRecord.remove(mainRecordName); // Remove tmp save
	    } catch (Exception e) {
		ErrorList.add(node.getAssign(), e.getMessage() + " with main record");
	    }
	} else {
	    // Rrecord ting dot...
	}
    }
}
