package dk.auc.cs.dogs.compiler;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import dk.auc.cs.dogs.compiler.node.*;


/**
 * FilenameProber.java
 *
 *
 * Created: Thu May 20 11:11:07 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class FilenameProber extends DepthFirstAdapter {

    private String filename = "";

    public FilenameProber() {
	
    } // FilenameProber constructor
    
    public void caseAProgram(AProgram node){
        if(node.getIdentifier() != null){
	    filename = node.getIdentifier().getText();
        }
    }

    public void caseAPackageProgram(APackageProgram node){
        if(node.getIdentifier() != null)
        {
	    filename = node.getIdentifier().getText();
        }
    }

    public String getFilename(){
	return filename;
    }

} // FilenameProber
