package dk.auc.cs.dogs.compiler;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.lexer.*;
import dk.auc.cs.dogs.compiler.parser.*;
import dk.auc.cs.dogs.compiler.optimiser.*;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.codegeneration.*;
import dk.auc.cs.dogs.compiler.libraryhandler.*;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;

import java.io.*;
import jasmin.*;

public class Main{

    private static void showUsage() {
	System.out.println("usage:");
	System.out.println("  java dk.auc.cs.dogs.compiler.Main [-<option>] filename");
	System.out.println("Options:");
	System.out.println("\tO\t\tDisable optimisation");
	System.out.println("\tJ\t\tOutput as Jasmin file");
	System.out.println("\tV\t\tPrint version information");
	System.out.println("\tP\t\tPrint initialisation of phases");
	//System.out.println("\tT\t\tDisable the typechecker");
    }

    public static void main(String[] arguments){

	Library library = new Library();
	FunctionProcedureProber prober = new FunctionProcedureProber();
	IdentificationTableRecord idRecord = new IdentificationTableRecord();
	IdentitiesAndTypesTable idTypeTable = new IdentitiesAndTypesTable();
	StandardEnvironment std = new StandardEnvironment();

	String filename = "";
	boolean verbose = false;
	boolean optimise = true;
	boolean typechecker = true;
	boolean jOutput = false;

        if(arguments.length < 1){
	    showUsage();
	    System.exit(1);
	}
	for (int i = 0; i < arguments.length; i++) {
	    if (arguments[i].toLowerCase().equals("-v")) {
		System.out.println("Dogsc version 1.0\nAuthors are group E3-210 at AAU Denmark, Computer Science\nwww.cs.aau.dk");
       		System.exit(1);
	    } else if (arguments[i].toLowerCase().equals("-o")) {
		optimise = false;
	    } else if (arguments[i].toLowerCase().equals("-p")) {
		verbose = true;
	    } else if (arguments[i].toLowerCase().equals("-t")) {
		typechecker = false;
	    } else if (arguments[i].toLowerCase().equals("-j")) {
		jOutput = true;
	    } else {
		if (filename.equals("")) {
		    filename = arguments[i];
		} else {
		    System.out.println("dogsc kan only compile one sourcefile at a time");
		}
	    }
	}

        try {
	    if(verbose)System.out.println("Lexer Started......");
	    Lexer lexer = new Lexer(new PushbackReader(new BufferedReader(new FileReader(filename)), 1024));
	    if(verbose)System.out.println("Parser Started......");
	    Parser parser = new Parser(lexer);
	    Node root = parser.parse();
	    
	    //contextual analysis
	    if(verbose)System.out.println("BreakChecker Started......");
	    root.apply(new BreakChecker());
	    checkError();
	    if(verbose)System.out.println("MainProcedureChecker Started......");
	    root.apply(new MainProcedureChecker());
	    checkError();
	    if(verbose)System.out.println("ReturnChecker Started......");
	    root.apply(new ReturnChecker());
	    checkError();
	    if (optimise){
		if(verbose)System.out.println("Optimiser Started......");
		root.apply(new Optimiser());
		checkError();
	    }
	    if(verbose)System.out.println("DivisionByZeroChecker Started......");
	    root.apply(new DivisionByZeroChecker());
	    checkError();
	    if (typechecker){
		if(verbose)System.out.println("TypeChecker Started......");
		root.apply(new TypeChecker(std, library, prober, idRecord, idTypeTable));
		checkError();
	    }
	    
	    
	    //code generation
	    if (verbose) System.out.println("CodeGenerator Started......");
	    FilenameProber fp = new FilenameProber();
	    root.apply(fp);
	    String outputFilename = fp.getFilename();
	    root.apply(new CodeGenerator(library, std, filename, outputFilename, idRecord, prober, idTypeTable));
	    String[] args = new String[1];
	    args[0] = outputFilename + ".j";
	    if (!jOutput) {
		jasmin.Main.main(args);
		new File(args[0]).delete();
	    } else {
		System.out.println("Generated: " + args[0]);
	    }

	} catch(Exception e) {
	    System.out.println(e);
	}
    }

    private static void checkError() {
	if (ErrorList.size() > 0){
	    ErrorList.printErrors();
	    System.exit(-1);
	}
    }
}
