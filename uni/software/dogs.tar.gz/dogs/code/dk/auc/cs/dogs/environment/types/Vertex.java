package dk.auc.cs.dogs.environment.types;

public class Vertex extends GraphType {

    private java.lang.String name;
    private GraphComposite graph;
    
    public Vertex(String name, GraphComposite graph) {
	this(name.getValue(), graph);
    }

    public Vertex(java.lang.String name, GraphComposite graph) {
	this.name = name;
	this.graph = graph;
    }

    public Type duplicate() {
	return this;
    }

    public java.lang.String getName() {
	return name;
    }

    public String getVName() {
	return new String(name);
    }
    
    public Set getEdges() {
	return graph.getEdges(name);
    }
    
    public Set getAdjacents() {
	return graph.getAdjacents(this);
    }

    public GraphComposite getGraph() {
      	return graph;
    }

    public boolean equals(Object o) {
	if (o instanceof Vertex) {
	    Vertex v = (Vertex)o;
	    //	    boolean graph = ;
	    return ((v.getName().equals(name) && v.getGraph().equals(graph)) && (v.getName().equals(this.name)));
	} else {
	    return false;
	}
    }

    public Boolean isEqual(Primitive p) {
	return new Boolean(equals((Object)p));
    }
}
