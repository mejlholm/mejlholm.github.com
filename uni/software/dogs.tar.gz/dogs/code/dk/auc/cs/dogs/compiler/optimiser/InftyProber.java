package dk.auc.cs.dogs.compiler.optimiser;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.analysis.*;
import java.util.ArrayList;

public class InftyProber extends DepthFirstAdapter {
    
    private boolean infty = false;

    public void inAInftyPrimaryExpression(AInftyPrimaryExpression node){
	infty = true;
    }
    
    public boolean isInfty() {
	return infty;
    }
}
