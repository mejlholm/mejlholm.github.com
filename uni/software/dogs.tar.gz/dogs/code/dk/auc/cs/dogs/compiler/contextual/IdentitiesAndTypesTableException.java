package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.contextual.helpers.*;
/**
 * This exception class is used by the identification table
 *
 */
public class IdentitiesAndTypesTableException extends Exception {
    
    public IdentitiesAndTypesTableException(){
	super("Unknown exception");
    }

    public IdentitiesAndTypesTableException(String msg){
	super(msg);
    }

    public IdentitiesAndTypesTableException(String msg, Throwable cause){
	super(msg, cause);
    }
}
