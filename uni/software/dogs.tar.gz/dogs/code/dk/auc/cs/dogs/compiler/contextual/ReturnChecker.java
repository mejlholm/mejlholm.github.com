package dk.auc.cs.dogs.compiler.contextual;

import java.util.*;

import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.node.*;

public class ReturnChecker extends Checker{

    private boolean debug = false;
    private int level = 0;
    private BooleanList blist = new BooleanList(debug);
    private DoubleBooleanList ifElse = new DoubleBooleanList(debug);

    public ReturnChecker() {
	super();
    }

    public void inAReturnBasicCommands(AReturnBasicCommands node) {
	if (level > 0) {
	    if (ifElse.isActive()) {
		// Inside if-else
		ifElse.addToDouble(true);
	    } else if (blist.isReturned()) {
		ErrorList.add(node.getReturn(), "Return already specified");
	    } else {
		blist.setReturned(true);
	    }
	} else {
	    ErrorList.add(node.getReturn(), "Illegal placing of return");
	}
    }

    public void inAFunctionSingleSecondaryDeclaration(AFunctionSingleSecondaryDeclaration node) {
	blist.addReturnLevel();
	if (debug) System.out.println("incrementing level");
	level++;
    }

    public void outAFunctionSingleSecondaryDeclaration(AFunctionSingleSecondaryDeclaration node) {
	if (!blist.isReturned()) {
	    ErrorList.add(node.getFunction(), "No return has been specified");
	}
	blist.removeReturnLevel();
	if (debug) System.out.println("decrementing level");
	level--;
    }

    /* if-then-else */
    public void inAIfOpenElseClosedCommand(AIfOpenElseClosedCommand node) {
	if (level > 0) {
	    ifElse.addReturnLevel();
	}
    }

    public void outAIfOpenElseClosedCommand(AIfOpenElseClosedCommand node) {
	if (level > 0) {
	    boolean b = false;
	    if (ifElse.isBothReturned()) {
		b = true;
	    }
	    ifElse.removeReturnLevel();
	    if (ifElse.isActive()) {
		ifElse.addToDouble(b);
	    } else {
		if (blist.isReturned()) {
		    if (b) {
			ErrorList.add(node.getIf(), "return is already defined outside if-else");
		    }
		} else {
		blist.setReturned(b);
		}
	    }
	}
    }
}

class DoubleBoolean {
    private boolean b1 = false;
    private boolean b2 = false;
    public void setB1 (boolean b) {b1 = b;}
    public void setB2 (boolean b) {b2 = b;}
    public boolean getB1() {return b1;}
    public boolean getB2() {return b2;}
}

class DoubleBooleanList {
    private boolean debug = false;
    private LinkedList returnList = new LinkedList();

    public DoubleBooleanList(boolean debug) {
	this.debug = debug;
    }

    public void addToDouble(boolean b) {
	if (isReturned1()) {
	    setReturned2(b);
	} else {
	    setReturned1(b);
	}
    }

    public boolean isActive() {
	return (returnList.size() > 0);
    }

    private boolean isReturned1() {
	if (debug) System.out.println("isReturned1: returnList.size() = " + returnList.size());
	DoubleBoolean db = (DoubleBoolean) returnList.getLast();
	return db.getB1();
    }

    private boolean isReturned2() {
	if (debug) System.out.println("isReturned2: returnList.size() = " + returnList.size());
	DoubleBoolean db = (DoubleBoolean) returnList.getLast();
	return db.getB2();
    }

    public boolean isBothReturned() {
	if (debug) System.out.println("isBothReturned: returnList.size() = " + returnList.size());
	DoubleBoolean db = (DoubleBoolean) returnList.getLast();
	return (db.getB2() && db.getB2());
    }

    private void setReturned1(boolean b) {
	if (debug) System.out.println("setReturned1: returnList.size() = " + returnList.size());
	DoubleBoolean db = (DoubleBoolean) returnList.getLast();
	db.setB1(b);
    }

    private void setReturned2(boolean b) {
	if (debug) System.out.println("setReturned2: returnList.size() = " + returnList.size());
	DoubleBoolean db = (DoubleBoolean) returnList.getLast();
	db.setB2(b);
    }
    
    public void addReturnLevel() {
	returnList.addLast(new DoubleBoolean());
    }

    public void removeReturnLevel() {
	if (returnList.size() > 0) {
	    returnList.removeLast();
	} else {
	    throw new RuntimeException("size of returnList illegal!");
	}
    }
}

class BooleanList {
    private boolean debug = false;
    private LinkedList returnList = new LinkedList();

    public BooleanList(boolean debug) {
	this.debug = debug;
    }

    public boolean isReturned() {
	if (debug) System.out.println("isReturned: returnList.size() = " + returnList.size());
	if (returnList.size() > 0) {
	    Boolean b = (Boolean) returnList.getLast();
	    return b.booleanValue();
	} else {
	    return false;
	}
    }

    public void setReturned(boolean b) {
	if (debug) System.out.println("setReturned: returnList.size() = " + returnList.size());
	returnList.removeLast();
	returnList.addLast(new Boolean(b));
    }
    
    public void addReturnLevel() {
	if (debug) System.out.println("addReturnLevel");
	returnList.addLast(new Boolean(false));
    }

    public void removeReturnLevel() {
	if (returnList.size() > 0) {
	    returnList.removeLast();
	} else {
	    throw new RuntimeException("size of returnList illegal!");
	}
    }
}
