package dk.auc.cs.dogs.environment.types;

public interface WeightEdge extends WeightInterface {
}