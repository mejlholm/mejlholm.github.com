package dk.auc.cs.dogs.environment.types;

public class Edge extends GraphType {

    private java.lang.String name;
    private Vertex v1, v2;
    
    public Edge(Vertex v1, Vertex v2) {
	this.v1 = v1;
	this.v2 = v2;
    }

    public Type duplicate() {
	return this;
    }

   public boolean addToGraph(GraphComposite g) {
	return g.addEdge(this);
    }

    public Vertex getVertex1() {
	return v1;
    }

    public Vertex getVertex2() {
	return v2;
    }

    public boolean sameGraph() {
	return (v1.getGraph().equals(v2.getGraph()));
    }

    public boolean equals(Object o) {
	boolean result = false;
	if (o instanceof Edge) {
	    Edge e = (Edge)o;
	    if ((e.v1.getGraph() instanceof Graph) && (e.v2.getGraph() instanceof Graph)) {
		// If normal graph, (v1, v2) equals (v2, v1)
		result = ((e.v1.equals(v1) && e.v2.equals(v2)) || (e.v1.equals(v2) && e.v2.equals(v1)));
	    } else {
		result = (e.v1.equals(v1) && e.v2.equals(v2));
	    }
	}
	return result;
    }
    
    public Boolean isEqual(Primitive p) {
	return new Boolean(equals(p));
    }

}
