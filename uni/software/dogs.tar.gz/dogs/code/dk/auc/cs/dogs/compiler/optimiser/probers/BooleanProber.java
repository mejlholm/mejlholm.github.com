package dk.auc.cs.dogs.compiler.optimiser.probers;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.optimiser.InftyProber;

import java.util.ArrayList;

public class BooleanProber extends TypeProber {

    private ArrayList expressions = new ArrayList();
    private ArrayList types = new ArrayList();
    private ArrayList nodes = new ArrayList();
    private boolean negativeInfty = false;

    public BooleanProber() {
	super();
    }

    public void inAExpression(AExpression node){
	cleanLists();
    }

    //// Logic Expressions ///
    /// tokens ////
    public void caseALtLessGreaterExpr(ALtLessGreaterExpr node)
    {
        inALtLessGreaterExpr(node);
        if(node.getLessGreaterExpr() != null)
        {
            node.getLessGreaterExpr().apply(this);
        }
        if(node.getLt() != null)
        {
            node.getLt().apply(this);
	    add(node, "", node.getLt().getText());
        }
        if(node.getPlusMinusExpr() != null)
        {
            node.getPlusMinusExpr().apply(this);
        }
        outALtLessGreaterExpr(node);
    }

    public void caseALteqLessGreaterExpr(ALteqLessGreaterExpr node){
        inALteqLessGreaterExpr(node);
        if(node.getLessGreaterExpr() != null)
        {
            node.getLessGreaterExpr().apply(this);
        }
        if(node.getLteq() != null)
        {
            node.getLteq().apply(this);
	    add(node, "", node.getLteq().getText());
        }
        if(node.getPlusMinusExpr() != null)
        {
            node.getPlusMinusExpr().apply(this);
        }
        outALteqLessGreaterExpr(node);
    }

    public void caseAGteqLessGreaterExpr(AGteqLessGreaterExpr node){
        inAGteqLessGreaterExpr(node);
        if(node.getLessGreaterExpr() != null)
        {
            node.getLessGreaterExpr().apply(this);
        }
        if(node.getGteq() != null)
        {
            node.getGteq().apply(this);
	    add(node, "", node.getGteq().getText());
        }
        if(node.getPlusMinusExpr() != null)
        {
            node.getPlusMinusExpr().apply(this);
        }
        outAGteqLessGreaterExpr(node);
    }

    public void caseAGtLessGreaterExpr(AGtLessGreaterExpr node){
        inAGtLessGreaterExpr(node);
        if(node.getLessGreaterExpr() != null)
        {
            node.getLessGreaterExpr().apply(this);
        }
        if(node.getGt() != null)
        {
            node.getGt().apply(this);
	    add(node, "", node.getGt().getText());
        }
        if(node.getPlusMinusExpr() != null)
        {
            node.getPlusMinusExpr().apply(this);
        }
        outAGtLessGreaterExpr(node);
    }

    public void caseAEqualCompareExpr(AEqualCompareExpr node){
        inAEqualCompareExpr(node);
        if(node.getCompareExpr() != null)
        {
            node.getCompareExpr().apply(this);
        }
        if(node.getEqual() != null)
        {
            node.getEqual().apply(this);
	    add(node, "", node.getEqual().getText());
        }
        if(node.getLessGreaterExpr() != null)
        {
            node.getLessGreaterExpr().apply(this);
        }
        outAEqualCompareExpr(node);
    }

    public void caseANotEqualCompareExpr(ANotEqualCompareExpr node)
    {
        inANotEqualCompareExpr(node);
        if(node.getCompareExpr() != null)
        {
            node.getCompareExpr().apply(this);
        }
        if(node.getNeq() != null)
        {
            node.getNeq().apply(this);
	    add(node, "", node.getNeq().getText());
        }
        if(node.getLessGreaterExpr() != null)
        {
            node.getLessGreaterExpr().apply(this);
        }
        outANotEqualCompareExpr(node);
    }


    //// words ////
    public void caseANotNotExpr(ANotNotExpr node){
        inANotNotExpr(node);
        if(node.getNot() != null)
        {
            node.getNot().apply(this);
	    add(node, "", node.getNot().getText());
        }
        if(node.getNotExpr() != null)
        {
            node.getNotExpr().apply(this);
        }
        outANotNotExpr(node);
    }

    public void caseAAndAndExpr(AAndAndExpr node)
    {
        inAAndAndExpr(node);
        if(node.getAndExpr() != null)
        {
            node.getAndExpr().apply(this);
        }
        if(node.getAnd() != null)
        {
            node.getAnd().apply(this);
	    add(node, "", node.getAnd().getText());
        }
        if(node.getNotExpr() != null)
        {
            node.getNotExpr().apply(this);
        }
        outAAndAndExpr(node);
    }

    public void caseAXorOrExpr(AXorOrExpr node)
    {
        inAXorOrExpr(node);
        if(node.getOrExpr() != null)
        {
            node.getOrExpr().apply(this);
        }
        if(node.getXor() != null)
        {
            node.getXor().apply(this);
	    add(node, "", node.getXor().getText());
        }
        if(node.getAndExpr() != null)
        {
            node.getAndExpr().apply(this);
        }
        outAXorOrExpr(node);
    }

    public void caseAOrOrExpr(AOrOrExpr node)
    {
        inAOrOrExpr(node);
        if(node.getOrExpr() != null)
        {
            node.getOrExpr().apply(this);
        }
        if(node.getOr() != null)
        {
            node.getOr().apply(this);
	    add(node, "", node.getOr().getText());
        }
        if(node.getAndExpr() != null)
        {
            node.getAndExpr().apply(this);
        }
        outAOrOrExpr(node);
    }






    //// TYPES ////


    public void inAIntegerPrimaryExpression(AIntegerPrimaryExpression node){
	nodes.add(node);
	types.add("i");
	expressions.add(node.getIntegerLiteral().getText());
    }

    public void inAFloatPrimaryExpression(AFloatPrimaryExpression node){
	nodes.add(node);
	types.add("f");
	expressions.add(node.getFloatLiteral().getText());
    }

    public void inAInftyPrimaryExpression(AInftyPrimaryExpression node){
	nodes.add(node);
	types.add("inf");
	expressions.add(node.getInfty().getText());
    }

    public void inABooleanPrimaryExpression(ABooleanPrimaryExpression node){
	nodes.add(node);
	types.add("b");
	expressions.add(node.getBooleanLiteral().getText());
    }
    
    public void inAUnaryMinusPlusMinusExpr(AUnaryMinusPlusMinusExpr node) {
	InftyProber ip = new InftyProber();
	node.apply(ip);
	if (ip.isInfty()) {
	    negativeInfty = !negativeInfty;
	}
    }

    //// Misc. Methods ////

    private void add(Node node, String type, String expr) {
	nodes.add(node);
	types.add(type);
	expressions.add(expr);
    }

    public boolean getNegativeInfty() {
	return negativeInfty;
    }
    
    public String getType(int i)  {
	return (String)types.get(i);
    }

    public String getExpression(int i) {
	return (String)expressions.get(i);
    }

    public Node getNode(int i)  {
	return (Node) nodes.get(i);
    }
    
    public void cleanLists(){
	nodes.clear();
	expressions.clear();
	types.clear();
    }

    public int size(){
	return expressions.size();
    }

    public void print(){
	System.out.println("Left in the list:");
	for (int i=0; i < expressions.size(); i++){
	    System.out.print("" + expressions.get(i));
	    System.out.println(" " + types.get(i));
	}
    }

}
