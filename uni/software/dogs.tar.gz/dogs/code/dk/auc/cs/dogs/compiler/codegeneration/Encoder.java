package dk.auc.cs.dogs.compiler.codegeneration;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.libraryhandler.Library;
import dk.auc.cs.dogs.compiler.node.*;

import java.io.*;
import java.util.*;

/**
 * Encoder.java
 *
 *
 * Created: Mon May 17 16:56:12 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public abstract class Encoder extends DepthFirstAdapter {

    public FunctionProcedureProber prober;
    public String sourcefile;
    public String objectfile;
    public Library lib;
    public StandardEnvironment std;
    public VariableMap vmap = new VariableMap();
    public IdentificationTableRecord idRecord = null;
    public IdentitiesAndTypesTable idTypeTable;
    public CodeWriter cw = null;
    public boolean assign = false;


    //HAX
    //private HashMap wList = new HashMap();
    //private HashMap lList = new HashMap();


    private boolean debug = false;

    public Encoder(Library lib, StandardEnvironment std, String sourcefile, String objectfile, IdentificationTableRecord idRecord, FunctionProcedureProber prober, IdentitiesAndTypesTable idTypeTable) {
	this.lib = lib;
	this.std = std;
	this.idRecord = idRecord;
	this.idTypeTable = idTypeTable;
	this.prober = prober;
	this.objectfile = objectfile;//"" + objectfile.substring(0,1).toUpperCase() + objectfile.substring(1);
	this.sourcefile = sourcefile.substring(1 + sourcefile.lastIndexOf('/'));

	cw = new CodeWriter(objectfile, true);
    } // Encoder constructor

    public Encoder() {
	
    } // Encoder constructor

    public final void caseABeginEndBasicCommands(ABeginEndBasicCommands node)
    {
	cw.addIndentScope();
        inABeginEndBasicCommands(node);
        if(node.getBegin() != null) 
        {
            node.getBegin().apply(this);
        }
        {
            Object temp[] = node.getSingleCommand().toArray();
            for(int i = 0; i < temp.length; i++)
            {
                ((PSingleCommand) temp[i]).apply(this);
            }
        }
        if(node.getEnd() != null)
        {
            node.getEnd().apply(this);
        }
        outABeginEndBasicCommands(node);
	cw.removeIndentScope();
    }

    String patherify(String vname){
	String output = "";
	output = vname.replace('.', '/');
	return output;
    }

    String parameterify(String vname){
	String output = "";
	try{
	    ArrayList types = prober.getTypes(vname);
	    ArrayList flags = prober.getFlags(vname);
	    String parameters = "";
	    String identifier, idFlag;
	    for (int i = 0; i < types.size(); i++){
		identifier = upperify((String)types.get(i));
		idFlag = (String)flags.get(i);
		//System.out.println("id: " + identifier + " - " + idFlag);
		if ((idFlag.equals("variable")) && (identifier.equals("Integer") || identifier.equals("Float"))) {
		    identifier += "Number";
		} else if (identifier.substring(0, 3).equals("Std")) {
		    identifier = identifier.substring(3) + "Interface";
		} else {
		    if (!idFlag.equals("variable")) {
			    identifier = upperify(idFlag) + identifier;
			}
		}
		//		System.out.println("new identifier: " + identifier);
		parameters = parameters + "Ldk/auc/cs/dogs/environment/types/" + identifier + ";";
	    }
	    output = parameters;
	} catch (FunctionProcedureProberException fppe){
	
	}

	return output;
    }

    String returnerify(String vname){
	//System.out.println("returnerify start");
	String output = "";
	ArrayList returns = null;
	Node rNode = null;
	IdentitiesAndTypesTableElements idatte = null;
	String returnv = "";
	
	try{
	    //System.out.println("is in table?");
	    if (prober.isInTable(vname)) {
		returns = prober.getReturnType(vname);
		returnv = (String)returns.get(0);
	    } else {
		// weight or label function
		idatte = idTypeTable.getIdentifier(vname);
		returnv = idatte.getType();
	    }
	    //System.out.println("flaffer");
	    String objectname = "";
	    String identifier, idFlag;



	    if (returnv.equals("void")){
		objectname = "V";
	    } else{

		identifier = upperify(returnv);

		idFlag = (String)prober.getReturnType(vname).get(1);
		//System.out.println("id: " + identifier + " - " + idFlag);
		if ((idFlag.equals("variable")) && (identifier.equals("Integer") || identifier.equals("Float"))) {
		    identifier += "Number";
		} else if (identifier.substring(0, 3).equals("Std")) {
		    identifier = identifier.substring(3) + "Interface";
		} else if (identifier.substring(0, 3).equals("set")) {
		    //System.out.println("haxing: " + identifier);
		    identifier = identifier.substring(3) + "Interface";
		} else {
		    if (!idFlag.equals("variable")) {
			identifier = upperify(idFlag) + identifier;
		    }
		}
// 		if (identifier.substring(0, 3).equals("Set")) {
// 		    System.out.println("maffer: " + identifier);
// 		    identifier = identifier.substring(3) + "Interface";
// 		}

		//		if (tmp.equals("Integer") || tmp.equals("Float")) {
		//    tmp += "Number";
		//}
		objectname = "Ldk/auc/cs/dogs/environment/types/" + identifier + ";";
	    }
	    output = objectname;
	} catch (FunctionProcedureProberException fppe){
	    throw new RuntimeException("Decoder: exception in returnerify: " + fppe.getMessage());
	}
	//	System.out.println("returnerify end");
	//System.out.println("return value for " + vname + " is: " + output);
	return output;
    }

    
    java.lang.String arrayify(java.lang.String str){
	return str.replace(':', ' ').replace('=', ' ').replace('{', ' ')
	    .replace('}', ' ').replaceAll("[\\s][,][\\s]", ",").replaceAll("[\"]", "\\\"").trim();
    }

    String upperify(String str){
	return  "" + str.substring(0,1).toUpperCase() + str.substring(1);
    }

    void boolEval() {
	cw.codePrintln("; Evaluating boolean");
	cw.codePrintln("invokevirtual dk/auc/cs/dogs/environment/types/Boolean/getValue()Z");
    }

    // makes the first character uppercase
    String makeType(String str) {
	str = str.trim();
	return str.substring(0, 1).toUpperCase() + str.substring(1);
    }

    void addWeight(String idName, String type) {
	idName = idName.trim();
	//wList.put(idName.trim(), type);
	//System.out.println("adding weight '" + idName + "' " + isWeight(idName));
    }

    boolean isWeight(String idName) {
	idName = idName.trim();
	boolean result = false;
	//	System.out.println("checking weight '" + idName + "'");
	//	return wList.containsKey(idName.trim());
	if (idTypeTable.getIdentifier(idName) != null) {
	    //	    System.out.println("haffanaffa - !null");
	    String id = idTypeTable.getIdentifier(idName).getType();
	    String flag = idTypeTable.getIdentifier(idName).getFlag();
	    //	System.out.println("flag: " + flag + " - " + id);
	    result = flag.equals("weight");
	}
	return result;
    }

    String getWeightType(String idName) {
	//	String str = (String)wList.get(idName.trim());
	String str = idTypeTable.getIdentifier(idName).getType();
	if (str.equals("integer") || str.equals("float")) {
	    str = str + "Number";
	}
	return makeType(str);
    }
    
    void addLabel(String idName, String type) {
	idName = idName.trim();
	//lList.put(idName.trim(), type);
	//	System.out.println("adding label '" + idName + "' " + isLabel(idName));
    }

    boolean isLabel(String idName) {
	idName = idName.trim();
	boolean result = false;
	//	System.out.println("checking label '" + idName + "'");
	//	return lList.containsKey(idName.trim());
	if (idTypeTable.getIdentifier(idName) != null) {
	    //	    System.out.println("haffanaffa - !null");
	    String id = idTypeTable.getIdentifier(idName).getType();
	    String flag = idTypeTable.getIdentifier(idName).getFlag();
	    //	System.out.println("flag: " + flag + " - " + id);
	    result = flag.equals("label");
	}
	return result;
    }

    String getLabelType(String idName) {
	//	String str = (String)lList.get(idName.trim());
	String str = idTypeTable.getIdentifier(idName).getType();
	if (str.equals("integer") || str.equals("float")) {
	    str = str + "Number";
	}
	return makeType(str);
    }


    void castToType(java.lang.String type) {
	if (debug) System.out.println("casting to " + type);
	cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/" + makeType(type));
    }

} // Encoder
