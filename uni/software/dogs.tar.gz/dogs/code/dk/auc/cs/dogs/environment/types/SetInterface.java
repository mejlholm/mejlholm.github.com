package dk.auc.cs.dogs.environment.types;

import java.util.LinkedList;
import java.util.Iterator;
import java.io.*;

public interface SetInterface extends CompositeIterable {

    public Integer size();
    public Boolean isEmpty();
    public Iterator getIterator(java.lang.String type);
    public void add(Primitive element);
    public void remove(Primitive element);
    public int exists(Primitive element);
    public void clear();
}