package dk.auc.cs.dogs.environment;

import dk.auc.cs.dogs.environment.types.*;
import dk.auc.cs.dogs.environment.types.String;
import dk.auc.cs.dogs.environment.types.Integer;
import dk.auc.cs.dogs.environment.types.Float;
import dk.auc.cs.dogs.environment.types.ArrayInterface;
import dk.auc.cs.dogs.environment.types.Boolean;

import java.io.*;

public class Standard {
    private Standard() {
	
    }

    public static void version() {
	System.out.println("dogs environment, ver. 1.0");
    }
    

    /*
      CONVERSION METHODS
    */

    // function string integerToString(integer i)
    public static String integerToString(IntegerNumber i) {
	return new String(i.toString());
    }

    // function string floatToString(float i)
    public static String floatToString(FloatNumber f) {
	return new String(f.toString());
    }

    // function integer round(float i)
    public static IntegerNumber round(FloatNumber f) {
	return f.round();
    }

    // function string booleanToString(boolean b)
    public static String booleanToString(Boolean b) {
	return new String(b.toString());
    }

    // function integer stringToInteger(string s)
    public static IntegerNumber stringToInteger(String s) {
	java.lang.String str = s.getValue().trim();
	if (str.equals("infty") || str.equals("-infty")) {
	    return new Infty(!str.substring(0, 1).equals("-"));
	} else {
	    Long l = new Long(str);
	    return new Integer(l.longValue());
	}
    }

    // function integer stringToFloat(string s)
    public static FloatNumber stringToFloat(String s) {
	java.lang.String str = s.getValue().trim();
	if (str.equals("infty") || str.equals("-infty")) {
	    return new Infty(!str.substring(0, 1).equals("-"));
	} else {
	    Double d = new Double(str);
	    return new Float(d.doubleValue());
	}
    }

    // function boolean stringToBoolean(string s)
    public static Boolean stringToBoolean(String s) {
	java.lang.String str = s.getValue().trim();
	return new Boolean(java.lang.Boolean.valueOf(str).booleanValue());
    }

    // function array of string explodeString(string s, string pattern)
    public static Array explodeString(String s, String pattern) {
	java.lang.String str = s.getValue();

	java.lang.String[] content = str.split(pattern.getValue());

	Array arr = new Array(content);

	if (arr.size() < 1) {
	    arr = new Array("String", "[1]");
	    arr.setValue("[1]", new String(str));
	}
	return arr;

// 	arr = new Array("String", "[]");
// 	int index;
// 	if ((index = str.indexOf(pattern.getValue())) != -1) {
// 	    java.lang.String ss;
// 	    do {
// 		ss = str.substring(0, index);
// 		arr.add(new String(ss));
// 		str = str.substring(index + pattern.getValue().length());
// 	    } while ((index = str.indexOf(pattern.getValue())) != -1);
// 	} else {
// 	    arr.add(new String(str));
// 	}
// 	return arr;
    }


    /*
      I/O METHODS
    */

    // procedure exit(string message)
    public static void exit(String message) {
	System.out.println(message.getValue());
	System.exit(0);
    }

    // procedure print(string message)
    public static void print(String message) {
	System.out.println(message.getValue());
    }

    // function boolean fileExists(string filename)
    public static Boolean fileExists(String filename) {
	return new Boolean(new File(filename.getValue()).exists());
    }

    // function string readFile(string filename)
    public static String readFile(String filename) {
	java.lang.String str = "";
	try {
	    FileReader file = new FileReader(filename.getValue());
	    char[] buffer = {};
	    int i;
	    while ((i = file.read()) != -1) {
		str += (char)i;
	    }
	} catch (Exception e) {
	    throw new RuntimeException("the file '" + filename.getValue() + "' could not be read (" + e.getMessage() + ")");
	}
	return new String(str);
    }

    // function boolean writeFile(string filename, string content)
    public static Boolean writeFile(String filename, String content) {
	return writeContent(filename, content.getValue(), false);
    }

    // function boolean appendToFile(string filename, string content)
    public static Boolean appendToFile(String filename, String content) {
	return writeContent(filename, "\n" + content.getValue(), true);
    }

    private static Boolean writeContent(String filename, java.lang.String content, boolean append) {
	boolean result = false;
	try {
	    java.lang.String fn = filename.getValue().replaceAll("\\", "/");
	    FileWriter fw = new FileWriter(fn, append);
	    fw.write(content);
	    fw.flush();
	    fw.close();
	    result = true;
	} catch(Exception e) {
	    System.err.println("Could not write to file '" + filename + "' (" + e.getMessage() + ")");
	}
	return new Boolean(result);
    }


    // function string readStringInput()
    public static String readStringInput() {
	int ch;
	java.lang.String r = "";
	boolean done = false;
	while (!done) {
	    try {
		ch = System.in.read();
		if (ch < 0 || (char)ch == '\n')
		    done = true;
		else if ((char)ch != '\r') // weird--it used to do \r\n translation
		    r = r + (char) ch;
	    }catch(java.io.IOException e) {
		done = true;
	    }
	}
	return new String(r);
    }

    // function integer readIntegerInput()
    public static IntegerNumber readIntegerInput(){
	while(true) {
	    try {
		return new Integer(Long.valueOf(readStringInput().getValue().trim()).longValue());
	    } catch( NumberFormatException e) {
		System.out.println("Not an integer. Please try again!");
	    }
	}
    }

    // function integer readFloatInput()
    public static FloatNumber readFloatInput(){
	while(true) {
	    try {
		return new Float(Double.valueOf(readStringInput().getValue().trim()).doubleValue());
	    } catch( NumberFormatException e) {
		System.out.println("Not a float. Please try again!");
	    }
	}
    }



    /*
      ARRAY METHODS
    */
    
    // function integer arrayDimensions(array a)
    public static Integer arrayDimensions(ArrayInterface a) {
	return new Integer(a.dimSize());
    }

    // function integer arrayDimSize(array a, integer dim)
    public static Integer arrayDimSize(ArrayInterface a, Integer dim) {
	return new Integer(a.dimSize(dim.getIntegerValue()));
    }


    /*
      SET METHODS
    */
    
    // procedure addToSet(set S, primitive p)
    public static void addToSet(SetInterface s, Primitive p) {
	s.add(p);
    }

    // procedure removeFromSet(set S, primitive p)
    public static void removeFromSet(SetInterface s, Primitive p) {
	if (p == null) {
	    System.out.println("null!");
	}
	s.remove(p);
    }

    // function boolean isInSet(set S, primitive p)
    public static Boolean inSet(SetInterface s, Primitive p) {
	return new Boolean(s.exists(p) != -1);
    }

    // function integer sizeOfSet(set s)
    public static IntegerNumber sizeOfSet(SetInterface s) {
	return s.size();
    }

    // function boolean isSetEmpty(set s)
    public static Boolean isSetEmpty(SetInterface s) {
	return s.isEmpty();
    }

    /*
      GRAPH METHODS
    */

    // function string nameOfVertex(vertex v)
    public static String nameOfVertex(Vertex v) {
	return v.getVName();
    }

    // function vertex addVertex(graphComposite G, string name)
    public static Vertex addVertex(GraphComposite g, String name) {
	return g.addVertex(name);
    }

    // procedure removeVertex(graphComposite G, vertex v)
    public static void removeVertex(GraphComposite g, Vertex v) {
	g.removeVertex(v);
    }

    // function set of vertex vertices(graphComposite G)
    public static SetInterface vertices(GraphComposite g) {
	return g.getVertices();
    }

    // function set of edge edges(graphComposite G)
    public static SetInterface edges(GraphComposite g) {
	return g.getEdges();
    }

    // function set of vertex adjecent(vertex v)
    public static SetInterface adjacent(Vertex v) {
	return v.getGraph().getAdjacents(v);
    }

    // function boolean isEdge(vertex v1, vertex v2)
    public static Boolean isEdge(Vertex v1, Vertex v2) {
	v1.getGraph().equals(v2.getGraph());
	return new Boolean(v1.getGraph().hasEdge(v1, v2));
    }

    // function vertex getVertex(graphComposite g, string name)
    public static Vertex getVertex(GraphComposite g, String name) {
	return g.getVertex(name);
    }

    // function edge getEdge(graphComposite g, vertex v1, vertex v2)
    public static Edge getEdge(GraphComposite g, Vertex v1, Vertex v2) {
	return g.getEdge(v1, v2);
    }

    // function boolean addEdge(graphComposite G, edge e)
    public static Boolean addEdge(GraphComposite g, Edge e) {
	return new Boolean(g.addEdge(e));
    }

//     // function edge makeEdge(graphComposite G, vertex v1, vertex v2)
//     public static Edge makeEdge(GraphComposite g, Vertex v1, Vertex v2) {
// 	Edge e = new Edge(v1, v2);
// 	if (!g.addEdge(e) && !g.isEdge(e.getVertex1(), e.getVertex2())) {
// 	    throw new RuntimeException("The edge cannot be added to the graph");
// 	}
// 	return e;
//     }
}
