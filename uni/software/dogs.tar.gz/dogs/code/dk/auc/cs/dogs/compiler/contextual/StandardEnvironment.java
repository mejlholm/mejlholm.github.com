package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.node.*;
import java.util.HashMap;

/**
 * StandardEnvironment.java
 *
 *
 * Created: Fri Apr 30 10:42:14 2004
 *
 * @author <a href="mailto:aaby@gentoo.org"></a>
 * @version 1.0
 */
public class StandardEnvironment {

    private HashMap hmap = new HashMap();

    
    /**
     * Creates a new <code>StandardEnvironment</code> instance by
     * entering our standard types
     *
     */
    public StandardEnvironment() {
	hmap.put("string", null);
	hmap.put("float", null);
	hmap.put("integer", null);
	hmap.put("boolean", null);
	hmap.put("array", null);
	hmap.put("set", null);
	hmap.put("vertex", null);
	hmap.put("edge", null);
	hmap.put("graph", null);
	hmap.put("diGraph", null);
    } // StandardEnvironment constructor
    
    public void enter(String type, Node node) throws StandardEnvironmentException{
	if (knownType(type)){
	    throw new StandardEnvironmentException("Type already exists");
	}
	else{
	    hmap.put(type, node);
	}
    }

    public boolean knownType(String type){
	boolean value = false;
	if (hmap.containsKey(type)){
	    value = true;
	}
	return value;
    }

    public boolean isRecord(String recordName) {
	if (knownType(recordName) && hmap.get(recordName) != null) {
	    return true;
	}
	return false;
    }

    public ARecordDeclaration getRecord(String recordname) throws StandardEnvironmentException{
	ARecordDeclaration node = new ARecordDeclaration();
	if (!knownType(recordname)){
	    throw new StandardEnvironmentException("Not a known type");
	} else{
	    node = (ARecordDeclaration) hmap.get(recordname);
	}
	return node;
    }

} // StandardEnvironment
