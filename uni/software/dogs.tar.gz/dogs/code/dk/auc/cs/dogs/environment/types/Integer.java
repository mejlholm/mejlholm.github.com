package dk.auc.cs.dogs.environment.types;

public class Integer extends Reading implements IntegerNumber {
    
    private long value;

    public Integer(long i) {
	super();
	value = i;
    }

    public java.lang.String toString() {
	return "" + value;
    }

    public Type duplicate() {
	return new Integer(value);
    }

    public Integer duplicate(boolean b) {
	return new Integer(value);
    }

    /*************************
     * Arithmetic operations *
     *************************/

    public void increment() {
	value++;
    }

    public void decrement() {
	value--;
    }

    public Float addition(Float f) {
	return new Float(value + f.getValue());
    }

    public NumberNumber addition(Integer i) {
	return new Integer(value + i.getIntegerValue());
    }


    public Float subtraction(Float f) {
	return new Float(value - f.getValue());
    }

    public NumberNumber subtraction(Integer i) {
	return new Integer(value - i.getIntegerValue());
    }


    public Float multiplication(Float f) {
	return new Float(value * f.getValue());
    }

    public NumberNumber multiplication(Integer i) {
	return new Integer(value * i.getIntegerValue());
    }

    public Float division(Integer i) {
	return new Float(value / i.getValue());
    }

    public Float division(Float f) {
	return new Float(value / f.getValue());
    }

    public Integer modulus(Integer i) {
	return new Integer(value % i.getIntegerValue());
    }

    public Integer integerDivision(Integer i) {
	return new Integer((int) value / i.getIntegerValue());
    }

    /*  */
    public double getValue() {
	return (double) value;
    }

    public long getIntegerValue() {
	return value;
    }
    
    private void floatError() {
	throw new RuntimeException("Float values cannot be assigned to integers");
    }

}
