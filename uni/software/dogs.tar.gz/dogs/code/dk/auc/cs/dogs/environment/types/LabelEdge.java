package dk.auc.cs.dogs.environment.types;

public interface LabelEdge extends LabelInterface {
}