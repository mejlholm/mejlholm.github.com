package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.libraryhandler.*;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;

import java.util.*;

public class TypeChecker extends Checker {

    // Uses the super classes variables
    private IdentitiesAndTypesTable idTypeTable = new IdentitiesAndTypesTable();
    private IdentificationTable idTable;
    private StandardEnvironment stdEnv = new StandardEnvironment();
    private String lastType = new String();
    private boolean isAConstant = false;
    private IdentificationTableRecord idRecord = null;
    private FunctionProcedureProber prober = null;
    private PackageImporterChecker packageImporter = null;
    private Library lib = null;
    private String procedureCallName = null; // used user CallBasicCommand
    private String nameToReturn = null;
    private boolean labelWeightFound = false;
    private String labelOrWeight = new String();
    private String labelOrWeightType = new String();
    private boolean debug = false;
    private boolean assignment = false;

    // Empty default constructor
    public TypeChecker(StandardEnvironment stdEnv, Library lib, FunctionProcedureProber prober, IdentificationTableRecord idRecord, IdentitiesAndTypesTable idTypeTable) {
	this.stdEnv = stdEnv;
	this.lib = lib;
	this.prober = prober;
	this.idRecord = idRecord;
	this.idTypeTable = idTypeTable;
	idTable =  new IdentificationTable(idTypeTable);
    }

    public void caseStart(Start node) {
	// Apply the prober to find functions and procedures in the tree
	node.getPProgram().apply(prober);
	// Apply to load package into the typechecker
	packageImporter = new PackageImporterChecker(idRecord, prober, lib);
	node.getPProgram().apply(packageImporter);
	//Apply the typechecker "this" to the tree
	node.getPProgram().apply(this);
        node.getEOF().apply(this);
    }

    public void inAConstDeclaration(AConstDeclaration node) {
	isAConstant = true;
    }

    public void outAConstDeclaration(AConstDeclaration node) {
	isAConstant = false;
    }

    
    public void inASetArrayVarSingleDeclaration(ASetArrayVarSingleDeclaration node) {
        if(node.getDeclarationAssignment() != null) {
	    assignment = true;
        }
    }

    // Declaration of singel varibale
    public void outAVariableDeclaration(AVariableDeclaration node) {
	try {
	    if (stdEnv.knownType(node.getType().getText())) {
		if (stdEnv.isRecord(node.getType().getText())) {
		    idTable.enter(node.getName().getText(), stdEnv.getRecord(node.getType().getText()), false);
		    lastType = node.getType().getText();
		    if (lastType.equals("graph") || lastType.equals("diGraph")) {
			assignment = false;
		    }
		    if (isAConstant && (lastType.equals("graph") || lastType.equals("diGraph"))) {
			throw new IdTableException(lastType + " can not be a constant");
		    }
		    if (lastType.equals(node.getName().getText())) {
			throw new IdTableException(lastType + " can not be named " + node.getName().getText() + " because it is a type");
		    }
		} else {
		    idTable.enter(node.getName().getText(), node, isAConstant);
		    lastType = node.getType().getText();
		}
	    } else {
		ErrorList.add(node.getType(), "unknown type");
	    }
	} catch(IdTableException e) {
	    ErrorList.add(node.getName(), e.getMessage());
	} catch(StandardEnvironmentException e) {
	    ErrorList.add(node.getName(), e.getMessage());
	}
    }

    // Declaration of arrays
    public void inAArrayDeclaration(AArrayDeclaration node) {
	try {
	    if (stdEnv.knownType(node.getType().getText())) {
		idTable.enter(node.getName().getText(), node, isAConstant);
		lastType = node.getType().getText();
	    } else {
		ErrorList.add(node.getName(), "unknown type");
	    }
	} catch(IdTableException e) {
	    ErrorList.add(node.getName(), e.getMessage());
	}
    }

    public void inASetDeclaration(ASetDeclaration node) {
	try {
	    if (stdEnv.knownType(node.getType().getText())) {
		idTable.enter(node.getName().getText(), node, isAConstant);
		lastType = node.getType().getText();
		assignment = false;
		if (isAConstant) {
		    throw new IdTableException(lastType + " can not be a constant");
		}
	    } else {
		ErrorList.add(node.getName(), "unknown type");
	    }
	} catch(IdTableException e) {
	    ErrorList.add(node.getName(), e.getMessage());
	}
    }

    public void inAWeightWeightLabelDeclaration(AWeightWeightLabelDeclaration node) {
	try {
	    if (stdEnv.knownType(node.getType().getText())) {
		if (!node.getType().getText().equals("graph") || !node.getType().getText().equals("diGraph")) {
		    idTable.enter(node.getName().getText(), node, isAConstant);
		    lastType = node.getType().getText();
		} else {
		    throw new IdTableException("Can not make a weight of type " + node.getType().getText());
		}
	    } else {
		ErrorList.add(node.getName(), "unknown type");
	    }
	} catch(IdTableException e) {
	    ErrorList.add(node.getName(), e.getMessage());
	}
    }

    public void inALabelWeightLabelDeclaration(ALabelWeightLabelDeclaration node) {
	try {
	    if (stdEnv.knownType(node.getType().getText())) {
		if (!node.getType().getText().equals("graph") || !node.getType().getText().equals("diGraph")) {
		    idTable.enter(node.getName().getText(), node, isAConstant);
		    lastType = node.getType().getText();
		} else {
		    throw new IdTableException("Can not make a weight of type " + node.getType().getText());
		}
	    } else {
		ErrorList.add(node.getName(), "unknown type");
	    }
	} catch(IdTableException e) {
	    ErrorList.add(node.getName(), e.getMessage());
	}
    }

    // Declaration of procedure
    public void caseAProcedureSingleSecondaryDeclaration(AProcedureSingleSecondaryDeclaration node) {
	FormalParameterSequenceExtractor fpse;

	if(debug)System.out.println("Procedure: " + node.getIdentifier().getText());

	idTypeTable.openScope();
	try {
	    idTable.enter(node.getIdentifier().getText(), node, false);
	} catch(IdTableException e) {
	    ErrorList.add(node.getIdentifier(), e.getMessage());
	}
    	idTable.openScope();

	// The apply stuff
        if(node.getFormalParameterSequence() != null) {
	    fpse = new FormalParameterSequenceExtractor(idTable, stdEnv);
            node.getFormalParameterSequence().apply(fpse);
        }
        if(node.getCommand() != null) {
            node.getCommand().apply(this);
        }

	// Leaving the procedure
	try {
	    idTable.closeScope();
	    idTypeTable.closeScope(node.getIdentifier().getText());
	} catch (IdTableException e) {
	    ErrorList.add(node.getIdentifier(), e.getMessage());
	}
    }

    // Declaration of function
    public void caseAFunctionSingleSecondaryDeclaration(AFunctionSingleSecondaryDeclaration node) {
	FormalParameterSequenceExtractor fpse;

	idTypeTable.openScope();
	try {
	    idTable.enter(node.getIdentifier().getText(), node, false);
	    nameToReturn = node.getIdentifier().getText();
	} catch(IdTableException e) {
	    ErrorList.add(node.getIdentifier(), e.getMessage());
	}
    	idTable.openScope();
	
	// Apply stuff
        if(node.getFormalParameterSequence() != null) {
	    fpse = new FormalParameterSequenceExtractor(idTable, stdEnv);
            node.getFormalParameterSequence().apply(fpse);
        }

        if(node.getCommand() != null) {
            node.getCommand().apply(this);
        }

	// Leaving the procedure
	try {
	    idTable.closeScope();
	    idTypeTable.closeScope(node.getIdentifier().getText());
	} catch (Exception e) {
	    ErrorList.add(node.getIdentifier(), e.getMessage());
	}
    }

    public void caseARecordDeclaration(ARecordDeclaration node) {
	String mainRecordName = node.getType().getText();
	IdentitiesAndTypesTable tmpIdTypeTable = new IdentitiesAndTypesTable();
	IdentificationTable tmpIdTable = new IdentificationTable(tmpIdTypeTable);
	RecordIdentitiesAndTypeExtractorChecker riatec =  new RecordIdentitiesAndTypeExtractorChecker(stdEnv,
												      tmpIdTable,
												      idRecord,
												      mainRecordName,
												      prober);
	try {
	    stdEnv.enter(node.getType().getText(), node);
	    idTable.enter(node.getType().getText(), node, false); // Not Constant
	} catch (IdTableException e) {
	    ErrorList.add(node.getType(), e.getMessage());
	} catch (StandardEnvironmentException e) {
	    ErrorList.add(node.getType(), e.getMessage());
	}

        if(node.getCsavHelpDeclarations() != null) {
            node.getCsavHelpDeclarations().apply(riatec); // riatec apply
        }
        if(node.getDeclarationAssignment() != null) {
            node.getDeclarationAssignment().apply(riatec);
        }
	// Internal bock runs through the linked list, the elements in
	// the record, except the first one
        {
            Object temp[] = node.getTypeDeclarationHelper().toArray();
            for(int i = 0; i < temp.length; i++) {
                ((ATypeDeclarationHelper)temp[i]).getCsavHelpDeclarations().apply(riatec);
                if (((ATypeDeclarationHelper)temp[i]).getDeclarationAssignment() != null) {
		    ((ATypeDeclarationHelper)temp[i]).getDeclarationAssignment().apply(riatec);
		}
            }
        }

	try {
	    idRecord.saveRecord(mainRecordName);
	} catch(IdRecordTableException e) {
	    ErrorList.add(node.getType(), e.getMessage());
	}
    }

    ///////////////////////////////////////// ASSIGNMENT ///////////////////////////////////////////

    public void inADeclarationAssignment(ADeclarationAssignment node) {

	MultiTypeChecker multiTypeChecker = null;
	String type = lastType;
	
	
	//Hvis record s� g�r noget...
	if (stdEnv.isRecord(type)) {
	    // s� skulle det v�re ok, eller..?
	} else {
	    if (assignment) {
		multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, type);
		node.getExpression().apply(multiTypeChecker);
		if(!multiTypeChecker.isRightType()) {
		    ErrorList.add(node.getAssign(), "illegal type, " + type.trim()  + " expected on right side of expression");
		}
	    } else {
		ErrorList.add(node.getAssign(), "Decalartion can not be initialized under declaration");
		assignment = true;
	    }
	}
    }
    
    /**
     * Check the types on both sides of the assignment of an
     * expression to an identifier
     *
     * @param node an <code>AAssignBasicCommands</code> value
     */
    public void caseAAssignBasicCommands(AAssignBasicCommands node) {
	MultiTypeChecker multiTypeChecker = null;	
	Node typeNode = null;
	ARecordDeclaration recordType = null;
	String type = null;
	String castType = null;
	String key = null;
	String booleanCheck = null;

	if (node.getVName() != null) {
            node.getVName().apply(this);
        }

        if (node.getExpression() != null) {
	    // Evaluate the expression on the right side in relation
	    // to the left side
	    // Retrieve the information form the idTable
	    try {
		key = ((AVName)node.getVName()).getIdentifier().getText();
		typeNode = idTable.retrieve(key);
		type = findNodeType(typeNode, node.getAssign()); // finde the nodes type
		castType = typeNode.getClass().getName().substring(29);
		// Evaluate the expresion, first the new record types
		if (type.equals("boolean")) {
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "boolean");
		    node.getExpression().apply(multiTypeChecker);
		    if(!multiTypeChecker.isRightType()) {
			ErrorList.add(node.getAssign(), "illegal type, boolean expected on right side of expression");
		    }
		} else if (type.equals("edge")) {
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "edge");
		    node.getExpression().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(node.getAssign(), "illegal type, vertex expected on right side of expression");
		    }
		} else if (type.equals("string")){ 
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "string");
		    node.getExpression().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(node.getAssign(), "illegal string expression on right side of expression");
		    }
		} else if (type.equals("integer")){
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "integer");
		    node.getExpression().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(node.getAssign(), "illegal integer expression on right side of expression");
		    }
		} else if (type.equals("float")){
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "float");
		    node.getExpression().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(node.getAssign(), "illegal float expression on right side of expression");
		    }
		} else if (type.equals("graph")) {
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "graph");
		    node.getExpression().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(node.getAssign(), "illegal type on right side of assignment expected graph");
		    }
		} else if (type.equals("vertex")) {
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "vertex");
		    node.getExpression().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(node.getAssign(), "illegal type on right side of assignment expected vertex");
		    }
		} else if (type.equals("edge")) {
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "edge");
		    node.getExpression().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(node.getAssign(), "illegal type on right side of assignment expected edge");
		    }
		} else if (type.equals("diGraph")) {
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "diGraph");
		    node.getExpression().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(node.getAssign(), "illegal type on right side of assignment expected diGraph");
		    }
		} else if (castType.equals("AForToLoopHeaders")) {
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "integer");
		    node.getExpression().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(node.getAssign(), "illegal integer expression on right side of expression");
		    }
		} else if (castType.equals("ARecordDeclaration")) {
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "");
 		    node.getVName().apply(multiTypeChecker);
		    type = multiTypeChecker.getType();
		    // Now ensure that both types are the same
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, type);
		    node.getExpression().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(node.getAssign(), "Illegal " + type.trim() + 
				      " expression on the right side of expression");
		    }
		} else {
		    throw new IdTableException("Unknow type, big error, I don't have the power captain, I can't do it");
		}
	    } catch(IdTableException e) {
		ErrorList.add(node.getAssign(), e.getMessage());
	    }	    	    
	}
    }
    
    //////////////////////////////////////////// LOOP STRUCTURES ////////////////////////////////////////////


    public void inALoopClosedCommand(ALoopClosedCommand node) {
	idTable.openScope();
    }

    public void inALoopOpenCommand(ALoopClosedCommand node) {
	idTable.openScope();
    }

    public void caseAWhileDoOpenCommand(AWhileDoOpenCommand node) {
	MultiTypeChecker multiTypeChecker = null;	

	multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "boolean");
	node.getExpression().apply(multiTypeChecker);
	if (!multiTypeChecker.isRightType()) {
	    ErrorList.add(node.getWhile(), "illegal type, boolean expression expected");
	}
        if(node.getOpenCommand() != null) {
            node.getOpenCommand().apply(this);
        }
    }

    public void caseAWhileDoClosedCommand(AWhileDoClosedCommand node) {
	MultiTypeChecker multiTypeChecker = null;	

	multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "boolean");
	node.getExpression().apply(multiTypeChecker);
	if (!multiTypeChecker.isRightType()) {
	    ErrorList.add(node.getWhile(), "illegal type, boolean expression expected");
	}
        if(node.getClosedCommand() != null) {
            node.getClosedCommand().apply(this);
        }
    }

    public void caseADoWhileOpenCommand(ADoWhileOpenCommand node) {
	MultiTypeChecker multiTypeChecker = null;	

        if(node.getOpenCommand() != null) {
            node.getOpenCommand().apply(this);
        }
	multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "boolean");
	node.getExpression().apply(multiTypeChecker);
	if (!multiTypeChecker.isRightType()) {
	    ErrorList.add(node.getWhile(), "illegal type, boolean expression expected");
	}
    }

    public void caseADoWhileClosedCommand(ADoWhileClosedCommand node) {
	MultiTypeChecker multiTypeChecker = null;	

	if(node.getClosedCommand() != null) {
            node.getClosedCommand().apply(this);
        }
	multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "boolean");
	node.getExpression().apply(multiTypeChecker);
	if (!multiTypeChecker.isRightType()) {
	    ErrorList.add(node.getWhile(), "illegal type, boolean expression expected");
	}
    }

    public void caseAForToLoopHeaders(AForToLoopHeaders node) {
	MultiTypeChecker multiTypeChecker = null;	
	String id = null;

        if(node.getVName() != null) {
            node.getVName().apply(this);
	    try {
		idTable.enter(((AVName)node.getVName()).getIdentifier().getText(), node, false);
		id = ((AVName)node.getVName()).getIdentifier().getText();
	    } catch (IdTableException e) {
		ErrorList.add(node.getFor(), e.getMessage());
	    }
        }

        if (node.getFromExpr() != null) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "integer");
	    node.getFromExpr().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getFor(), "illegal expression, integer expression expected");
	    }
	}

        if(node.getToExpr() != null) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "integer");
	    node.getToExpr().apply(multiTypeChecker);
	    if(!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getTo(), "illegal expression, integer expression expected");
	    }
        }
    }

    public void caseAForDowntoLoopHeaders(AForDowntoLoopHeaders node) {
	MultiTypeChecker multiTypeChecker = null;	
	String id = null;

        if (node.getVName() != null) {
            node.getVName().apply(this);
	    try {
		idTable.enter(((AVName)node.getVName()).getIdentifier().getText(), node, false);
		id = ((AVName)node.getVName()).getIdentifier().getText();
	    } catch (IdTableException e) {
		ErrorList.add(node.getFor(), e.getMessage());
	    }
        }

        if (node.getFromExpr() != null) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "integer");
	    node.getFromExpr().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getFor(), "illegal expression, integer expression expected");
	    }
	}

        if (node.getDowntoExpr() != null) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "integer");
	    node.getDowntoExpr().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getDownto(), "illegal expression, integer expression expected");
	    }
        }
    }

    public void caseAForeachInDoLoopHeaders(AForeachInDoLoopHeaders node) {

	Node typeNode = null;
	String castType = null;
	String type = null;

        if (node.getSingleDeclaration() != null) {
            node.getSingleDeclaration().apply(this);
        }

        if (node.getVName() != null) {
	    try {
		typeNode = idTable.retrieve(((AVName)node.getVName()).getIdentifier().getText());
		castType = typeNode.getClass().getName().substring(29);
		if (castType.equals("AArrayDeclaration")) {
		    // Array Declaration type found
		} else if (castType.equals("ASetDeclaration")) {
		    // Set Declaration type found
		} else if (castType.equals("AWeightWeightLabelDeclaration")) {
		    // Weight Declaration type found
		} else if (castType.equals("ALabelWeightLabelDeclaration")) {
		    // Label Declaration type found
		} else if (castType.equals("AVariableDeclaration")) {
		    type = ((AVariableDeclaration)typeNode).getType().getText();
		    if ((!type.equals("graph")) || (!type.equals("diGraph"))) {
			ErrorList.add(node.getIn(), "illegal variable, some kind of graph type was expected");
		    }
		} else if (castType.equals("AIdentifierTypeDenoter")) {
		    type = ((AIdentifierTypeDenoter)typeNode).getIdentifier().getText();
		    if ((!type.equals("graph")) || (!type.equals("diGraph"))) {
			ErrorList.add(node.getIn(), "illegal variable, some kind of graph type was expected");
		    }
		} else if (castType.equals("AArrayTypeDenoter")) {
		    // Array parameter type found
		} else if (castType.equals("AWeightTypeDenoter")) {
		    // Weight parameter type found
		} else if (castType.equals("ALabelTypeDenoter")) {
		    // Label parameter type found
		} else if (castType.equals("ASetTypeDenoter")) {
		    // Set parameter type found
		} else {
		    throw new IdTableException("Not a vaild declaration to iterate over");
		}
	    } catch (IdTableException e) {
		ErrorList.add(node.getForeach(), e.getMessage());		
	    }
        }
    }

    public void caseAForeachInWhereDoLoopHeaders(AForeachInWhereDoLoopHeaders node) {
	MultiTypeChecker multiTypeChecker = null;
	Node typeNode = null;
	String castType = null;
	String type = null;

        if (node.getSingleDeclaration() != null) {
            node.getSingleDeclaration().apply(this);
        }

        if (node.getVName() != null) {
	    try {
		typeNode = idTable.retrieve(((AVName)node.getVName()).getIdentifier().getText());
		castType = typeNode.getClass().getName().substring(29);
		if (castType.equals("AArrayDeclaration")) {
		    // Array Declaration type found
		} else if (castType.equals("ASetDeclaration")) {
		    // Set Declaration type found
		} else if (castType.equals("AWeightWeightLabelDeclaration")) {
		    // Weight Declaration type found
		} else if (castType.equals("ALabelWeightLabelDeclaration")) {
		    // Label Declaration type found
		} else if (castType.equals("AVariableDeclaration")) {
		    type = ((AVariableDeclaration)typeNode).getType().getText();
		    if ((!type.equals("graph")) || (!type.equals("diGraph"))) {
			ErrorList.add(node.getIn(), "illegal variable, some kind of graph type was expected");
		    }
		} else if (castType.equals("AIdentifierTypeDenoter")) {
		    type = ((AIdentifierTypeDenoter)typeNode).getIdentifier().getText();
		    if ((!type.equals("graph")) || (!type.equals("diGraph"))) {
			ErrorList.add(node.getIn(), "illegal variable, some kind of graph type was expected");
		    }
		} else if (castType.equals("AArrayTypeDenoter")) {
		    // Array parameter type found
		} else if (castType.equals("AWeightTypeDenoter")) {
		    // Weight parameter type found
		} else if (castType.equals("ALabelTypeDenoter")) {
		    // Label parameter type found
		} else if (castType.equals("ASetTypeDenoter")) {
		    // Set parameter type found
		} else {
		    throw new IdTableException("Not a vaild declaration to iterate over");
		}
	    } catch (IdTableException e) {
		ErrorList.add(node.getForeach(), e.getMessage());		
	    }
        }

	if (node.getExpression() != null) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "boolean");
	    node.getExpression().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getWhere(), "illegal type, boolean expression expected");
	    }
	}
    }


    public void outALoopClosedCommand(ALoopClosedCommand node) {
	try {
	    idTable.closeScope();
	} catch (IdTableException e) {
	    ErrorList.add(new TAssign(), e.getMessage());
	}
    }

    public void outALoopOpenCommand(ALoopClosedCommand node) {
	try {
	    idTable.closeScope();
	} catch (IdTableException e) {
	    ErrorList.add(new TAssign(), e.getMessage());
	}
    }

    ///////////////////////////////////////////// IF THEN ELSE //////////////////////////////////////////////

    public void inAIfThenOpenCommand(AIfThenOpenCommand node) {

	MultiTypeChecker multiTypeChecker = null;	

	multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "boolean");
	node.getExpression().apply(multiTypeChecker);
	if (!multiTypeChecker.isRightType()) {
	    ErrorList.add(node.getIf(), "illegal type, boolean expression expected");
	}
    }

    public void inAIfElseOpenCommand(AIfElseOpenCommand node) {

	MultiTypeChecker multiTypeChecker = null;	
	
	multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "boolean");
	node.getExpression().apply(multiTypeChecker);
	if (!multiTypeChecker.isRightType()) {
	    ErrorList.add(node.getIf(), "illegal type, boolean expression expected");
	}
    }

    public void inAIfOpenClosedCommandElse(AIfOpenElseClosedCommand node) {

	MultiTypeChecker multiTypeChecker = null;	
	
	multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "boolean");
	node.getExpression().apply(multiTypeChecker);
	if (!multiTypeChecker.isRightType()) {
	    ErrorList.add(node.getIf(), "illegal type, boolean expression expected");
	}
    }

    /////////////////////////////////////// PROCEDURE / FUNCTION CALL ///////////////////////////////////////

    public void caseALwAssBasicCommands(ALwAssBasicCommands node) {
	MultiTypeChecker multiTypeChecker = null;
	
        if(node.getParameterCall() != null) {
	    labelWeightFound = true;
            node.getParameterCall().apply(this);
        }

        if(node.getExpression() != null) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, labelOrWeightType);
	    node.getExpression().apply(multiTypeChecker);
	    if(!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getAssign(), "illegal type, " + labelOrWeightType  + " expected on right side of expression");
	    }
        }
    }

    public void inAParameterCall(AParameterCall node) {
	Node rNode = null;
	String castType = null;

	if (!prober.isInTable(node.getName().getText()) && idTable.isInTable(procedureCallName)) {
	    labelWeightFound = true;
	}

	if (!labelWeightFound) {
	    procedureCallName = node.getName().getText();
	} else {
	    if (idTable.isInTable(node.getName().getText())) {
		try {
		    rNode = idTable.retrieve(node.getName().getText());
		    castType = rNode.getClass().getName().substring(29);

		    if (castType.equals("AWeightWeightLabelDeclaration")) {
			labelOrWeight = "weight";
			labelOrWeightType = ((AWeightWeightLabelDeclaration)rNode).getType().getText();
		    } else if (castType.equals("ALabelWeightLabelDeclaration")) {
			labelOrWeight = "label";
			labelOrWeightType = ((ALabelWeightLabelDeclaration)rNode).getType().getText();
		    } else if (castType.equals("ALabelTypeDenoter")) {
			labelOrWeight = "label";
			labelOrWeightType = ((ALabelTypeDenoter)rNode).getType().getText();
		    } else if (castType.equals("AWeightTypeDenoter")) {
			labelOrWeight = "weight";
			labelOrWeightType = ((AWeightTypeDenoter)rNode).getType().getText();
		    } else {
			throw new IdTableException("Not a weight or label function");
		    }
		} catch (IdTableException e) {
		    ErrorList.add(node.getName(), e.getMessage());
		}
	    }
	}
    }

    public void caseAActualParameterSequence(AActualParameterSequence node) {
	MultiTypeChecker multiTypeChecker = null;
	ExpressionEvaluater ee = null;
	ArrayList formalTypes = null;
	ArrayList formalFlags = null;
	String type = null;
	String flag = null;
	int parameterNumber = 0;

	if (!prober.isInTable(procedureCallName) && idTable.isInTable(procedureCallName)) {
	    labelWeightFound = true;
	}

	if (!labelWeightFound) {
	    try {
		formalTypes = prober.getTypes(procedureCallName);
		formalFlags = prober.getFlags(procedureCallName);

		if (debug) {
		    System.out.println(procedureCallName);
		    System.out.println(formalTypes);
		    System.out.println(formalFlags);
		    System.out.println("");
		}
		
		if (formalTypes != null) {
		    if(node.getExpression() != null) {
			ee = new ExpressionEvaluater(idTable, idRecord, prober, procedureCallName);
			ee.evaluate(node.getExpression());
			type = ee.getType();
			flag = ee.getFlag();

			if (type == null || flag == null) {
			    throw new FunctionProcedureProberException("Error unknown parameter passed to procedure or function");
			}
			
			if (!formalTypes.get(parameterNumber).equals(type) || !formalFlags.get(parameterNumber).equals(flag)) {
			    if ((!compareTypes(type, formalTypes.get(parameterNumber).toString(), formalFlags.get(parameterNumber).toString()))) {
				throw new FunctionProcedureProberException("parameter "+parameterNumber+" expected as " + 
									   formalTypes.get(parameterNumber) + " " + 
									   formalFlags.get(parameterNumber) + " but was " + 
									   type + " " + flag);
			    }
			}
			parameterNumber++;
		    }
		    {
			Object temp[] = node.getActualExpression().toArray();
			for(int i = 0; i < temp.length; i++) {
			    if (parameterNumber >= formalTypes.size()) {
				throw new FunctionProcedureProberException("To many parameters in call");
			    }
			    
			    ee = new ExpressionEvaluater(idTable, idRecord, prober, procedureCallName);
			    ee.evaluate(((AActualExpression)temp[i]).getExpression());
			    type = ee.getType();
			    flag = ee.getFlag();

			    if (type == null || flag == null) {
				throw new FunctionProcedureProberException("Error unknown parameter passed to procedure or function");
			    }

			    if (!formalTypes.get(parameterNumber).equals(type) || !formalFlags.get(parameterNumber).equals(flag)) {
				if (!compareTypes(type, formalTypes.get(parameterNumber).toString(), formalFlags.get(parameterNumber).toString())) {
				    throw new FunctionProcedureProberException("parameter "+parameterNumber+" expected as " + 
									       formalTypes.get(parameterNumber - 1) +  " " + 
									       formalFlags.get(parameterNumber - 1) + " but was " + 
									       type + " " + flag);
				}
			    }
			    parameterNumber++;
			}
		    }
		} else {
		    throw new FunctionProcedureProberException("Unknown procedure or function " + procedureCallName);
		}
	    } catch (FunctionProcedureProberException e) {
		ErrorList.add(((AParameterCall)node.parent()).getLPar(), e.getMessage());
	    }
	} else {
	    if (labelOrWeight.equals("label")) {
		multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "vertex");
		node.getExpression().apply(multiTypeChecker);
		if(!multiTypeChecker.isRightType()) {
		    ErrorList.add(((AParameterCall)node.parent()).getLPar(), "illegal type, vertex expected as parameter");
		}
	    } else if (labelOrWeight.equals("weight")) {
		multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "edge");
		node.getExpression().apply(multiTypeChecker);
		if(!multiTypeChecker.isRightType()) {
		    ErrorList.add(((AParameterCall)node.parent()).getLPar(), "illegal type, edge expected as parameter");
		}
	    } else {
		ErrorList.add(((AParameterCall)node.parent()).getLPar(), "unknown error with label or weight functions");
	    }
	}
	labelWeightFound = false;
    }

    public void caseAReturnBasicCommands(AReturnBasicCommands node) {
	ExpressionEvaluater ee = null;
	String flag = null;
	String type = null;
	String returnType = null;
	String returnFlag = null;

	try {
	    returnType = (String)((ArrayList)prober.getReturnType(nameToReturn)).get(0);
	    returnFlag = (String)((ArrayList)prober.getReturnType(nameToReturn)).get(1);
	    
	    if(node.getExpression() != null) {
		ee = new ExpressionEvaluater(idTable, idRecord, prober, null);
		ee.evaluate(node.getExpression());
		type = ee.getType();
		flag = ee.getFlag();
		
		if(!(type.equals(returnType)) || !(flag.equals(returnFlag))) {
		    ErrorList.add(node.getReturn(), "wrong return type expected " + 
				  returnType +  " " + returnFlag + " but was " + type + " " + flag);
		
		}
	    }
	} catch (FunctionProcedureProberException e) {
	    ErrorList.add(node.getReturn(), e.getMessage());
	}
    }

    ///////////////////////////////////////////// OTHER THINGS //////////////////////////////////////////////

    // postfixx ++ and --
    public void caseAPostfixPpBasicCommands(APostfixPpBasicCommands node) {
	MultiTypeChecker multiTypeChecker = null;

        if(node.getVName() != null) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "integer");
	    node.getVName().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "float");
		node.getVName().apply(multiTypeChecker);
		if (!multiTypeChecker.isRightType()) {
		    ErrorList.add(node.getPlusPlus(), "illegal type, float or integer type expected");
		}
	    }
        }
        if(node.getPlusPlus() != null) {
            node.getPlusPlus().apply(this);
        }
    }

    public void caseAPostfixMmBasicCommands(APostfixMmBasicCommands node) {
	MultiTypeChecker multiTypeChecker = null;

        if(node.getVName() != null)  {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "integer");
	    node.getVName().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "float");
		node.getVName().apply(multiTypeChecker);
		if (!multiTypeChecker.isRightType()) {
		    ErrorList.add(node.getMinusMinus(), "illegal type, float or integer type expected");
		}
	    }
	}
	if(node.getMinusMinus() != null) {
            node.getMinusMinus().apply(this);
        }
    }

    // Array use a integer in [] check
    public void caseAIdentifierArrayVNameExtension(AIdentifierArrayVNameExtension node) {
	MultiTypeChecker multiTypeChecker = null;

        if (node.getExpression() != null) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "integer");
	    node.getExpression().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getLBracket(), "illegal expression, used as index to array");
	    }
        }
    }

    // Check of what switch is switching over
    public void caseASwitchBasicCommands(ASwitchBasicCommands node) {
	MultiTypeChecker multiTypeChecker = null;

        if(node.getVName() != null) {
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "integer");
	    node.getVName().apply(multiTypeChecker);
	    if (!multiTypeChecker.isRightType()) {
		ErrorList.add(node.getSwitch(), "illegal expression, used to switch over");
	    }
        }
        {
            Object temp[] = node.getCaseItem().toArray();
            for(int i = 0; i < temp.length; i++) {
		((PCaseItem) temp[i]).apply(this);
            }
        }
        if(node.getDefaultItem() != null) {
            node.getDefaultItem().apply(this);
        }
    }
                                                  //////////////////
                                                 // Other things //
                                                //////////////////

    private boolean compareTypes(String dogsType, String type, String flag) {
	boolean result = false;
	boolean graph = (dogsType.equals("graph") || dogsType.equals("diGraph"));
	boolean set = (dogsType.equals("integer") || dogsType.equals("float") || 
		       dogsType.equals("string") || dogsType.equals("boolean") || 
		       dogsType.equals("edge") || dogsType.equals("vertex"));
	boolean array = (dogsType.equals("integer") || dogsType.equals("float") || 
		       dogsType.equals("string") || dogsType.equals("boolean") || 
		       dogsType.equals("edge") || dogsType.equals("vertex"));
	boolean primitive = (dogsType.equals("integer") || dogsType.equals("float") || 
			     dogsType.equals("string") || dogsType.equals("boolean") || 
			     dogsType.equals("edge") || dogsType.equals("vertex"));

	if (graph && type.equals("GraphComposite")) {
	    result = true;
	}

	if (primitive && type.equals("primitive")) {
	    result = true;
	}

	if ((set || type.equals("stdSet")) && flag.equals("set")) {
	    result = true;
	}

	if ((array || type.equals("stdArray")) && flag.equals("array")) {
	    result = true;
	}

	return result;
    }
    
    private String findNodeType(Node typeNode, TAssign token) {
	String type = new String();
	String castType = null;

	try {
	    // Test if it is constant
	    if (idTable.isConstant()) {
		throw new IdTableException("illegal, can not modify a constant");
	    }
	    // REMEBER to update this case when a new declaration node type is add to idTable
	    castType = typeNode.getClass().getName().substring(29);
	    if (castType.equals("AVariableDeclaration")) {
		type = ((AVariableDeclaration)typeNode).getType().getText();
	    } else if (castType.equals("AArrayDeclaration")) {
		type = ((AArrayDeclaration)typeNode).getType().getText();
	    } else if (castType.equals("ASetDeclaration")) {
		type = ((ASetDeclaration)typeNode).getType().getText();
	    } else if (castType.equals("AWeightWeightLabelDeclaration")) {
		type = ((AWeightWeightLabelDeclaration)typeNode).getType().getText();
	    } else if (castType.equals("ALabelWeightLabelDeclaration")) {
		type = ((ALabelWeightLabelDeclaration)typeNode).getType().getText();
	    } else if (castType.equals("ARecordDeclaration")) {
		type = ((ARecordDeclaration)typeNode).getType().getText();
	    } else if (castType.equals("AIdentifierTypeDenoter")) {
		type = ((AIdentifierTypeDenoter)typeNode).getIdentifier().getText();
	    } else if (castType.equals("AArrayTypeDenoter")) {
		type = ((AArrayTypeDenoter)typeNode).getType().getText();
	    } else if (castType.equals("AWeightTypeDenoter")) {
		type = ((AWeightTypeDenoter)typeNode).getType().getText();
	    } else if (castType.equals("ALabelTypeDenoter")) {
		type = ((ALabelTypeDenoter)typeNode).getType().getText();
	    } else if (castType.equals("ASetTypeDenoter")) {
		type = ((ASetTypeDenoter)typeNode).getType().getText();
	    } else if (castType.equals("AForToLoopHeaders")) {
		type = "integer";
	    } else {
		throw new IdTableException("Unknow cast type " + castType);
	    }
	} catch(IdTableException e) {
	    ErrorList.add(token, e.getMessage());
	}   
	return type;
    }
}
