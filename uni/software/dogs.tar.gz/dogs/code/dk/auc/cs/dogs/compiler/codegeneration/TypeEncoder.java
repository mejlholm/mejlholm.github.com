package dk.auc.cs.dogs.compiler.codegeneration;

import dk.auc.cs.dogs.compiler.codegeneration.Encoder;
import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.libraryhandler.Library;

/**
 * TypeEncoder.java
 *
 *
 * Created: Tue May 18 19:25:15 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public abstract class TypeEncoder extends Encoder {

    private boolean inPackage = false;

    public TypeEncoder(Library lib, StandardEnvironment std, String sourcefile, String objectfile, IdentificationTableRecord idRecord, FunctionProcedureProber prober, IdentitiesAndTypesTable idTypeTable) {
	super(lib, std, sourcefile, objectfile, idRecord, prober, idTypeTable);
    } // TypeEncoder constructor



    public final void outAStringPrimaryExpression(AStringPrimaryExpression node){
	cw.codePrintln("new dk/auc/cs/dogs/environment/types/String");
	cw.codePrintln("dup");
	cw.codePrintln("ldc " + node.getStringLiteral().getText());
	cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/String/<init>(Ljava/lang/String;)V");
    }

    public final void outAFloatPrimaryExpression(AFloatPrimaryExpression node){
	if(node.parent().parent().parent().getClass().getName().equals("dk.auc.cs.dogs.compiler.node.AUnaryMinusPlusMinusExpr")){
	    cw.codePrintln("new dk/auc/cs/dogs/environment/types/Float");
	    cw.codePrintln("dup");
	    cw.codePrintln("ldc2_w -" + node.getFloatLiteral().getText());
	    cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Float/<init>(D)V");
	} else{
	    cw.codePrintln("new dk/auc/cs/dogs/environment/types/Float");
	    cw.codePrintln("dup");
	    cw.codePrintln("ldc2_w " + node.getFloatLiteral().getText());
	    cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Float/<init>(D)V");
	}
	cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
    }

    public final  void outAIntegerPrimaryExpression(AIntegerPrimaryExpression node){
	if(node.parent().parent().parent().getClass().getName().equals("dk.auc.cs.dogs.compiler.node.AUnaryMinusPlusMinusExpr")){
	    cw.codePrintln("new dk/auc/cs/dogs/environment/types/Integer");
	    cw.codePrintln("dup");
	    cw.codePrintln("ldc2_w -" + node.getIntegerLiteral().getText());
	    cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Integer/<init>(J)V");
	} else{
	    cw.codePrintln("new dk/auc/cs/dogs/environment/types/Integer");
	    cw.codePrintln("dup");
	    cw.codePrintln("ldc2_w " + node.getIntegerLiteral().getText());
	    cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Integer/<init>(J)V");
	}
	cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
    }

    public final void outABooleanPrimaryExpression(ABooleanPrimaryExpression node){
	cw.codePrintln("new dk/auc/cs/dogs/environment/types/Boolean");
	cw.codePrintln("dup");
	if (node.getBooleanLiteral().getText().equals("true")) {
	    cw.codePrintln("bipush 1");
	} else {
	    cw.codePrintln("bipush 0");
	}
	cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Boolean/<init>(Z)V");
    }

    public final void outAInftyPrimaryExpression(AInftyPrimaryExpression node){
	if(!node.parent().parent().parent().getClass().getName().equals("dk.auc.cs.dogs.compiler.node.AUnaryMinusPlusMinusExpr")){
	//if positive
	    cw.codePrintln("new dk/auc/cs/dogs/environment/types/Infty"); 
	    cw.codePrintln("dup");
	    cw.codePrintln("bipush 1");
	    cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Infty/<init>(Z)V");	    
	} else{
	    //if negative
	    cw.codePrintln("new dk/auc/cs/dogs/environment/types/Infty"); 
	    cw.codePrintln("dup");
	    cw.codePrintln("bipush 0");
	    cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Infty/<init>(Z)V");
	}
	cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/NumberNumber");
    }

    public void inAPackageImport(APackageImport node) {
	inPackage = true;
    }

    public final void caseAVName(AVName node) {

	String name = node.getIdentifier().toString().trim();
	inAVName(node);
	if(node.getIdentifier() != null) {
	    node.getIdentifier().apply(this);
	}
	
	String parent = node.parent().getClass().getName().substring(29);
	
	if (!parent.equals("AAssignBasicCommands") && !parent.equals("APackageImport")) {
	    String vname = node.getIdentifier().getText();
	    cw.codePrintln("aload " + vmap.getLocation(vname));
	    outAVName(node);
	} else if (!inPackage && idTypeTable.getIdentifier(name).getFlag().equals("array")) {
	    cw.codePrintln("aload " + vmap.getLocation(name));
	    cw.codePrintln("ldc \"[\"");
	    node.getVNameExtension().apply(this);
	    cw.codePrintln("invokevirtual java/lang/Object/toString()Ljava/lang/String;");
	    cw.codePrintln("invokevirtual java/lang/String/concat(Ljava/lang/String;)Ljava/lang/String;");
	    cw.codePrintln("ldc \"]\"");
	    cw.codePrintln("invokevirtual java/lang/String/concat(Ljava/lang/String;)Ljava/lang/String;");
		
	    cw.codePrintln("invokevirtual dk/auc/cs/dogs/environment/types/Array/getValue(Ljava/lang/String;)Ldk/auc/cs/dogs/environment/types/Primitive;");
	    castToType(idTypeTable.getIdentifier(name).getType());
	}
	inPackage = false;
    }



} // TypeEncoder
