package dk.auc.cs.dogs.environment.types;

public interface LabelBoolean extends LabelInterface {
}