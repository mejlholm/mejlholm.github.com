package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.contextual.helpers.*;
/**
 * This exception class is used by the identification table
 *
 */
public class IdTableException extends Exception {
    
    public IdTableException(){
	super("Unknown exception");
    }

    public IdTableException(String msg){
	super(msg);
    }

    public IdTableException(String msg, Throwable cause){
	super(msg, cause);
    }
}
