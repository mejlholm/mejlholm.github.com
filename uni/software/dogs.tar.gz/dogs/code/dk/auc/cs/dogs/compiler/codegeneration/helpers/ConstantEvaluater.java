package dk.auc.cs.dogs.compiler.codegeneration.helpers;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;

public class ConstantEvaluater extends DepthFirstAdapter {


}
