package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.optimiser.probers.ArithmeticProber;

/**
 * DivisionByZeroChecker.java
 *
 *
 * Created: Wed May  5 18:25:56 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class DivisionByZeroChecker extends Checker {

    public DivisionByZeroChecker() {
	super();
    } // DivisionByZeroChecker constructor
    
    public void inAModMultiplicationExpr(AModMultiplicationExpr node){
	ArithmeticProber a = new ArithmeticProber();
	node.apply(a);
	if (a.size() == 3){
	    if (a.getType(2).equals("i")){
		if (a.getExpression(1).equals("%") && a.getExpression(2).equals("0")){
		    ErrorList.add(((AIntegerPrimaryExpression)a.getNode(2)).getIntegerLiteral(), "Mod by Zero");
		}
	    }
	    if (a.getType(2).equals("f")){
		if (a.getExpression(1).equals("%") && a.getExpression(2).equals("0.0")){
		    ErrorList.add(((AFloatPrimaryExpression)a.getNode(2)).getFloatLiteral(), "Mod by Zero");
		}
	    }
	}
    }

    public void inADivMultiplicationExpr(ADivMultiplicationExpr node){
	ArithmeticProber a = new ArithmeticProber();
	node.apply(a);
	if (a.size() == 3){
	    if (a.getType(2).equals("i")){
		if (a.getExpression(1).equals("/") && a.getExpression(2).equals("0")){
		    ErrorList.add(((AIntegerPrimaryExpression)a.getNode(2)).getIntegerLiteral(), "Div by Zero");
		}
	    }
	    if (a.getType(2).equals("f")){
		if (a.getExpression(1).equals("/") && a.getExpression(2).equals("0.0")){
		    ErrorList.add(((AFloatPrimaryExpression)a.getNode(2)).getFloatLiteral(), "Div by Zero");
		}
	    }
	}
    }

    public void inAIntDivMultiplicationExpr(AIntDivMultiplicationExpr node){
	ArithmeticProber a = new ArithmeticProber();
	node.apply(a);
	if (a.size() == 3){
	    if (a.getType(2).equals("i")){
		if (a.getExpression(1).equals("div") && a.getExpression(2).equals("0")){
		    ErrorList.add(((AIntegerPrimaryExpression)a.getNode(2)).getIntegerLiteral(), "Div by Zero");
		}
	    }
	    if (a.getType(2).equals("f")){
		if (a.getExpression(1).equals("div") && a.getExpression(2).equals("0.0")){
		    ErrorList.add(((AFloatPrimaryExpression)a.getNode(2)).getFloatLiteral(), "Div by Zero");
		}
	    }
	}
    }

} // DivisionByZeroChecker
