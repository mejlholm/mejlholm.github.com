package dk.auc.cs.dogs.compiler.codegeneration;

import java.util.*;

//import dk.auc.cs.dogs.compiler.codegeneration.BranchingEncoder;
import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.libraryhandler.Library;

/**
 * LoopingEncoder.java
 *
 *
 * Created: Mon May 17 16:58:50 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public abstract class LoopingEncoder extends BranchingEncoder {
    private boolean debug = false;

    private int loopCounter = 1;
    private LinkedList scopeVariables = new LinkedList();
    private LinkedList scopeVNames = new LinkedList();
    private int scopeCounter = 1;
    private int loopStartCounter = 1;

    public LoopingEncoder(Library lib, StandardEnvironment std, String sourcefile, String objectfile, IdentificationTableRecord idRecord, FunctionProcedureProber prober,  IdentitiesAndTypesTable idTypeTable) {
	super(lib, std, sourcefile, objectfile, idRecord, prober, idTypeTable);
    } // LoopingEncoder constructor

    public final void caseALoopOpenCommand(ALoopOpenCommand node) {
	makeScopeVariables();
	cw.addIndentScope();
	cw.codePrintln("; LoopOpenCommand - starting loop");
	//	cw.codePrintln("; " + node);
	cw.makeBreakLabel();
        inALoopOpenCommand(node);
        if (node.getLoopHeaders() != null) {
	    if (debug) System.out.println("LoopOpenCommand - before getLoopHeaders");
	    // Starting the loop...
            node.getLoopHeaders().apply(this);
        }
        if (node.getOpenCommand() != null) {
	    if (debug) System.out.println("LoopOpenCommand - before getClosedCommand");
	    // Executing body of the loop...
            node.getOpenCommand().apply(this);
        }
        outALoopOpenCommand(node);
	cw.codePrintln("goto " + cw.popLabel());
	cw.popBreakLabel();
	cw.codePrintln("; LoopOpenCommand - loop ending\n");
	cw.removeIndentScope();
	popScopeVariables();
    }

   public final void caseALoopClosedCommand(ALoopClosedCommand node) {
	makeScopeVariables();
	cw.addIndentScope();
	cw.codePrintln("; LoopClosedCommand - starting loop");
	//	cw.codePrintln("; " + node);
	cw.makeBreakLabel();
        inALoopClosedCommand(node);
        if (node.getLoopHeaders() != null) {
	    if (debug) System.out.println("LoopClosedCommand - before getLoopHeaders");
	    // Starting the loop...
            node.getLoopHeaders().apply(this);
        }
        if (node.getClosedCommand() != null) {
	    if (debug) System.out.println("LoopClosedCommand - before getClosedCommand");
	    // Executing body of the loop...
            node.getClosedCommand().apply(this);
        }
        outALoopClosedCommand(node);
	cw.codePrintln("goto " + cw.popLabel());
	cw.popBreakLabel();
	cw.codePrintln("; LoopClosedCommand - loop ending\n");
	cw.removeIndentScope();
	popScopeVariables();
    }






    /*
      FOREACH <type> IN <composite> DO ...
    */
    public final void caseAForeachInDoLoopHeaders(AForeachInDoLoopHeaders node) {
	int varLocation = -1;
	int itLocation = -1;
	String type = "ERRORerrorERROR";
	if (debug) System.out.println("Foreach loop header started");
	cw.codePrintln("; Foreach loop header started");
	//	cw.codePrintln("; " + node);
        inAForeachInDoLoopHeaders(node);
        if(node.getForeach() != null) {
            node.getForeach().apply(this);
        }
        if(node.getSingleDeclaration() != null) {
	    AVariableDeclaration vd = (AVariableDeclaration)((AVariableSavHelpDeclarations)((ASetArrayVarSingleDeclaration)node.getSingleDeclaration()).getSavHelpDeclarations()).getVariableDeclaration();
	    varLocation = addScopeVariable(vd.getName().toString(), true);
	    type = makeType(vd.getType().toString());
	    if (type.equals("Integer") || type.equals("Float")) {
		type = type + "Number";
	    }
            //node.getSingleDeclaration().apply(this);
        }
        if(node.getIn() != null) {
            node.getIn().apply(this);
        }
        if(node.getVName() != null) {
	    cw.codePrintln("; Loading iterator for composite type");
	    cw.codePrintln("aload " + vmap.getLocation(node.getVName().toString()));
	    cw.codePrintln("ldc \"" + type + "\"");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/CompositeIterable/getIterator(Ljava/lang/String;)Ljava/util/Iterator; 2");
	    itLocation = addScopeVariable("@itCOMP");;
	    cw.codePrintln("astore " + itLocation);
            //node.getVName().apply(this);
        }
//         if(node.getDo() != null) {
//             node.getDo().apply(this);
//         }
        outAForeachInDoLoopHeaders(node);
	makeLabel();

	cw.codePrintln("aload " + itLocation);
	cw.codePrintln("invokeinterface java/util/Iterator/hasNext()Z 1");
	cw.codePrintln("ifeq " + cw.topBreakLabel());
	cw.codePrintln("aload " + itLocation);
	cw.codePrintln("invokeinterface java/util/Iterator/next()Ljava/lang/Object; 1");
	castToType(type);
	cw.codePrintln("astore " + varLocation);

	if (debug) System.out.println("Foreach loop header ended");
	cw.codePrintln("; Foreach loop header ended\n");
    }


    /*
      FOREACH <type> IN <composite> WHERE <expr> DO ...
    */

    public final void caseAForeachInWhereDoLoopHeaders(AForeachInWhereDoLoopHeaders node) {
	int varLocation = -1;
	int itLocation = -1;
	String type = "ERRORerrorERROR";
	if (debug) System.out.println("Foreach-where loop header started");
	cw.codePrintln("; Foreach-where loop header started");
	//	cw.codePrintln("; " + node);
        inAForeachInWhereDoLoopHeaders(node);
        if (node.getForeach() != null) {
            node.getForeach().apply(this);
        }
        if (node.getSingleDeclaration() != null) {
	    AVariableDeclaration vd = (AVariableDeclaration)((AVariableSavHelpDeclarations)((ASetArrayVarSingleDeclaration)node.getSingleDeclaration()).getSavHelpDeclarations()).getVariableDeclaration();
	    varLocation = addScopeVariable(vd.getName().toString(), true);
	    type = makeType(vd.getType().toString());
            //node.getSingleDeclaration().apply(this);
        }
//         if (node.getIn() != null) {
//             node.getIn().apply(this);
//         }
        if (node.getVName() != null) {
	    cw.codePrintln("; Loading iterator for composite type");
	    cw.codePrintln("aload " + vmap.getLocation(node.getVName().toString()));
	    cw.codePrintln("ldc \"" + type + "\"");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/CompositeIterable/getIterator(Ljava/lang/String;)Ljava/util/Iterator; 2");
	    itLocation = addScopeVariable("@itCOMP");;
	    cw.codePrintln("astore " + itLocation);
	    //            node.getVName().apply(this);
        }
        if (node.getWhere() != null) {
            node.getWhere().apply(this);
        }
	makeLabel();
	cw.codePrintln("aload " + itLocation);
	cw.codePrintln("invokeinterface java/util/Iterator/hasNext()Z 1");
	cw.codePrintln("ifeq " + cw.topBreakLabel());
	cw.codePrintln("aload " + itLocation);
	cw.codePrintln("invokeinterface java/util/Iterator/next()Ljava/lang/Object; 1");
	castToType(type);
	cw.codePrintln("astore " + varLocation);

	
	assign = true;
        if (node.getExpression() != null) {
	    //	    cw.codePrintln("\n\n\n\n\n\n");
            node.getExpression().apply(this);
	    //cw.codePrintln("\n\n\n\n\n\n");
        }
	assign = false;
//         if(node.getDo() != null) {
//             node.getDo().apply(this);
//         }
	boolEval();
	cw.codePrintln("ifeq "+ cw.topLabel());
	//       outAForeachInWhereDoLoopHeaders(node);

	if (debug) System.out.println("Foreach-where loop header ended");
	cw.codePrintln("; Foreach-where loop header ended\n");
    }


//     public final void inAForeachInWhereDoLoopHeaders(AForeachInWhereDoLoopHeaders node){
// 	if (debug) System.out.println("Foreach-where loop started");
// 	cw.codePrintln("; Foreach-where loop started");

// 	makeLabel();
//     }





    /*
      FOR <int assign> TO <int> DO...
    */
    public final void caseAForToLoopHeaders(AForToLoopHeaders node) {
	int startLocation = -1;
	int endLocation = -1;
	if (debug) System.out.println("For-to loop header started");
	cw.codePrintln("; For-to loop header started");
	//	cw.codePrintln("; " + node);
        inAForToLoopHeaders(node);
        if (node.getFor() != null) {
            node.getFor().apply(this);
        }
        if (node.getVName() != null) {
	    // Adding local variable for loop-scope...
	    startLocation = addScopeVariable(node.getVName().toString(), true);
            //node.getVName().apply(this);
	    if (debug) System.out.println("local address for " + node.getVName().toString() + ": " + getScopeVariable(node.getVName().toString()));
        }
//         if(node.getAssign() != null) {
//             node.getAssign().apply(this);
//         }
        if (node.getFromExpr() != null) {
            node.getFromExpr().apply(this);
	    duplicateType("IntegerNumber");
	    cw.codePrintln("astore " + startLocation);
        }
        if (node.getTo() != null) {
            node.getTo().apply(this);
        }
        if (node.getToExpr() != null) {
            node.getToExpr().apply(this);
	    duplicateType("NumberNumber");
	    endLocation = addScopeVariable("@endTO");
	    cw.codePrintln("astore " + endLocation);
        }
	cw.codePrintln("goto LOOPSTART" + loopStartCounter);
//         if(node.getDo() != null) {
//             node.getDo().apply(this);
//         }
        outAForToLoopHeaders(node);
	makeLabel();
	
	cw.codePrintln("; Loading variables for loop");
	cw.codePrintln("aload " + startLocation);
	cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/IntegerNumber/increment()V 1");
	cw.codePrintln("LOOPSTART" + loopStartCounter++ + ":");

	cw.codePrintln("aload " + startLocation);
	cw.codePrintln("aload " + endLocation);
	cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/IntegerNumber/isLessOrEqual(Ldk/auc/cs/dogs/environment/types/NumberNumber;)Ldk/auc/cs/dogs/environment/types/Boolean; 2");
	boolEval();
	cw.codePrintln("ifeq " + cw.topBreakLabel());

	if (debug) System.out.println("For-to loop header ended");
	cw.codePrintln("; For-to loop header ended\n");
    }


    /*
      FOR <int assign> DOWNTO <int> DO...
    */
    public final void caseAForDowntoLoopHeaders(AForDowntoLoopHeaders node) {
	int startLocation = -1;
	int endLocation = -1;
	if (debug) System.out.println("For-downto loop header started");
	cw.codePrintln("; For-downto loop header started");
	//	cw.codePrintln("; " + node);
        inAForDowntoLoopHeaders(node);
        if (node.getFor() != null) {
            node.getFor().apply(this);
        }
        if (node.getVName() != null) {
	    // Adding local variable for loop-scope...
	    startLocation = addScopeVariable(node.getVName().toString(), true);
            //node.getVName().apply(this);
	    if (debug) System.out.println("local address for " + node.getVName().toString() + ": " + getScopeVariable(node.getVName().toString()));
        }
//         if(node.getAssign() != null) {
//             node.getAssign().apply(this);
//         }
        if (node.getFromExpr() != null) {
            node.getFromExpr().apply(this);
	    duplicateType("IntegerNumber");
	    cw.codePrintln("astore " + startLocation);
        }
        if (node.getDownto() != null) {
            node.getDownto().apply(this);
        }
        if (node.getDowntoExpr() != null) {
            node.getDowntoExpr().apply(this);
	    duplicateType("NumberNumber");
	    endLocation = addScopeVariable("@endDOWNTO");
	    cw.codePrintln("astore " + endLocation);
        }
	cw.codePrintln("goto LOOPSTART" + loopStartCounter);
//         if(node.getDo() != null) {
//             node.getDo().apply(this);
//         }
        outAForDowntoLoopHeaders(node);
	makeLabel();
	
	cw.codePrintln("; Loading variables for loop");
	cw.codePrintln("aload " + startLocation);
	cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/decrement()V 1");

	cw.codePrintln("LOOPSTART" + loopStartCounter++ + ":");
	cw.codePrintln("aload " + startLocation);
	cw.codePrintln("aload " + endLocation);
	cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/isGreaterOrEqual(Ldk/auc/cs/dogs/environment/types/NumberNumber;)Ldk/auc/cs/dogs/environment/types/Boolean; 2");
	boolEval();
	cw.codePrintln("ifeq " + cw.topBreakLabel());

	if (debug) System.out.println("For-downto loop header ended");
	cw.codePrintln("; For-downto loop header ended\n");
    }


    /*
      WHILE <boolean> DO ...
     */
    public final void caseAWhileDoOpenCommand(AWhileDoOpenCommand node) {
	if (debug) System.out.println("While-do (open) loop started");
	cw.addIndentScope();
	cw.makeBreakLabel();
	cw.codePrintln("; While-do (open) loop started");
	//	cw.codePrintln("; " + node);
	makeLabel();
        inAWhileDoOpenCommand(node);
        if (node.getWhile() != null) {
            node.getWhile().apply(this);
        }
	//	System.out.println("ASSIGN: true;");
       	assign = true;
        if (node.getExpression() != null) {
            node.getExpression().apply(this);
        }
	assign = false;
	//	System.out.println("ASSIGN: false;");
	boolEval();
	cw.codePrintln("ifeq "+ cw.topBreakLabel());
        if(node.getOpenCommand() != null) {
            node.getOpenCommand().apply(this);
        }
        outAWhileDoOpenCommand(node);
	if (debug) System.out.println("While-do (open) loop ended");
	cw.codePrintln("goto " + cw.popLabel());
	cw.popBreakLabel();
	cw.codePrintln("; While-do (open) loop ended\n");
	cw.removeIndentScope();
    }

    public final void caseAWhileDoClosedCommand(AWhileDoClosedCommand node) {
	if (debug) System.out.println("While-do (closed) loop started");
	cw.addIndentScope();
	cw.makeBreakLabel();
	cw.codePrintln("; While-do (closed) loop started");
	//	cw.codePrintln("; " + node);
	makeLabel();
        inAWhileDoClosedCommand(node);
        if(node.getWhile() != null) {
            node.getWhile().apply(this);
        }
	// 	System.out.println("ASSIGN: true;");
	assign = true;
	if(node.getExpression() != null) {
            node.getExpression().apply(this);
	    boolEval();
	    cw.codePrintln("ifeq "+ cw.topBreakLabel());
        }
	assign = false;
	//	System.out.println("ASSIGN: false;");
        if(node.getDo() != null) {
            node.getDo().apply(this);
        }
        if(node.getClosedCommand() != null) {
            node.getClosedCommand().apply(this);
        }
        outAWhileDoClosedCommand(node);
	if (debug) System.out.println("While-do (closed) loop ended");
	cw.codePrintln("goto " + cw.popLabel());
	cw.popBreakLabel();
	cw.codePrintln("; While-do (closed) loop ended\n");
	cw.removeIndentScope();
    }

    /*
      DO ... WHILE <boolean>
    */

    public final void caseADoWhileOpenCommand(ADoWhileOpenCommand node) {
	if (debug) System.out.println("Do-while (open) loop started");
	cw.addIndentScope();
	cw.makeBreakLabel();
	cw.codePrintln("; Do-while (open) loop started");
	//	cw.codePrintln("; " + node);
	makeLabel();
	inADoWhileOpenCommand(node);
        if(node.getDo() != null) {
            node.getDo().apply(this);
        }
        if(node.getOpenCommand() != null) {
            node.getOpenCommand().apply(this);
        }
        if(node.getWhile() != null) {
            node.getWhile().apply(this);
        }
        if(node.getExpression() != null) {
	    assign = true;
            node.getExpression().apply(this);
	    assign = false;
	    boolEval();
	    cw.codePrintln("ifgt " + cw.popLabel());
        }
        if(node.getSemicolon() != null) {
            node.getSemicolon().apply(this);
        }
        outADoWhileOpenCommand(node);
	if (debug) System.out.println("Do-while (open) loop ended");
	cw.popBreakLabel();
	cw.codePrintln("; Do-while (open) loop ended\n");
	cw.removeIndentScope();
    }

    public final void caseADoWhileClosedCommand(ADoWhileClosedCommand node) {
	if (debug) System.out.println("Do-while (closed) loop started");
	cw.addIndentScope();
	cw.makeBreakLabel();
	cw.codePrintln("; Do-while (closed) loop started");
	//	cw.codePrintln("; " + node);
	makeLabel(); 
	inADoWhileClosedCommand(node);
        if(node.getDo() != null) {
            node.getDo().apply(this);
        }
        if(node.getClosedCommand() != null) {
            node.getClosedCommand().apply(this);
        }
        if(node.getWhile() != null) {
            node.getWhile().apply(this);
        }
        if(node.getExpression() != null) {
	    assign = true;
            node.getExpression().apply(this);
	    assign = false;
	    boolEval();
	    cw.codePrintln("ifgt " + cw.popLabel());
        }
        if(node.getSemicolon() != null) {
            node.getSemicolon().apply(this);
        }
        outADoWhileClosedCommand(node);
	if (debug) System.out.println("Do-while (closed) loop ended");
	cw.popBreakLabel();
	cw.codePrintln("; Do-while (closed) loop ended\n");
	cw.removeIndentScope();
    }

    public final void caseABreakBasicCommands(ABreakBasicCommands node){
	cw.codePrintln("; breaking out of loop");
	cw.codePrintln("goto " + cw.topBreakLabel());
    }

    private void duplicateType(java.lang.String type) {
	cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/Type");
	cw.codePrintln("invokevirtual dk/auc/cs/dogs/environment/types/Type/duplicate()Ldk/auc/cs/dogs/environment/types/Type;");
	castToType(type);
    }

    private String makeLabel() {
	return cw.makeLabel("LOOP");
    }

    private void popScopeVariables() {
	if (debug) System.out.println("Popping scope variables");
      	HashMap tmpList = (HashMap)scopeVariables.get(scopeVariables.size() -1);
	vmap.remove(tmpList.size());
	scopeVariables.removeLast();
    }

    private void makeScopeVariables() {
	if (debug) System.out.println("Making scope variable");
	scopeVariables.addLast(new HashMap());
    }

    // Adds to the variablemap, and returns the local address
    private int addScopeVariable(String name) {
	return addScopeVariable(name, false);
    }

    // Adds to the variablemap, and returns the local address
    // if b is true, the name will be saved as given...
    private int addScopeVariable(String name, boolean b) {
	HashMap tmpList = (HashMap)scopeVariables.get(scopeVariables.size() -1);
	String str = name;
	if (!b) {
	   str = "@LocalVariable" + name + scopeCounter++;
	}
	tmpList.put(name, str);
	scopeVNames.addLast(str);
	return vmap.enterNew(str);
	//return vmap.getLocation(str);
    }

    // Returns the local address from the variablemap
    private int getScopeVariable(String name) {
	HashMap tmpList = (HashMap)scopeVariables.get(scopeVariables.size() -1);
	String str = (String)tmpList.get(name);
	return vmap.getLocation(str);
    }


} // LoopingEncoder
