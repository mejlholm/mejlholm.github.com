package dk.auc.cs.dogs.compiler.contextual.helpers;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.contextual.*;

import java.util.*;

public class ExpressionEvaluater {

    private IdentificationTable idTable = null;
    private IdentificationTableRecord idRecord = null;
    private FunctionProcedureProber prober = null;
    private String type = null;
    private String flag = null;
    private String name = null;

    public ExpressionEvaluater(IdentificationTable idTable, IdentificationTableRecord idRecord, FunctionProcedureProber prober, String name) {
	this.idTable = idTable;
	this.prober = prober;
	this.name = name;
	this.idRecord = idRecord;
    }
    
    public void evaluate(PExpression expr) {
	MultiTypeChecker multiTypeChecker = null;

 	if (type == null) {
 	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "string");
 	    multiTypeChecker.setFullEvaluation(true);
 	    expr.apply(multiTypeChecker);
 	    if (multiTypeChecker.isRightType()) {
 		type = "string";
 		flag = multiTypeChecker.getFlag();
 	    }
 	}
	
 	if (type == null) {
 	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "integer");
 	    multiTypeChecker.setFullEvaluation(true);
 	    expr.apply(multiTypeChecker);
 	    if (multiTypeChecker.isRightType()) {
 		type = "integer";
 		flag = multiTypeChecker.getFlag();
 	    }
 	}

 	if (type == null) {
 	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "float");
 	    multiTypeChecker.setFullEvaluation(true);
 	    expr.apply(multiTypeChecker);
 	    if (multiTypeChecker.isRightType()) {
 		type = "float";
 		flag = multiTypeChecker.getFlag();
 	    }	    
 	}

 	if (type == null) {
 	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "boolean");
 	    multiTypeChecker.setFullEvaluation(true);
 	    expr.apply(multiTypeChecker);
 	    if(multiTypeChecker.isRightType()) {
 		type = "boolean";
 		flag = multiTypeChecker.getFlag();
 	    }
 	}
	
	
 	if (type == null) {
 	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "edge");
 	    multiTypeChecker.setFullEvaluation(true);
 	    expr.apply(multiTypeChecker);
 	    if (multiTypeChecker.isRightType()) {
 		type = "edge";
 		flag = multiTypeChecker.getFlag();
 	    }
 	}

 	if (type == null) {
 	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "vertex");
 	    multiTypeChecker.setFullEvaluation(true);
 	    expr.apply(multiTypeChecker);
 	    if (multiTypeChecker.isRightType()) {
 		type = "vertex";
 		flag = multiTypeChecker.getFlag();
 	    }
 	}

 	if (type == null) {
 	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "graph");
 	    multiTypeChecker.setFullEvaluation(true);
 	    expr.apply(multiTypeChecker);
 	    if (multiTypeChecker.isRightType()) {
 		type = "graph";
 		flag = multiTypeChecker.getFlag();
 	    }
 	}

 	if (type == null) {
 	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "diGraph");
 	    multiTypeChecker.setFullEvaluation(true);
 	    expr.apply(multiTypeChecker);
 	    if (multiTypeChecker.isRightType()) {
 		type = "diGraph";
 		flag = multiTypeChecker.getFlag();
 	    }
 	}

 	if (type == null) {
 	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "label");
 	    multiTypeChecker.setFullEvaluation(true);
 	    expr.apply(multiTypeChecker);
 	    if (multiTypeChecker.isRightType()) {
 		type = "label";
 		flag = multiTypeChecker.getFlag();
 	    }
 	}

 	if (type == null) {
 	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "weight");
 	    multiTypeChecker.setFullEvaluation(true);
 	    expr.apply(multiTypeChecker);
 	    if (multiTypeChecker.isRightType()) {
 		type = "weight";
 		flag = multiTypeChecker.getFlag();
 	    }
 	}

 	if (type == null) {
	    // RECORD TYPE ???? - Skal komme til sidst!!!
	    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "");
	    multiTypeChecker.setFullEvaluation(true);
	    expr.apply(multiTypeChecker);
	    type = multiTypeChecker.getType();
	    flag = multiTypeChecker.getFlag();
 	}
    }
    
    public String getFlag() {
	return flag;
    }

    public String getType() {
	return type;
    }
}
