package dk.auc.cs.dogs.compiler.optimiser.probers;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.optimiser.probers.TypeProber;
import java.util.ArrayList;


/**
 * BranchingProber.java
 *
 *
 * Created: Wed May 12 19:39:17 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class BranchingProber extends TypeProber {

    private boolean debug = false;

    private ArrayList expressions = new ArrayList();
    private ArrayList types = new ArrayList();
    private ArrayList nodes = new ArrayList();

    public BranchingProber() {
	
    } // BranchingProber constructor
    
    
    public void caseAIfElseOpenCommand(AIfElseOpenCommand node){
        inAIfElseOpenCommand(node);
        if(node.getIf() != null)
        {
            node.getIf().apply(this);
	    nodes.add(node);
	    types.add("branch");
	    expressions.add(node.getIf().getText());
        }
        if(node.getExpression() != null)
        {
            node.getExpression().apply(this);
        }
        if(node.getThen() != null)
        {
            node.getThen().apply(this);
	    nodes.add(node);
	    types.add("branch");
	    expressions.add(node.getThen().getText());
        }
        if(node.getClosedCommand() != null)
        {
            node.getClosedCommand().apply(this);
        }
        if(node.getElse() != null)
        {
            node.getElse().apply(this);
	    nodes.add(node);
	    types.add("branch");
	    expressions.add(node.getElse().getText());
        }
        if(node.getOpenCommand() != null)
        {
            node.getOpenCommand().apply(this);
        }
        outAIfElseOpenCommand(node);
    }

    public void caseAIfOpenElseClosedCommand(AIfOpenElseClosedCommand node){
        inAIfOpenElseClosedCommand(node);
        if(node.getIf() != null)
        {
            node.getIf().apply(this);
	    nodes.add(node);
	    types.add("branch");
	    expressions.add(node.getIf().getText());
        }
        if(node.getExpression() != null)
        {
            node.getExpression().apply(this);
        }
        if(node.getThen() != null)
        {
            node.getThen().apply(this);
	    nodes.add(node);
	    types.add("branch");
	    expressions.add(node.getThen().getText());
        }
        if(node.getTrue() != null)
        {
            node.getTrue().apply(this);
        }
        if(node.getElse() != null)
        {
            node.getElse().apply(this);
	    nodes.add(node);
	    types.add("branch");
	    expressions.add(node.getElse().getText());
        }
        if(node.getFalse() != null)
        {
            node.getFalse().apply(this);
        }
        outAIfOpenElseClosedCommand(node);
    }

    public void caseAIfThenOpenCommand(AIfThenOpenCommand node){
        inAIfThenOpenCommand(node);
        if(node.getIf() != null)
        {
            node.getIf().apply(this);
	    nodes.add(node);
	    types.add("branch");
	    expressions.add(node.getIf().getText());
        }
        if(node.getExpression() != null)
        {
            node.getExpression().apply(this);
        }
        if(node.getThen() != null)
        {
            node.getThen().apply(this);
	    nodes.add(node);
	    types.add("branch");
	    expressions.add(node.getThen().getText());
        }
        if(node.getSingleCommand() != null)
        {
            node.getSingleCommand().apply(this);
        }
        outAIfThenOpenCommand(node);
    }

    public void inABooleanPrimaryExpression(ABooleanPrimaryExpression node){
    nodes.add(node);
    types.add("bool");
    expressions.add(node.getBooleanLiteral().getText());
    }


    public void cleanLists(){
	expressions.clear();
	types.clear();
	nodes.clear();
    }
    
    public int size(){
	return expressions.size();
    }

    public void print(){
	System.out.println("Left in the list:");
	for (int i=0; i < expressions.size(); i++){
	    System.out.print("" + expressions.get(i));
	    System.out.println(" " + types.get(i));
	}
    }

    /**
     * Gets the value of expressions
     *
     * @return the value of expressions
     */
    public String getExpression(int i)  {
	return (String)expressions.get(i);
    }

    /**
     * Gets the value of types
     *
     * @return the value of types
     */
    public String getType(int i)  {
	return (String)types.get(i);
    }

    /**
     * Gets the value of nodes
     *
     * @return the value of nodes
     */
    public Node getNode(int i)  {
	return (Node) nodes.get(i);
    }

} // BranchingProber
