package dk.auc.cs.dogs.environment.types;

public interface WeightString extends WeightInterface {
}