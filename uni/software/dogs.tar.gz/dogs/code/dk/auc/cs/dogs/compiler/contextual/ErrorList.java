package dk.auc.cs.dogs.compiler.contextual;

import java.util.*;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.node.Token;


/**
 * The <code>ErrorList</code> class wraps a static list of error reports.
 *
 * @version 1.0
 */
public class ErrorList {
    private static List errors = new LinkedList();
    private static String last = new String();
    
    /**
     * The <code>add</code> method adds an error to the list.
     *
     * @param token a <code>Token</code> value
     * @param errMessage a <code>String</code> value
     */
    public static void add(Token token, String errMessage) {
	if (!last.equals("Error in line " + token.getLine() + ": " + errMessage)); {
	    errors.add("Error in line " + token.getLine() + ": " + errMessage);
	}
	last = "Error in line " + token.getLine() + ": " + errMessage;
    }

    
    /**
     * The <code>add</code> method adds an error to the list.
     *
     * @param errMessage a <code>String</code> value
     */
    public static void add(String errMessage) {
	errors.add(errMessage);
    }

    
    /**
     * The <code>printErrors</code> method prints contents of the
     * errorlist.
     *
     */
    public static void printErrors() {
	System.out.println(getErrors());
    }

    
    /**
     * The <code>getErrors</code> method makes one string of all the
     * errors.
     *
     * @return a <code>String</code> value
     */
    public static String getErrors() {
	String err = "";
	for (int i = 0; i < errors.size(); i++) {
	    if (err.length() > 0) {
		err = err + "\n";
	    }
	    err = err + errors.get(i).toString();
	}
	return err;
    }

    
    /**
     * The <code>size</code> method returns the size of the errorslist.
     *
     * @return an <code>int</code> value
     */
    public static int size(){
	return errors.size();
    }

    
    /**
     * The <code>flush</code> method clears the list.
     *
     */
    public static void flush() {
	errors = new LinkedList();
    }
}
