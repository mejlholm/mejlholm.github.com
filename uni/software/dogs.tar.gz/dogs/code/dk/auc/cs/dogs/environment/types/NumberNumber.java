package dk.auc.cs.dogs.environment.types;

public interface NumberNumber extends TypeInterface {

    public Type duplicate();
    public java.lang.String toString();


    /*
      BOOLEAN EXPRESSIONS
    */

    public Boolean isLess(NumberNumber n);
    public Boolean isGreater(NumberNumber n);
    public Boolean isLessOrEqual(NumberNumber n);
    public Boolean isGreaterOrEqual(NumberNumber n);
    public Boolean isEqual(NumberNumber n);
    public Boolean isDifferent(NumberNumber n);

    /*
      ARITHMETIC OPERATIONS
    */

    public void increment();
    public void decrement();

    public NumberNumber modulus(NumberNumber n);
    public NumberNumber integerDivision(NumberNumber n);

    public NumberNumber addition(NumberNumber n);
    public NumberNumber subtraction(NumberNumber n);
    public NumberNumber multiplication(NumberNumber n);
    public NumberNumber division(NumberNumber n);

    public double getValue();
    public java.lang.String getName();


}// NumberNumber