package dk.auc.cs.dogs.environment.types;

public interface SetVertex extends SetInterface {
}