package dk.auc.cs.dogs.environment.types;

public class Boolean extends Primitive {
    private boolean value;
    private boolean debug = false;

    public java.lang.String toString() {
	return "" + value;
    }

    public Boolean(boolean b) {
	super();
	if (debug) System.out.println("Creating boolean with value " + b);
	value = b;
    }

    public Type duplicate() {
	return new Boolean(value);
    }

    public void setValue(boolean b) {
	value = b;
    }

    public boolean getValue() {
	if (debug) System.out.println("Getting " + value + " from boolean");
	return value;
    }

    public Boolean isEqual(Boolean b) {
	return new Boolean((getValue() && b.getValue())||(!getValue() && !b.getValue()));
    }

    // returns a new inverted Boolean
    public Boolean invert() {
	return new Boolean(!value);
    }

    public Boolean and(Boolean b){
	return new Boolean(value && b.getValue());
    }

    public Boolean xor(Boolean b){
	return new Boolean((value && !b.getValue()) || (!value && b.getValue()));
    }

    public Boolean isEqual(Primitive p) {
	System.out.println("comparing...");
	if (p instanceof Boolean) {
	    return isEqual((Boolean)p);
	} else {
	    return new Boolean(false);
	}
    }
}
