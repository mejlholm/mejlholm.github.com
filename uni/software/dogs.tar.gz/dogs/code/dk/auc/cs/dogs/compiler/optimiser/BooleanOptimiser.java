package dk.auc.cs.dogs.compiler.optimiser;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.optimiser.probers.*;

public class BooleanOptimiser extends TypeOptimiser {

    boolean debug = true;

    public BooleanOptimiser() {
	super();
    } // BooleanOptimiser constructor

    public void outALtLessGreaterExpr(ALtLessGreaterExpr node){
	optimise(node);
    }

    public void outALteqLessGreaterExpr(ALteqLessGreaterExpr node){
	optimise(node);
    }

    public void outAGteqLessGreaterExpr(AGteqLessGreaterExpr node){
	optimise(node);
    }

    public void outAGtLessGreaterExpr(AGtLessGreaterExpr node){
	optimise(node);
    }

    public void outANotEqualCompareExpr(ANotEqualCompareExpr node){
	BooleanProber bp = new BooleanProber();
 	node.apply(bp);
	if (bp.size() == 3) {
	    APlusMinusLessGreaterExpr apm = optimise(bp);
	    if (apm != null){
		ALtGtCompareExpr agc = new ALtGtCompareExpr();
		agc.setLessGreaterExpr(apm);
		node.replaceBy(agc);
	    }
	}
    }

    public void outAEqualCompareExpr(AEqualCompareExpr node){
	BooleanProber bp = new BooleanProber();
 	node.apply(bp);
	if (bp.size() == 3) {
	    APlusMinusLessGreaterExpr apm = optimise(bp);
	    if (apm != null){
		ALtGtCompareExpr agc = new ALtGtCompareExpr();
		agc.setLessGreaterExpr(apm);
		node.replaceBy(agc);
	    }
	}
    }

    public void outANotNotExpr(ANotNotExpr node){
	BooleanProber bp = new BooleanProber();
	boolean b = false;
 	node.apply(bp);
	if (bp.size() == 2) {
	    if (!bp.getExpression(1).equals("true")) {
		b = true;
	    }
	    APlusMinusLessGreaterExpr apm = makeBoolean(b);;
	    ALtGtCompareExpr agc = new ALtGtCompareExpr();
	    ACompareNotExpr ace = new ACompareNotExpr();
	    agc.setLessGreaterExpr(apm);
	    ace.setCompareExpr(agc);
	    node.replaceBy(ace);
	}
    }

    public void outAAndAndExpr(AAndAndExpr node){
	BooleanProber bp = new BooleanProber();
	boolean b1 = false, b2 = false, b = false;
 	node.apply(bp);
	if (bp.size() == 3) {
	    if (bp.getExpression(0).equals("true")) {
		b1 = true;
	    }
	    if (bp.getExpression(2).equals("true")) {
		b2 = true;
	    }
	    b = (b1 && b2);
	    APlusMinusLessGreaterExpr apm = makeBoolean(b);;
	    ALtGtCompareExpr agc = new ALtGtCompareExpr();
	    ACompareNotExpr ace = new ACompareNotExpr();
	    ANotAndExpr ana = new ANotAndExpr();
	    agc.setLessGreaterExpr(apm);
	    ace.setCompareExpr(agc);
	    ana.setNotExpr(ace);
	    node.replaceBy(ana);
	}
    }

    public void outAXorOrExpr(AXorOrExpr node){
	BooleanProber bp = new BooleanProber();
	boolean b1 = false, b2 = false, b = false;
 	node.apply(bp);
	if (bp.size() == 3) {
	    if (bp.getExpression(0).equals("true")) {
		b1 = true;
	    }
	    if (bp.getExpression(2).equals("true")) {
		b2 = true;
	    }
	    b = (b1 && !b2) || (!b1 && b2);
	    APlusMinusLessGreaterExpr apm = makeBoolean(b);;
	    ALtGtCompareExpr agc = new ALtGtCompareExpr();
	    ACompareNotExpr ace = new ACompareNotExpr();
	    ANotAndExpr ana = new ANotAndExpr();
	    AAndOrExpr aoe = new AAndOrExpr();
	    agc.setLessGreaterExpr(apm);
	    ace.setCompareExpr(agc);
	    ana.setNotExpr(ace);
	    aoe.setAndExpr(ana);
	    node.replaceBy(aoe);
	}
    }

    public void outAOrOrExpr(AOrOrExpr node){
	BooleanProber bp = new BooleanProber();
	boolean b1 = false, b2 = false, b = false;
 	node.apply(bp);
	if (bp.size() == 3) {
	    if (bp.getExpression(0).equals("true")) {
		b1 = true;
	    }
	    if (bp.getExpression(2).equals("true")) {
		b2 = true;
	    }
	    b = (b1 || b2);
	    APlusMinusLessGreaterExpr apm = makeBoolean(b);;
	    ALtGtCompareExpr agc = new ALtGtCompareExpr();
	    ACompareNotExpr ace = new ACompareNotExpr();
	    ANotAndExpr ana = new ANotAndExpr();
	    AAndOrExpr aoe = new AAndOrExpr();
	    agc.setLessGreaterExpr(apm);
	    ace.setCompareExpr(agc);
	    ana.setNotExpr(ace);
	    aoe.setAndExpr(ana);
	    node.replaceBy(aoe);
	}
    }

    public void outAParPrimaryExpression(AParPrimaryExpression node){
	BooleanProber bp = new BooleanProber();
	node.apply(bp);
	if (bp.size() == 1 && bp.getType(0).equals("b")){
	    if (debug) System.out.println("Removing boolean ()");
	    node.replaceBy(bp.getNode(0));
	}
    }

    private void optimise(Node node) {
	BooleanProber bp = new BooleanProber();
 	node.apply(bp);
	if (bp.size() == 3) {
	    APlusMinusLessGreaterExpr tmp = optimise(bp);
	    if (tmp != null){
		node.replaceBy(tmp);
	    }
	}
    }

    private APlusMinusLessGreaterExpr optimise(BooleanProber bp){

	String s1, s2, s3;
	String t1, t2, t3;

	boolean b = false;
	boolean optimiseable = false;

       	s1 = bp.getExpression(0);
       	s2 = bp.getExpression(1);
       	s3 = bp.getExpression(2);

       	t1 = bp.getType(0);
       	t2 = bp.getType(1);
       	t3 = bp.getType(2);

	// Sammenligninger mellem 2 tal
	if ((t1.equals("i") || t1.equals("f")) && t2.equals("") && (t3.equals("i") || t3.equals("f"))){
	    float f1 = new Float(s1).floatValue();
	    float f2 = new Float(s3).floatValue();
	    if (s2.equals("<")) {
		optimiseable = true;
		b = (f1 < f2);
		if (debug) System.out.println(f1 + " < " + f2 + " : " + b);
	    }
	    if (s2.equals(">")) {
		optimiseable = true;
		b = (f1 > f2);
		if (debug) System.out.println(f1 + " > " + f2 + " : " + b);
	    }
	    if (s2.equals("<=")) {
		optimiseable = true;
		b = (f1 <= f2);
		if (debug) System.out.println(f1 + " <= " + f2 + " : " + b);
	    }
	    if (s2.equals(">=")) {
		optimiseable = true;
		b = (f1 >= f2);
		if (debug) System.out.println(f1 + " >= " + f2 + " : " + b);
	    }
	    if (s2.equals("<>")) {
		optimiseable = true;
		b = (f1 != f2);
	    }
	    if (s2.equals("=")) {
		optimiseable = true;
		b = (f1 == f2);
		if (debug) System.out.println(f1 + " = " + f2 + " : " + b);
	    }
	}
	
	// infty p� h�jre side
	if ((t1.equals("i") || t1.equals("f")) && t2.equals("") && (t3.equals("inf"))){
	    if (s2.equals("<")) {
		optimiseable = true;
		b = true;
	    }
	    if (s2.equals(">")) {
		optimiseable = true;
		b = false;
	    }
	    if (s2.equals("<=")) {
		optimiseable = true;
		b = true;
	    }
	    if (s2.equals(">=")) {
		optimiseable = true;
		b = false;
	    }
	    if (s2.equals("<>")) {
		optimiseable = true;
		b = true;
	    }
	    if (s2.equals("=")) {
		optimiseable = true;
		b = false;
	    }	    
	}

	// infty p� venstre side
	if (t1.equals("inf") && t2.equals("") && ((t3.equals("i") || t3.equals("f")))){
	    if (s2.equals("<")) {
		optimiseable = true;
		b = false;
	    }
	    if (s2.equals(">")) {
		optimiseable = true;
		b = true;
	    }
	    if (s2.equals("<=")) {
		optimiseable = true;
		b = false;
	    }
	    if (s2.equals(">=")) {
		optimiseable = true;
		b = true;
	    }
	    if (s2.equals("<>")) {
		optimiseable = true;
		b = true;
	    }
	    if (s2.equals("=")) {
		optimiseable = true;
		b = true;
	    }
	}

	// infty p� begge sider
	if (t1.equals("inf") && t2.equals("") && t3.equals("inf")){
	    if (s2.equals("<")) {
		optimiseable = true;
		b = false;
	    }
	    if (s2.equals(">")) {
		optimiseable = true;
		b = false;
	    }
	    if (s2.equals("<=")) {
		optimiseable = true;
		b = true;
	    }
	    if (s2.equals(">=")) {
		optimiseable = true;
		b = true;
	    }
	    if (s2.equals("<>")) {
		optimiseable = true;
		b = false;
	    }
	    if (s2.equals("=")) {
		optimiseable = true;
		b = true;
	    }	    
	}

	if (bp.getNegativeInfty()) {
	    optimiseable = true;
	    b = !b;
	}
	if (optimiseable)
	    return makeBoolean(b);

	return null;
    }

    private APlusMinusLessGreaterExpr makeBoolean(boolean b) {
	APlusMinusLessGreaterExpr apm = new APlusMinusLessGreaterExpr();
	AMultiPlusMinusExpr mpm = new AMultiPlusMinusExpr();
	AConcatinationExprMultiplicationExpr aceme = new AConcatinationExprMultiplicationExpr();
	AUnaryPpMmConcatinationExpr aexp = new AUnaryPpMmConcatinationExpr();
	ABooleanPrimaryExpression bpe = new ABooleanPrimaryExpression(new TBooleanLiteral("" + b));

	apm.setPlusMinusExpr(mpm);
	mpm.setMultiplicationExpr(aceme);
	aceme.setConcatinationExpr(aexp);
	aexp.setPrimaryExpression(bpe);

	return apm;
    }

} // BooleanOptimiser
