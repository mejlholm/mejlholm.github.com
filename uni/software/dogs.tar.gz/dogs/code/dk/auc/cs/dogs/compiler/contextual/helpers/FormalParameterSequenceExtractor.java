package dk.auc.cs.dogs.compiler.contextual.helpers;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.contextual.*;

public class FormalParameterSequenceExtractor extends DepthFirstAdapter {

    private IdentificationTable idTable = null;
    private StandardEnvironment stdEnv = null;
    private String idName = null;

    public FormalParameterSequenceExtractor(IdentificationTable idTable, StandardEnvironment stdEnv) {
	this.idTable = idTable;
	this.stdEnv = stdEnv;
    }
    
    // The identifier
    public void inAFormalParameterSequence(AFormalParameterSequence node) {
	idName = node.getIdentifier().getText();
    }

    // The identifier
    public void inAFormalTypeDenoter(AFormalTypeDenoter node) {
	idName = node.getIdentifier().getText();
    }

    public void inAIdentifierTypeDenoter(AIdentifierTypeDenoter node) {
	try {
	    if (stdEnv.knownType(node.getIdentifier().getText())) {
		if (stdEnv.isRecord(node.getIdentifier().getText())) {
		    idTable.enter(idName, stdEnv.getRecord(node.getIdentifier().getText()), false);
		} else {
		    idTable.enter(idName, node, false);
		}
	    } else {
		ErrorList.add(node.getIdentifier(), "unknown type");
	    }
	} catch(IdTableException e) {
	    ErrorList.add(node.getIdentifier(), e.getMessage());
	} catch(StandardEnvironmentException e) {
	    ErrorList.add(node.getIdentifier(), e.getMessage());
	}
    }

    // Declaration of arrays
    public void inAArrayTypeDenoter(AArrayTypeDenoter node) {
	try {
	    if (stdEnv.knownType(node.getType().getText())) {
		idTable.enter(idName, node, false);
	    } else {
		ErrorList.add(node.getType(), "unknown type");
	    }
	} catch(IdTableException e) {
	    ErrorList.add(node.getType(), e.getMessage());
	}
    }

    public void inAWeightTypeDenoter(AWeightTypeDenoter node) {
	try {
	    if (stdEnv.knownType(node.getType().getText())) {
		idTable.enter(idName, node, false);
	    } else {
		ErrorList.add(node.getType(), "unknown type");
	    }
	} catch(IdTableException e) {
	    ErrorList.add(node.getType(), e.getMessage());
	}
    }

    public void inALabelTypeDenoter(ALabelTypeDenoter node) {
	try {
	    if (stdEnv.knownType(node.getType().getText())) {
		idTable.enter(idName, node, false);
	    } else {
		ErrorList.add(node.getType(), "unknown type");
	    }
	} catch(IdTableException e) {
	    ErrorList.add(node.getType(), e.getMessage());
	}
    }

    public void inASetTypeDenoter(ASetTypeDenoter node) {
	try {
	    if (stdEnv.knownType(node.getType().getText())) {
		idTable.enter(idName, node, false);
	    } else {
		ErrorList.add(node.getType(), "unknown type");
	    }
	} catch(IdTableException e) {
	    ErrorList.add(node.getType(), e.getMessage());
	}
    }
}
