package dk.auc.cs.dogs.environment.types;

import java.util.*;

public class Graph extends GraphComposite {

    private boolean debug = true;

    private LinkedList 
	vertices = new LinkedList(),
	connections = new LinkedList(),
	weightList = new LinkedList(),
	labelList = new LinkedList();

    public Graph() {
	super();
    }

    public boolean isEdge(Vertex v1, Vertex v2) {
	return isEdge(getIndex(v1), getIndex(v2));
    }

    public boolean isEdge(int i1, int i2) {
	LinkedList tmpList = (LinkedList)connections.get(i1);
	return ((Boolean)tmpList.get(i2)).getValue();
    }

    // Returns the index in the linkedlist
    public int getIndex(Vertex v) {
	int index = -1;
	if (v.getGraph().equals(this)) {
	    if ((index = vertices.indexOf(v.getName())) != -1) {
		return index;
	    } else {
		throw new RuntimeException("Fatal error: inconsistent vertex cannot be localised in graph");
	    }
	} else {
	    throw new RuntimeException("Cannot extract index for vertex from wrong graph");
	}
    }

    public void removeEdge(Vertex v1, Vertex v2) {
	removeEdge(new Edge(v1, v2));
    }

    public void removeEdge(Edge e) {
	java.lang.String n1, n2;
	n1 = e.getVertex1().getName();
	n2 = e.getVertex2().getName();
	int index1, index2;
	index1 = vertices.indexOf(n1);
	index2 = vertices.indexOf(n2);
	LinkedList tmpList;
	if (index1 != -1 && index2 != -1) {
	    tmpList = (LinkedList)connections.get(index1);
	    ((Boolean)tmpList.get(index2)).setValue(false);
	    tmpList = (LinkedList)connections.get(index2);
	    ((Boolean)tmpList.get(index1)).setValue(false);
	    notifyRemoveWeights(e);
	} else {
	    throw new RuntimeException("Cannot remove edge with inconsistent vertices");
	}
    }

    public void addLabel(LabelInterface l) {
	if (l.getGraph().equals(this)) {
	    labelList.add(l);
	    for (int i = 0; i < vertices.size(); i++) {
		l.notifyAdd(new Vertex((java.lang.String)vertices.get(i), this));
	    }
	} else {
	    throw new RuntimeException("Cannot add label to graph: incompatible");
	}
    }

    public void addWeight(WeightInterface w) {
	if (w.getGraph().equals(this)) {
	    weightList.add(w);
	    // Tilf�jer knuderne til v�gt-funktionen
	    for (int i = 0; i < vertices.size(); i++) {
		w.notifyAdd(new Vertex((String)vertices.get(i), this));
	    }
	    for (int i = 0; i < vertices.size(); i++) {
		for (int j = 0; j  < vertices.size(); j++) {
		    if (isEdge(i, j)) {
			w.notifyAdd(new Edge(getVertex(i), getVertex(j)));
		    }
		}
	    }
	} else {
	    throw new RuntimeException("Cannot add weight to graph: incompatible");
	}
    }

    private Vertex getVertex(int i) {
	return new Vertex((java.lang.String)vertices.get(i), this);
    }

    public void removeVertex(Vertex v) {
	if (v.getGraph().equals(this)) {
	    removeVertex(v.getName());
	} else {
	    throw new RuntimeException("Inconsistent vertex: cannot remove from graph");
	}
    }

    public void removeVertex(java.lang.String name) {
	int i;
	if ((i = vertices.indexOf(name)) != -1) {
	    vertices.remove(i);
	    LinkedList tmpList;
	    for (int j = 0; i < connections.size(); i++) {
		tmpList = (LinkedList)connections.get(j);
		tmpList.remove(i);
	    }
	    notifyRemoveLabels(new Vertex(name, this));
	    notifyRemoveWeights(new Vertex(name, this));
	} else {
	    throw new RuntimeException("Inconsistent vertex: cannot remove from graph");
	}
    }

    public Set getAdjacents(Vertex v) {
	Set s = new Set("Vertex");
	int index;
	LinkedList tmpList;
	if ((index = vertices.indexOf(v.getName())) != -1) {
	    for (int i = 0; i < vertices.size(); i++) {
		tmpList = (LinkedList)connections.get(i);
		if (((Boolean)tmpList.get(index)).getValue()) {
		    s.add(new Vertex((java.lang.String)vertices.get(i), this));
		}
	    }
	} else {
	    throw new RuntimeException("Fatal error: inconsistent vertex!");
	}
	return s;
    }

    public boolean addEdge(Vertex v1, Vertex v2) {
	return addEdge(new Edge(v1, v2));
    }

    public boolean addEdge(Edge e) {
	boolean result = false;
	if (!hasEdge(e)) {
	    LinkedList tmpList;
	    int index1 = vertices.indexOf(e.getVertex1().getName());
	    int index2 = vertices.indexOf(e.getVertex2().getName());
	    tmpList = (LinkedList)connections.get(index1);
	    ((Boolean)tmpList.get(index2)).setValue(true);
	    tmpList = (LinkedList)connections.get(index2);
	    ((Boolean)tmpList.get(index1)).setValue(true);
	    notifyAddWeights(e);
	}
	return result;
    }

    private boolean hasEdge(Edge e) {
	return hasEdge(e.getVertex1(), e.getVertex2());
    }

    public boolean hasEdge(Vertex v1, Vertex v2) {
	boolean result = false;
	if (v1.getGraph().equals(this) && v2.getGraph().equals(this)) {
	    int index1, index2;
	    if (((index1 = vertices.indexOf(v1.getName())) != -1) && ((index2 = vertices.indexOf(v2.getName())) != -1)) {
		LinkedList tmpList = (LinkedList)connections.get(index1);
		return ((Boolean)tmpList.get(index2)).getValue();
	    }
	}
	return result;
    }

    public Edge getEdge(Vertex v1, Vertex v2) {
	if (v1.getGraph().equals(this) && v2.getGraph().equals(this)) {
	    if (hasEdge(v1, v2)) {
		return new Edge(v1, v2);
	    } else {
		throw new RuntimeException("There was not found an edge between the two vertices");
	    }
	} else {
	    throw new RuntimeException("There was not found an edge between the two vertices");
	}
    }

    public Set getVertices() {
	Set s = new Set("Vertex");
	Iterator it = getVertexIterator();
	while (it.hasNext()) {
	    s.add((Vertex)it.next());
	}
	return s;
    }
    
    public Iterator getVertexIterator() {
	LinkedList tmpList = new LinkedList();
	for (int i = 0; i < vertices.size(); i++) {
	    tmpList.addLast(new Vertex((java.lang.String)vertices.get(i), this));
	}
	return tmpList.iterator();
    }

    public Iterator getEdgeIterator() {
	return getEdges().getIterator("Edge");
    }

    public Set getEdges(Vertex v) {
	return getEdges(v.getName());
    }

    public Set getEdges() {
	Set s = new Set("Edge");
	Iterator it;
	for (int i = 0; i < vertices.size(); i++) {
	    it = getEdges((java.lang.String)vertices.get(i)).getIterator("Edge");
	    while (it.hasNext()) {
		// TODO: Skal der returneres en kant b�de for (v1, v2) + (v2, v1), eller kun den ene af disse?
		// Lige nu returneres begge...
		s.add((Primitive)it.next());
	    }
	}
	return s;
    }

    public Set getEdges(String name) {
	return getEdges(name.getValue());
    }

    public Set getEdges(java.lang.String name) {
	int index;
	if ((index = vertices.indexOf(name)) != -1) {
	    LinkedList tmpList = new LinkedList(), bList = (LinkedList)connections.get(index);
	    for (int i = 0; i < bList.size(); i++) {
		if (((Boolean)bList.get(i)).getValue()) {
		    tmpList.add(new Edge(getVertex((java.lang.String)vertices.get(index)),
					 getVertex((java.lang.String)vertices.get(i))));
		}
	    }
	    return new Set("Edge", tmpList.iterator());
	} else {
	    throw new RuntimeException("Fatal error: inconsistent vertex!");
	}
    }
    
    public Vertex addVertex(String name) {
	return addVertex(name.getValue());
    }

    public Vertex getVertex(String name) {
	return getVertex(name.getValue());
    }

    public Vertex addVertex(java.lang.String name) {
	if (!vertices.contains(name)) {
	    vertices.addLast(name);
	    for (int i = 0; i < connections.size(); i++) {
		((LinkedList)connections.get(i)).addLast(new Boolean(false));
	    }
	    LinkedList tmpList = new LinkedList();
	    for (int i = 0; i < vertices.size(); i++) {
		tmpList.addLast(new Boolean(false));
	    }
	    connections.addLast(tmpList);
	    Vertex v = new Vertex(name, this);
	    notifyAddLabels(v);
	    notifyAddWeights(v);
	    return v;
	} else {
	    throw new RuntimeException("Cannot add vertex \"" + name + "\" to graph twice");
	}
    }

    public Vertex getVertex(java.lang.String name) {
	Vertex v = null;
	if (vertices.contains(name)) {
	    v = new Vertex(name, this);
	}
	return v;
    }

    private void notifyAddLabels(Vertex v) {
	for (int i = 0; i < labelList.size(); i++) {
	    ((Label)labelList.get(i)).notifyAdd(v);
	}
    }

    private void notifyAddWeights(Vertex v) {
	for (int i = 0; i < weightList.size(); i++) {
	    ((Weight)weightList.get(i)).notifyAdd(v);
	}
    }

    private void notifyAddWeights(Edge e) {
	for (int i = 0; i < weightList.size(); i++) {
	    ((Weight)weightList.get(i)).notifyAdd(e);
	}
    }

    private void notifyRemoveLabels(Vertex v) {
	for (int i = 0; i < labelList.size(); i++) {
	    ((Label)labelList.get(i)).notifyRemove(v);
	}
    }

    private void notifyRemoveWeights(Vertex v) {
	for (int i = 0; i < weightList.size(); i++) {
	    ((Weight)weightList.get(i)).notifyRemove(v);
	}
    }

    private void notifyRemoveWeights(Edge e) {
	for (int i = 0; i < weightList.size(); i++) {
	    ((Weight)weightList.get(i)).notifyRemove(e);
	}
    }
}
