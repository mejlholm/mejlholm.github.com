package dk.auc.cs.dogs.compiler.contextual.helpers;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.node.*;

import java.util.*;

public class MultiTypeChecker extends DepthFirstAdapter {
    private String typeToMatch = null;
    private String stackSymbol = null;
    private Stack stack = null;
    private IdentificationTable idTable = null;
    private IdentificationTableRecord idRecord = null;
    private FunctionProcedureProber prober = null;
    private String procedureCallName = null;
    private boolean fullEvaluation = false; // Used to change the behavior
    private String flag = "variable"; // Standard flag value
    private boolean needToEvaluateParameters = false; // Flag used to check nested functions
    private boolean isRecord = false;
    private int notInStack = 0;
    private String tmpType = null;
    private boolean unaryInStack = false;
    private boolean equalsInStack = false;
    private boolean neqInStack = false;
    private boolean labelOrWeight = false;
    private int divInStack = -2;
    private String labelOrWeightType = null;
    private String typeWL = null;
    private boolean debug = false;

    public MultiTypeChecker() {
	// Empty constructor
    }

    public MultiTypeChecker(IdentificationTable idTable, IdentificationTableRecord idRecord, FunctionProcedureProber prober, String typeToMatch) {
	this.idTable = idTable;
	this.idRecord = idRecord;
	this.prober = prober;
	this.typeToMatch = typeToMatch;
	this.stackSymbol = typeToMatch;
	stack = new Stack();
    }
    
                                      /////////////////////////
                                     // Primary Expressions //
                                    /////////////////////////

    public void inAIntegerPrimaryExpression(AIntegerPrimaryExpression node) {
	if (!flag.equals("array")) {
	    if (typeToMatch.equals("float")) {
		stack.push("float");
	    } else {
		stack.push("integer");
	    }
	} else if (flag.equals("array")) {
	    stack.push(stackSymbol);
	    flag = "variable";
	}
    }
    
    public void inAFloatPrimaryExpression(AFloatPrimaryExpression node) {
	stack.push("float");
    }
    
    public void inAStringPrimaryExpression(AStringPrimaryExpression node) {    
	stack.push("string");
    }
    
    public void inABooleanPrimaryExpression(ABooleanPrimaryExpression node) {
	stack.push("boolean");
    }
    
    public void inAInftyPrimaryExpression(AInftyPrimaryExpression node) {
	stack.push("infty");
    } 

    public void caseAEdgePrimaryExpression(AEdgePrimaryExpression node) {
	String first = node.getFirst().getText();
	String last = node.getLast().getText();
	Node firstNode = null;
	Node lastNode = null;

	try {
	    firstNode = idTable.retrieve(first);
	    lastNode = idTable.retrieve(last);
	    if ((firstNode.getClass().getName().substring(29).equals("AVariableDeclaration")) && 
		(lastNode.getClass().getName().substring(29).equals("AVariableDeclaration"))) {
		if((((AVariableDeclaration)firstNode).getType().getText()).equals("vertex") && 
		   (((AVariableDeclaration)lastNode).getType().getText()).equals("vertex")) {
		    stack.push("edge");
		}
	    }
	} catch (IdTableException e) {
	    ErrorList.add(node.getFirst(), e.getMessage());
	}
    }


                                             //////////////////////
                                            // Operator symbols //
                                           //        Math      //  
                                          //////////////////////
    
    public void caseAPlusPlusMinusExpr(APlusPlusMinusExpr node) {
        if(node.getPlusMinusExpr() != null) {
            node.getPlusMinusExpr().apply(this);
        }
        if(node.getPlus() != null) {
	    if (stackSymbol.equals("float")) {
		stack.push("float");
	    } else {
		stack.push("integer");
	    }
        }
        if(node.getMultiplicationExpr() != null) {
            node.getMultiplicationExpr().apply(this);
        }
    }

    public void caseAMinusPlusMinusExpr(AMinusPlusMinusExpr node) {
        if(node.getPlusMinusExpr() != null) {
            node.getPlusMinusExpr().apply(this);
        }
        if(node.getMinus() != null) {
	    if (stackSymbol.equals("float")) {
		stack.push("float");
	    } else {
		stack.push("integer");
	    }
        }
        if(node.getMultiplicationExpr() != null) {
            node.getMultiplicationExpr().apply(this);
        }
    }

    public void caseAUnaryPlusPlusMinusExpr(AUnaryPlusPlusMinusExpr node) {
        if(node.getPlus() != null) {
	    unaryInStack = true;
	    if (stackSymbol.equals("float")) {
		stack.push("float");
	    } else {
		stack.push("integer");
	    }
        }
        if(node.getMultiplicationExpr() != null) {
            node.getMultiplicationExpr().apply(this);
        }
    }

    public void caseAUnaryMinusPlusMinusExpr(AUnaryMinusPlusMinusExpr node) {
        if(node.getMinus() != null) {
	    unaryInStack = true;
	    if (stackSymbol.equals("float")) {
		stack.push("float");
	    } else {
		stack.push("integer");
	    }
        }
        if(node.getMultiplicationExpr() != null) {
            node.getMultiplicationExpr().apply(this);
        }
    }

    public void caseAStarMultiplicationExpr(AStarMultiplicationExpr node) {
        if(node.getMultiplicationExpr() != null) {
            node.getMultiplicationExpr().apply(this);
        }
        if(node.getStar() != null) {
	    if (stackSymbol.equals("float")) {
		stack.push("float"); 
	    } else {
		stack.push("integer");
	    }
        }
        if(node.getConcatinationExpr() != null) {
            node.getConcatinationExpr().apply(this);
        }
    }

    public void caseADivMultiplicationExpr(ADivMultiplicationExpr node) {
        if(node.getMultiplicationExpr() != null) {
            node.getMultiplicationExpr().apply(this);
        }
        if(node.getDiv() != null) {
	    divInStack = stack.size();
	    stack.push("float"); // You can't make div with integer
        }
        if(node.getConcatinationExpr() != null) {
            node.getConcatinationExpr().apply(this);
        }
    }
    
    public void caseAIntDivMultiplicationExpr(AIntDivMultiplicationExpr node) {
        if(node.getMultiplicationExpr() != null) {
            node.getMultiplicationExpr().apply(this);
        }
        if(node.getIntDiv() != null) {
	    stack.push("integer"); // You can't make int div with float
        }
        if(node.getConcatinationExpr() != null) {
            node.getConcatinationExpr().apply(this);
        }
    }

    public void caseAModMultiplicationExpr(AModMultiplicationExpr node) {
        if(node.getMultiplicationExpr() != null) {
            node.getMultiplicationExpr().apply(this);
        }
        if(node.getMod() != null) {
	    stack.push("integer"); // You can't make mod with float
        }
        if(node.getConcatinationExpr() != null) {
            node.getConcatinationExpr().apply(this);
        }
    }
    
                                             //////////////////////
                                            // Operator symbols //
                                           //      boolean     //  
                                          //////////////////////

    public void caseAOrOrExpr(AOrOrExpr node) {
        if(node.getOrExpr() != null) {
            node.getOrExpr().apply(this);
        }
        if(node.getOr() != null) {
	    stack.push("boolean");
        }
        if(node.getAndExpr() != null) {
            node.getAndExpr().apply(this);
        }
    }

    public void caseAXorOrExpr(AXorOrExpr node) {
        if(node.getOrExpr() != null) {
            node.getOrExpr().apply(this);
        }
        if(node.getXor() != null) {
	    stack.push("boolean");
        }
        if(node.getAndExpr() != null) {
            node.getAndExpr().apply(this);
        }
    }

    public void caseAAndAndExpr(AAndAndExpr node) {
        if(node.getAndExpr() != null) {
            node.getAndExpr().apply(this);
        }
        if(node.getAnd() != null) {
	    stack.push("boolean");
        }
        if(node.getNotExpr() != null) {
            node.getNotExpr().apply(this);
        }
    }

    public void caseANotNotExpr(ANotNotExpr node) {
        if(node.getNot() != null) {
	    if (stack.empty()) {
		notInStack = 1;
	    } else {
		notInStack = stack.size();
	    }
	    stack.push("boolean");
        }
        if(node.getNotExpr() != null) {
            node.getNotExpr().apply(this);
        }
    }

    public void caseAEqualCompareExpr(AEqualCompareExpr node) {
        if(node.getCompareExpr() != null) {
            node.getCompareExpr().apply(this);
        }
        if(node.getEqual() != null) {
	    equalsInStack = true;
	    stack.push("boolean");
        }
        if(node.getLessGreaterExpr() != null) {
            node.getLessGreaterExpr().apply(this);
        }
    }

    public void caseANotEqualCompareExpr(ANotEqualCompareExpr node) {
        if(node.getCompareExpr() != null) {
            node.getCompareExpr().apply(this);
        }
        if(node.getNeq() != null) {
	    stack.push("boolean");
	    neqInStack = true;
        }
        if(node.getLessGreaterExpr() != null) {
            node.getLessGreaterExpr().apply(this);
        }
    }

    public void caseALtLessGreaterExpr(ALtLessGreaterExpr node) {
        if(node.getLessGreaterExpr() != null) {
            node.getLessGreaterExpr().apply(this);
        }
        if(node.getLt() != null) {
	    stack.push("boolean");
        }
        if(node.getPlusMinusExpr() != null) {
            node.getPlusMinusExpr().apply(this);
        }
    }

    public void caseAGtLessGreaterExpr(AGtLessGreaterExpr node) {
        if(node.getLessGreaterExpr() != null) {
            node.getLessGreaterExpr().apply(this);
        }
        if(node.getGt() != null) {
	    stack.push("boolean");
        }
        if(node.getPlusMinusExpr() != null) {
            node.getPlusMinusExpr().apply(this);
        }
    }

    public void caseALteqLessGreaterExpr(ALteqLessGreaterExpr node) {
        if(node.getLessGreaterExpr() != null) {
            node.getLessGreaterExpr().apply(this);
        }
        if(node.getLteq() != null) {
	    stack.push("boolean");
        }
        if(node.getPlusMinusExpr() != null) {
            node.getPlusMinusExpr().apply(this);
        }
    }

    public void caseAGteqLessGreaterExpr(AGteqLessGreaterExpr node) {
        if(node.getLessGreaterExpr() != null) {
            node.getLessGreaterExpr().apply(this);
        }
        if(node.getGteq() != null) {
	    stack.push("boolean");
        }
        if(node.getPlusMinusExpr() != null) {
            node.getPlusMinusExpr().apply(this);
        }
    }

    public void caseAConcatinationExpr(AConcatinationExpr node) {
        if (node.getPrimaryExpression() != null) {
            node.getPrimaryExpression().apply(this);
        }
        if (node.getConcat() != null) {
            node.getConcat().apply(this);
	    stack.push("&");
        }
        if (node.getConcatinationExpr() != null) {
            node.getConcatinationExpr().apply(this);
        }
    }

                                      /////////////////////////
                                     // Variable evaluation //
                                    /////////////////////////
    
    public void inAVName(AVName node) {
	Node rNode = null;
	String type = null;
	String castType = null;
	if (isRecord) {
	    try {
		idRecord.loadRecord(tmpType);	   
		rNode = idRecord.retrieve(node.getIdentifier().getText());
	    } catch (IdRecordTableException e) {
		ErrorList.add(node.getIdentifier(), e.getMessage());
	    }
	    type = findNodeType(rNode, node.getIdentifier());
	    tmpType = type;
	    stack.push(type);
	    isRecord = false;
	} else {
	    try {
		rNode = idTable.retrieve(node.getIdentifier().getText());
		castType = rNode.getClass().getName().substring(29);
		if (castType.equals("AVariableDeclaration")) {
		    type = ((AVariableDeclaration)rNode).getType().getText();
		    tmpType = type;
		    if (type.equals(typeToMatch)) {
			stack.push(stackSymbol);
			flag = "variable";
		    } else if (flag.equals("array") && typeToMatch.equals("string")) {
			stack.push("string");
			flag = "array";
		    } else if (typeToMatch.equals("boolean") && (type.equals("integer") ||
								 type.equals("float") ||
								 type.equals("string") ||
								 type.equals("vertex") ||
								 type.equals("edge"))) {
			stack.push(type);
			flag = "variable";
		    } else if (typeToMatch.equals("float") && (type.equals("integer") || (castType.equals("AForToLoopHeaders")))) {
			stack.push(stackSymbol);
			flag = "variable";
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("AIdentifierTypeDenoter")) {
		    type = ((AIdentifierTypeDenoter)rNode).getIdentifier().getText();
		    tmpType = type;
		    if (type.equals(typeToMatch)) {
			stack.push(stackSymbol);
			flag = "variable";
		    } else if (flag.equals("array") && typeToMatch.equals("string")) {
			stack.push("string");
			flag = "array";
		    } else if (typeToMatch.equals("boolean") && (type.equals("integer") ||
								 type.equals("float") ||
								 type.equals("string") ||
								 type.equals("vertex") ||
								 type.equals("edge"))) {
			stack.push(type);
			flag = "variable";
		    } else if (typeToMatch.equals("float") && (type.equals("integer") || (castType.equals("AForToLoopHeaders")))) {
			stack.push(stackSymbol);
			flag = "variable";
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("ARecordDeclaration")) {
		    type = ((ARecordDeclaration)rNode).getType().getText();
		    tmpType = type;
		    if (type.equals(typeToMatch)) {
			stack.push(stackSymbol);
			flag = "variable";
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("AArrayTypeDenoter")) {
		    type = ((AArrayTypeDenoter)rNode).getType().getText();
		    tmpType = type;
		    if (type.equals(typeToMatch)) {
			stack.push(stackSymbol);
			flag = "array";
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("AArrayDeclaration")) {
		    type = ((AArrayDeclaration)rNode).getType().getText();
		    tmpType = type;
		    if (type.equals(typeToMatch)) {
			stack.push(stackSymbol);
			flag = "array";
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("AIdentifierTypeDenoter")) {
		    type = ((AIdentifierTypeDenoter)rNode).getIdentifier().getText();
		    tmpType = type;
		    if (type.equals(typeToMatch)) {
			stack.push(stackSymbol);
			flag = "variable";
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("AWeightTypeDenoter")) {
		    type = ((AWeightTypeDenoter)rNode).getType().getText();
		    tmpType = type;
		    if (type.equals(typeToMatch)) {
			stack.push(stackSymbol);
			flag = "weight";
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("AWeightWeightLabelDeclaration")) {
		    type = ((AWeightWeightLabelDeclaration)rNode).getType().getText();
		    tmpType = type;
		    if (type.equals(typeToMatch)) {
			stack.push(stackSymbol);
			flag = "weight";
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("ALabelTypeDenoter")) {
		    type = ((ALabelTypeDenoter)rNode).getType().getText();
		    tmpType = type;
		    if (type.equals(typeToMatch)) {
			stack.push(stackSymbol);
			flag = "label";
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("ALabelWeightLabelDeclaration")) {
		    type = ((ALabelWeightLabelDeclaration)rNode).getType().getText();
		    tmpType = type;
		    if (type.equals(typeToMatch)) {
			stack.push(stackSymbol);
			flag = "label";
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("ASetDeclaration")) {
		    type = ((ASetDeclaration)rNode).getType().getText();
		    tmpType = type;
		    if (type.equals(typeToMatch)) {
			stack.push(stackSymbol);
			flag = "set";
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("ASetTypeDenoter")) {
		    type = ((ASetTypeDenoter)rNode).getType().getText();
		    tmpType = type;
		    if (type.equals(typeToMatch)) {
			stack.push(stackSymbol);
			flag = "set";
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("AForToLoopHeaders")) {
		    type = "integer";
		    tmpType = type;
		    stack.push("integer");
		    flag = "variable";
		} else {
		    if (!fullEvaluation) {
			throw new IdTableException(typeToMatch + " expected from a variable declaration, but other declaration type found");
		    } else {
			procedureCallName = node.getIdentifier().getText(); // maybe a proc or func name
		    }
		}
	    } catch(IdTableException e) {
		if (prober.isInTable(node.getIdentifier().getText())) {
		    procedureCallName = node.getIdentifier().getText(); // maybe a proc or func name
		    
		} else {
		    ErrorList.add(node.getIdentifier(), e.getMessage());
		}
	    }
	}
    }

                                    //////////////////////////////
                                   // Variable Name Extensions //
                                  //////////////////////////////

    public void inAIdentifierRecordVNameExtension(AIdentifierRecordVNameExtension node) {
	// Verify that the record is the rigth type in relation to typeToMatch
	flag = "variable";
	isRecord = true;
	stack.pop();
    }

    public void inAIdentifierArrayVNameExtension(AIdentifierArrayVNameExtension node) {
	String arrayName = ((AVName)node.parent()).getIdentifier().getText();
	Node arrayNode = null;

	try {
	    arrayNode = idTable.retrieve(arrayName);
	    if (arrayNode.getClass().getName().substring(29).equals("AArrayDeclaration")) {
		if (((AArrayDeclaration)arrayNode).getType().getText().equals(typeToMatch)) {
		    flag = "array";
		    stack.push(stackSymbol);
		} else {
		    stack.push("!!");
		}
	    } else if (arrayNode.getClass().getName().substring(29).equals("AArrayTypeDenoter")) {
		if (((AArrayTypeDenoter)arrayNode).getType().getText().equals(typeToMatch)) {
		    flag = "array";
		    stack.push(stackSymbol);
		} else {
		    stack.push("!!");
		}
	    }
	} catch (IdTableException e) {
	    ErrorList.add(node.getLBracket(), e.getMessage());
	}
    }

    public void caseAActualParameterSequence(AActualParameterSequence node) {
	if (needToEvaluateParameters) {
	    ExpressionEvaluater ee = null;
	    ArrayList formalTypes = null;
	    ArrayList formalFlags = null;
	    String type = null;
	    String flagA = null;
	    int parameterNumber = 0;
	    
	    if (!labelOrWeight) { 
		try {
		    formalTypes = prober.getTypes(procedureCallName);
		    formalFlags = prober.getFlags(procedureCallName);
		    
		    if (formalTypes != null) {
			if(node.getExpression() != null) {
			    ee = new ExpressionEvaluater(idTable, idRecord, prober, procedureCallName);
			    ee.evaluate(node.getExpression());
			    type = ee.getType();
			    flagA = ee.getFlag();

			    if (type == null || flagA == null) {
				throw new FunctionProcedureProberException("Error unknown parameter passed to procedure or function");
			    }

			    if (debug) {
				System.out.println(formalTypes);
				System.out.println(formalFlags);
				System.out.println(type);
				System.out.println(flagA);
				System.out.println(formalTypes.get(parameterNumber).equals(type));
				System.out.println(formalFlags.get(parameterNumber).equals(flagA));
			    }

			    if (!formalTypes.get(parameterNumber).equals(type) || !formalFlags.get(parameterNumber).equals(flagA)) {
				if (!compareTypes(type, formalTypes.get(parameterNumber).toString(), formalFlags.get(parameterNumber).toString())) {
				    throw new FunctionProcedureProberException("parameter "+parameterNumber+" expected as " + 
									       formalTypes.get(parameterNumber) + " " + 
									       formalFlags.get(parameterNumber) + " but was " + 
									       type + " " + flagA);
				}
			    }
			    parameterNumber++;
			}
			{
			    Object temp[] = node.getActualExpression().toArray();
			    for(int i = 0; i < temp.length; i++) {
				if (parameterNumber >= formalTypes.size()) {
				    throw new FunctionProcedureProberException("To many parameters in call");
				}
				
				ee = new ExpressionEvaluater(idTable, idRecord, prober, procedureCallName);
				ee.evaluate(((AActualExpression)temp[i]).getExpression());
				type = ee.getType();
				flagA = ee.getFlag();

				if (debug) {
				    System.out.println(type);
				    System.out.println(flagA);
				    System.out.println(formalTypes.get(parameterNumber).equals(type));
				    System.out.println(formalFlags.get(parameterNumber).equals(flagA));
				    System.out.println();
				}
				
				if (type == null || flagA == null) {
				    throw new FunctionProcedureProberException("Error unknown parameter passed to procedure or function");
				}
				
				if (!formalTypes.get(parameterNumber).equals(type) || !formalFlags.get(parameterNumber).equals(flagA)) {
				    if (!compareTypes(type, formalTypes.get(parameterNumber).toString(), formalFlags.get(parameterNumber).toString())) {
					throw new FunctionProcedureProberException("parameter "+parameterNumber+" expected " + 
										   formalTypes.get(parameterNumber) +  " " + 
										   formalFlags.get(parameterNumber) + " but was " +
										   type + " " + flagA);
				    }
				}
				parameterNumber++;
			    }
			}
		    } else {
			throw new FunctionProcedureProberException("Unknown procedure or function " + procedureCallName);
		    }
		} catch (FunctionProcedureProberException e) {
		    ErrorList.add(((AParameterCall)node.parent()).getLPar(), e.getMessage());
		}
	    } else {
		// label or weight function
		if (node.getExpression() != null) {
		    ee = new ExpressionEvaluater(idTable, idRecord, prober, procedureCallName);
		    ee.evaluate(node.getExpression());
		    type = ee.getType();
		    flagA = ee.getFlag();

		    if (labelOrWeightType.equals("label") && type.equals("vertex") && flagA.equals("variable")) {
			// Do nothing
		    } else if (labelOrWeightType.equals("weight") && type.equals("edge") && flagA.equals("variable")) {
			// Do nothing
		    } else {
			ErrorList.add(((AParameterCall)node.parent()).getLPar(), 
				      "wrong parameter type expected " + typeWL + " variable but was " + type + " " + flagA);
		    }
		}
	    }
	}

	// Reset
	labelOrWeight = false;
	needToEvaluateParameters = false;
    }

    public void inAParameterCall(AParameterCall node) {
	String castType = null;
        String parentType = null;
	Node rNode = null;

	procedureCallName = node.getName().getText();

	// Try to finde out if it is a label or weight function
	if (idTable.isInTable(procedureCallName) && !prober.isInTable(procedureCallName)) {
	    // We got a label or weight function
	    try {
		rNode = idTable.retrieve(node.getName().getText());
		castType = rNode.getClass().getName().substring(29);
		if (castType.equals("AWeightWeightLabelDeclaration")) {
		    typeWL = ((AWeightWeightLabelDeclaration)rNode).getType().getText();
		    if (typeWL.equals(typeToMatch)) {
			stack.push(stackSymbol);
			labelOrWeight = true;
			labelOrWeightType = "weight";
			needToEvaluateParameters = true;
		    } else if (typeToMatch.equals("boolean")) {
			stack.push(typeWL);
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("ALabelWeightLabelDeclaration")) {
		    typeWL = ((ALabelWeightLabelDeclaration)rNode).getType().getText();
		    if (typeWL.equals(typeToMatch)) {
			stack.push(stackSymbol);
			labelOrWeight = true;
			labelOrWeightType = "label";
			needToEvaluateParameters = true;
		    } else if (typeToMatch.equals("boolean")) {
			stack.push(typeWL);
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("ALabelTypeDenoter")) {
		    typeWL = ((ALabelTypeDenoter)rNode).getType().getText();
		    if (typeWL.equals(typeToMatch)) {
			stack.push(stackSymbol);
			labelOrWeight = true;
			labelOrWeightType = "label";
			needToEvaluateParameters = true;
		    } else if (typeToMatch.equals("boolean")) {
			stack.push(typeWL);
		    } else {
			stack.push("!!");
		    }
		} else if (castType.equals("AWeightTypeDenoter")) {
		    typeWL = ((AWeightTypeDenoter)rNode).getType().getText();
		    if (typeWL.equals(typeToMatch)) {
			stack.push(stackSymbol);
			labelOrWeight = true;
			labelOrWeightType = "weight";
			needToEvaluateParameters = true;
		    } else if (typeToMatch.equals("boolean")) {
			stack.push(typeWL);
		    } else {
			stack.push("!!");
		    }
		} else {
		    throw new IdTableException("Not a weight or label function");
		}
	    } catch (IdTableException e) {
		ErrorList.add(node.getName(), e.getMessage());
	    }
	} else {
	    try {
		flag = (String)((ArrayList)prober.getReturnType(procedureCallName)).get(1);
		if (((String)((ArrayList)prober.getReturnType(procedureCallName)).get(0)).equals(typeToMatch)) {
		    stack.push(stackSymbol);
		    needToEvaluateParameters = true;
		} else {
		    if (!compareTypes("", ((String)((ArrayList)prober.getReturnType(procedureCallName)).get(0)), flag)) {
			if (typeToMatch.equals("boolean")) {
			    stack.push(stackSymbol);
			    needToEvaluateParameters = true;
			} else {
			    stack.push("!!");
			}
		    } else {
			stack.push(stackSymbol);
			needToEvaluateParameters = true;
		    }
		}
	    } catch (FunctionProcedureProberException e) {
		ErrorList.add(node.getName(), e.getMessage());
	    }
	}
    }
    
                                         //////////////////////////////
                                        // The heart of the object  //
                                       //  check that the result   //
                                      //   of the type evaluation //
                                     //////////////////////////////
    
    public boolean isRightType() {
	String poppedElement = new String(); // s,i
	String popped2 = new String(); // s
	String popped1 = new String(); // s
	String last = new String(); // b
	int count = 0;
	boolean found = false;

	if (debug) System.out.println("IsRigth information");
	if (debug) System.out.println("TypeToMatch: " + typeToMatch);
	if (debug) System.out.println("Stack: " + stack + "\n");

	if (typeToMatch.equals("string")) {
	      /////////////////
	     // String type //
	    /////////////////
	    // Check if it is a string array we have found
	    if (stack.isEmpty()) {
		if (debug) System.out.println("Error empty stack " + typeToMatch);
		return false;
	    }

	    if (flag.equals("array") && ((String)stack.pop()).equals("string")) {
		if(stack.pop().equals("string") && (stack.empty() || (stack.size() == 1))) {
		    flag = "variable";
		    return true;
		} else {
		    return false;
		}
	    } 
	    
	    // Only one element in stack and it's a string
	    if ((stack.size() == 1) && (((String)stack.peek()).equals("string"))) {
		return true;
	    } else if (stack.size() > 1) {
		popped1 = (String)stack.pop(); // the first one popped, relative to the next one
		if (!popped1.equals("string")) {
		    return false;
		}
		
		// More the one element in stack run through it
		// er iorden hvis to eller flere strenge er separerede af &
		// altsaa: s1 & s2 & s3... ellers: s
		while (!stack.empty()) {
		    // Skal hele tiden(!) kende foreg�ende tegn...
		    // Hvis forrige var en string, s� skal n�ste v�re & og efterfulgt af string
		    // Hvis forrige var &, s� skal n�ste v�re string
		    // Ellers er det IKKE iorden...
		    poppedElement = (String)stack.pop();

		    if(poppedElement.equals("string")) {
			if (popped1.equals("&")) {
			    found = true;
			} else {
			    found = false;
			    break;
			}
		    } else if (poppedElement.equals("&")) {
			if (popped1.equals("&")) {
			    found = false;
			    break;
			}
		    } else {
			found = false;
			break;
		    }
		    
		    popped1 = poppedElement;
		}
	    }
	    return found;
	} else if (typeToMatch.equals("integer")) {
	      //////////////////
	     // Integer type //
	    //////////////////
	    if (stack.isEmpty()) {
		if (debug) System.out.println("Error empty stack " + typeToMatch);
		return false;
	    }

	    if ((stack.size() == 1) && ((((String)stack.peek()).equals("integer")) ||
					(((String)stack.peek()).equals("infty")))) {
		return true;
	    }

	    if (((String)stack.peek()).equals("infty")) {
		if (unaryInStack) {
		    return true;
		} else {
		    return false;
		}
	    }
	    
	    // More the one element i stack run through it
	    while(!stack.empty()) {	
		if((poppedElement = (String)stack.pop()).equals("integer")) {
		    found = true;
		} else {
		    found = false;
		    break;
		}
	    }
	    return found;
	} else if (typeToMatch.equals("float")) {
	      ////////////////
	     // Float type //
	    ////////////////
	    if (stack.isEmpty()) {
		if (debug) System.out.println("Error empty stack " + typeToMatch);
		return false;
	    }

	    // Check if it is a float array we have found
	    if (flag.equals("array") && stack.pop().equals("float")) {
		if(stack.pop().equals("float") && stack.empty()) {
		    flag = "variable";
		    return true;
		} else {
		    return false;
		}
	    } 
	    
	    if ((stack.size() == 1) && ((((String)stack.peek()).equals("float")) || 
					(((String)stack.peek()).equals("infty")))) {
		return true;
	    }
	    
	    if (((String)stack.peek()).equals("infty")) {
		if (unaryInStack) {
		    return true;
		} else {
		    return false;
		}
	    }

	    while(!stack.empty()) {
		if((poppedElement = (String)stack.pop()).equals("float")) {
		    found = true;
		} else {
		    if ((divInStack == count - 1) || (divInStack == count + 1)) {
			found = true;
		    } else {
			found = false;
			break;
		    }
		}
		count++;
	    }
	    return found;
	} else if (typeToMatch.equals("boolean")) {
	      //////////////////
	     // Boolean type //
	    //////////////////
	    if (stack.isEmpty()) {
		if (debug) System.out.println("Error empty stack " + typeToMatch);
		return false;
	    }

	    // Check if it is a string array we have found
	    if (flag.equals("array") && stack.pop().equals("boolean")) {
		if(stack.pop().equals("boolean") && stack.empty()) {
		    flag = "variable";
		    return true;
		} else {
		    return false;
		}
	    } 


	    if (stack.size() == 1) {
		poppedElement = (String)stack.pop();
		if (poppedElement.equals("boolean")) {
		    return true;
		} else {
		    return false;
		}
	    }
		
	    if (stack.size() == 2) {
		poppedElement = (String)stack.pop();
		if (((String)stack.peek()).equals("boolean")) {
		    if (notInStack == 1) {
			return true;
		    } else {
			return false;
		    }
		} else {
		    return false;
		}
	    }

	    if (((String)stack.peek()).equals("string") || ((String)stack.peek()).equals("vertex") || ((String)stack.peek()).equals("edge")) {
		if ((equalsInStack || neqInStack) && stack.size() == 3) {
		    stack.pop();
		    stack.pop();
		    if (((String)stack.peek()).equals("string") || ((String)stack.peek()).equals("vertex") || ((String)stack.peek()).equals("edge")) {
			return true;
		    } else {
			return false;
		    }
		} else {
		    return false;
		}
	    }

	    if (stack.size() > 2) {
		while(!stack.empty()) {

		    poppedElement = (String)stack.pop();    

		    if (poppedElement.equals("!!")) {
			return false;
		    }

		    if (!poppedElement.equals("boolean") && !poppedElement.equals("!!")) {
			if (last.equals(poppedElement) || last.equals("boolean")) {
			    found = true;
			} else {
			    if (!last.equals("")) {
				return false;
			    }
			}
		    } else if (poppedElement.equals("boolean")){
			found = true;
		    }
		    last = poppedElement;
		}
	    }
	    return found;
	} else if (typeToMatch.equals("edge")) {
	      ///////////////
	     // Edge type //
	    ///////////////
	    if (stack.isEmpty()) {
		if (debug) System.out.println("Error empty stack " + typeToMatch);
		return false;
	    }

	    // Only one element in stack and it's a string
	    if ((stack.size() == 1) && (((String)stack.peek()).equals("edge"))) {
		return true;
	    }
	    
	    // More the one element i stack run through it
	    while(!stack.empty()) {
		if((poppedElement = (String)stack.pop()).equals("edge")) {
		    found = true;
		} else {
		    found = false;
		    break;
		}
	    }
	    return found;  
	} else if (typeToMatch.equals("vertex")) {
	      /////////////////
	     // vertex type //
	    /////////////////
	    if (stack.isEmpty()) {
		if (debug) System.out.println("Error empty stack " + typeToMatch);
		return false;
	    }

	    while(!stack.empty()) {
		poppedElement = (String)stack.pop();
		if (poppedElement.equals("vertex")) {
		    found = true;
		} else {
		    return false;
		}
	    }
	    return found;
	} else if (typeToMatch.equals("graph")) {
	      ////////////////
	     // graph type //
	    ////////////////
	    if (stack.isEmpty()) {
		if (debug) System.out.println("Error empty stack " + typeToMatch);
		return false;
	    }

	    while(!stack.empty()) {
		poppedElement = (String)stack.pop();
		if (poppedElement.equals("graph")) {
		    found = true;
		} else {
		    return false;
		}
	    }
	    return found;
	} else if (typeToMatch.equals("diGraph")) {
	      //////////////////
	     // diGraph type //
	    //////////////////
	    if (stack.isEmpty()) {
		if (debug) System.out.println("Error empty stack " + typeToMatch);
		return false;
	    }

	    while(!stack.empty()) {
		poppedElement = (String)stack.pop();
		if (poppedElement.equals("diGraph")) {
		    found = true;
		} else {
		    return false;
		}
	    }
	    return found;
	} else {
	    return false;
	}
    }
        
                                       ///////////////////////
                                      // Set / Get metodes //
                                     ///////////////////////
    
    public String getFlag() {
	return flag;
    }

    public String getType() {
	return tmpType;
    }
    
    public void setFullEvaluation(boolean value) {	
	fullEvaluation = value;
    }

                                       ///////////////////
                                      // Other Methods //
                                     ///////////////////

    private String findNodeType(Node typeNode, Token token) {
	String type = new String();
	String castType = null;

	// Test if it is constant
	if (idTable.isConstant()) {
	    ErrorList.add(token, "illegal, can not modify a constant");
	}
	castType = typeNode.getClass().getName().substring(29);
	if (castType.equals("AVariableDeclaration")) {
	    type = ((AVariableDeclaration)typeNode).getType().getText();
	} else if (castType.equals("AArrayDeclaration")) {
	    type = ((AArrayDeclaration)typeNode).getType().getText();
	} else if (castType.equals("ASetDeclaration")) {
	    type = ((ASetDeclaration)typeNode).getType().getText();
	} else if (castType.equals("AWeightWeightLabelDeclaration")) {
	    type = ((AWeightWeightLabelDeclaration)typeNode).getType().getText();
	} else if (castType.equals("ALabelWeightLabelDeclaration")) {
	    type = ((ALabelWeightLabelDeclaration)typeNode).getType().getText();
	} else if (castType.equals("ARecordDeclaration")) {
	    type = ((ARecordDeclaration)typeNode).getType().getText();
	} else if (castType.equals("AIdentifierTypeDenoter")) {
	    type = ((AIdentifierTypeDenoter)typeNode).getIdentifier().getText();
	} else if (castType.equals("AArrayTypeDenoter")) {
	    type = ((AArrayTypeDenoter)typeNode).getType().getText();
	} else if (castType.equals("AWeightTypeDenoter")) {
	    type = ((AWeightTypeDenoter)typeNode).getType().getText();
	} else if (castType.equals("ALabelTypeDenoter")) {
	    type = ((ALabelTypeDenoter)typeNode).getType().getText();
	} else if (castType.equals("AForToLoopHeaders")) {
	    type = "integer";
	} else if (castType.equals("ASetTypeDenoter")) {
	    type = ((ASetTypeDenoter)typeNode).getType().getText();
	}

	return type;
    }    
    private boolean compareTypes(String dogsType, String type, String flag) {
	boolean result = false;
	boolean graph = (dogsType.equals("graph") || dogsType.equals("diGraph"));
	boolean set = (dogsType.equals("integer") || dogsType.equals("float") || 
		       dogsType.equals("string") || dogsType.equals("boolean") || 
		       dogsType.equals("edge") || dogsType.equals("vertex"));
	boolean array = (dogsType.equals("integer") || dogsType.equals("float") || 
			 dogsType.equals("string") || dogsType.equals("boolean") || 
			 dogsType.equals("edge") || dogsType.equals("vertex"));
	boolean primitive = (dogsType.equals("integer") || dogsType.equals("float") || 
			     dogsType.equals("string") || dogsType.equals("boolean") || 
			     dogsType.equals("edge") || dogsType.equals("vertex"));

	if (graph && type.equals("GraphComposite")) {
	    result = true;
	}

	if (primitive && type.equals("primitive")) {
	    result = true;
	}

	if ((set || type.equals("stdSet")) && flag.equals("set")) {
	    result = true;
	}

	if ((array || type.equals("stdArray")) && flag.equals("array")) {
	    result = true;
	}

	return result;
    }
}

