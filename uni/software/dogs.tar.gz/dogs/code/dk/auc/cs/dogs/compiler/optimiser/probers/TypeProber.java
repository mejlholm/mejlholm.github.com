package dk.auc.cs.dogs.compiler.optimiser.probers;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import java.util.ArrayList;


public abstract class TypeProber extends DepthFirstAdapter {

    public TypeProber() {
	
    } // TypeProber constructor
    
    //    public abstract void print();

    public abstract int size();

    public abstract void cleanLists();
    

} // TypeProber
