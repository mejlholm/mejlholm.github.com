package dk.auc.cs.dogs.compiler.optimiser.probers;

import java.util.ArrayList;

import dk.auc.cs.dogs.compiler.node.*;

/**
 * StringProber.java
 *
 *
 * Created: Tue May  4 10:19:22 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */
public class StringProber extends TypeProber {

    private ArrayList expressions = new ArrayList();
    private ArrayList types = new ArrayList();
    private ArrayList nodes = new ArrayList();

    public StringProber() {
	
    } // StringProber constructor

    public void inAExpression(AExpression node){
	cleanLists();
    }

    public void caseAConcatinationExpr(AConcatinationExpr node){
        inAConcatinationExpr(node);
        if(node.getPrimaryExpression() != null)
        {
            node.getPrimaryExpression().apply(this);
        }
        if(node.getConcat() != null)
        {
            node.getConcat().apply(this);
	    nodes.add(node);
	    types.add("");
	    expressions.add("&");
        }
        if(node.getConcatinationExpr() != null)
        {
            node.getConcatinationExpr().apply(this);
        }
        outAConcatinationExpr(node);
    }

    public void inAStringPrimaryExpression(AStringPrimaryExpression node){
	nodes.add(node);
	types.add("s");
	expressions.add(node.getStringLiteral().getText());
    }

    public void print(){
	System.out.println("Left in the list:");
	for (int i=0; i < expressions.size(); i++){
	    System.out.print("" + expressions.get(i));
	    System.out.println(" " + types.get(i));
	}
    }

    public int size(){
	return expressions.size();
    }

    public void cleanLists(){
	nodes.clear();
	expressions.clear();
	types.clear();
    }

    public String getExpression(int i) {
	return (String) expressions.get(i);
    }

} // StringProber
