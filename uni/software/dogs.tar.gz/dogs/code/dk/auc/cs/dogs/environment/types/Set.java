package dk.auc.cs.dogs.environment.types;

import java.util.LinkedList;
import java.util.Iterator;
import java.io.*;

public class Set extends Composite implements CompositeIterable, SetInteger, SetFloat, SetBoolean, SetString, SetEdge, SetVertex, SetInterface {

    private LinkedList list = new LinkedList();
    private java.lang.String type;
    private boolean debug = false;

    public Set(java.lang.String type) {
        this(type, new LinkedList().iterator());
    }

    public Set(java.lang.String type, Iterator it) {
        super();
        if (type.trim().equals("")) {
            throw new RuntimeException("No type for set was given");
        }
        this.type = type;
        if (it != null) {
            while (it.hasNext()) {
                add((Primitive) it.next());
            }
        }
    }

    public Integer size() {
	return new Integer(list.size());
    }

    public Boolean isEmpty() {
	return new Boolean(list.size() > 0);
    }

//     public SetInterface union(SetInterface set) {
// 	if (!type.equals(set.type)) {
// 	    if (debug) System.out.println(type + " - " + set.type);
// 	    throw new RuntimeException("Cannot union two sets of different types");
// 	}
// 	Set returnSet = new Set(type, getIterator(type));
// 	Iterator it = set.getIterator(type);
// 	while (it.hasNext()) {
// 	    returnSet.add((Primitive) it.next());
// 	}	
// 	return set;
//     }

    public Iterator getIterator(java.lang.String type) {
        if (!type.equals(this.type)) {
	    throw new RuntimeException("Cannot extract " + type + " from set");
	}
        return list.iterator();
    }

    public void add(Primitive element) {
        if (exists(element) == -1) {
	    if (debug) System.out.println("adding element...");
            list.add(element);
        } else {
            if (debug) System.out.println("element already in set");
        }
    }

    public void remove(Primitive element) {
        int i;
	if ((i = exists(element)) != -1) {
	    if (debug) System.out.println("removing element " + i + "...");
            list.remove(i);
        } else {
            if (debug) System.out.println("element not in set");
        }
    }

    // Returns -1 if non existing in list, otherwise the index
    public int exists(Primitive element) {
        boolean cont = false;
	int result = -1;
        java.lang.String elementName = element.getClass().getName().substring(33);
        if (elementName.equals("Infty")) {
	    if (!(type.equals("Integer") || type.equals("Float"))) {
		throw new RuntimeException("Infty cannot be added to this set");
	    } else {
		cont = true;
	    }
        }
        if (type.equals(elementName) || cont) {
            Primitive p;
            for (int i = 0; i < list.size(); i++) {
                if (debug) System.out.println("Checking element " + i + " of set (size of set: " + list.size() + ")");
                p = (Primitive) list.get(i);
		
		java.lang.String pName = p.getClass().getName().substring(33);
                if (debug) System.out.println("\t" + elementName + " -> set of " + type + "(" + pName + ")");

		if (elementName.equals("Infty")) {
		    if (debug) System.out.println("Infty localised...");
		    if (pName.equals(elementName)) {
			if (((Infty)p).isPositive() == ((Infty)element).isPositive()) {
			    result = i;
			    break;
			}
		    } else {
			// EVIL HAX so no errors will occur if infty comes out of the internal list...
			if (debug) System.out.println("Activating EVIL HAX...");
			continue;
		    }
                } else if (elementName.equals("Integer")) {
                    if ((((Integer) p).isEqual((Integer) element)).getValue()) {
                        result = i;
                        break;
                    }
                } else if (elementName.equals("Float")) {
                    if (((Float) p).isEqual((Float) element).getValue()) {
                        result = i;
                        break;
                    }
                } else if (elementName.equals("Boolean")) {
                    if (((Boolean)p).isEqual((Boolean) element).getValue()) {
                        result = i;
                        break;
                    }
                } else if (elementName.equals("String")) {
                    if ((((String)p).isEqual((String) element))) {
                        result = i;
                        break;
                    }
                } else if (elementName.equals("Edge")) {
                    if (((Edge)p).isEqual((Edge)element).getValue()) {
			result = i;
			break;
                    }
                } else if (elementName.equals("Vertex")) {
                    if (((Vertex)p).isEqual((Vertex)element).getValue()) {
			result = i;
			break;
                    }
                } else {
		    if (debug) System.out.println("<" + elementName + ">");
                    throw new RuntimeException("Set only accepts primitives");
                }
            }
        } else {
	    if (debug) System.out.println("Error when adding a " + elementName + " to set containing " + type + "s");
            throw new RuntimeException("Incompatible types in set");
        }
        return result;
    }

    public void clear() {
        list = new LinkedList();
    }
}
