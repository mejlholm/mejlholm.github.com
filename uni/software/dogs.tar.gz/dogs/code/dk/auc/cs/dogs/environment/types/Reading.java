package dk.auc.cs.dogs.environment.types;

public abstract class Reading extends Number {
    
    public Reading() {
	super();
    }

    public abstract void increment();
    public abstract void decrement();

    /***********************
     * Boolean expressions *
     ***********************/

    public final Boolean isLess(Integer n) {
	return new Boolean(getValue() < n.getValue());
    }

    public final Boolean isLess(Float n) {
	return new Boolean(getValue() < n.getValue());
    }

    public final Boolean isLess(Infty i) {
	if (i.isPositive().getValue()) {
	    return new Boolean(true);
	} else {
	    return new Boolean(false);
	}
    }

    public final Boolean isGreater(Integer n) {
	return new Boolean(getValue() > n.getValue());
    }

    public final Boolean isGreater(Float n) {
	return new Boolean(getValue() > n.getValue());
    }

    public final Boolean isGreater(Infty i) {
	if (i.isPositive().getValue()) {
	    return new Boolean(false);
	} else {
	    return new Boolean(true);
	}
    }

    public final Boolean isLessOrEqual(Integer n) {
	return new Boolean(getValue() <= n.getValue());
    }

    public final Boolean isLessOrEqual(Float n) {
	return new Boolean(getValue() <= n.getValue());
    }

    public final Boolean isLessOrEqual(Infty i) {
	return isLess(i);
    }

    public final Boolean isGreaterOrEqual(Integer n) {
	return new Boolean(getValue() >= n.getValue());
    }

    public final Boolean isGreaterOrEqual(Float n) {
	return new Boolean(getValue() >= n.getValue());
    }

    public final Boolean isGreaterOrEqual(Infty i) {
	return isGreater(i);
    }

    public final Boolean isEqual(Integer n) {
    	return new Boolean(getValue() == n.getValue());
    }

    public final Boolean isEqual(Float n) {
    	return new Boolean(getValue() == n.getValue());
    }

    public final Boolean isEqual(Infty i) {
	return new Boolean(false);
    }

    //    public Boolean isEqual(Primitive p) {
    //    	throw new RuntimeException("Cannot compare incompatible types");
    //    }

    public final Boolean isDifferent(Integer n) {
	return new Boolean(getValue() != n.getValue());
    }

    public final Boolean isDifferent(Float n) {
	return new Boolean(getValue() != n.getValue());
    }

    public final Boolean isDifferent(Infty i) {
	return new Boolean(true);
    }

    /*  */
    public abstract double getValue();

}
