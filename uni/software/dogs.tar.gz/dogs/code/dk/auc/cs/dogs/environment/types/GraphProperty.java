package dk.auc.cs.dogs.environment.types;

public abstract class GraphProperty extends Type {

    public GraphProperty() {
	super();
    }
}
