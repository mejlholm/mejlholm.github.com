
package dk.auc.cs.dogs.compiler.codegeneration;

import dk.auc.cs.dogs.compiler.node.*;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.codegeneration.*;
import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.libraryhandler.Library;
import dk.auc.cs.dogs.compiler.codegeneration.helpers.*;

/**
 * StatementEncoder.java
 *
 *
 * Created: Mon May 17 16:58:19 2004
 *
 * @author <a href="mailto:aaby@brick.aaby"></a>
 * @version 1.0
 */

public abstract class StatementEncoder extends DeclarationEncoder {

    private boolean debug = false;
    private int aps = 0;
    private String tmpAssignName = "";
    //    private IdentitiesAndTypesTable idTypeTable;

    public StatementEncoder(Library lib, StandardEnvironment std, String sourcefile, String objectfile, IdentificationTableRecord idRecord, FunctionProcedureProber prober, IdentitiesAndTypesTable idTypeTable) {
	super(lib, std, sourcefile, objectfile, idRecord, prober, idTypeTable);
	//this.idTypeTable = idTypeTable;
    } // StatementEncoder constructor


    public final void inAActualParameterSequence(AActualParameterSequence node){
	aps++;
    }

    public final void outAActualParameterSequence(AActualParameterSequence node){
	aps--;
    }

    public final void caseAAssignBasicCommands(AAssignBasicCommands node) {
	assign = true;
	tmpAssignName = node.getVName().toString().trim();
        inAAssignBasicCommands(node);
	String name = ((AVName)node.getVName()).getIdentifier().toString().trim();
        if(node.getVName() != null) {
            //node.getVName().apply(this);
	    if (idTypeTable.getIdentifier(name).getFlag().equals("array")) {
		cw.codePrintln("aload " + vmap.getLocation(name));
		// array assignment
		AVName v = (AVName)node.getVName();
		AIdentifierArrayVNameExtension ve = (AIdentifierArrayVNameExtension)v.getVNameExtension();
		cw.codePrintln("ldc \"[\"");
		ve.getExpression().apply(this);
		cw.codePrintln("invokevirtual java/lang/Object/toString()Ljava/lang/String;");
		cw.codePrintln("invokevirtual java/lang/String/concat(Ljava/lang/String;)Ljava/lang/String;");
		cw.codePrintln("ldc \"]\"");
		cw.codePrintln("invokevirtual java/lang/String/concat(Ljava/lang/String;)Ljava/lang/String;");
		//		
	    }
        }
        if(node.getAssign() != null) {
            node.getAssign().apply(this);
        }
        if(node.getExpression() != null) {
            node.getExpression().apply(this);
        }
        outAAssignBasicCommands(node);
	assign = false;
	if (idTypeTable.getIdentifier(name).getFlag().equals("array")) {
	    cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/Primitive");
	    cw.codePrintln("invokevirtual dk/auc/cs/dogs/environment/types/Array/setValue(Ljava/lang/String;Ldk/auc/cs/dogs/environment/types/Primitive;)V");
	} else {
	    int loc = vmap.getLocation(name);
	    cw.codePrintln("astore " + loc + "\n");
	}
	tmpAssignName = "";
    }


    public final void outAReturnBasicCommands(AReturnBasicCommands node){
	cw.codePrintln("goto RETURNLABEL\n");
    }

    public final void inAParameterCall(AParameterCall node){
	String vname = node.getName().getText().trim();

	//	System.out.println("inAParameterCall - " + vname + " - " + vmap.getLocation(vname));
	if ((vmap.getLocation(vname) != -1) && (isWeight(vname) || isLabel(vname))) {
	    //	    System.out.println("WEIGHT or LABEL! - getting (" + vname + ")");
	    cw.codePrintln("; Loading weight or label for getting...");
	    cw.codePrintln("aload " + vmap.getLocation(vname));
	}
	//	System.out.println("haffer snaffer");
    }

    public final void outAParameterCall(AParameterCall node){
	//	System.out.println("outAParameterCall");
	String flag = "";
	String vname = node.getName().getText().trim();
	if (idTypeTable.getIdentifier(vname) != null) {
	    flag = idTypeTable.getIdentifier(vname).getFlag();
	}
	
// 	if (vmap.getLocation(vname) != -1) {
// 	    System.out.println(vname + " is in vmap");
// 	} else {
// 	    System.out.println(vname + " is NOT in vmap");
// 	}
	if (isWeight(vname)) {
	    //	    cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/Primitive");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/WeightInterface/getWeight(Ldk/auc/cs/dogs/environment/types/Edge;)Ldk/auc/cs/dogs/environment/types/Primitive; 2");
	    cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/" + getWeightType(vname));
	    //	    System.out.println("weight: (" + vname + ")" + getWeightType(vname) + " flag: " + flag + " - " + node.getName().getLine());
	} else if (isLabel(vname)) {
	    //	    cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/Primitive");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/LabelInterface/getLabel(Ldk/auc/cs/dogs/environment/types/Vertex;)Ldk/auc/cs/dogs/environment/types/Primitive; 2");
	    cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/" + getLabelType(vname));
	    //	    System.out.println("label: (" + vname + ")" + getLabelType(vname) + " flag: " + flag + " - " + node.getName().getLine());
	    //	    parameterify();
	} else {
	    //	    lib.print();
	    // normal procedure eller functions call
	    if (lib.isFunctionKnown(vname)) {
		cw.codePrintln("invokestatic " + patherify(lib.getPackageNameFromFunctionname(vname))
		       + "/" + vname + "(" + parameterify(vname) + ")" + returnerify(vname));
	    } else{
		cw.codePrintln("invokestatic " + objectfile + "/" + vname + "(" + parameterify(vname) + ")" + returnerify(vname));
	    }
	    if (!returnerify(vname).equals("V") && aps == 0 && !assign) {
		//System.out.println("popping from stack - assign: " + assign);
		cw.codePrintln("pop");
	    }
	}
    }


    public void caseALwAssBasicCommands(ALwAssBasicCommands node)
    {
	String wlName = ((AParameterCall)node.getParameterCall()).getName().toString().trim();
 	//System.out.println("'" +wlName + "' is weight: " + isWeight(wlName));
	// 	System.out.println("'" +wlName + "' is label: " + isLabel(wlName));

	cw.codePrintln("; Loading weight or label for setting...");
	cw.codePrintln("aload " + vmap.getLocation(wlName));
	((AParameterCall)node.getParameterCall()).getActualParameterSequence().apply(this);

        if(node.getExpression() != null)
        {
            node.getExpression().apply(this);
        }

	if (isWeight(wlName)) {
	    //	    System.out.println(wlName + " is a weight (caseALwAssBasicCommands)");
	    cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/Primitive");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/WeightInterface/setWeight(Ldk/auc/cs/dogs/environment/types/Edge;Ldk/auc/cs/dogs/environment/types/Primitive;)V 3");

	} else if (isLabel(wlName)) {
	    //	    System.out.println(wlName + " is a label (caseALwAssBasicCommands)");
	    cw.codePrintln("checkcast dk/auc/cs/dogs/environment/types/Primitive");
	    cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/LabelInterface/setLabel(Ldk/auc/cs/dogs/environment/types/Vertex;Ldk/auc/cs/dogs/environment/types/Primitive;)V 3");

	}
    }


    public void caseAEdgePrimaryExpression(AEdgePrimaryExpression node) {
        inAEdgePrimaryExpression(node);

	String v1Name = node.getFirst().toString().trim(),
	    v2Name = node.getLast().toString().trim();

	cw.codePrintln("new dk/auc/cs/dogs/environment/types/Edge");
	cw.codePrintln("dup");
	
	cw.codePrintln("aload " + vmap.getLocation(v1Name));
	cw.codePrintln("aload " + vmap.getLocation(v2Name));

	cw.codePrintln("invokespecial dk/auc/cs/dogs/environment/types/Edge/<init>(Ldk/auc/cs/dogs/environment/types/Vertex;Ldk/auc/cs/dogs/environment/types/Vertex;)V");

	if (aps == 0 && !assign){
	    cw.codePrintln("pop");
	}

        outAEdgePrimaryExpression(node);
    }


    public final void caseAPostfixPpBasicCommands(APostfixPpBasicCommands node){
	String vname =((AVName)node.getVName()).getIdentifier().getText().trim();
	cw.codePrintln("; caseAPostfixPpBasicCommands");
	cw.codePrintln("aload " + vmap.getLocation(vname));
	cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/increment()V 1\n");
    }

    public final void caseAPostfixMmBasicCommands(APostfixMmBasicCommands node){
	String vname =((AVName)node.getVName()).getIdentifier().getText().trim();
	cw.codePrintln("; caseAPostfixMmBasicCommands");
	cw.codePrintln("aload " + vmap.getLocation(vname));
	cw.codePrintln("invokeinterface dk/auc/cs/dogs/environment/types/NumberNumber/decrement()V 1\n");
	}

} // StatementEncoder
