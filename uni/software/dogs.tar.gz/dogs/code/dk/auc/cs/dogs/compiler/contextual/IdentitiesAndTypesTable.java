package dk.auc.cs.dogs.compiler.contextual;

import dk.auc.cs.dogs.compiler.contextual.helpers.*;
import dk.auc.cs.dogs.compiler.node.*;
import java.util.*;

public class IdentitiesAndTypesTable {

    private HashMap data;
    private HashMap elements;
    private boolean debug = false;

    public IdentitiesAndTypesTable() {
	data = new HashMap();
    }
     
    public void enter(String id, String type, String flag, boolean constant, Node node) throws IdentitiesAndTypesTableException {
	String castType = node.getClass().getName().substring(29);

	if (elements == null) {
	    throw new IdentitiesAndTypesTableException("No scope was opened in IdentitiesAndTypesTable");
	}

	elements.put(id, new IdentitiesAndTypesTableElements(type, flag, constant, node, castType));

	if (debug) System.out.println("Elements in enter: \t" + elements + "\n");
    }
    
    public void openScope() {
	if (debug) System.out.println("Open");
	elements = new HashMap();
    }

    public void closeScope(String savename) {
	if (debug) System.out.println("Elements in save: \t" + elements);
	data.put(savename, elements);
	if (debug) System.out.println("Data in save: \t" + data);
	elements = new HashMap(); // before = null;
    }

    public void loadScope(String name) {
	if (debug) System.out.println("Name: " + name + "\t Data: " + data);

	if (data.containsKey(name)) {
	    elements = (HashMap)data.get(name);
	} else {
	    if (debug) System.out.println(name + " not in the table");
	    System.exit(-1);
	}
    }
	
    public IdentitiesAndTypesTableElements getIdentifier(String identifier) {
	if (elements != null) {
	    if (elements.containsKey(identifier)) {
		return (IdentitiesAndTypesTableElements)elements.get(identifier);
	    } else {
		if (debug) System.out.println("Identifier " + identifier + " not in table");
		return null;
	    }
	} else {
	    return null;
	}
    }

    public String[] findNodeType(Node typeNode) {
	String castType = null;
	String[] value = new String[2];

	castType = typeNode.getClass().getName().substring(29);
	if (castType.equals("AVariableDeclaration")) {
	    value[0] = ((AVariableDeclaration)typeNode).getType().getText();
	    value[1] = "variable";
	} else if (castType.equals("AArrayDeclaration")) {
	    value[0] = ((AArrayDeclaration)typeNode).getType().getText();
	    value[1] = "array";
	} else if (castType.equals("ASetDeclaration")) {
	    value[0] = ((ASetDeclaration)typeNode).getType().getText();
	    value[1] = "set";
	} else if (castType.equals("AWeightWeightLabelDeclaration")) {
	    value[0] = ((AWeightWeightLabelDeclaration)typeNode).getType().getText();
	    value[1] = "weight";
	} else if (castType.equals("ALabelWeightLabelDeclaration")) {
	    value[0] = ((ALabelWeightLabelDeclaration)typeNode).getType().getText();
	    value[1] = "label";
	} else if (castType.equals("ARecordDeclaration")) {
	    value[0] = ((ARecordDeclaration)typeNode).getType().getText();
	    value[1] = "record";
	} else if (castType.equals("AIdentifierTypeDenoter")) {
	    value[0] = ((AIdentifierTypeDenoter)typeNode).getIdentifier().getText();
	    value[1] = "variable";
	} else if (castType.equals("AArrayTypeDenoter")) {
	    value[0] = ((AArrayTypeDenoter)typeNode).getType().getText();
	    value[1] = "array";
	} else if (castType.equals("AWeightTypeDenoter")) {
	    value[0] = ((AWeightTypeDenoter)typeNode).getType().getText();
	    value[1] = "weight";
	} else if (castType.equals("ALabelTypeDenoter")) {
	    value[0] = ((ALabelTypeDenoter)typeNode).getType().getText();
	    value[1] = "label";
	} else if (castType.equals("AForToLoopHeaders")) {
	    value[0] = "integer";
	    value[1] = "variable";
	} else if (castType.equals("ASetTypeDenoter")) {
	    value[0] = ((ASetTypeDenoter)typeNode).getType().getText();
	    value[1] = "set";
	} else {
	    
	}
	return value;
    }
}
