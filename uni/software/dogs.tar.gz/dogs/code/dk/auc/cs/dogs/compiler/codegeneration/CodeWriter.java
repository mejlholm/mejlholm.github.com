package dk.auc.cs.dogs.compiler.codegeneration;

import java.io.*;
import java.util.*;

public class CodeWriter {

    private PrintWriter out = null;
    private String filename = null;
    private int indent = 0;
    private int labelCounter = 1;
    private int breakLabelCounter = 1;
    private LinkedList labels = new LinkedList();
    private LinkedList breakLabels = new LinkedList();
    private boolean verbose = false;

    public CodeWriter(String filename, boolean verbose) {
	this.verbose = verbose;
	if (verbose) {
	    System.out.println("Compiling " + filename + "...");
	    System.out.print(".");
	}
	filename = filename + ".j";
	this.filename = filename;
	try {
	    out = new PrintWriter(new BufferedWriter(new FileWriter(filename)));
	} catch(IOException e) {
	    System.out.println(e);
	}
    }

        String indent() {
	String indentChar = "  ";
	String indentStr = "";
	for (int i = 0; i < indent; i++) {
	    indentStr += indentChar;
	}
	return indentStr;
    }

    public void flush() {
	if (verbose) System.out.println(".");
	out.flush();
    }

    public String getFilename() {
	return filename;
    }

    public void addIndentScope() {
	indent++;
    }

    public void removeIndentScope() {
	indent--;
    }

    public void codePrint(String str) {
	if (verbose) System.out.print(".");
	out.print(indent() + str);
    }
    
    public void codePrintln(String str) {
	codePrint(str + "\n");
    }

    // Returns the newest label
    public String topLabel() {
	int i = labels.size() - 1;
	String str = (String)labels.get(i);
	return str;
    }

    // Returns the newest label, and removes it from the list of labels
    public String popLabel() {
	int i = labels.size() - 1;
	String str = (String)labels.get(i);
	labels.remove(i);
	return str;
    }

    // Adds a loop label to out
    public String makeLabel(String postFix) {
	String str = postFix + "Label" + labelCounter++;
	str = str.toUpperCase();
	indent--;
	codePrintln(str + ":");
	indent++;
	labels.add(str);
	return str;
    }

    public String topBreakLabel() {
	int i = breakLabels.size() - 1;
	String str = (String)breakLabels.get(i);
	return str;
    }

    public String popBreakLabel() {
	int i = breakLabels.size() - 1;
	String str = (String)breakLabels.get(i);
	breakLabels.remove(i);
	codePrintln(str + ":");
	return str;
    }

    public String makeBreakLabel() {
	String str = "BREAKLABEL" + breakLabelCounter++;
	breakLabels.add(str);
	return str;
    }
}
