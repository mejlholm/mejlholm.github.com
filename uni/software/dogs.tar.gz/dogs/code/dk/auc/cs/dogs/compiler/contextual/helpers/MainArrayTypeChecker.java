package dk.auc.cs.dogs.compiler.contextual.helpers;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.node.*;

public class MainArrayTypeChecker extends DepthFirstAdapter {

    String type = new String();

    public void caseAArrayTypeDenoter(AArrayTypeDenoter node) {
        if(node.getType() != null) {
            type = node.getType().getText();
        }
    }    

    public String getType() {
	return type;
    }
}

