package dk.auc.cs.dogs.compiler.contextual.helpers;

import dk.auc.cs.dogs.compiler.analysis.DepthFirstAdapter;
import dk.auc.cs.dogs.compiler.contextual.*;
import dk.auc.cs.dogs.compiler.node.*;

import java.util.*;

public class RecordTypeChecker extends DepthFirstAdapter {
    
    private int braceLevel = 0;
    private String lastType = new String();
    private IdentificationTable idTable = null;
    private StandardEnvironment stdEnv = null;
    private IdentificationTableRecord idRecord = null;
    private FunctionProcedureProber prober = null;
    private String castType = new String();
    private String currentRecordName = new String();

    public RecordTypeChecker(IdentificationTable idTable, StandardEnvironment stdEnv, IdentificationTableRecord idRecord, String currentRecordName, FunctionProcedureProber prober) {
	this.currentRecordName = currentRecordName;
	this.idTable = idTable;
	this.stdEnv = stdEnv;
	this.idRecord = idRecord;
	this.prober = prober;
    }

    public void caseABracePrimaryExpression(ABracePrimaryExpression node) {

        if(node.getLBrace() != null) {
	    braceLevel++;
        }

	try {
	    if(node.getExpression() != null) {
		if (braceLevel >= 2) {
		    if (stdEnv.isRecord(lastType)) {
			idRecord.loadRecord(lastType);
		    }
		    node.getExpression().apply(new RecordTypeChecker(idTable, stdEnv, idRecord, lastType, prober));
		    idRecord.loadRecord(currentRecordName);
		} else {
		    node.getExpression().apply(this);
		}
	    }
	} catch (IdRecordTableException e) {
	    ErrorList.add(node.getLBrace(), e.getMessage());
	}   
        {
	    try {
		Object temp[] = node.getPrimaryExprCommaExpr().toArray();
		for(int i = 0; i < temp.length; i++)
		    {
			if (braceLevel >= 2) {
			    if (stdEnv.isRecord(lastType)) {
				idRecord.loadRecord(lastType);
			    }
			    ((APrimaryExprCommaExpr) temp[i]).getExpression().apply(new RecordTypeChecker(idTable, stdEnv, idRecord, lastType, prober));
			    idRecord.loadRecord(currentRecordName);
			} else {
			    ((APrimaryExprCommaExpr) temp[i]).getExpression().apply(this);
			}
		    }
	    } catch (IdRecordTableException e) {
		ErrorList.add(node.getLBrace(), e.getMessage());
	    }
        }
	if(node.getRBrace() != null)
	    {
		braceLevel--;
	    }
    }


    public void inAVName(AVName node) {
	Node typeNode = null;
	
	try {
	    typeNode = (Node)idRecord.retrieve(node.getIdentifier().getText());
	    if (typeNode != null) {
		castType = typeNode.getClass().getName().substring(29);
		if (castType.equals("AVariableDeclaration")) {
		    lastType = ((AVariableDeclaration)typeNode).getType().getText();
		} else if (castType.equals("AArrayDeclaration")) {
		    lastType = ((AArrayDeclaration)typeNode).getType().getText();
		} else if (castType.equals("ASetDeclaration")) {
		    lastType = ((ASetDeclaration)typeNode).getType().getText();
		} else if (castType.equals("AWeightWeightLabelDeclaration")) {
		    lastType = ((AWeightWeightLabelDeclaration)typeNode).getType().getText();
		} else if (castType.equals("ALabelWeightLabelDeclaration")) {
		    lastType = ((ALabelWeightLabelDeclaration)typeNode).getType().getText();
		} else if (castType.equals("ARecordDeclaration")) {
		    lastType = ((ARecordDeclaration)typeNode).getType().getText();
		} else {
		    ErrorList.add(node.getIdentifier(), "Unknown declaration type");
		}
	    } else {
		ErrorList.add(node.getIdentifier(), "Unknown variable");
	    }
	} catch (IdRecordTableException e) {
	    ErrorList.add(node.getIdentifier(), e.getMessage());
	}
    }

    public void caseAOrAssignExpr(AOrAssignExpr node) {
	MultiTypeChecker multiTypeChecker = null;
	String type = lastType;

	if (((node.parent()).getClass().getName().substring(29)).equals("AAssignAssignExpr") && !stdEnv.isRecord(lastType)) {     
	    if(node.getOrExpr() != null) {
		// Evaluate the expresion, first the new record types
		if (type.equals("boolean")) {
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "boolean");
		    node.getOrExpr().apply(multiTypeChecker);
		    if(!multiTypeChecker.isRightType()) {
			ErrorList.add(((AAssignAssignExpr)node.parent()).getAssign(), "illegal type, boolean expected on rigth side of expression");
		    }
		} else if (type.equals("edge")) {
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "edge");
		    node.getOrExpr().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(((AAssignAssignExpr)node.parent()).getAssign(), "illegal type, vertex expected on rigth side of expression");
		    }
		} else if (type.equals("string")){ 
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "string");
		    node.getOrExpr().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(((AAssignAssignExpr)node.parent()).getAssign(), "illegal string expression on rigth side of expression");
		    }
		} else if (type.equals("integer")){
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "integer");
		    node.getOrExpr().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(((AAssignAssignExpr)node.parent()).getAssign(), "illegal integer expression on rigth side of expression");
		    }	    
		} else if (type.equals("float")){
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "float");
		    node.getOrExpr().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(((AAssignAssignExpr)node.parent()).getAssign(), "illegal float expression on rigth side of expression");
		    }	    
		} else if (type.equals("graph")) {
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "graph");
		    node.getOrExpr().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(((AAssignAssignExpr)node.parent()).getAssign(), "illegal type on rigth side of assignment expected graph");
		    }
		} else if (type.equals("diGraph")) {
		    multiTypeChecker = new MultiTypeChecker(idTable, idRecord, prober, "diGraph");
		    node.getOrExpr().apply(multiTypeChecker);
		    if (!multiTypeChecker.isRightType()) {
			ErrorList.add(((AAssignAssignExpr)node.parent()).getAssign(), "illegal type on rigth side of assignment expected diGraph");
		    }
		} else {
		    // Record dot ting...
		    // LABEL OG WEIGHT SKAL VI HUSKE
		}
	    }
	} else {
	    // Run normal case
	    inAOrAssignExpr(node);
	    if(node.getOrExpr() != null)
		{
		    node.getOrExpr().apply(this);
		}
	    outAOrAssignExpr(node);
	}
    }
}
