package dk.auc.cs.dogs.environment.types;

import java.util.*;

public class Weight extends GraphProperty implements WeightInteger, WeightFloat, WeightString, WeightBoolean, WeightEdge, WeightVertex, WeightInterface {

    //    private LinkedList list = new LinkedList();
    private LinkedList weights = new LinkedList();
    private GraphComposite graph;
    private java.lang.String type;

    public Weight (java.lang.String type, GraphComposite g) {
	super();
	graph = g;
	this.type = type;
	g.addWeight(this);
	Iterator it = g.getEdgeIterator();
	while (it.hasNext()) {
	    notifyAdd((Edge)it.next());
	}
    }

    public Primitive getWeight(Edge e) {
	//	int i = list.indexOf(e);
	Object o;
	if (e.getVertex1().getGraph().equals(graph) && e.sameGraph()) {
	    int index1 = graph.getIndex(e.getVertex1()),
		index2 = graph.getIndex(e.getVertex2());
	    LinkedList tmpList = (LinkedList)weights.get(index1);
	    o = tmpList.get(index2);
	    if (o instanceof java.lang.String) {
		throw new RuntimeException("Fatal error: weight value not set for edge");
	    } else {
		return (Primitive)o;
	    }
	} else {
	    throw new RuntimeException("Fatal error: weight value not set for edge, vertices not in same graph");
	}
    }

    public GraphComposite getGraph() {
	return graph;
    }

    public void setWeight(Edge e, Primitive weight) {
	java.lang.String name = weight.getType();
	if (((type.equals("Integer") || type.equals("Float")) && name.equals("Infty")) || type.equals(name)) {
	    int index1 = graph.getIndex(e.getVertex1()),
		index2 = graph.getIndex(e.getVertex2());
	    if (graph.isEdge(index1, index2)) {
		//	    if (list.contains(v)) {
		//		if (!(weight instanceof Edge || weight instanceof Vertex)) {
		    LinkedList tmpList = (LinkedList)weights.get(index1);
		    tmpList.remove(index2);
		    tmpList.add(index2, weight);
		    if (graph instanceof Graph) {
			tmpList = (LinkedList)weights.get(index2);
			tmpList.remove(index1);
			tmpList.add(index1, weight);
		    }
// 		} else {
// 		    throw new RuntimeException("Fatal error: cannot add vertex and edge as weight");
// 		}
	    } else {
		throw new RuntimeException("Cannot set weight for edge: edge not in correct graph");
	    }
	} else {
	    throw new RuntimeException("Cannot add weight of different type");
	}
    }

    public void notifyAdd(Vertex v) {
	LinkedList tmpList;
	for (int i = 0; i < weights.size(); i++) {
	    tmpList = (LinkedList)weights.get(i);
	    tmpList.addLast("");
	}
	tmpList = new LinkedList();
	weights.addLast(tmpList);
	for (int i = 0; i < weights.size(); i++) {
	    tmpList.add(i, "");
	}
	
    }

    public void notifyRemove(Vertex v) {
	int index = graph.getIndex(v);
	weights.remove(index);
	LinkedList tmpList;
	for (int i = 0; i < weights.size(); i++) {
	    tmpList = (LinkedList)weights.get(i);
	    tmpList.remove(index);
	}
    }

    public void notifyRemove(Edge e) {
       	if (e.getVertex1().getGraph().equals(graph) && e.sameGraph()) {
	    LinkedList tmpList = (LinkedList)weights.get(graph.getIndex(e.getVertex1()));
	    int index2 = graph.getIndex(e.getVertex2());
	    tmpList.remove(index2);
	    tmpList.add(index2, "");
	    //	    weights.remove(list.indexOf(e));
	    //	    list.remove(e);
	} else {
	    throw new RuntimeException("Cannot remove edge from weight: edge not in correct graph");
	}
    }

    public void notifyAdd(Edge e) {
	if (e.getVertex1().getGraph().equals(graph) && e.sameGraph()) {
	    int index1 = graph.getIndex(e.getVertex1()),
		index2 = graph.getIndex(e.getVertex2());
	    LinkedList tmpList = (LinkedList)weights.get(index1);
	    tmpList.remove(index2);
	    tmpList.add(index2, "");
	    //	    list.addLast(e);
	    //	    weights.addLast("");
	} else {
	    throw new RuntimeException("Cannot add edge to weight: edge not in correct graph");
	}
    }
}
