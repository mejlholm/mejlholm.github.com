package dk.auc.cs.whiner.function;

import java.util.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.rmi.*;
import java.rmi.*;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;

public class TestNotify extends TestCase{

    public void testMakeNotification() throws RemoteException, DAOException{
	ApplicantDAO applicantDAO = new ApplicantDAO();
	ApplicationDAO applicationDAO = new ApplicationDAO();
	NotificationDAO notificationDAO = new NotificationDAO();
	JobDAO jobDAO = new JobDAO();

	Applicant applicant;

	applicant = applicantDAO.add();
	applicant.setLoginName("bennett");
	applicantDAO.update(applicant);


	Job job;

	job = jobDAO.add();
	job.setTitle("Lame job");
	jobDAO.update(job);

	Notify.makeNotification(applicant.getID(), job.getID(), "Application rejected");

	ArrayList list = notificationDAO.getNotifications(applicant.getID());
	Notification notification1 = (Notification) list.get(0);


	assertEquals("jobID!!", job.getID(), notification1.getJobID());
	assertEquals("applicantID!!", applicant.getID(), notification1.getApplicantID());
	assertEquals("notification type!!", "Application rejected", notification1.getNotificationType());
	assertFalse("Body text!!", (notification1.getBodyText()).equals(""));


	//clean up
	applicantDAO.delete(applicant.getID());
	jobDAO.delete(job.getID());
	notificationDAO.delete(notification1.getID());
	
	
    }
    
    
    
}
