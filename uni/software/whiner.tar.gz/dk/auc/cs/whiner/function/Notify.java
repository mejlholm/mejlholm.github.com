package dk.auc.cs.whiner.function;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.*;
import java.util.Date;


/**
 * This class handles the different notifications sent to the
 * applicants. It contains the method makeNotification which takes
 * care of notifying the applicants and is used by the "Job" and
 * "Application" class.
 *
 * @author <a href="mailto:bennett@luke.cs.auc.dk">Anders Bennett-Therkildsen</a>
 * @version 1.0
 */
public abstract class Notify{
    /**
     * Sends out a notification to the involved applicant(s) regarding
     * the relevant type of event (i.e., rejection of an application
     * due to closure or occupation of a job, or deletion of an
     * application.
     *
     * @param applicantID an <code>int</code> value
     * @param jobID an <code>int</code> value
     * @param notificationType a <code>String</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public static void makeNotification(int applicantID, int jobID, String notificationType) throws DAOException, RMIException{
	NotificationDAO notificationDAO;
	notificationDAO = new NotificationDAO();
	//return an empty notification object		
	Notification newNotification;
	newNotification = notificationDAO.add();
	if(notificationType == "Application rejected"){
	    newNotification.setApplicantID(applicantID);
	    newNotification.setJobID(jobID);
	    newNotification.setDateOfDispatch(new Date());
	    newNotification.setNotificationType(notificationType);
	    notificationDAO.update(newNotification);		
	}
	else if(notificationType == "Application deleted"){
	    newNotification.setApplicantID(applicantID);
	    newNotification.setJobID(jobID);
	    newNotification.setDateOfDispatch(new Date());
	    newNotification.setNotificationType(notificationType);
	    notificationDAO.update(newNotification);
	}
	else if(notificationType == "Job reopened"){
	    newNotification.setApplicantID(applicantID);
	    newNotification.setJobID(jobID);
	    newNotification.setDateOfDispatch(new Date());
	    newNotification.setNotificationType(notificationType);
	    notificationDAO.update(newNotification);    
	}
    }
}
