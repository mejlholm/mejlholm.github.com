package dk.auc.cs.whiner.function;

import java.rmi.*;
import java.rmi.server.*;
import dk.auc.cs.whiner.function.*;

/**
 * The <code>Server</code> is the responsible for starting the server and 
 * binding the Remote classes with the RMI-registry 
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public class Server{

    /**
     * The <code>main</code> bind the LoginServer and the RegistryServer to 
     * the RMI-registry.
     *
     * @param args a <code>String[]</code> value
     */
    public static void main(String[] args){
	if (System.getSecurityManager() == null){
	    System.setSecurityManager(new SecurityManager());
	}


	String loginConnectstring =  "//130.225.194.15:2002/WhinerLoginServer";
	try{
	    Login loginServer = new Login();
	    Naming.rebind(loginConnectstring, loginServer);
	    System.out.println("WhinerLoginServer started");
	} catch (Exception e){
	    System.err.println("WhinerLoginServer failure: " + e.getMessage());
	}

	String registryConnectstring =  "//130.225.194.15:2002/WhinerRegistryServer";
	try{
	    Register registryServer = new Register();
	    Naming.rebind(registryConnectstring, registryServer);
	    System.out.println("WhinerRegistryServer started");
	} catch (Exception e){
	    System.err.println("WhinerLoginServer failure: " + e.getMessage());
	}
	System.out.println("WhinerServer Online");
    }
}