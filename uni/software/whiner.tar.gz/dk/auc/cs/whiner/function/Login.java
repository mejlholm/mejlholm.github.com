package dk.auc.cs.whiner.function;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.RMIException;

import java.util.*;
import java.rmi.*;
import java.rmi.server.*;


/**
 * The "Login" class handles the the login procedure. The method login
 * takes care of this and decides, based on the user type, which main
 * screen will be presented for the user.
 *
 * @author <a href="mailto:bennett@atto.cs.auc.dk">Anders Bennett-Therkildsen</a>
 * @version 1.0
 */
public class Login extends UnicastRemoteObject implements LoginI{
    private final String app = "applicant";
    private final String hh = "headhunter";
    private final String admin = "administrator";

    //DAO OBJECTS
    private ApplicantDAO applicantDAO;
    private HeadhunterDAO headhunterDAO;
    private AdministratorDAO administratorDAO;

    public Login() throws RemoteException, DAOException{
	    applicantDAO = new ApplicantDAO();
	    headhunterDAO = new HeadhunterDAO();
	    administratorDAO = new AdministratorDAO();
    }
    
    /**
     * Checks if the login name and password is accepted, then checks
     * what user type is logging in and returns the type in question,
     * when it finds a user in the database who has the respective
     * login name. 
     *
     * @param userLginName a <code>String</code> value
     * @param userPassword a <code>String</code> value
     * @return an <code>User</code> value
     * @exception DAOException if an dataaccess error occurs
     * @exception RMIException if an error occurs
     * @exception WrongPasswordOrUsernameException if an error occurs
     */
    public UserI login(String userLginName, String userPassword) throws DAOException, RMIException, WrongPasswordOrUsernameException {
	UserI retUser;
	String user = RegisterDAO.checkUserType(userLginName, userPassword);
	if(hh.equals(user)){
	    Headhunter headhunter = headhunterDAO.getHeadhunter(userLginName);
	    retUser = (UserI)headhunter;
	}
	else if(app.equals(user)){
	    Applicant applicant = applicantDAO.getApplicant(userLginName);
	    retUser = (UserI)applicant;
	}
	else if(admin.equals(user)){
	    Administrator administrator = administratorDAO.getAdministrator(userLginName);
	    retUser = (UserI)administrator;
	}
	else
	    throw new WrongPasswordOrUsernameException("Error. Something seems to be wrong with your registered user!");
	return retUser;
    }
    
}
