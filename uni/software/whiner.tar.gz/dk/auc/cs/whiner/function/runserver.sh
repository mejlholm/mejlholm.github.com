cd ..

cvs update -Pd

echo Removing Classes
rm interfaces/*.class
rm model/*.class
rm dataaccess/*.class
rm function/*.class

echo "Compiling interfaces"
javac interfaces/*.java
echo "Compiling model"
javac model/*.java
echo "Compiling dataaccess"
javac dataaccess/*.java
echo "Compiling function"
javac function/*.java

cd ~/cvs/programming/
echo "Compiling Model stubs"
rmic dk.auc.cs.whiner.model.Address		       
rmic dk.auc.cs.whiner.model.Job	   
rmic dk.auc.cs.whiner.model.Qualification
rmic dk.auc.cs.whiner.model.Applicant       
rmic dk.auc.cs.whiner.model.Match	   
rmic dk.auc.cs.whiner.model.Application
rmic dk.auc.cs.whiner.model.Name	   
rmic dk.auc.cs.whiner.model.SkillLevel
rmic dk.auc.cs.whiner.model.CV		       
rmic dk.auc.cs.whiner.model.Notification
rmic dk.auc.cs.whiner.model.User
rmic dk.auc.cs.whiner.model.GlobalQualificationList
rmic dk.auc.cs.whiner.model.PhoneNumber
rmic dk.auc.cs.whiner.model.Headhunter
rmic dk.auc.cs.whiner.model.Project
rmic dk.auc.cs.whiner.model.Administrator

echo "Compiling Function stubs"
rmic dk.auc.cs.whiner.function.Login   
rmic dk.auc.cs.whiner.function.Register
rmic dk.auc.cs.whiner.function.Search

cd ~/cvs/programming/dk/auc/cs/whiner/
#set classpath=
export CLASSPATH2=$CLASSPATH
export CLASSPATH=
echo Starting Registry
rmiregistry 2002&


export CLASSPATH=$CLASSPATH2
#set classpath=d:\storage\development\java;
echo Starting ClassFileServer
java ClassServer.ClassFileServer 2001 /user/peng/cvs/programming/ &

#set classpath=d:\storage\development\Dat1\programming\
echo Starting WhinerServer
java -Djava.security.policy=/user/peng/cvs/programming/dk/auc/cs/whiner/function/policy -Djava.rmi.server.codebase=http://130.225.194.15:2001/ dk.auc.cs.whiner.function.Server
