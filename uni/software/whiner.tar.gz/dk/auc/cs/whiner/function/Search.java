package dk.auc.cs.whiner.function;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.model.*;
import java.util.*;

import java.rmi.*;
import java.rmi.server.*;
import dk.auc.cs.whiner.rmi.RMIException;

/**
 * This class handles the search functionality in the system. It
 * contains methods for specifying the search performed by the
 * applicant by adding or removing qualifications and also the search
 * method itself.
 *
 * @author <a href="mailto:carlsen@fatboy"></a>
 * @version 1.0
 */
public class Search extends UnicastRemoteObject implements SearchI{
    private ArrayList searchResult;

    //DAO objects
    SearchDAO searchDAO;
    
    /**
     * The constructor initializes the list of qualifications, gets the id's
     * for the chosen qualifications and envokes the searchForJob method 
     * which does the actual search.
     *
     * @param argSearchCriteria an <code>int[]</code> value
     * @exception RemoteException if an error occurs
     * @exception DAOException if an error occurs
     */
    public Search(int[] argSearchCriteria)throws RemoteException, DAOException{
	searchDAO = new SearchDAO();
	searchForJob(argSearchCriteria);
    }

    /**
     * Returns the job selected by the applicant for further view.
     *
     * @param jobNo an <code>int</code> value
     * @return a <code>Job</code> value
     * @exception RMIException if an error occurs
     */
    public JobI getJob(int jobNo) throws RMIException{
	return (JobI) searchResult.get(jobNo);
    }


    /**
     * Returns the length of the searchResult list. Is used in 
     * the User Interface.
     *
     * @return an <code>int</code> value
     */
    public int getLength(){
	return searchResult.size();
    }

    /**
     * Invokes the searchForJob method in the SearchDAO class which
     * accesses the database and searches through it based on the
     * search criteria specified by the applicant. The resulting list
     * of jobs gets returned and the searchResult list points to this
     * list.
     *
     * @param argCriteria an <code>int[]</code> value
     * @exception RMIException if an error occurs
     * @exception DAOException if an error occurs
     */
    private void searchForJob(int[] argCriteria) throws RMIException, DAOException{
	searchResult = searchDAO.searchForJob(argCriteria);
	removeNotAnnouncedJobs();
    }

    
    /**
     * The <code>removeNotAnnouncedJobs</code> runs through the searchResult 
     * arraylist and removes the jobs that is not announced.
     *
     * @exception RMIException if an error occurs
     */
    private void removeNotAnnouncedJobs() throws RMIException{
	for(int i = 0; i < searchResult.size(); i++){
	    Job job = (Job) searchResult.get(i);
	    if (!(job.getStatus().equals("announced"))){
		searchResult.remove(job);
		i--;
	    }
	}
    }
}


