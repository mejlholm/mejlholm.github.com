package dk.auc.cs.whiner.function;

import java.util.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.rmi.*;
import java.rmi.*;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.interfaces.*;

public class TestRegister extends TestCase{

    public void testActivateApplicant() throws RMIException, RemoteException, DAOException, LoginNameException{
	Register reg = new Register();
	ApplicantDAO applicantDAO = new ApplicantDAO();

	Applicant app1 = applicantDAO.add();
	app1.setLoginName("bennett1");
	applicantDAO.update(app1);

	String userName = "bennett1";
	String passwrd = "2*uglyPirates";	

	Applicant app2 = new Applicant();
	try{
	    app2 = (Applicant) reg.activateApplicant(userName, passwrd);
	    fail("The username is alreeady in use!! Exception expected!");
	} catch (LoginNameException e){
	    //passed
	}

	userName = "Carlson";

	try{
	    app2 = (Applicant) reg.activateApplicant(userName, passwrd);
	    //passed
	} catch (LoginNameException e){
	    fail("The username is not in use!! Exception not expected!");
	}

	assertEquals("Username not saved correctly", userName, app2.getLoginName());
	assertEquals("Password not saved correctly", passwrd, app2.getPassword());

	//cleanup
	applicantDAO.delete(app1.getID());
	applicantDAO.delete(app2.getID());

    }
}
