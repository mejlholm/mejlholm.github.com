package dk.auc.cs.whiner.function;

import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.interfaces.*;

import java.util.Date;
import java.rmi.*;
import java.rmi.server.*;

/**
 * The "Register" class handles the registration process of the system.
 *
 * @author <a href="mailto:bennett@flatboy"></a>
 * @version 1.0
 */
public class Register extends UnicastRemoteObject implements RegisterI{
    private String userType = "";

    //DAO objects
    private ApplicantDAO applicantDAO;
    private HeadhunterDAO headhunterDAO;
    private RegisterDAO registerDAO;    

    public Register() throws RemoteException, DAOException{
	applicantDAO = new ApplicantDAO();
	headhunterDAO = new HeadhunterDAO();
	registerDAO = new RegisterDAO();

    }

    /**
     * Tests if the login name chosen complies with the naming
     * conventions in the system which is done by invoking the
     * acceptLoginName method in the "RegisterDAO" class.
     *
     * @param argLoginName a <code>String</code> value
     * @return a <code>boolean</code> value
     * @exception DAOException if a dataaccess error occurs
     */
    private boolean acceptLoginName(String argLoginName) throws DAOException{
	boolean retVal = false;
	if(registerDAO.acceptLoginName(argLoginName))
	    retVal = true;
	return retVal;
    }

    
    /**
     * Activates an applicant profile, which means creating a new object
     * of the applicant, setting the attributes loginName and password and
     * storing him in the database. Finally, the object is returned to the GUI.
     *
     * @param argLoginName a <code>String</code> value
     * @param argPassword a <code>String</code> value
     * @return an <code>Applicant</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     * @exception LoginNameException if the typed login name does not
     * match any in the database
     */
    public ApplicantI activateApplicant(String argLoginName, String argPassword) throws DAOException, RMIException, LoginNameException{
	Applicant newApplicant;	
	try{	
	    newApplicant = new Applicant();	
	    if (acceptLoginName(argLoginName) == false)
		throw new LoginNameException();	
	    newApplicant = applicantDAO.add();
	    newApplicant.setLoginName(argLoginName);
	    newApplicant.setPassword(argPassword);
	    newApplicant.setDateOfInterest(new Date());
	    applicantDAO.update(newApplicant);
	} catch(RemoteException e){
	    throw new RMIException();
	}
	return (ApplicantI)newApplicant;
    }

    

    /**
     * Activates a headhunter, which means creating a new object
     * of the headhunter, setting the attributes loginName and password and
     * storing him in the database.
     *
     * @param argLoginName a <code>String</code> value
     * @param argPassword a <code>String</code> value
     * @exception LoginNameException if the typed login name does not
     * match any in the database
     * @exception RMIException if a dataaccess error occurs
     * @exception DAOException if an error occurs
     */
    public void activateHeadhunter(String argLoginName, String argPassword) throws LoginNameException, RMIException, DAOException{
	if (acceptLoginName(argLoginName) == false)
	    throw new LoginNameException();	
	Headhunter newHeadhunter = headhunterDAO.add();
	newHeadhunter.setLoginName(argLoginName);
	newHeadhunter.setPassword(argPassword);
	headhunterDAO.update(newHeadhunter);
    }
    
}

