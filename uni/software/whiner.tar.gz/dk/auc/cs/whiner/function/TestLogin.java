package dk.auc.cs.whiner.function;

import java.util.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.rmi.*;
import java.rmi.*;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.interfaces.*;

public class TestLogin extends TestCase{

    public void setUp() throws RMIException, RemoteException, DAOException{	
	ApplicantDAO applicantDAO = new ApplicantDAO();
    
	//applicant
	
	Name name = new Name();
	name.setFirstName("Applicant1");
	name.setMiddleName("");
	name.setLastName("Bennett");
	
	Address address = new Address();
	address.setAddress1("bla");
	address.setAddress2("");
	address.setCity("ComputerCity");
	address.setPostCode(1);
	address.setRegion("fdsa");
	address.setCountry("faf");
	
	PhoneNumber phoneNumber = new PhoneNumber();
	phoneNumber.setHomePhone(002);
	phoneNumber.setWorkPhone(543);
	phoneNumber.setMobile(23532);
	phoneNumber.setFax(32456);
	
	
	Applicant app1 = applicantDAO.add();	
	
	
	CV cv = new CV();
	cv.setApplicantID(app1.getID());
	cv.setDateOfBirth(new Date(0));
	cv.setSex("male");
	cv.setMaritalStatus("single");
	cv.setEducation("none");
	cv.setWorkingExperience("none");
	cv.setReEducation("none");
	cv.setLanguageSkills("none");
	cv.setOtherITKnowledge("none");
	cv.setSpareTimeInterests("none");

	
	
	app1.setLoginName("bennett");
	app1.setPassword("2*uglyPirates");
	app1.setLastLogin(new Date(0));
	app1.setDateOfInterest(new Date(0));
	app1.setName(name);
	app1.setAddress(address);
	app1.setPhoneNumber(phoneNumber);
	app1.setEmail("jack@ass");
	app1.setCV(cv);

	applicantDAO.update(app1);
	applicantDAO.update(cv);



        ////////////////////
    	//More applicants //
    	//Headhunter      // 
    	//Administrator   //
	////////////////////

    }


    public void tearDown() throws RMIException, RemoteException, DAOException{
	
	ApplicantDAO applicantDAO = new ApplicantDAO();
	
	try{
	    //Admin Smith is the first inserted User, he has id value 0	    
	    applicantDAO.delete(1);
	} catch(DAOException e){
	    System.out.println("Error.. tearDown could not delete something from the DB as it was supposed to!"); 
	}
    }





    public void testLogin() throws RMIException, RemoteException, DAOException, WrongPasswordOrUsernameException{
	ApplicantDAO applicantDAO = new ApplicantDAO();

	String argOne = "bennett";
	String argTwo = "2*uglyPirates";

	Login login = new Login();

	//User user = new User();

	Applicant applicantDB = applicantDAO.getApplicant(1);

	Applicant applicantLogin = (Applicant)login.login(argOne, argTwo);

	//Applicant applicantLogin = (Applicant) user;

	assertEquals("ID!!", applicantDB.getID(), applicantLogin.getID());

	assertTrue("CV!!", applicantDB.getCV().equals(applicantLogin.getCV()));


	assertTrue("Applicants should be instances of same object", applicantDB.equals(applicantLogin));


    }

}
