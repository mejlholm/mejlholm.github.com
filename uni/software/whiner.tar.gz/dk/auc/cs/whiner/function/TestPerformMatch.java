package dk.auc.cs.whiner.function;

import java.util.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.rmi.*;
import java.rmi.*;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;


public class TestPerformMatch extends TestCase{
	
    
    public void setUp() throws RMIException, RemoteException, DAOException{	
	JobDAO jobDAO = new JobDAO();
	ApplicantDAO applicantDAO = new ApplicantDAO();
	QualificationDAO qualDAO = new QualificationDAO();
	MatchesDAO matchesDAO = new MatchesDAO();
    
	//job1	

	Job job1 = jobDAO.add();
	job1.setProjectID(0);
	job1.setStatus("announced");
	job1.setTitle("Job1");
	job1.setDescription("description");
	job1.setDateOfCreation(new Date(0));
	job1.setDateOfAnnouncement(new Date(0));
	job1.setDateOfOccupation(new Date(0));
	jobDAO.update(job1);
	
	Qualification qual1;
	Qualification qual2;
	
	qual1 = qualDAO.add();
	qual1.setName("qual1");
	qual1.setDescription("a description");
	qualDAO.update(qual1);
    
	qual2 = qualDAO.add();
	qual2.setName("qual2");
	qual2.setDescription("a description 2");
	qualDAO.update(qual2);
	

	SkillLevel skill1;
	SkillLevel skill2;
	
	skill1 = new SkillLevel();
	skill1.setID(job1.getID());
	skill1.setLevel(4);
	skill1.setQualification(qual1);
	
	skill2 = new SkillLevel();
	skill2.setID(job1.getID());
	skill2.setLevel(3);
	skill2.setQualification(qual2);	
	
	jobDAO.insertSkillLevel(skill1);
	jobDAO.insertSkillLevel(skill2);

		
	//job2	

	/*
	Job job2 = jobDAO.add();
	job2.setProjectID(0);
	job2.setStatus("announced");
	job2.setTitle("Job2");
	job2.setDescription("description");
	job2.setDateOfCreation(new Date(0));
	job2.setDateOfAnnouncement(new Date(0));
	job2.setDateOfOccupation(new Date(0));
	jobDAO.update(job2);
	
	Qualification qual3;
	Qualification qual4;
	
	qual3 = qualDAO.add();
	qual3.setName("qual3");
	qual3.setDescription("a description 3");
	qualDAO.update(qual3);
    
	qual4 = qualDAO.add();
	qual4.setName("qual4");
	qual4.setDescription("a description 4");
	qualDAO.update(qual4);
	


	SkillLevel skill5;
	SkillLevel skill6;
	
	skill5 = new SkillLevel();
	skill5.setID(job2.getID());
	skill5.setLevel(6);
	skill5.setQualification(qual3);
	
	skill6 = new SkillLevel();
	skill6.setID(job2.getID());
	skill6.setLevel(6);
	skill6.setQualification(qual4);	
	
	jobDAO.insertSkillLevel(skill5);
	jobDAO.insertSkillLevel(skill6);
	*/



	//applicant
	
	Name name = new Name();
	name.setFirstName("Agent");
	name.setMiddleName("");
	name.setLastName("Smith");
	
	Address address = new Address();
	address.setAddress1("bla");
	address.setAddress2("");
	address.setCity("ComputerCity");
	address.setPostCode(1);
	address.setRegion("fdsa");
	address.setCountry("faf");
	
	PhoneNumber phoneNumber = new PhoneNumber();
	phoneNumber.setHomePhone(002);
	phoneNumber.setWorkPhone(543);
	phoneNumber.setMobile(23532);
	phoneNumber.setFax(32456);
	
	
	Applicant app1 = applicantDAO.add();	
	
	
	CV cv = new CV();
	cv.setApplicantID(app1.getID());
	cv.setDateOfBirth(new Date(0));
	cv.setSex("male");
	cv.setMaritalStatus("single");
	cv.setEducation("none");
	cv.setWorkingExperience("none");
	cv.setReEducation("none");
	cv.setLanguageSkills("none");
	cv.setOtherITKnowledge("none");
	cv.setSpareTimeInterests("none");
	
	
	app1.setLoginName("A.Smith");
	app1.setPassword("fisk4U*");
	app1.setLastLogin(new Date(0));
	app1.setDateOfInterest(new Date(0));
	app1.setName(name);
	app1.setAddress(address);
	app1.setPhoneNumber(phoneNumber);
	app1.setEmail("fdjalkf");
	app1.setCV(cv);
	applicantDAO.update(app1);


	SkillLevel skill3;
	SkillLevel skill4;
	//SkillLevel skill7;
	

	skill3 = new SkillLevel();
	skill3.setID(app1.getID());
	skill3.setLevel(4);
	skill3.setQualification(qual1);
	
	skill4 = new SkillLevel();
	skill4.setID(app1.getID());
	skill4.setLevel(1);
	skill4.setQualification(qual2);	
	
	/*
	skill7 = new SkillLevel();
	skill7.setID(app1.getID());
	skill7.setLevel(7);
	skill7.setQualification(qual4);	
	*/

	applicantDAO.insertSkillLevel(skill3);
	applicantDAO.insertSkillLevel(skill4);
	//applicantDAO.insertSkillLevel(skill7);

	//set a match object i DB

	Match match1 = matchesDAO.add();
	Match match2 = matchesDAO.add();

	List metReqs1 = new ArrayList();
	List metReqs2 = new ArrayList();

	MatchInformation matchInfo1 = new MatchInformation();
	MatchInformation matchInfo2 = new MatchInformation();

	matchInfo1.setMatchID(match1.getID());
	matchInfo1.setLevelJobSkillLevel(4);
	matchInfo1.setLevelApplicantSkillLevel(4);
	matchInfo1.setQualificationName(qual1.getName());

	metReqs1.add(matchInfo1);

	matchInfo2.setMatchID(match1.getID());
	matchInfo2.setLevelJobSkillLevel(3);
	matchInfo2.setLevelApplicantSkillLevel(3);
	matchInfo2.setQualificationName(qual2.getName());

	metReqs1.add(matchInfo2);


	MatchInformation matchInfo3 = new MatchInformation();
	MatchInformation matchInfo4 = new MatchInformation();

	matchInfo3.setMatchID(match2.getID());
	matchInfo3.setLevelJobSkillLevel(4);
	matchInfo3.setLevelApplicantSkillLevel(4);
	matchInfo3.setQualificationName(qual1.getName());

	metReqs2.add(matchInfo3);

	matchInfo4.setMatchID(match2.getID());
	matchInfo4.setLevelJobSkillLevel(3);
	matchInfo4.setLevelApplicantSkillLevel(3);
	matchInfo4.setQualificationName(qual2.getName());

	metReqs2.add(matchInfo4);

	match1.setApplicantID(app1.getID());
	match1.setJobID(job1.getID());
	match1.setRequirementScore(6);
	match1.setMetRequirements(metReqs1);
	match1.setDateOfMatch(new Date());

	match2.setApplicantID(app1.getID());
	match2.setJobID(job1.getID());
	match2.setRequirementScore(6);
	match2.setMetRequirements(metReqs2);
	match2.setDateOfMatch(new Date());


	matchesDAO.update(match1);
	matchesDAO.update(match2);
	
    }
    
    
   
    public void tearDown() throws RMIException, RemoteException, DAOException{
	JobDAO jobDAO = new JobDAO();
	QualificationDAO qualDAO = new QualificationDAO();
	ApplicantDAO applicantDAO = new ApplicantDAO();
	MatchesDAO matchesDAO = new MatchesDAO();	

	SkillLevel skill1;
	SkillLevel skill2;
	
	skill1 = new SkillLevel();
	skill1.setID(0); //sets the first job's id
	skill1.setLevel(4);
	skill1.setQualification(qualDAO.getQualification(0));
	
	skill2 = new SkillLevel();
	skill2.setID(0); //sets the first job's id
	skill2.setLevel(3);
	skill2.setQualification(qualDAO.getQualification(1));	

	SkillLevel skill5;
	SkillLevel skill6;
	
	skill5 = new SkillLevel();
	skill5.setID(1); //sets the first job's id
	skill5.setLevel(6);
	skill5.setQualification(qualDAO.getQualification(2));
	
	skill6 = new SkillLevel();
	skill6.setID(1); //sets the first job's id
	skill6.setLevel(7);
	skill6.setQualification(qualDAO.getQualification(3));	
	

	
	SkillLevel skill3;
	SkillLevel skill4;
	SkillLevel skill7;

	skill3 = new SkillLevel();
	skill3.setID(1); //sets the first applicant's id (the first after Admin Smith)
	skill3.setLevel(4);   
	skill3.setQualification(qualDAO.getQualification(0));

	skill4 = new SkillLevel();
	skill4.setID(1);  //sets the first applicant's id (the first after Admin Smith)
	skill4.setLevel(1);
	skill4.setQualification(qualDAO.getQualification(1));	

	skill7 = new SkillLevel();
	skill7.setID(1);  //sets the first applicant's id (the first after Admin Smith)
	skill7.setLevel(7);
	skill7.setQualification(qualDAO.getQualification(3));	

	try{
	    jobDAO.deleteSkillLevel(skill1);
	    jobDAO.deleteSkillLevel(skill2);
	    jobDAO.deleteSkillLevel(skill5);
	    jobDAO.deleteSkillLevel(skill6);
	    applicantDAO.deleteSkillLevel(skill3);
	    applicantDAO.deleteSkillLevel(skill4);
	    applicantDAO.deleteSkillLevel(skill7);
	    jobDAO.delete(0);
	    jobDAO.delete(1);
	    //jobDAO.delete(1);
	    qualDAO.delete(0);
	    qualDAO.delete(1);
	    qualDAO.delete(2);
	    qualDAO.delete(3);
	    //Admin Smith is the first inserted User, he has id value 0	    
	    applicantDAO.delete(1);
	    matchesDAO.delete(0);	
	    matchesDAO.delete(1);	
	} catch(DAOException e){
	    System.out.println("Error.. tearDown could not delete something from the DB as it was supposed to!"); 
	}
    }
    
    
    public void testMatchApplicant() throws RMIException, RemoteException, DAOException{
	JobDAO jobDAO = new JobDAO();
	ApplicantDAO applicantDAO = new ApplicantDAO();
	QualificationDAO qualDAO = new QualificationDAO();
	MatchesDAO matchesDAO = new MatchesDAO();
	Match match1 = matchesDAO.getMatch(0);
	Match match2 = matchesDAO.getMatch(1);
	
	PerformMatch.matchApplicant(1);
    

	match1.setID(match2.getID());

	assertTrue("Match object 1 should equal match object 2", match1.equals(match2));


    }

  public void testMatchJob() throws RMIException, RemoteException, DAOException{
	JobDAO jobDAO = new JobDAO();
	ApplicantDAO applicantDAO = new ApplicantDAO();
	QualificationDAO qualDAO = new QualificationDAO();
	MatchesDAO matchesDAO = new MatchesDAO();
	Match match1 = matchesDAO.getMatch(0);
	Match match2 = matchesDAO.getMatch(1);
	

	PerformMatch.matchJob(0);

	
	match1.setID(match2.getID());

	assertTrue("Match object 1 should equal match object 2", match1.equals(match2));
	

	
  }
}
