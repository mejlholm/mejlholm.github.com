package dk.auc.cs.whiner.function;

/* Simple exception class - basically just renaming... */


public class LoginNameException extends Exception {
 
    public LoginNameException(){
	super("Unknown exception");
    }

    public LoginNameException(String msg){
	super(msg);
    }

    public LoginNameException(String msg, Throwable cause){
	super(msg, cause);
    }

}
