package dk.auc.cs.whiner.function;

import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.interfaces.*;
import java.util.*;

import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.*;
import java.rmi.server.*;



/**
 * This class handles the matching between an applicant and a job in
 * the system. The matchApplicant method matches a new applicant, or
 * an applicant who has edited his or hers qualifications, with all
 * jobs in the system. The matchJob method matches a new job, or an
 * already existing job that has had its requirements redefined, with
 * all applicants in the system. The DAO objects get initialized in
 * the individual method because this class is abstract and hence does
 * not allow creation of objects. Therefore, we do not use a
 * constructor for initialization.
 *
 * @author <a href="mailto:bennett@atto.cs.auc.dk">Anders Bennett-Therkildsen</a>
 * @version 1.0
 */
public abstract class PerformMatch{
    /**
     * Matches a new applicant, or an already signed up applicant who
     * has redefined his qualifications, with all jobs in the system.
     *
     * @param applicantID an <code>int</code> value
     * @exception RemoteException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public static void matchApplicant(int applicantID) throws RemoteException, DAOException, RMIException{
	List contApplicantSkillLevels = new ArrayList();
	List matchedJobList = new ArrayList();    

	MatchesDAO matchesDAO = new MatchesDAO();	
	ApplicantDAO applicantDAO = new ApplicantDAO();
	/* fetch all jobs with one or more requirements coherent with
	 * the applicant's qualifications
	 */
	matchedJobList = matchesDAO.getMatchedJobs(applicantID);	
	//fill a container with all the applicant's skill-level objects
	contApplicantSkillLevels = applicantDAO.getSkillLevels(applicantID);
	compareApplicantWithJobs(matchedJobList, contApplicantSkillLevels, applicantID);
    }
    
    
    /**
     * Matches a new job, or an already existing job that has had its
     * requirements redefined, with all applicants in the system.
     *
     * @param jobID an <code>int</code> value
     * @exception RemoteException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public static void matchJob(int jobID) throws RemoteException, DAOException, RMIException{
	List contJobSkillLevels = new ArrayList();
	List matchedApplicantList = new ArrayList();

	MatchesDAO matchesDAO = new MatchesDAO();
	JobDAO jobDAO = new JobDAO();	
	/* fetch all applicants with one or more qualifications
	 * coherent with the job's requirements
	 */
	matchedApplicantList = matchesDAO.getMatchedApplicants(jobID);
	//fill a container with all the job's skill-level objects
	contJobSkillLevels = jobDAO.getSkillLevels(jobID);
	compareJobWithApplicants(matchedApplicantList, contJobSkillLevels, jobID);

    }
    
    

    /**
     * Compares the applicant's skill-level objects with all jobs'
     * skill-level objects. This method consists of three nested
     * for-loops which do the following (example on a first run): For
     * the first job in the passed jobList, we get its skill-level
     * objects. Then, for each of the applicant's skill-level objects,
     * we run through the container of the first job's skill-level
     * objects to see which skill-level objects equal eachother. This
     * is done by fetching the qualification object from both the
     * applicant's and the job's skill-level object and then invoke
     * the equals method defined in the "Qualification" class to see
     * if it is the same from the global qualification list. If it is,
     * the calcReqScore method is invoked and the variable result is
     * incremented with the return value of the method. This is the
     * requirement score the applicant gets for the particular job we
     * do the run-through of. An object from the "MatchInformation"
     * class, matchInfo, then gets its attributes set. This object
     * holds information on how the specific match between a specific
     * job and the applicant has happened which is achieved by storing
     * the name of the qualification the job and the applicant had in
     * common, which skill level was required by the job and which
     * skill level the applicant had. It also has a matchID
     * attribute. This is the case since the matchInfo object is a
     * part of a match object. This object has an ArrayList of
     * matchInfo objects as attribute. When all of the first job's
     * skill-level objects have been compared with the applicant's
     * skill-level objects (by comparing the qualifications), the
     * metRequirement ArrayList consists of one or more matchInfo
     * objects. This is used when we set the match object's
     * attributes. The match object holds information on which job was
     * matched with the applicant (based on id values), what the
     * requirement score was (calculated by calcReqScore) and the list
     * of matchInfo objects. Finally, the match object is stored in
     * the database.
     *
     * @param jobList a <code>List</code> value
     * @param appSkillLevels a <code>List</code> value
     * @param appID an <code>int</code> value
     * @exception RemoteException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    private static void compareApplicantWithJobs(List jobList, List appSkillLevels, int appID) throws RemoteException, DAOException, RMIException{
	MatchesDAO matchesDAO = new MatchesDAO();
        JobDAO jobDAO = new JobDAO();	
	Job job = new Job();	
	SkillLevel skillLevelJob;
	SkillLevel skillLevelApplicant;
	int result = 0;
	List contJobSkillLevels = new ArrayList();
	List metRequirements = new ArrayList();	
	Match match = new Match();	
	MatchInformation matchInfo = new MatchInformation();
	for (int i = 0; i < jobList.size(); i++){
	    /* at this point, we know that for each job in the jobList,
	     * a match object will be created. Therefore, we make a new
	     * match object here so that later on we have access to its
	     * id value when we create a matchInfo object
	     */
	    match = matchesDAO.add();
	    job = (Job) jobList.get(i);
	    /* we want the job's skill-level objects from its id for
	     * calculation of the req. score
	     */
	    contJobSkillLevels = jobDAO.getSkillLevels(job.getID());
	    /* reset the result value to 0 when the next of the
	     * applicant's skill-level objects gets compared, otherwise
	     * the value would be accumulated and yield wrong values
	     */
	    result = 0;	    
	    //for each of the applicant's skill-level objects...
	    for (int j = 0; j < appSkillLevels.size(); j++){
		skillLevelApplicant = (SkillLevel) appSkillLevels.get(j);
		/* ...run through all the skill-level objects in the
		 * job to check if the qualification attribute equals
		 * the one in the applicant's skill-level object
		 */
		for (int k = 0; k < contJobSkillLevels.size(); k++){
		    skillLevelJob = (SkillLevel) contJobSkillLevels.get(k);		    
		    if ((skillLevelJob.getQualification()).equals(skillLevelApplicant.getQualification())){
			result += calcReqScore(skillLevelJob, skillLevelApplicant);
			/* create a new matchInfo object that holds
			 * information on which qualification was in
			 * question, what level the job had set it to
			 * and what level the applicant had set it
			 * to. Further, it holds information on which
			 * match object it is related to
			 */
			matchInfo.setMatchID(match.getID());			
			matchInfo.setLevelJobSkillLevel(skillLevelJob.getLevel());			
			matchInfo.setLevelApplicantSkillLevel(skillLevelApplicant.getLevel());
			matchInfo.setQualificationName((skillLevelJob.getQualification()).getName());			
			metRequirements.add(matchInfo);
			/* we know that when the if-statement has been
			 * true once, it does NOT make sense to run
			 * the inner for-loop through once again
			 * because a job can only contain one
			 * qualification of a certain type (i.e.,
			 * Java), so the algorithm will not find any
			 * other qualifications of the same
			 * type. Hence, we might as well break here
			 * and force the second-most inner for-loop to
			 * increment (which means that we proceed to
			 * the next applicant skill-level object).
			 */			
			break;
		    }
		}
	    }
	    /* set the already created match object's attributes and
	     * save it in the database
	     */
	    match.setApplicantID(appID);
	    match.setJobID(job.getID());
	    match.setRequirementScore(result);
	    match.setMetRequirements(metRequirements);
	    match.setDateOfMatch(new Date());
	    matchesDAO.update(match);
	}
    }
    
    

    /**
     * Compares the job's skill-level objects with all applicants'
     * skill-level objects. What happens here is the exact same as for
     * the compareApplicantWithJobs method which is described in
     * detail. Confer this method for a deeper understanding of what
     * this method does.
     *
     * @param appList a <code>List</code> value
     * @param jobSkillLevels a <code>List</code> value
     * @param jobID an <code>int</code> value
     * @exception RemoteException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    private static void compareJobWithApplicants(List appList, List jobSkillLevels, int jobID) throws RemoteException, DAOException, RMIException{
	ApplicantDAO applicantDAO = new ApplicantDAO();
	MatchesDAO matchesDAO = new MatchesDAO();
	Applicant applicant = new Applicant();	
	SkillLevel skillLevelJob;
	SkillLevel skillLevelApplicant;
	int result = 0;
	List contAppSkillLevels = new ArrayList();
	List metRequirements = new ArrayList();	
	Match match;	
	MatchInformation matchInfo = new MatchInformation();
	for (int i = 0; i < appList.size(); i++){
	    /* at this point, we know that for each applicant in the
	     * appList, a match object will be created. Therefore, we
	     * make a new match object here so that later on we have
	     * access to its id value when we create a matchInfo object
	     */
	    match = matchesDAO.add();	    
	    applicant = (Applicant) appList.get(i);
	    /* we want the applicant's skill-level objects from his id
	     * for calculation of the req. score
	     */
	    contAppSkillLevels = applicantDAO.getSkillLevels(applicant.getID());
	    /* reset the result value to 0 when the next of the
	     * applicant's skill-level objects gets compared, otherwise
	     * the value would be accumulated and yield wrong values
	     */
	    result = 0;	    
	    //for each of the applicant's skill-level objects...
	    //for each of the job's skill-level objects...
	    for (int j = 0; j < jobSkillLevels.size(); j++){
		skillLevelJob = (SkillLevel) jobSkillLevels.get(j);
		/* ...run through all the skill-level objects in the
		 * applicant to check if the qualification attribute
		 * equals the one in the job's skill-level object
		 */
		for (int k = 0; k < contAppSkillLevels.size(); k++){
		    skillLevelApplicant = (SkillLevel) contAppSkillLevels.get(k);		    
		    if ((skillLevelJob.getQualification()).equals(skillLevelApplicant.getQualification())){
			result += calcReqScore(skillLevelJob, skillLevelApplicant);
			/* create a new matchInfo object that holds
			 * information on which qualification was in
			 * question, what level the job had set it to
			 * and what level the applicant had set it
			 * to. Further, it holds information on which
			 * match object it is related to
			 */
			matchInfo.setMatchID(match.getID());			
			matchInfo.setLevelJobSkillLevel(skillLevelJob.getLevel());			
			matchInfo.setLevelApplicantSkillLevel(skillLevelApplicant.getLevel());
			matchInfo.setQualificationName((skillLevelApplicant.getQualification()).getName());			
			metRequirements.add(matchInfo);
			/* we know that when the if-statement has been
			 * true once, it does NOT make sense to run
			 * the inner for-loop through once again
			 * because an applicant can only have one
			 * qualification of a certain type (i.e.,
			 * Java), so the algorithm will not find any
			 * other qualifications of the same
			 * type. Hence, we might as well break here
			 * and force the second-most inner for-loop to
			 * increment (which means that we proceed to
			 * the next job skill-level object).
			 */			
			break;
		    }
		}
	    }
	    /* set the already created match object's attributes and
	     * save it in the database
	     */
	    match.setApplicantID(applicant.getID());
	    match.setJobID(jobID);
	    match.setRequirementScore(result);
	    match.setMetRequirements(metRequirements);
	    match.setDateOfMatch(new Date());
	    matchesDAO.update(match);
	}
    }


    
    /**
     * Calculates the requirement score from a job's skill level and
     * an applicant's skill level.
     *
     * @param skillLevelJob a <code>SkillLevel</code> value
     * @param skillLevelApplicant a <code>SkillLevel</code> value
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    private static int calcReqScore(SkillLevel skillLevelJob, SkillLevel skillLevelApplicant) throws RMIException{
	int resultReqScore = 0;
	int levelJob = skillLevelJob.getLevel();
	int levelApplicant = skillLevelApplicant.getLevel();	
	if (levelJob > levelApplicant){
	    resultReqScore = levelApplicant;
	}
	else if (levelJob <= levelApplicant){
	    resultReqScore = levelJob + 1; 
	}//1 is a bonus for "reaching" the requirement 
	return resultReqScore;
    }
}
