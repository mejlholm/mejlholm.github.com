package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.dataaccess.*;
import java.rmi.RemoteException;
import dk.auc.cs.whiner.function.Notify;
import java.util.Date;

import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.rmi.RMIException;

import java.rmi.*;
import java.rmi.server.*;

/**
 * The Application class contains id attributes related to the
 * applicant and the job and Date attributes for registering the time
 * of different events. The class also has access objects for the
 * application objects in the database. Among the methods, this class
 * has a save method, that saves the changes made to the object in
 * question as well as a reject method which sets the application's
 * status to "rejected" and notifies the related applicant about the
 * rejection.
 * @author <a href="mailto:carlsen@pico.cs.auc.dk">Jeppe Carlsen</a>
 * @author <a href="mailto:bennett@pico.cs.auc.dk">Anders Bennett</a>
 * @version 1.0
 */


public class Application extends UnicastRemoteObject implements ApplicationI{
    private int id = 0;
    private int jobID = 0;
    private int applicantID = 0;
    private String status = "";
    private String bodyText = "";
    private Date dateOfCreation = new Date(0);
    private Date dateOfSubmission = new Date(0);
    private Date dateOfRejection = new Date(0);

    //DAO objects
    private ApplicationDAO applicationDAO;
    private ApplicantDAO applicantDAO;
    private JobDAO jobDAO;


    
    /**
     * Initializes the DAO objects.
     *
     * @exception DAOException if a dataaccess error occurs
     * @exception RemoteException if an error occurs
     */
    public Application() throws DAOException, RemoteException{
	applicationDAO = new ApplicationDAO();
	applicantDAO = new ApplicantDAO();
	jobDAO = new JobDAO();
    }
    
    /**
     * Tests the equality between two object of this class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj){
	if (this == obj) return true;
	if (!(obj instanceof Application)) return false;
	Application objApp = (Application) obj;
	boolean result = false;
	try{
	    result = 
		(this.id == objApp.getID()) &&
		(this.jobID == objApp.getJobID()) &&
		(this.applicantID == objApp.getApplicantID()) &&
		((this.status).equals(objApp.getStatus())) &&
		((this.bodyText).equals(objApp.getBodyText()));
		//((this.dateOfCreation).equals(objApp.getDateOfCreation())) &&
		//((this.dateOfSubmission).equals(objApp.getDateOfSubmission())) &&
		//((this.dateOfRejection).equals(objApp.getDateOfRejection())) ;
	}catch (RMIException r){
	    // necessary to keep the compiler from whining
	}
	return result;
    }


    /**
     * Returns the requirement score to the GUI.
     *
     * @return an <code>int</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public int findRequirementScore() throws DAOException, RMIException{
	return applicationDAO.getRequirementScore(this.applicantID, this.jobID);
    }

    /**
     * Returns an applicant object from the applicant's id value.
     *
     * @param applicantID an <code>int</code> value
     * @return an <code>Applicant</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public ApplicantI getApplicant(int applicantID) throws DAOException, RMIException{
	return ((ApplicantI)applicantDAO.getApplicant(applicantID));
    }

    /**
     * Returns a job object from the jobID value.
     *
     * @param jobID an <code>int</code> value
     * @return a <code>Job</code> value
     */
    public JobI getJob(int jobID) throws DAOException, RMIException{
	return ((JobI)jobDAO.getJob(jobID));
    }


    /**
     * Returns an applicant's login name from his id value.
     *
     * @param applicantID an <code>int</code> value
     * @return a <code>String</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public String getApplicantName(int applicantID) throws DAOException, RMIException{
	Applicant app = applicantDAO.getApplicant(applicantID);
	String userName = app.getLoginName();
	return userName;
    }



    /**
     * Updates the application in the database.
     * @exception DAOException if a dataaccess error occurs
     */
    public void save() throws DAOException, RMIException{
	applicationDAO.update(this);
    }


    /**
     * Enables the applicant to cancel his application in question.
     *
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void cancelApplication() throws DAOException, RMIException{
	setStatus("cancelled");
	applicationDAO.update(this);
    }


    /**
     * Submits the application in question by setting the status to
     * submitted and updates the application in the database.
     *
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     * @exception Exception if an error occurs
     */
    public void submitApplication() throws DAOException, RMIException, Exception{
	Job job = jobDAO.getJob(jobID);
	if(!((job.getStatus().equals("announced")))){
	    throw new Exception("The job has been closed!");
	}
	setStatus("submitted");
	dateOfSubmission = new Date();
	applicationDAO.update(this);
    }


    /**
     * Sets the application's status to rejected and sends a notification
     * to the related applicant.
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void reject() throws DAOException, RMIException{
	if(status.equals("submitted")){
	    status = "rejected";
	    dateOfRejection = new Date();
	    Notify.makeNotification(applicantID, jobID, "Application rejected");
	    save();
	}
    }
        
    /*SET AND GET METHODS
      -------------------*/


    /**
     * Gets the value of id
     *
     * @return the value of id
     * @exception RMIException if an error occurs
     */
    public int getID() throws RMIException{
	return this.id;
    }

    /**
     * Sets the value of id
     *
     * @param argID Value to assign to this.id
     * @exception RMIException if an error occurs
     */
    public void setID(int argID) throws RMIException{
	this.id = argID;
    }

    /**
     * Gets the value of jobID
     *
     * @return the value of jobID
     * @exception RMIException if an error occurs
     */
    public int getJobID() throws RMIException{
	return this.jobID;
    }

    /**
     * Sets the value of jobID
     *
     * @param argJobID Value to assign to this.jobID
     * @exception RMIException if an error occurs
     */
    public void setJobID(int argJobID) throws RMIException{
	this.jobID = argJobID;
    }

    /**
     * Gets the value of applicantID
     *
     * @return the value of applicantID
     * @exception RMIException if an error occurs
     */
    public int getApplicantID() throws RMIException{
	return this.applicantID;
    }

    /**
     * Sets the value of applicantID
     *
     * @param argApplicantID Value to assign to this.applicantID
     * @exception RMIException if an error occurs
     */
    public void setApplicantID(int argApplicantID) throws RMIException{
	this.applicantID = argApplicantID;
    }

    /**
     * Gets the value of status
     *
     * @return the value of status
     * @exception RMIException if an error occurs
     */
    public String getStatus() throws RMIException{
	return this.status;
    }

    /**
     * Sets the value of status
     *
     * @param argStatus Value to assign to this.status
     * @exception RMIException if an error occurs
     */
    public void setStatus(String argStatus) throws RMIException{
	this.status = argStatus;
    }

    /**
     * Gets the value of bodyText
     *
     * @return the value of bodyText
     * @exception RMIException if an error occurs
     */
    public String getBodyText() throws RMIException{
	return this.bodyText;
    }

    /**
     * Sets the value of bodyText
     *
     * @param argBodyText Value to assign to this.bodyText
     * @exception RMIException if an error occurs
     */
    public void setBodyText(String argBodyText) throws RMIException{
	this.bodyText = argBodyText;
    }

    /**
     * Sets the value of dateOfCreation
     *
     * @param argDate Value to assign to this.dateOfCreation
     * @exception RMIException if an error occurs
     */
    public void setDateOfCreation(Date argDate) throws RMIException{
	this.dateOfCreation = argDate;
    }

    /**
     * Gets the value of dateOfCreation
     *
     * @return the value of dateOfCreation
     * @exception RMIException if an error occurs
     */
    public Date getDateOfCreation() throws RMIException{
	return this.dateOfCreation;
    }

    /**
     * Gets the value of dateOfSubmission
     *
     * @return the value of dateOfSubmission
     * @exception RMIException if an error occurs
     */
    public Date getDateOfSubmission() throws RMIException{
	return this.dateOfSubmission;
    }

    /**
     * Sets the value of dateOfSubmission
     *
     * @param argDateOfSubmission Value to assign to this.dateOfSubmission
     * @exception RMIException if an error occurs
     */
    public void setDateOfSubmission(Date argDateOfSubmission) throws RMIException{
	this.dateOfSubmission = argDateOfSubmission;
    }

    /**
     * Gets the value of dateOfRejection
     *
     * @return the value of dateOfRejection
     * @exception RMIException if an error occurs
     */
    public Date getDateOfRejection() throws RMIException{
	return this.dateOfRejection;
    }

    /**
     * Sets the value of dateOfRejection
     *
     * @param argDateOfRejection Value to assign to this.dateOfRejection
     * @exception RMIException if an error occurs
     */
    public void setDateOfRejection(Date argDateOfRejection) throws RMIException{
	this.dateOfRejection = argDateOfRejection;
    }
}
