package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.dataaccess.*;
import java.rmi.*;
import java.rmi.server.*;

import java.util.Date;


/**
 * The "Notification" class has no methods or DAO objects. Instances of this
 * class only provide the applicant with messages based on different types of
 * information.
 * @author <a href="mailto:carlsen@pico.cs.auc.dk">Jeppe Carlsen</a>
 * @author <a href="mailto:bennett@pico.cs.auc.dk">Anders Bennett</a>
 * @version 1.0
 */
public class Notification extends UnicastRemoteObject implements NotificationI{
    private int id = 0;
    private int applicantID = 0;
    private int jobID = 0;
    private String notificationType = "";
    private String title = "";
    private String bodyText = "";
    private Date dateOfDispatch = new Date(0);

    //DAO objects
    JobDAO jobDAO;
    
    /**
     * Creates an "MatchList" without getting the list of matches from
     * the database.
     *
     * @exception RemoteException if an error occurs
     * @exception DAOException if an error occurs
     */
    public Notification() throws RemoteException, DAOException{
	jobDAO = new JobDAO();    
    }
    
    /**
     * Tests for equality between two objects of the "Notification" class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj) {
	if ( this == obj ) return true;
	if ( !(obj instanceof Notification) ) return false;
	Notification objNot = (Notification) obj;
	boolean result = false;
	try{
	    result = 
		(this.id == objNot.getID()) &&
		(this.applicantID == objNot.getApplicantID()) &&
		(this.jobID == objNot.getJobID()) &&
		((this.notificationType).equals(objNot.getNotificationType())) &
		((this.title).equals(objNot.getTitle())) &&
		((this.bodyText).equals(objNot.getBodyText()));
	    //		((this.dateOfDispatch).equals(objNot.getDateOfDispatch())) ;		
	} catch(RMIException e){
	    //necessary to keep the compiler from whining
	}
	return result;
    }
    
    
    /**
     * Returns a job's title to the GUI.
     *
     * @return a <code>String</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public String getJobName() throws DAOException, RMIException{
	Job job;
	job = jobDAO.getJob(jobID);
	return job.getTitle();
    }


    /* SET AND GET METHODS
       -------------------*/

    /**
     * Gets the value of id
     *
     * @return the value of id
     * @exception RMIException if an error occurs
     */
    public int getID()  throws RMIException{
	return this.id;
    }

    /**
     * Sets the value of id
     *
     * @param argID Value to assign to this.id
     * @exception RMIException if an error occurs
     */
    public void setID(int argID) throws RMIException{
	this.id = argID;
    }

    /**
     * Gets the value of applicantID
     *
     * @return the value of applicantID
     * @exception RMIException if an error occurs
     */
    public int getApplicantID()  throws RMIException{
	return this.applicantID;
    }

    /**
     * Sets the value of applicantID
     *
     * @param argApplicantID Value to assign to this.applicantID
     * @exception RMIException if an error occurs
     */
    public void setApplicantID(int argApplicantID) throws RMIException{
	this.applicantID = argApplicantID;
    }

    /**
     * Gets the value of jobID
     *
     * @return the value of jobID
     * @exception RMIException if an error occurs
     */
    public int getJobID()  throws RMIException{
	return this.jobID;
    }

    /**
     * Sets the value of jobID
     *
     * @param argJobID Value to assign to this.jobID
     * @exception RMIException if an error occurs
     */
    public void setJobID(int argJobID) throws RMIException{
	this.jobID = argJobID;
    }

    /**
     * Gets the value of notificationType
     *
     * @return the value of notificationType
     * @exception RMIException if an error occurs
     */
    public String getNotificationType()  throws RMIException{
	return this.notificationType;
    }

    /**
     * Sets the value of notificationType
     *
     * @param argNotificationType Value to assign to this.notificationType
     * @exception RMIException if an error occurs
     */
    public void setNotificationType(String argNotificationType) throws RMIException{
	this.notificationType = argNotificationType;
    }

    
    /**
     * Gets the value of title
     *
     * @return the value of title
     * @exception RMIException if an error occurs
     */
    public String getTitle()  throws RMIException{
	return this.title;
    }

    /**
     * Sets the value of title
     *
     * @param argTitle Value to assign to this.title
     * @exception RMIException if an error occurs
     */
    public void setTitle(String argTitle) throws RMIException{
	this.title = argTitle;
    }

    
    /**
     * Gets the value of bodyText
     *
     * @return the value of bodyText
     * @exception RMIException if an error occurs
     */
    public String getBodyText() throws RMIException{
	return this.bodyText;
    }

    /**
     * Sets the value of bodyText
     *
     * @param argBodyText Value to assign to this.bodyText
     * @exception RMIException if an error occurs
     */
    public void setBodyText(String argBodyText) throws RMIException{
	this.bodyText = argBodyText;
    }

    /**
     * Gets the value of dateOfDispatch
     *
     * @return the value of dateOfDispatch
     * @exception RMIException if an error occurs
     */
    public Date getDateOfDispatch() throws RMIException{
	return this.dateOfDispatch;
    }
    
    /**
     * Sets the value of dateOfDispatch
     *
     * @param argDateOfDispatch Value to assign to this.dateOfDispatch
     * @exception RMIException if an error occurs
     */
    public void setDateOfDispatch(Date argDateOfDispatch) throws RMIException{
	    this.dateOfDispatch = argDateOfDispatch;
	}
}
    
