package dk.auc.cs.whiner.model;

import java.rmi.*;
import java.rmi.server.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;


public class SkillLevel extends UnicastRemoteObject implements SkillLevelI{
    private int id = 0;       //kan enten vaere applicant.id eller job.id 
    private Qualification qualification;
    private int level = 0;
    
    public SkillLevel() throws DAOException, RemoteException{
	qualification = new Qualification() ;
    }

    /**
     * Tests for equality between two objects of the "Qualification" class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     * @exception RMIException if an error occurs
     */
    public boolean equals(Object obj){
	if (this == obj) 
	    return true;
	if (!(obj instanceof SkillLevel)) 
	    return false;
	SkillLevel objSkillLevel = (SkillLevel) obj;
	boolean result = false;
	try {
	    result = 
		(this.id == objSkillLevel.getID()) &&
		((this.qualification).equals(objSkillLevel.getQualification())) &&
		(this.level == objSkillLevel.getLevel()) ;
	} catch(RMIException e){
	    //do stuff!
	}
	return result;
    }


    /*SET AND GET METHODS
      -------------------*/

    
    /**
     * Gets the value of id
     *
     * @return the value of id
     */
    public int getID()throws RMIException{
	return this.id;
    }
    

    /**
     * Sets the value of id
     *
     * @param argID Value to assign to this.id
     */
    public void setID(int argID)throws RMIException{
	this.id = argID;
    }


    /**
     * Gets the value of qualification
     *
     * @return the value of qualification
     */
    public QualificationI getQualification()  throws RMIException{
	return (QualificationI)this.qualification;
    }

    /**
     * Sets the value of qualification
     *
     * @param argQualification Value to assign to this.qualification
     */
    public void setQualification(QualificationI argQualification) throws RMIException{
	this.qualification = (Qualification)argQualification;
    }

    /**
     * Gets the value of level
     *
     * @return the value of level
     */
    public int getLevel()  throws RMIException{
	return this.level;
    }

    /**
     * Sets the value of level
     *
     * @param argLevel Value to assign to this.level
     */
    public void setLevel(int argLevel) throws RMIException{
	this.level = argLevel;
    }
}
