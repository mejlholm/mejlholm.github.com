package dk.auc.cs.whiner.model;

import java.util.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.rmi.*;
import java.rmi.*;
import dk.auc.cs.whiner.dataaccess.*;

public class TestCV extends TestCase{

    public void testEquals() throws RemoteException, DAOException{
	CV cv1 = new CV();
	CV cv2 = new CV();
	
	assertTrue("The two CVs should be equal", cv1.equals(cv2));
	cv2.setApplicantID(60);
	assertFalse("The two CVs should not be equal", cv1.equals(cv2));
    }

    public void testAddQualification() throws RemoteException, DAOException{
	CV cv1 = new CV();
	cv1.setApplicantID(1);

	QualificationDAO qualDAO = new QualificationDAO();
	Qualification qual1 = qualDAO.add();
	qual1.setName("Java1");
	qualDAO.update(qual1);
	Qualification qual2 = qualDAO.add();
	qual2.setName("Java2");
	qualDAO.update(qual2);

	cv1.initializeGlobalQualificationList();
	cv1.initializeQualificationList();

	cv1.addQualification(qual1.getID(), 3);
	cv1.saveQualifications();
	cv1.initializeQualificationList();
	assertEquals("Should contain one qualification", 1, cv1.getApplicantQualificationListLength());
	cv1.addQualification(qual2.getID(), 5);
	cv1.saveQualifications();
	cv1.initializeQualificationList();
	assertEquals("Should contain two qualifications", 2, cv1.getApplicantQualificationListLength());

	int skillNo = 0;
	for(skillNo = 0; (skillNo < 2) && (!(((SkillLevel) cv1.getQualification(skillNo)).getLevel() == 3)); skillNo++);
	SkillLevel skill1 = (SkillLevel) cv1.getQualification(skillNo);
	for(skillNo = 0; (skillNo < 2) && (!(((SkillLevel) cv1.getQualification(skillNo)).getLevel() == 5)); skillNo++);
	SkillLevel skill2 = (SkillLevel) cv1.getQualification(skillNo);

	SkillLevel skill1Expected = new SkillLevel();
	skill1Expected.setQualification(qual1);
	skill1Expected.setLevel(3);
	skill1Expected.setID(cv1.getApplicantID());
	
	SkillLevel skill2Expected = new SkillLevel();
	skill2Expected.setQualification(qual2);
	skill2Expected.setLevel(5);
	skill2Expected.setID(cv1.getApplicantID());

	


	assertEquals("ID", skill1Expected.getID(), skill1.getID());
	assertEquals("LEVEL", skill1Expected.getLevel(), skill1.getLevel());
	assertTrue("Qual!!", skill1Expected.getQualification().equals(skill1.getQualification()));


	assertTrue("Wrong skill-level object added", skill1Expected.equals(skill1));
	assertTrue("Wrong skill-level object added", skill2Expected.equals(skill2));

	//cleanup
	qualDAO.delete(qual1.getID());
	qualDAO.delete(qual2.getID());
	ApplicantDAO appDAO = new ApplicantDAO();
	appDAO.deleteSkillLevel(skill1Expected);
	appDAO.deleteSkillLevel(skill2Expected);
    }
}
