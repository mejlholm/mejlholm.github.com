package dk.auc.cs.whiner.model;

import java.util.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.rmi.*;
import java.rmi.*;
import dk.auc.cs.whiner.dataaccess.*;

public class TestHeadhunter extends TestCase{


    public void testEquals() throws RMIException, RemoteException, DAOException{
	HeadhunterDAO headhunterDAO = new HeadhunterDAO();
	Headhunter headhunter1 = headhunterDAO.add();
	headhunterDAO.update(headhunter1);
	
	Headhunter headhunter2 = headhunterDAO.getHeadhunter(headhunter1.getID());

      	assertTrue("Two headhunters with same attributes are expected to be equal", headhunter1.equals(headhunter2));
	headhunter1.setLoginName("mamaosama");
	assertFalse("Two headhunters with different attributes are expected not to be equal", headhunter1.equals(headhunter2));
	
	//clean up
	headhunterDAO.delete(headhunter1.getID());
	
    }
    
    public void testGetProject() throws RMIException, DAOException, RemoteException{	
	ProjectDAO projectDAO = new ProjectDAO();
	HeadhunterDAO headhunterDAO = new HeadhunterDAO();
	Headhunter headhunter = headhunterDAO.add();
	
	
	Project project1 = projectDAO.add();
	project1.setHeadhunterID(headhunter.getID());
	projectDAO.update(project1);
	
	headhunter.initializeProjectList();
	assertEquals("Should only have one project", 1, headhunter.getProjectListLength());
	
	//clean up
	headhunterDAO.delete(headhunter.getID());
	projectDAO.delete(project1.getID());

    }


    public void testGetProjectListLength()throws RemoteException, DAOException{
	ProjectDAO projectDAO = new ProjectDAO();
	HeadhunterDAO headhunterDAO = new HeadhunterDAO();
	Headhunter headhunter = headhunterDAO.add();
	
 	Project project1 = projectDAO.add();
	project1.setHeadhunterID(headhunter.getID());
	projectDAO.update(project1);
 	Project project2 = projectDAO.add();
	project2.setHeadhunterID(headhunter.getID());
	projectDAO.update(project2);

	headhunter.initializeProjectList();
	assertEquals("Should only have one project", 2, headhunter.getProjectListLength());

	//clean up
	headhunterDAO.delete(headhunter.getID());
	projectDAO.delete(project1.getID());
	projectDAO.delete(project2.getID());

    }

    public void testCreateProject() throws DAOException, RemoteException{
	ProjectDAO projectDAO = new ProjectDAO();
	HeadhunterDAO headhunterDAO = new HeadhunterDAO();
	Headhunter headhunter = headhunterDAO.add();

	headhunter.createProject();


 	Project project2 = new Project();
	project2.setID(0);
	project2.setHeadhunterID(headhunter.getID());
	project2.setStatus("filled");
	project2.setTitle("New Project");
	project2.setDescription("Enter description here");
	
	
	headhunter.initializeProjectList();
	
	assertTrue("Projects should be identical", (headhunter.getProject(0)).equals(project2));
	
	//clean up
	headhunterDAO.delete(headhunter.getID());
	projectDAO.delete(0);
    }

    public void testDeleteProject() throws DAOException, RemoteException{
	ProjectDAO projectDAO = new ProjectDAO();
	JobDAO jobDAO = new JobDAO();
	HeadhunterDAO headhunterDAO = new HeadhunterDAO();
	Headhunter headhunter = headhunterDAO.add();
	
 	Project project1 = projectDAO.add();
	project1.setHeadhunterID(headhunter.getID());
	projectDAO.update(project1);

	Job job1 = jobDAO.add();
	job1.setProjectID(project1.getID());
	job1.setStatus("announced");
	jobDAO.update(job1);
	Job job2 = jobDAO.add();
	job2.setProjectID(project1.getID());
	job2.setStatus("occupied");
	jobDAO.update(job2);

	headhunter.initializeProjectList();
	try{
	    headhunter.deleteProject(0);
	    fail("A job is announced. Exception expected");
	} catch (AnnouncedJobException e){
	    //passed!
	}
	
	int jobNo = 0;
	for(jobNo = 0; !(((Job)headhunter.getProject(0).getJob(jobNo)).getID() == job1.getID()); jobNo++);
	Job job = (Job) headhunter.getProject(0).getJob(jobNo);
	job.setStatus("not announced");
	job.save();
	try{
	    headhunter.deleteProject(0);
	    //passed!
	} catch (AnnouncedJobException e){
	    fail("Does not contain any announced jobs. Exception NOT expected!");
	}
	
	assertEquals("Headhunters projectList should be empty", 0, headhunter.getProjectListLength());

	//clean up
	headhunterDAO.delete(headhunter.getID());
    }


    public void testDeleteAllProjects() throws AnnouncedJobException, RMIException, DAOException, CloseException, RemoteException{
	ProjectDAO projectDAO = new ProjectDAO();
	JobDAO jobDAO = new JobDAO();
	HeadhunterDAO headhunterDAO = new HeadhunterDAO();
	Headhunter headhunter = headhunterDAO.add();
	
 	Project project1 = projectDAO.add();
	project1.setHeadhunterID(headhunter.getID());
	projectDAO.update(project1);

	Project project2 = projectDAO.add();
	project2.setHeadhunterID(headhunter.getID());
	projectDAO.update(project2);

	Job job1 = jobDAO.add();
	job1.setProjectID(project1.getID());
	job1.setStatus("announced");
	jobDAO.update(job1);
	Job job2 = jobDAO.add();
	job2.setProjectID(project1.getID());
	job2.setStatus("occupied");
	jobDAO.update(job2);


	headhunter.initializeProjectList();

	headhunter.deleteAllProjects();
		
	assertEquals("ProjectList length should be 0", 0, headhunter.getProjectListLength());

	//clean up
	
	headhunterDAO.delete(headhunter.getID());
    }


}
