package dk.auc.cs.whiner.model;

import java.util.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.rmi.*;
import java.rmi.*;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.function.*;

public class TestMatch extends TestCase{

    public void testEquals() throws RemoteException, DAOException{

	Match match1 = new Match();

	Match match2 = new Match();
	
	
	assertTrue("Two matches with same attributes are expected to be equal", match1.equals(match2));
	match1.setRequirementScore(4);
	assertFalse("Two skillLevels with different attributes are expected not to be equal", match1.equals(match2));
    }


    public void testGetJob() throws DAOException, RemoteException{
	JobDAO jobDAO = new JobDAO();
	MatchesDAO matchesDAO = new MatchesDAO();

	Job job1 = jobDAO.add();
	job1.setStatus("announced");
	jobDAO.update(job1);

	Match match = matchesDAO.add();
	match.setJobID(job1.getID());
	
	Job job2 = (Job)match.getJob();

	Job job3 = new Job();
	job3.setID(job1.getID());
	job3.setStatus("announced");

	assertTrue("job1 and job3 should be identical", job3.equals(job1));

	job3.setStatus("not announced");

	assertFalse("job1 and job3 should not be identical", job3.equals(job1));

	//clean up
	jobDAO.delete(job1.getID());
	matchesDAO.delete(match.getID());



    }
}	
