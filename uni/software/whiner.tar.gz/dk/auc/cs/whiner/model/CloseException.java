package dk.auc.cs.whiner.model;

/* Simple exception class - basically just renaming... */

public class CloseException extends Exception {
    
    private int type = 0;

    public CloseException(){
	super("Unknown exception");
    }

    public CloseException(String msg){
	super(msg);
    }

    public CloseException(String msg, Throwable cause){
	super(msg, cause);
    }

}
