package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.function.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.rmi.RMIException;

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;

/**
 * The "CV" class contains information about an applicant.
 *
 * @author <a href="mailto:bennett@flatboy"></a>
 * @version 1.0
 */
public class CV extends UnicastRemoteObject implements CVI{
    private int applicantID = 0;
    private Date dateOfBirth = new Date(0);
    private String sex = "";
    private String maritalStatus = "";
    private String education = "";
    private String workingExperience = "";
    private String reEducation = "";
    private String languageSkills = "";
    private String otherITKnowledge = "";
    private String spareTimeInterests = "";
    private ApplicantQualificationList qualifications;
    private GlobalQualificationList globalQualifications;

    //DAO objects
    private ApplicantDAO applicantDAO;
    private QualificationDAO qualificationDAO;


    /**
     * Initializes DAO objects
     *
     * @exception DAOException if a dataaccess error occurs
     * @exception RemoteException if an error occurs
     */
    public CV() throws DAOException, RemoteException{
	    applicantDAO = new ApplicantDAO();
	    qualificationDAO = new QualificationDAO();
	    qualifications = new ApplicantQualificationList();
    }


    /**
     * Tests for equality between two objects of the "CV" class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj){
	if(this == obj) 
	    return true;
	if(!(obj instanceof CV))
	    return false;
	CV objCV = (CV) obj;
	boolean result = false;
	try {
	    result = 
		((this.applicantID == objCV.getApplicantID())) &&
		((this.sex).equals(objCV.getSex())) &&
		((this.maritalStatus).equals(objCV.getMaritalStatus())) &
		((this.education).equals(objCV.getEducation())) &&
		((this.workingExperience).equals(objCV.getWorkingExperience())) &&
		((this.reEducation).equals(objCV.getReEducation())) &&		
		((this.languageSkills).equals(objCV.getLanguageSkills())) &&		
		((this.otherITKnowledge).equals(objCV.getOtherITKnowledge())) &&		
		((this.spareTimeInterests).equals(objCV.getSpareTimeInterests())) &&		
		((this.qualifications).equals(objCV.getQualifications())) ;		
	}    
        catch(RMIException e){
	    // necessary to keep the compiler from whining
	}
	return result;
    }

    /**
     * Initializes the cv's global qualification list.
     *
     * @exception RMIException if an error occurs
     */
    public void initializeGlobalQualificationList()throws RMIException{
	try{
	    globalQualifications = new GlobalQualificationList();
	}
	catch(Exception e){
	    //do stuff
	}
    }

    /**
     * Initializes the cv's local qualification list.
     *
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public void initializeQualificationList()throws RMIException, DAOException{
	qualifications = new ApplicantQualificationList(applicantID);
    }
    
    /**
     * Gets a SkillLevel object from the applicants list of qualificaitons.
     *
     * @param qualNo an <code>int</code> value
     * @return a <code>SkillLevel</code> value
     * @exception RMIException if an error occurs
     */
    public SkillLevelI getQualification(int qualNo) throws RMIException{
	return (SkillLevelI)qualifications.getSkillLevel(qualNo);
    }


    /**
     * Returns the selected global qualification object to the client.
     *
     * @param globalQualNo an <code>int</code> value
     * @return a <code>Qualification</code> value
     * @exception RMIException if an error occurs
     */
    public QualificationI getGlobalQualification(int globalQualNo) throws RMIException{
	return (QualificationI)globalQualifications.getQualification(globalQualNo);
    }

    /**
     * Returns the length of the list of qualification at the CV to the client.
     *
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public int getApplicantQualificationListLength()throws RMIException{
	return qualifications.getLength();
    }


    /**
     * Returns the length of the global qualification list.
     *
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public int getGlobalQualificationListLength() throws RMIException{
	return globalQualifications.getLength();
    }

    
    /**
     * Makes the containers with local and global qualifications ready
     * for garbage collection.
     *
     * @exception RMIException if an error occurs
     */
    public void deselectCV()throws RMIException{
	qualifications = null;
	globalQualifications = null;
    }


    
    /**
     * Adds a qualification from the global qualification list to the cv's local
     * qualification list along with a level of experience in that qualification.
     *
     * @param globalQualificationNo an <code>int</code> value
     * @param level an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public void addQualification(int globalQualificationNo, int level)throws RMIException{
	Qualification qual = (Qualification)globalQualifications.getQualification(globalQualificationNo);
	qualifications.addQualification(qual, level);
    }

    /**
     * Removes a qualification (skill-level object) from the cv's local
     * qualification list.
     *
     * @param qualificationNo an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public void removeQualification(int qualificationNo)throws RMIException{
	qualifications.removeQualification(qualificationNo);
    }

    /**
     * Updates the cv's attributes in the database.
     *
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public void save()throws RMIException, DAOException{
	applicantDAO.update(this);
    }

    /**
     * Invokes the save method in the applicant-qualification list
     * which updates the qualification list in the database.
     *
     * @exception DAOException if a dataaccess error occurs
     * @exception RemoteException if an error occurs
     */
    public void saveQualifications()throws RMIException, DAOException, RemoteException{
	qualifications.save();
	PerformMatch.matchApplicant(applicantID);    
    }



    /*SET AND GET METHODS
      -------------------*/

    /**
     * Gets the value of applicantID
     *
     * @return the value of applicantID
     * @exception RMIException if an error occurs
     */
    public int getApplicantID()  throws RMIException{
	return this.applicantID;
    }

    /**
     * Sets the value of applicantID
     *
     * @param argApplicantID Value to assign to this.applicantID
     * @exception RMIException if an error occurs
     */
    public void setApplicantID(int argApplicantID) throws RMIException{
	this.applicantID = argApplicantID;
    }

    /**
     * Gets the value of dateOfBirth
     *
     * @return the value of dateOfBirth
     * @exception RMIException if an error occurs
     */
    public Date getDateOfBirth()  throws RMIException{
	return this.dateOfBirth;
    }

    /**
     * Sets the value of dateOfBirth
     *
     * @param argDateOfBirth Value to assign to this.dateOfBirth
     * @exception RMIException if an error occurs
     */
    public void setDateOfBirth(Date argDateOfBirth) throws RMIException{
	this.dateOfBirth = argDateOfBirth;
    }

    /**
     * Gets the value of sex
     *
     * @return the value of sex
     * @exception RMIException if an error occurs
     */
    public String getSex()  throws RMIException{
	return this.sex;
    }

    /**
     * Sets the value of sex
     *
     * @param argSex Value to assign to this.sex
     * @exception RMIException if an error occurs
     */
    public void setSex(String argSex) throws RMIException{
	this.sex = argSex;
    }

    /**
     * Gets the value of maritalStatus
     *
     * @return the value of maritalStatus
     * @exception RMIException if an error occurs
     */
    public String getMaritalStatus()  throws RMIException{
	return this.maritalStatus;
    }

    /**
     * Sets the value of maritalStatus
     *
     * @param argMaritalStatus Value to assign to this.maritalStatus
     * @exception RMIException if an error occurs
     */
    public void setMaritalStatus(String argMaritalStatus) throws RMIException{
	this.maritalStatus = argMaritalStatus;
    }

    /**
     * Gets the value of education
     *
     * @return the value of education
     * @exception RMIException if an error occurs
     */
    public String getEducation()  throws RMIException{
	return this.education;
    }

    /**
     * Sets the value of education
     *
     * @param argEducation Value to assign to this.education
     * @exception RMIException if an error occurs
     */
    public void setEducation(String argEducation) throws RMIException{
	this.education = argEducation;
    }

    /**
     * Gets the value of workingExperience
     *
     * @return the value of workingExperience
     * @exception RMIException if an error occurs
     */
    public String getWorkingExperience()  throws RMIException{
	return this.workingExperience;
    }

    /**
     * Sets the value of workingExperience
     *
     * @param argWorkingExperience Value to assign to this.workingExperience
     * @exception RMIException if an error occurs
     */
    public void setWorkingExperience(String argWorkingExperience) throws RMIException{
	this.workingExperience = argWorkingExperience;
    }

    /**
     * Gets the value of reEducation
     *
     * @return the value of reEducation
     * @exception RMIException if an error occurs
     */
    public String getReEducation()  throws RMIException{
	return this.reEducation;
    }

    /**
     * Sets the value of reEducation
     *
     * @param argReEducation Value to assign to this.reEducation
     * @exception RMIException if an error occurs
     */
    public void setReEducation(String argReEducation) throws RMIException{
	this.reEducation = argReEducation;
    }

    /**
     * Gets the value of languageSkills
     *
     * @return the value of languageSkills
     * @exception RMIException if an error occurs
     */
    public String getLanguageSkills()  throws RMIException{
	return this.languageSkills;
    }

    /**
     * Sets the value of languageSkills
     *
     * @param argLanguageSkills Value to assign to this.languageSkills
     * @exception RMIException if an error occurs
     */
    public void setLanguageSkills(String argLanguageSkills) throws RMIException{
	this.languageSkills = argLanguageSkills;
    }

    /**
     * Gets the value of otherITKnowledge
     *
     * @return the value of otherITKnowledge
     * @exception RMIException if an error occurs
     */
    public String getOtherITKnowledge()  throws RMIException{
	return this.otherITKnowledge;
    }

    /**
     * Sets the value of otherITKnowledge
     *
     * @param argOtherITKnowledge Value to assign to this.otherITKnowledge
     * @exception RMIException if an error occurs
     */
    public void setOtherITKnowledge(String argOtherITKnowledge) throws RMIException{
	this.otherITKnowledge = argOtherITKnowledge;
    }

    /**
     * Gets the value of spareTimeInterests
     *
     * @return the value of spareTimeInterests
     * @exception RMIException if an error occurs
     */
    public String getSpareTimeInterests()  throws RMIException{
	return this.spareTimeInterests;
    }

    /**
     * Sets the value of spareTimeInterests
     *
     * @param argSpareTimeInterests Value to assign to this.spareTimeInterests
     * @exception RMIException if an error occurs
     */
    public void setSpareTimeInterests(String argSpareTimeInterests) throws RMIException{
	this.spareTimeInterests = argSpareTimeInterests;
    }
    

    /**
     * Gets the value of qualifications
     *
     * @return the value of qualifications
     */
    public ApplicantQualificationList getQualifications()  {
	return this.qualifications;
    }

    /**
     * Sets the value of qualifications
     *
     * @param argQualifications Value to assign to this.qualifications
     */
    public void setQualifications(ApplicantQualificationList argQualifications) {
	this.qualifications = argQualifications;
    }

    /**
     * Gets the value of globalQualifications
     *
     * @return the value of globalQualifications
     */
    public GlobalQualificationList getGlobalQualifications()  {
	return this.globalQualifications;
    }

    /**
     * Sets the value of globalQualifications
     *
     * @param argGlobalQualifications Value to assign to this.globalQualifications
     */
    public void setGlobalQualifications(GlobalQualificationList argGlobalQualifications) {
	this.globalQualifications = argGlobalQualifications;
    }
}


/**
 * Contains attributes and methods for maintaining a list of qualifications. Is
 * used by the "CV" class.
 *
 * @author <a href="mailto:carlsen@flatboy"></a>
 * @version 1.0
 */
class ApplicantQualificationList{
    private List contApplicantQualifications  = new ArrayList();      //contains skill-level objects
    private List contAddTemp = new ArrayList();    //temporary container which holds added skill-level objects
    private List contRemoveTemp = new ArrayList(); //temporary container which holds removed skill-level objects    
    private int appID; //used when storing to the database.

    //DAO objects
    ApplicantDAO applicantDAO;
    
    public ApplicantQualificationList() throws DAOException{
	applicantDAO = new ApplicantDAO();
    }
    
    /**
     * Initializes the DAO object and gets the skill-level objects
     * related to the applicant from the database.
     *
     * @param argAppID an <code>int</code> value
     * @exception DAOException if an error occurs
     */
    public ApplicantQualificationList(int argAppID) throws DAOException{
	applicantDAO = new ApplicantDAO();
	contApplicantQualifications = applicantDAO.getSkillLevels(argAppID); //NOTE: returns skill-level objects
	appID = argAppID;
    }
    

    /**
     * Tests the equality between to objects of the "ApplicantQualificationList" class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj){
	if (this == obj) {
	    return true;
	}

	if (!(obj instanceof ApplicantQualificationList)) {
	    return false;
	}

	ApplicantQualificationList objAppQualList = (ApplicantQualificationList) obj;

	if(this.getLength() != (objAppQualList.getLength())) 
	    return false;

	for(int i = 0; i < this.getLength(); i++){
	    if(!(getSkillLevel(i).equals(objAppQualList.getSkillLevel(i))))
		return false;
	}

	return true;
    }


    /**
     * Returns a skill-level object from the contApplicantQualifications container.
     *
     * @param skillLevelNo an <code>int</code> value
     * @return a <code>SkillLevel</code> value
     */
    public SkillLevel getSkillLevel(int skillLevelNo){
	return (SkillLevel) contApplicantQualifications.get(skillLevelNo);
    }


    /**
     * Invokes the fixTempLists method to fix a possible redundancy of
     * an object (cf. fixTempList method for further information) and
     * saves the edited job-qualification list in the database. This
     * method is handy because we want the user to be able to cancel
     * the changes made to the qualification-list, which is simply
     * done by NOT invoking this method when the qualification-list
     * has been edited.
     * 
     *
     * @exception DAOException if a dataaccess error occurs
     */
    public void save() throws DAOException{
	fixTempLists();
	for(int i = 0; i < contAddTemp.size(); i++){
	    SkillLevel skill = (SkillLevel) contAddTemp.get(i);
	    applicantDAO.insertSkillLevel(skill);
	    contApplicantQualifications.add(skill);
	}
	
	contAddTemp = new ArrayList();
	for(int i = 0; i < contRemoveTemp.size(); i++){
	    SkillLevel skill = (SkillLevel) contRemoveTemp.get(i);
	    applicantDAO.deleteSkillLevel(skill);
	    contApplicantQualifications.remove(skill);
	}
	contRemoveTemp = new ArrayList();
    }


    /**
     * Adds a new skill-level object to the contAddTemp container.
     *
     * @param argQual a <code>Qualification</code> value
     * @param level an <code>int</code> value
     */
    public void addQualification(Qualification argQual, int level){
	SkillLevel newSkillLevel = null;
	try{
	    newSkillLevel = new SkillLevel();
	    newSkillLevel.setQualification(argQual);
	    newSkillLevel.setLevel(level);
	    newSkillLevel.setID(appID);
	} catch (Exception e) {
	    //DO NOTHING
	}
	contAddTemp.add(newSkillLevel);
    }
    

    /**
     * Removes a skill-level object from the contRemoveTemp container.
     *
     * @param qualificationNo an <code>int</code> value
     */
    public void removeQualification(int qualificationNo){
	contRemoveTemp.add(contApplicantQualifications.get(qualificationNo));
    }


    /**
     * Runs through contAddTemp for each object in conRemoveTemp to
     * check whether or not the same object is added to both
     * containers. The problem is this: If an applicant adds a
     * skill-level object to the conAddTemp container, then decides to
     * remove it and thereby adding it to the contRemoveTemp
     * container, and once again changes his mind and adds it to the
     * contAddTemp container, the same object will be contained twice
     * in contAddTemp and once in the contRemoveTemp
     * container. Therefore, it is necessary to run through all
     * objects in one of the containers for each object in the other
     * container to remove the redundant object.
     *
     */
    public void fixTempLists(){
	for (int i = 0; i < contRemoveTemp.size(); i++){
	    for (int j = 0; j < contAddTemp.size(); j++){
		if ((contRemoveTemp.get(i)).equals(contAddTemp.get(j))){
		    contRemoveTemp.remove(contRemoveTemp.get(i));
		    contAddTemp.remove((contRemoveTemp.get(j)));
		    i--;
		    break;
		}
	    }
	}
    }

    /**
     * Calculates the size of the container contApplicantQualifications.
     *
     * @return an <code>int</code> value
     */
    public int getLength(){
	return contApplicantQualifications.size();
    }
}
