package dk.auc.cs.whiner.model;

import junit.framework.TestCase;
import dk.auc.cs.whiner.rmi.*;
import dk.auc.cs.whiner.dataaccess.*;
import java.rmi.*;

public class TestQualification extends TestCase{

    public void testEquals() throws RMIException, RemoteException, DAOException{
	Qualification qual1 = new Qualification();
	Qualification qual2 = new Qualification();
	assertEquals("Two new qualificaitons are expected to be equal", qual1, qual2);
	qual1.setID(5);
	qual1.setName("Java");
	qual1.setDescription("Java description");
	qual2.setID(5);
	qual2.setName("Java");
	qual2.setDescription("Java description");
	assertEquals("Two qualificaitons with same attributes are expected to be equal", qual1, qual2);
	qual2.setName("Sql");
	assertFalse("Two qualificaitons with different attributes are expected not to be equal", qual1.equals(qual2));

    }
}
