package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.function.*;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.*;

import java.util.*;

/**
 * The "Administrator" class manages the headhunters and applicants in
 * the system. It contains methods for the administrator to manage:
 * headhunter creation and deletion, applicant deletion, and change of
 * headhunter password (should he or she have forgotten it). This
 * class is inherited from the "User" class.
 *
 * @author <a href="mailto:bennett@atto.cs.auc.dk">Anders Bennett</a>
 * @author <a href="mailto:carlsen@pico.cs.auc.dk">Jeppe Carlsen</a>
 * @version 1.0
 */
public class Administrator extends User implements AdministratorI{
    //Inherited attributes
    private int id = 0;
    private String loginName = "";
    private String password = "";
    private HeadhunterList headhunters;
    private ApplicantList applicants;    

    //DAO objects
    private HeadhunterDAO headhunterDAO;
    private ApplicantDAO applicantDAO;    

    public Administrator() throws RemoteException, DAOException{
	headhunterDAO = new HeadhunterDAO();
	applicantDAO = new ApplicantDAO();    
	headhunters = new HeadhunterList();
	applicants = new ApplicantList();    
    }


    /**
     * Tests for equality between two objects of the "Administrator" class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj) {
	if ( this == obj ) return true;
	if ( !(obj instanceof Administrator) ) return false;
	Administrator objAdmin = (Administrator) obj;
	boolean result = false;
	    result = 
		(this.id == objAdmin.getID()) &&
		((this.loginName).equals(objAdmin.getLoginName())) &&
		((this.password).equals(objAdmin.getPassword())) &&
		((this.headhunters).equals(objAdmin.getHeadhunters())) ;
	return result;
    }


    /**
     * Makes an instance of the "HeadhunterList" class.
     *
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public void initializeHeadhunterList() throws RMIException, DAOException{
	headhunters = new HeadhunterList();
    }

    /**
     * Returns a headhunter object from its number in the container in the GUI.
     *
     * @param HHNo an <code>int</code> value
     * @return an <code>Applicant</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public String getHeadhunter(int HHNo) throws DAOException, RMIException{
	return ((String)headhunters.getHeadhunter(HHNo));
    }
    

    /**
     * Gets the length of the cont container in 
     * the "HeadhunterList" class.
     *
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public int getHeadhunterListLength() throws RMIException{
	return headhunters.getLength();
    }


    /**
     * Makes an instance of the "ApplicantList" class.
     *
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public void initializeApplicantList() throws RMIException, DAOException{
	applicants = new ApplicantList();
    }

    /**
     * Returns an applicant object from its number in the container to the GUI. 
     *
     * @param appNo an <code>int</code> value
     * @return an <code>Applicant</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public String getApplicant(int appNo)throws DAOException, RMIException{
	return ((String)applicants.getApplicant(appNo));
    }
    
    
    /**
     * Gets the length of the cont container in 
     * the "ApplicantList" class.
     *
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public int getApplicantListLength() throws RMIException{
	return applicants.getLength();
    }
    

    
    
    /**
     * Deletes an applicant from the system.
     *
     * @param appLginName a <code>String</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RemoteException if an error occurs
     */
    public void deleteApplicant(String appLginName) throws DAOException, RemoteException{
	Applicant app;	
	app = applicantDAO.getApplicant(appLginName);
	app.deleteApplicant();	
	applicants.deleteApplicant(appLginName);	
    }


    /**
     * Creates a new headhunter in the system. First, a new instance
     * of the "Register" class in the function component is created
     * which initializes an attributed used by the invoked
     * activateHeadhunter method to create a new headhunter
     * object. Next, the new headhunter is added to the
     * administrator's list of headhunters.
     *
     * @param argLoginName a <code>String</code> value
     * @param argPassword a <code>String</code> value
     * @exception RemoteException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     * @exception LoginNameException if the typed login name does not
     * match any in the database    
     * @see dk.auc.cs.whiner.function.Register#activateHeadhunter(String argLoginName)
     */
    public void createHeadhunter(String argLoginName, String argPassword) throws RemoteException, DAOException, LoginNameException{
	    Register register = new Register();	
	    register.activateHeadhunter(argLoginName, argPassword); 
	    headhunters.addHeadhunter(argLoginName);
    }
    
    
    /**
     * Deletes a headhunter from the system. First, all jobs get
     * closed, and all applicants get notified.  Then, all
     * applications get deleted, followed by the deletion of the
     * associated job. Finally, all projects associated with the
     * headhunter get deleted and then the headhunter is deleted from
     * the system and from the administrator's list of headhunters.
     *
     * @param hhLginName a <code>String</code> value
     * @exception AnnouncedJobException if an error occurs
     * @exception DAOException if an error occurs
     * @exception CloseException if a job is not announced, it cannot
     * be closed, hence an exception will be thrown.
     * @exception RemoteException if an error occurs
     */
    public void deleteHeadhunter(String hhLginName) throws AnnouncedJobException , DAOException, CloseException, RemoteException {
	Headhunter hh = headhunterDAO.getHeadhunter(hhLginName);
	hh.deleteAllProjects();
	headhunters.deleteHeadhunter(hhLginName);	
	headhunterDAO.delete(hhLginName);
    }
    
    
    
    /**
     * Changes the headhunter's password. The headhunter in question
     * gets fetched from the database and his password attribute is
     * set to the new value. Afterwards, the object is updated.
     *
     * @param newPassword a <code>String</code> value
     * @param hhLginName a <code>String</code> value
     * @exception RemoteException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public void changeHeadhunterPassword(String newPassword, String hhLginName)  throws DAOException, RemoteException{
	//if(Register.acceptPassword(newPassword, confNwPasswrd)){
	Headhunter hh = headhunterDAO.getHeadhunter(hhLginName);
	hh.setPassword(newPassword);	
	headhunterDAO.update(hh);	
    }



    /**
     * Changes the user password. The new password is set if the GUI
     * finds the new password acceptable in accordance with the
     * conditions the password must comply with.
     *
     * @param newPassword a <code>String</code> value
     * @exception RMIException if an error occurs
     */
    public void changePassword(String newPassword)throws RMIException{
	setPassword(newPassword);
    }




    /*SET AND GET METHODS
      -------------------*/

    /**
     * Gets the value of id
     *
     * @return the value of id
     */
    public int getID()  {
	return this.id;
    }

    /**
     * Sets the value of id
     *
     * @param argId Value to assign to this.id
     */
    public void setID(int argId) {
	this.id = argId;
    }

    /**
     * Gets the value of loginName
     *
     * @return the value of loginName
     */
    public String getLoginName()  {
	return this.loginName;
    }

    /**
     * Sets the value of loginName
     *
     * @param argLoginName Value to assign to this.loginName
     */
    public void setLoginName(String argLoginName) {
	this.loginName = argLoginName;
    }

    /**
     * Gets the value of password
     *
     * @return the value of password
     */
    public String getPassword()  {
	return this.password;
    }

    /**
     * Sets the value of password
     *
     * @param argPassword Value to assign to this.password
     */
    public void setPassword(String argPassword) {
	this.password = argPassword;
    }

    /**
     * Gets the value of headhunters
     *
     * @return the value of headhunters
     */
    public HeadhunterList getHeadhunters()  {
	return this.headhunters;
    }

    /**
     * Sets the value of headhunters
     *
     * @param argHeadhunters Value to assign to this.headhunters
     */
    public void setHeadhunters(HeadhunterList argHeadhunters) {
	this.headhunters = argHeadhunters;
    }




    /**
     * Contains methods for the administrator so he can manage the
     * headhunters. When an administrator logs in and views the
     * headhunters in the system, he gets a list of usernames of all
     * headhunters and not the actual headhunter objects.
     *
     * @author <a href="mailto:bennett@pico.cs.auc.dk">Anders Bennett</a>
     * @author <a href="mailto:carlsen@pico.cs.auc.dk">Jeppe Carlsen</a>
     * @version 1.0
     */
    private class HeadhunterList{
	private List cont = new ArrayList();
   
	//DAO objects
	private HeadhunterDAO headhunterDAO;


	/**
	 * Is invoked when an empty HeadhunterList attribute is needed.
	 *
	 */
	public HeadhunterList() throws DAOException{
	    headhunterDAO = new HeadhunterDAO();
	    cont = headhunterDAO.getLoginNames();
	}
    
   
	/**
	 * Gets all headhunter usernames from the system.
	 *
	 * @param jobID an <code>int</code> value
	 */
	public HeadhunterList(int adminID) throws DAOException{
	    headhunterDAO = new HeadhunterDAO();
	    cont = headhunterDAO.getLoginNames();
	}

    
	/**
	 * Tests for equality between two objects of the
	 * "HeadhunterList" class.
	 *
	 * @param obj an <code>Object</code> value
	 * @return a <code>boolean</code> value
	 */
	public boolean equals(Object obj) {
	    if(this == obj) 
		return true;
	    if(!(obj instanceof HeadhunterList)) 
		return false;
	    HeadhunterList objHHList = (HeadhunterList) obj;
	    if (this.getLength() != (objHHList.getLength()))
		return false;
	    for(int i = 0; i < this.getLength(); i++){
		try {
		    if(!(getHeadhunter(i).equals(objHHList.getHeadhunter(i)))) {
			return false;
		    }
		} catch (DAOException e) {
		    // necessary to keep the compiler from whining
		}
	    }
	    return true;
	}


    
	/**
	 * Calculates the size of the container cont.
	 *
	 * @return an <code>int</code> value
	 */
	public int getLength(){
	    return cont.size();
	}
    

	/**
	 * Gets a headhunter from the system from his login name.
	 *
	 * @param hhLginName a <code>String</code> value
	 * @return a <code>Headhunter</code> value
	 * @exception DAOException if a dataaccess error occurs
	 */
	public Headhunter getHeadhunter(String hhLginName) throws DAOException{
	    return  headhunterDAO.getHeadhunter(hhLginName);
	}


	/**
	 * Returns a headhunter object from its number in the container.
	 *
	 * @param HHNo an <code>int</code> value
	 * @return a <code>Headhunter</code> value
	 * @exception DAOException if a dataaccess error occurs
	 */
	public String getHeadhunter(int HHNo) throws DAOException {
	    return (String) cont.get(HHNo);
	}
    
	/**
	 * Adds a headhunter object to the cont container.
	 *
	 * @param argHeadhunter an <code>Application</code> value
	 */
	public void addHeadhunter(String LginName){
	    cont.add(LginName);
	}
    
        
	/**
	 * Removes a headhunter login name from the cont container.
	 *
	 * @param headhunterNo an <code>int</code> value
	 */
	public void deleteHeadhunter(String hhLginName){
	    cont.remove(hhLginName);
	}
    }

    /**
     * Contains methods for the administrator so he can manage the
     * applicants. When an administrator logs in and views the
     * applicants in the system, he gets a list of usernames of all
     * applicants and not the actual headhunter objects.
     *
     * @author <a href="mailto:bennett@pico.cs.auc.dk">Anders Bennett</a>
     * @author <a href="mailto:carlsen@pico.cs.auc.dk">Jeppe Carlsen</a>
     * @version 1.0
     */
    private class ApplicantList {
	private List cont = new ArrayList();
   
	//DAO objects
	private ApplicantDAO applicantDAO;


	/**
	 * Is invoked when an empty ApplicantList attribute is needed.
	 *
	 * @exception DAOException if a dataaccess error occurs
	 */
	public ApplicantList() throws DAOException {
	    applicantDAO = new ApplicantDAO();
	    cont = applicantDAO.getLoginNames();
	}
    
   
	/**
	 * Gets all applicant usernames from the system.
	 *
	 * @param AdminID an <code>int</code> value
	 * @exception DAOException if a dataaccess error occurs
	 */
	public ApplicantList(int AdminID) throws DAOException {
	    applicantDAO = new ApplicantDAO();
	    cont = applicantDAO.getLoginNames();
	}

    
	/**
	 * Tests for equality between two objects of the "ApplicantList" class.
	 *
	 * @param obj an <code>Object</code> value
	 * @return a <code>boolean</code> value
	 */
	public boolean equals(Object obj){
	    if(this == obj) {
		return true;
	    }
	    if(!(obj instanceof ApplicantList)) {
		return false;
	    }
	    ApplicantList objAppList = (ApplicantList) obj;
	    if (this.getLength() != (objAppList.getLength())) {
		return false;
	    }
	    for(int i = 0; i < this.getLength(); i++){
		try {
		    if(!(getApplicant(i).equals(objAppList.getApplicant(i)))) {
			return false;
		    }
		} catch (DAOException e) {
		    // necessary to keep the compiler from whining
		}
	    }
	    return true;
	}


    
	/**
	 * Calculates the size of the container cont.
	 *
	 * @return an <code>int</code> value
	 */
	public int getLength(){
	    return cont.size();
	}
    

	/**
	 * Gets a applicant from the system from his login name.
	 *
	 * @param appLginName a <code>String</code> value
	 * @return a <code>Applicant</code> value
	 * @exception DAOException if a dataaccess error occurs
	 */
	public Applicant getApplicant(String appLginName) throws DAOException{
	    return applicantDAO.getApplicant(appLginName);
	}


	/**
	 * Returns an applicant object from its number in the container.
	 *
	 * @param appNo an <code>int</code> value
	 * @return an <code>Applicant</code> value
	 * @exception DAOException if a dataaccess error occurs
	 */
	public String getApplicant(int appNo) throws DAOException {
	    return (String) cont.get(appNo);
	}
    
	/**
	 * Adds a applicant object to the cont container.
	 *
	 * @param argApplicant an <code>Application</code> value
	 */
	public void addApplicant(String LginName){
	    cont.add(LginName);
	}
    
        
	/**
	 * Removes a applicant login name from the cont container.
	 *
	 * @param applicantNo an <code>int</code> value
	 */
	public void deleteApplicant(String appLginName){
	    cont.remove(appLginName);
	}
    }
}
