package dk.auc.cs.whiner.model;

import java.util.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.rmi.*;
import java.rmi.*;
import dk.auc.cs.whiner.dataaccess.*;

public class TestApplicant extends TestCase{

    public void testEquals() throws RMIException, RemoteException, DAOException{
	ApplicantDAO appDAO = new ApplicantDAO();
	Applicant app1 = appDAO.add();
	appDAO.update(app1);
	appDAO.update((CV) app1.getCV());

	Applicant app2 = appDAO.getApplicant(app1.getID());

      	assertTrue("Two applicants with same attributes are expected to be equal", app1.equals(app2));
	app1.setEmail("saddam@baghdad");
	assertFalse("Two applicant with different attributes are expected not to be equal", app1.equals(app2));
	
	//clean up
	appDAO.delete(app1.getID());
	
    }

    
    public void testGetMatch() throws RMIException, DAOException, RemoteException{	
	MatchesDAO matchesDAO = new MatchesDAO();
	ApplicantDAO applicantDAO = new ApplicantDAO();
	Applicant applicant = applicantDAO.add();
	
	Match match1 = matchesDAO.add();
	match1.setApplicantID(applicant.getID());
	matchesDAO.update(match1);
	
	applicant.initializeMatchList();
	assertEquals("Should only have one match", 1, applicant.getMatchListLength());
	assertEquals("Wrong match object", match1, applicant.getMatch(0));

	//clean up
	applicantDAO.delete(applicant.getID());
	matchesDAO.delete(match1.getID());

    }
    
    public void testGetNotificationListLength() throws RMIException, DAOException, RemoteException{
	ApplicantDAO appDAO = new ApplicantDAO();
	Applicant app1 = appDAO.add();
	NotificationDAO notDAO = new NotificationDAO();
	Notification not1 = notDAO.add();
	Notification not2 = notDAO.add();
	not1.setApplicantID(app1.getID());
	not2.setApplicantID(app1.getID());
	not1.setNotificationType("Application rejected");
	not2.setNotificationType("Application rejected");

	notDAO.update(not1);
	notDAO.update(not2);

	app1.initializeNotificationList();
	assertEquals("The length of the list should be 2", 2, app1.getNotificationListLength());

	//cleanup
	appDAO.delete(app1.getID());
	notDAO.delete(not1.getID());
	notDAO.delete(not2.getID());

    }
    
    public void testGetApplicationListLength() throws RMIException, DAOException, RemoteException{
	ApplicantDAO appDAO = new ApplicantDAO();
	Applicant app1 = appDAO.add();
	ApplicationDAO applDAO = new ApplicationDAO();
	Application appl1 = applDAO.add();
	Application appl2 = applDAO.add();
	appl1.setApplicantID(app1.getID());
	appl2.setApplicantID(app1.getID());
	applDAO.update(appl1);
	applDAO.update(appl2);

	app1.initializeApplicantApplicationList();
	assertEquals("The length of the list should be 2", 2, app1.getApplicationListLength());

	//cleanup
	appDAO.delete(app1.getID());
	applDAO.delete(appl1.getID());
	applDAO.delete(appl2.getID());

    }

    public void testGetMatchListLength() throws RMIException, DAOException, RemoteException{
	ApplicantDAO appDAO = new ApplicantDAO();
	Applicant app1 = appDAO.add();
	MatchesDAO matchesDAO = new MatchesDAO();
	Match match1 = matchesDAO.add();
	Match match2 = matchesDAO.add();
	match1.setApplicantID(app1.getID());
	match2.setApplicantID(app1.getID());
	matchesDAO.update(match1);
	matchesDAO.update(match2);

	app1.initializeMatchList();
	assertEquals("The length of the list should be 2", 2, app1.getMatchListLength());

	//cleanup
	appDAO.delete(app1.getID());
	matchesDAO.delete(match1.getID());
	matchesDAO.delete(match2.getID());

    }


    public void testSelectCV() throws RemoteException, DAOException{
	ApplicantDAO appDAO = new ApplicantDAO();
	Applicant app1 = appDAO.add();
	CV cv1 = new CV();
	cv1.setApplicantID(app1.getID());
	appDAO.update(cv1);

	CV cv2 = new CV();
	cv2.setApplicantID(app1.getID());

	assertTrue("CVs should be identical", cv1.equals(cv2));
	CV cv3 = new CV();
	cv3.setApplicantID(3);
	assertFalse("cv1 and cv3 should not be identical", cv1.equals(cv3));


	//clean up
	appDAO.delete(app1.getID());

    }


    public void testDeleteApplicationDraft() throws DAOException, RemoteException{
	ApplicationDAO applicationDAO = new ApplicationDAO();
	ApplicantDAO applicantDAO = new ApplicantDAO();

	Applicant applicant = applicantDAO.add();
	applicantDAO.update(applicant);

	Application application1 = applicationDAO.add();
	application1.setStatus("incomplete");
	application1.setApplicantID(applicant.getID());
	applicationDAO.update(application1);
	Application application2 = applicationDAO.add();
	application2.setStatus("submitted");
	application2.setApplicantID(applicant.getID());
	applicationDAO.update(application2);


	applicant.initializeApplicantApplicationList();


	assertEquals("Application list length should be 2", 2, applicant.getApplicationListLength());

	int i = 0;
	for(i = 0; (applicant.getApplication(i)).getID() != 0; i++);
	application1 = (Application) applicant.getApplication(i);
	for(i = 0; (applicant.getApplication(i)).getID() != 1; i++);
	application2 = (Application) applicant.getApplication(i);
	
	applicant.deleteApplicationDraft(application1.getID());

	assertEquals("Application list length should be 1", 1, applicant.getApplicationListLength());

	
	Application application3 = applicationDAO.add();
	application3.setID(application2.getID());
	application3.setStatus("submitted");
	application3.setApplicantID(applicant.getID());
	applicationDAO.update(application3);

	assertTrue("application2 and application3 should be identical", application2.equals(application3));   


	//clean up
	applicantDAO.delete(applicant.getID());
	applicationDAO.delete(application1.getID());
	applicationDAO.delete(application2.getID());
    }



    public void testDeleteApplicant() throws DAOException, RemoteException{
	ApplicationDAO applicationDAO = new ApplicationDAO();
	ApplicantDAO applicantDAO = new ApplicantDAO();
	NotificationDAO notificationDAO = new NotificationDAO();
	QualificationDAO qualificationDAO = new QualificationDAO();
	MatchesDAO matchesDAO = new MatchesDAO();


	//applicant
	Applicant applicant = applicantDAO.add();
	applicantDAO.update(applicant);

	//CV
	CV cv = new CV();
	cv.setApplicantID(applicant.getID());
	applicantDAO.update(cv);


	//applications
	Application application1 = applicationDAO.add();
	application1.setStatus("incomplete");
	application1.setApplicantID(applicant.getID());
	applicationDAO.update(application1);
	Application application2 = applicationDAO.add();
	application2.setStatus("submitted");
	application2.setApplicantID(applicant.getID());
	applicationDAO.update(application2);
	Application application3 = applicationDAO.add();
	application3.setStatus("submitted");
	application3.setApplicantID(applicant.getID());
	applicationDAO.update(application3);


	//notifications
	Notification not1 = notificationDAO.add();
	Notification not2 = notificationDAO.add();
	not1.setApplicantID(applicant.getID());
	not2.setApplicantID(applicant.getID());
	not1.setNotificationType("Application rejected");
	not2.setNotificationType("Application rejected");
	notificationDAO.update(not1);
	notificationDAO.update(not2);


	//skill-levels
	Qualification qual1 = qualificationDAO.add();
	Qualification qual2 = qualificationDAO.add();
	
	qual1.setName("qual1");
	qual1.setDescription("a description");
	qualificationDAO.update(qual1);
    
	qual2.setName("qual2");
	qual2.setDescription("a description 2");
	qualificationDAO.update(qual2);


	SkillLevel skill1;
	SkillLevel skill2;
	
	skill1 = new SkillLevel();
	skill1.setID(applicant.getID());
	skill1.setLevel(4);
	skill1.setQualification(qual1);
	
	skill2 = new SkillLevel();
	skill2.setID(applicant.getID());
	skill2.setLevel(3);
	skill2.setQualification(qual2);	
	
	applicantDAO.insertSkillLevel(skill1);
	applicantDAO.insertSkillLevel(skill2);

	//match

	Match match = matchesDAO.add();
	List metReqs = new ArrayList();

	MatchInformation matchInfo1 = new MatchInformation();
	MatchInformation matchInfo2 = new MatchInformation();

	matchInfo1.setMatchID(match.getID());
	matchInfo1.setLevelJobSkillLevel(4);
	matchInfo1.setLevelApplicantSkillLevel(4);
	matchInfo1.setQualificationName(qual1.getName());

	metReqs.add(matchInfo1);

	matchInfo2.setMatchID(match.getID());
	matchInfo2.setLevelJobSkillLevel(3);
	matchInfo2.setLevelApplicantSkillLevel(3);
	matchInfo2.setQualificationName(qual2.getName());

	metReqs.add(matchInfo2);

	match.setApplicantID(applicant.getID());
	match.setRequirementScore(6);
	match.setMetRequirements(metReqs);
	match.setDateOfMatch(new Date());

	matchesDAO.update(match);


	applicant.initializeApplicantApplicationList();
	applicant.initializeMatchList();
	applicant.initializeNotificationList();

       
	assertEquals("ApplicationList length should be 3", 3, applicant.getApplicationListLength());
	assertEquals("MatchList length should be 1", 1, applicant.getMatchListLength());
	assertEquals("NotificationList length should be 2", 2, applicant.getNotificationListLength());


	applicant.deleteApplicant();


	applicant.initializeApplicantApplicationList();
	applicant.initializeMatchList();
	applicant.initializeNotificationList();


	assertEquals("ApplicationList length should be 0", 0, applicant.getApplicationListLength());
	assertEquals("MatchList length should be 0", 0, applicant.getMatchListLength());
	assertEquals("NotificationList length should be 0", 0, applicant.getNotificationListLength());


	//clean up
	qualificationDAO.delete(qual1.getID());
	qualificationDAO.delete(qual2.getID());
	applicantDAO.delete(applicant.getID());
	applicationDAO.delete(application2.getID());
	applicationDAO.delete(application3.getID());
	applicantDAO.deleteSkillLevel(skill1);
	applicantDAO.deleteSkillLevel(skill2);
	

    }
    
}
