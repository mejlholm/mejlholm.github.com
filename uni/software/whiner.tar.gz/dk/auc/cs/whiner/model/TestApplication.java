package dk.auc.cs.whiner.model;

import java.util.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.rmi.*;
import java.rmi.*;
import dk.auc.cs.whiner.dataaccess.*;

public class TestApplication extends TestCase{

    public void testEquals() throws RMIException, RemoteException, DAOException{
	Application app1 = new Application();
	Application app2 = new Application();
	assertEquals("Two new application instances are expected to be equal", app1, app2);
	app1.setID(0);
	app2.setID(0);
	app1.setJobID(2);
	app2.setJobID(2);
	app1.setApplicantID(5);
	app2.setApplicantID(5);
	app1.setStatus("announced");
	app2.setStatus("announced");
	app1.setBodyText("Some text");
	app2.setBodyText("Some text");
	app1.setDateOfCreation(new Date(0));
	app2.setDateOfCreation(new Date(0));
	app1.setDateOfSubmission(new Date(0));
	app2.setDateOfSubmission(new Date(0));
	app1.setDateOfRejection(new Date(0));
	app2.setDateOfRejection(new Date(0));
	assertEquals("Two qualificaitons with same attributes are expected to be equal", app1, app2);
	app1.setStatus("rejected");
	assertFalse("Two qualificaitons with different attributes are expected not to be equal", app1.equals(app2));
    }
    
    public void testSave() throws RMIException, DAOException, RemoteException{
	ApplicationDAO appDAO = new ApplicationDAO();
	Application app1;
	Application app2;
	app1 = appDAO.add();
        assertTrue("ApplicationDAO must assign the application a valid id", app1.getID()>-1); //-1 is the default value
	
        app1.setJobID(2);
	app1.setApplicantID(5);
        app1.setStatus("submitted");
        app1.setBodyText("Some text");
        app1.setDateOfCreation(new Date());
	app1.setDateOfSubmission(new Date());
        app1.setDateOfRejection(new Date());
	
	app1.save();
	
        app2 = appDAO.getApplication(app1.getID());

	assertTrue("The application attributes aren't saved correctly by the ApplicaitonDAO", app1.equals(app2));

	appDAO.delete(0);
    }
    
    //Tester ikke om en korrekt notification er sendt ud. boer den nok goere!
    //Jeg tester IKKE at status "rejected" bliver gemt i DB da save() bruges, og den er TESTET!
    public void testReject() throws RMIException, RemoteException, DAOException{
	ApplicationDAO appDAO = new ApplicationDAO();
	ApplicantDAO applicantDAO = new ApplicantDAO();
	Application app1 = appDAO.add();
	Applicant applicant = applicantDAO.add();
	int jobID = 2;

	app1.setApplicantID(applicant.getID());
	app1.setJobID(jobID);

	app1.setStatus("incomplete");
	app1.reject();
	assertEquals("The application should still be incomplete because only submitted applications can be rejected", 
		     app1.getStatus(), "incomplete");
	app1.setStatus("submitted");
	app1.reject();
	assertEquals("The application should have changed its status to rejected", 
		     app1.getStatus(), "rejected");

	//is the applicant correctly notified?
	NotificationDAO notDAO = new NotificationDAO();
	List notifications = notDAO.getNotifications(applicant.getID());
	assertEquals("The test requires the database to be default initialized (not notifications!)", 1, notifications.size());
	Notification not = (Notification) notifications.get(0);

	assertEquals("!!ID!!", 0, not.getID());
	assertEquals("!!app ID!!", applicant.getID(), not.getApplicantID());
	assertEquals("!!job ID!!", jobID, not.getJobID());
	assertEquals("!!Type!!", "Application rejected", not.getNotificationType());

	appDAO.delete(app1.getID());
	applicantDAO.delete(applicant.getID());
	notDAO.delete(0);
    }
}
