package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.dataaccess.QualificationDAO;
import dk.auc.cs.whiner.dataaccess.DAOException;
import java.util.*;

import java.rmi.*;
import java.rmi.server.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.rmi.RMIException;

/**
 * This class contains one attribute and methods for manipulating with the global qualification list. Is accessed from the "Job" class and "CV" class.
 *
 * @author <a href="mailto:bennett@fatboy"></a>
 * @author <a href="mailto:carlsen@fatboy"></a>
 * @version 1.0
 */

//extends UnicastRemoteObject
public class GlobalQualificationList extends UnicastRemoteObject implements GlobalQualificationListI{
    private List cont = new ArrayList();

    //DAO objects
    QualificationDAO qualificationDAO;


    /**
     * Creates a new "GlobalQualificationList" instance and fills the
     * container cont with all qualifications from the global
     * qualification list.
     *
     * @exception DAOException if an error occurs
     * @exception RemoteException if an error occurs
     */
    public GlobalQualificationList() throws DAOException, RemoteException{
	qualificationDAO = new QualificationDAO();
	cont = qualificationDAO.getQualifications();
    }

    /**
     * Compares to objects for equality from the "GlobalQualificationList" class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj){
	boolean result = true;
	if (this == obj) return true;
	if (!(obj instanceof GlobalQualificationList)) return false;
	GlobalQualificationList objGloQualList = (GlobalQualificationList) obj;
	try{
	    if(this.getLength() != (objGloQualList.getLength())) return false;
	    for(int i = 0; i < this.getLength(); i++){
		if(!(getQualification(i).equals(objGloQualList.getQualification(i))))
		    result = false;
	    }
	    result = true;
	} catch(RMIException e){
	    //(F)ISSE
	}
	return result;
    }

    
    /**
     * Gets a qualification object from the cont container.
     *
     * @param qualNo an <code>int</code> value
     * @return a <code>Qualification</code> value
     */
    public QualificationI getQualification(int qualNo){
	return (QualificationI) cont.get(qualNo);
    }
    

    /**
     * Calculates the size of the container cont.
     *
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public int getLength() throws RMIException{
	return cont.size();
    }

    

    /**
     * Adds a qualification to the global qualification list.
     *
     * @param argName a <code>String</code> value
     * @param argDescription a <code>String</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void createQualification(String argName, String argDescription) throws DAOException, RMIException{
	Qualification newQualification = qualificationDAO.add();
	try{
	    newQualification.setName(argName);
	    newQualification.setDescription(argDescription);
	} catch (Exception e) {
	    //DO NOTHING
	}
	cont.add(newQualification);
	qualificationDAO.update(newQualification);
    }
    

    /**
     * Deletes a global qualification from the database. The DAO object throws
     * an exception if the qualification cannot be deleted because it is used by
     * a job in the system.
     *
     * @param qualificationNo an <code>int</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void deleteQualification(int qualificationNo) throws DAOException, RMIException{
	Qualification qual = qualificationDAO.getQualification(qualificationNo);
	
	qualificationDAO.delete(qual.getID());
	cont.remove(qual);	
    } 


    /**
     * Gets the qualification in question and updates it in regards to
     * name and description.
     *
     * @param qualificationNo an <code>int</code> value
     * @param argName a <code>String</code> value
     * @param argDescription a <code>String</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void updateQualification(int qualificationNo, String argName, String argDescription) throws DAOException, RMIException{	
	Qualification updateQualification = (Qualification) cont.get(qualificationNo);  
	updateQualification.setName(argName);
	updateQualification.setDescription(argDescription);
	qualificationDAO.update(updateQualification);
    }
}
