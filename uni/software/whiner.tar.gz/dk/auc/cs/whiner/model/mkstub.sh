#!/bin/sh
# Make the stub files to use with RMI
touch empty.class
rm *.class
javac *.java

for i in *.class
 do echo "Compiling file $i"
/opt/blackdown-jdk-1.4.1/bin/rmic dk.auc.cs.whiner.model.`echo $i | sed 's/\.class/ /'`
done 

cp dk/auc/cs/whiner/model/*_Stub* .
rm -r dk
