package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.function.*;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.rmi.RMIException;

import java.util.*;
import java.sql.*;
import java.util.Date;

import java.rmi.*;
import java.rmi.server.*;
/**
 * The "Project" class is responsible for maintaining the jobs related to the
 * project in question. Therefore, the methods in this class relate to the job
 * objects contained in the different project objects.  The Project class has
 * access objects to the database for the "Project" and "Job" classes among its
 * attributes.  A JobList attribute makes it possible for the methods in the
 * class to access the related jobs, which lie in a container in the JobList
 * class.
 * @author <a href="mailto:carlsen@pico.cs.auc.dk">Jeppe Carlsen</a>
 * @author <a href="mailto:bennett@pico.cs.auc.dk">Anders Bennett</a>
 * @version 1.0
 */
public class Project extends UnicastRemoteObject implements ProjectI{
    private int id = 0;
    private int headhunterID = 0;
    private Date dateOfCreation = new Date(0);
    private String status = "";
    private String title = "";
    private String description = "";
    private JobList jobs;

    //DAO objects
    private ProjectDAO projectDAO;
    private JobDAO jobDAO;
    private ApplicationDAO applicationDAO; 
    
    
    /**
     * Initializes DAO objects and the jobs attribute.
     *
     * @exception RemoteException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public Project() throws RemoteException, DAOException {
	projectDAO = new ProjectDAO();
	jobDAO = new JobDAO();
	applicationDAO = new ApplicationDAO();
	jobs = new JobList(); //Default Constructor makes an empty JobList;
    }
    
    /**
     * Tests for equality between two objects of the "Project" class. 
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj){
	if (this == obj) return true;
	if (!(obj instanceof Project)) return false;
	Project objProject = (Project) obj;
	boolean result = false;
	try{
	    result =
		(this.id == objProject.getID()) &&
		(this.headhunterID == objProject.getHeadhunterID()) &&
		//		((this.dateOfCreation).equals(objProject.getDateOfCreation())) &&
		((this.status).equals(objProject.getStatus())) &&
		((this.title).equals(objProject.getTitle())) &&
		((this.description).equals(objProject.getDescription())) &&
		((this.jobs).equals((JobList) objProject.getJobs()));
	} catch(RMIException e){
	    // necessary to keep the compiler from whining
	}

	return result;
    }

    /**
     * Gets a JobList for the attribute jobs.
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public void initializeJobList() throws RMIException, DAOException {
	jobs = new JobList(id);
    }

    /**
     * Selects a specific job instance in the JobList, initializes the
     * JobApplicationList and JobQualificationList related to the job,
     * and returns the job object.
     *
     * @param jobNo an <code>int</code> value
     * @return a <code>Job</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public JobI selectJob(int jobNo) throws DAOException, RMIException{
	Job selectedJob = (Job)getJob(jobNo);
	selectedJob.initializeJobApplicationList();
	selectedJob.initializeJobQualificationList();

	return (JobI)selectedJob;
    }

    /**
     * Garbage collects the project's JobList.
     * @exception RMIException if an error occurs
     */
    public void deselectProject() throws RMIException{
	jobs = null;
    }


    /**
     * Returns a job from the project's list of jobs to the client.
     *
     * @param jobNo an <code>int</code> value
     * @return a <code>Job</code> value
     * @exception RMIException if an error occurs
     */
    public JobI getJob(int jobNo) throws RMIException{
	return (JobI)jobs.getJob(jobNo);
    }


    /**
     * Returns the length of the project's list of jobs to the client.
     *
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public int getJobListLength() throws RMIException{
	return jobs.getLength();
    }


    /**
     * Inserts a new job in the database, and 
     * adds it to the project's JobList.
     * @return a <code>JobI</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public JobI createJob() throws DAOException, RMIException{
	Job newJob = jobDAO.add();
	newJob.setProjectID(id);
	newJob.setStatus("not announced");
	newJob.setTitle("New job");
	newJob.setDescription("Enter description here"); 
	newJob.setDateOfCreation(new Date());
	jobDAO.update(newJob);
	jobs.addJob(newJob);
	
	return (JobI)newJob;
    }
    
    /**
     * Deletes a job if it's status is not "announced". Invokes the
     * deleteJob method to actually delete the job.
     *
     * @param jobNo an <code>int</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception AnnouncedJobException if the job in question is
     * announced when being deleted.
     * @exception RemoteException if an error occurs
     */
    public void deleteJobIfNotAnnounced(int jobNo) throws DAOException, AnnouncedJobException, RemoteException {
	Job delJob = jobs.getJob(jobNo);
	if((delJob.getStatus()).equals("announced")) {
	    throw new AnnouncedJobException();
	}
	deleteJob(jobNo);
    }
    

    /**
     * Deletes a job in the database and removes it from the project's
     * job list, but before this, it deletes all submitted
     * applications and notification in the job.
     * 
     * @param jobNo an <code>int</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RemoteException if an error occurs
     * @exception AnnouncedJobException if the job's status is
     * announced and hence cannot be deleted
     * @see dk.auc.cs.whiner.model.Headhunter#deleteProject()
     */
    protected void deleteJob(int jobNo) throws DAOException, RemoteException{
	Job delJob = jobs.getJob(jobNo);
	
	delJob.initializeJobApplicationList();
	int applicationListLength = delJob.getJobApplicationListLength();

	//delete all applications attached to the job	
	for(int i = 0; i < applicationListLength; i++){
	    delJob.deleteApplication(0);
	}
	//delete all skill-level objects of the job
	delJob.initializeJobQualificationList();
	int qualificationListLength = delJob.getJobQualificationListLength();
	for(int i = 0; i < qualificationListLength; i++){
	    delJob.removeRequirement(i);
	}
	delJob.saveRequirements(); 	//The deletion of the qualifications actually happen here.
	jobDAO.delete(jobs.getJobID(jobNo));
	jobs.deleteJob(jobNo);
    }    
    

    /**
     * Updates the project in regards to, for instance, title and
     * description, in the database.
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void save() throws DAOException, RMIException{
	projectDAO.update(this);
    }

    
    /**
     * Announces all jobs checked by the headhunter.  Confirms that a
     * checked job's status is "not announced" before announcing it.
     * If the job contains any rejected applications, these will be
     * made incomplete and the related applicants will be notified
     * about the reopening of the job. They will therefore be able to
     * submit their applications again.  Finally the method invokes
     * the matchJob method to match the job with all applicants in the
     * system.
     *
     * @param checked an <code>int[]</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RemoteException if an error occurs
     */
    public void announceCheckedJobs(int[] checked) throws DAOException, RemoteException{
	Job announceJob;
	
	if(this.getStatus().equals("filled")){
	    if (checked.length > 0){
		this.setStatus("announced");
		projectDAO.update(this);
	    }
	}
	
	for (int i = 0; i < checked.length; i++){
	    announceJob = jobs.getJob(checked[i]);
	    if(announceJob.getStatus().equals("not announced")){
		announceJob.setStatus("announced");
		announceJob.setDateOfAnnouncement(new Date());
		jobDAO.update(announceJob);
		announceJob.initializeJobApplicationList();
		for(int j = 0; j < announceJob.getJobApplicationListLength(); j++){
		    Application app = (Application)announceJob.getApplication(j);
		    if (app.getStatus().equals("rejected")){
			app.setStatus("incomplete");
			applicationDAO.update(app);
			Notify.makeNotification(app.getApplicantID(), announceJob.getID(), "Job reopened");
		    }
		}
		PerformMatch.matchJob(announceJob.getID());
	    }
	}
    }
    
    
    
    /**
     * Forces all jobs in a project to be closed. Is runned prior to
     * the deletion of the headhunter associated with the project that
     * contains the jobs.
     *
     * @exception RemoteException if an error occurs
     * @exception DAOException if an error occurs
     * @exception CloseException if a job is not announced, it cannot
     * be closed, hence an exception will be thrown.
     */
    public void closeAllJobs() throws RemoteException, DAOException, CloseException {
	initializeJobList();	
	int jobListLength = jobs.getLength();
	Job job;
	for(int i = 0; i < jobListLength; i++){
	    job = jobs.getJob(i);
	    if(job.getStatus().equals("announced"))
		job.close();
	}
    }

    /**
     * Tests if a project is filled, which means no more jobs are announced.
     *
     * @exception RemoteException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    void isFilled() throws RemoteException, DAOException{
	initializeJobList();
	boolean result = true;
	for(int i = 0; i < getJobListLength(); i++){
	    if (getJob(i).getStatus().equals("announced")){
		result = false;
		break;
	    }
	}
	
	if(result){
	    this.status = "filled";
	} else
	    {
		this.status = "announced";
	    }
	projectDAO.update(this);
    }
		
	
    /*SET AND GET METHODS
      ------------------*/

    /**
     * Gets the value of id
     *
     * @return the value of id
     * @exception RMIException if an error occurs
     */
    public int getID()  throws RMIException{
	return this.id;
    }

    /**
     * Sets the value of id
     *
     * @param argID Value to assign to this.id
     * @exception RMIException if an error occurs
     */
    public void setID(int argID) throws RMIException{
	this.id = argID;
    }

    /**
     * Gets the value of headhunterID
     *
     * @return the value of headhunterID
     * @exception RMIException if an error occurs
     */
    public int getHeadhunterID()  throws RMIException{
	return this.headhunterID;
    }

    /**
     * Sets the value of headhunterID
     *
     * @param argHeadhunterID Value to assign to this.headhunterID
     * @exception RMIException if an error occurs
     */
    public void setHeadhunterID(int argHeadhunterID) throws RMIException{
	this.headhunterID = argHeadhunterID;
    }

    /**
     * Gets the value of dateOfCreation
     *
     * @return the value of dateOfCreation
     * @exception RMIException if an error occurs
     */
    public Date getDateOfCreation()  throws RMIException{
	return this.dateOfCreation;
    }

    /**
     * Sets the value of dateOfCreation
     *
     * @param argDateOfCreation Value to assign to this.dateOfCreation
     * @exception RMIException if an error occurs
     */
    public void setDateOfCreation(Date argDateOfCreation) throws RMIException{
	this.dateOfCreation = argDateOfCreation;
    }
    
    /**
     * Gets the value of status
     *
     * @return the value of status
     * @exception RMIException if an error occurs
     */
    public String getStatus()  throws RMIException{
	return this.status;
    }

    /**
     * Sets the value of status
     *
     * @param argStatus Value to assign to this.status
     * @exception RMIException if an error occurs
     */
    public void setStatus(String argStatus) throws RMIException{
	this.status = argStatus;
    }

    /**
     * Gets the value of description
     *
     * @return the value of description
     * @exception RMIException if an error occurs
     */
    public String getDescription()  throws RMIException{
	return this.description;
    }

    /**
     * Sets the value of description
     *
     * @param argDescription Value to assign to this.description
     * @exception RMIException if an error occurs
     */
    public void setDescription(String argDescription) throws RMIException{
	this.description = argDescription;
    }

    /**
     * Gets the value of title
     *
     * @return the value of title
     * @exception RMIException if an error occurs
     */
    public String getTitle()throws RMIException{
	return this.title;
    }

    /**
     * Sets the value of title
     *
     * @param argTitle Value to assign to this.title
     * @exception RMIException if an error occurs
     */
    public void setTitle(String argTitle)throws RMIException{
	this.title = argTitle;
    }

    
    /**
     * Gets the value of jobs
     *
     * @return the value of jobs
     */
    public JobList getJobs()  {
	return this.jobs;
    }

    /**
     * Sets the value of jobs
     *
     * @param argJobs Value to assign to this.jobs
     */
    public void setJobs(JobList argJobs) {
	this.jobs = argJobs;
    }
    
    


    /**
     * The "JobList" class handles the retrival of the jobs associated to
     * the project and provides methods for the "Project" class to
     * manipulate these jobs.
     *
     * @author <a href="mailto:bennett@flatboy"></a>
     * @version 1.0
     */
    private class JobList{
	private List cont = new ArrayList();
	private JobDAO jobDAO;
    
	/**
	 * Gets all jobs associated with the project from the database.
	 *
	 * @param projectID an <code>int</code> value
	 * @exception DAOException if a dataaccess error occurs
	 */
	public JobList(int projectID) throws DAOException{
	    jobDAO = new JobDAO();
	    cont = jobDAO.getJobs(projectID);
	}

	/**
	 * Is used when an empty JobList attribute is needed.
	 *
	 * @exception DAOException if an error occurs
	 */
	public JobList() throws DAOException{
	}

    
	/**
	 * Compares to objects for equality from the "JobList" class
	 *
	 * @param obj an <code>Object</code> value
	 * @return a <code>boolean</code> value
	 */
	public boolean equals(Object obj){
	    boolean result = true;
	
	    if (this == obj) {
		return true;
	    }

	    if (!(obj instanceof JobList)) {
		return false;
	    }

	    JobList objJobList = (JobList) obj;

	    if(this.getLength() != (objJobList.getLength())) {
		return false;
	    }

	    for(int i = 0; i < this.getLength(); i++){
		if(!(getJob(i).equals(objJobList.getJob(i)))) {
		    return false;
		}
	    }
	
	    return true;
	}
    
    
	/**
	 * Returns the length of the JobList container cont.
	 *
	 * @return an <code>int</code> value
	 */
	public int getLength(){
	    return cont.size();
	}
    
    
	/**
	 * Returns a job object from the container cont.
	 *
	 * @param jobNo an <code>int</code> value
	 * @return a <code>Job</code> value
	 */
	public Job getJob(int jobNo){
	    return (Job) (cont.get(jobNo));
	}
    
    
	/**
	 * Adds a job object to the JobList's container cont.
	 *
	 * @param newJob a <code>Job</code> value
	 */
	public void addJob(Job newJob){
	    cont.add(newJob);
	}
    
	/**
	 * Removes a job object from the cont container at a certain index.
	 *
	 * @param jobNo an <code>int</code> value
	 */
	public void deleteJob(int jobNo){
	    cont.remove(cont.get(jobNo));
	}
    
	public int getJobID(int jobNo) throws RMIException {
	    int retVal = 0;
	    retVal = ((Job)cont.get(jobNo)).getID();
	
	    return retVal;
	}
    }
}
