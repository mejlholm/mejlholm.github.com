package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.function.*;
import dk.auc.cs.whiner.dataaccess.*;

import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.model.AnnouncedJobException;
import dk.auc.cs.whiner.rmi.RMIException;

import java.rmi.*;
import java.rmi.server.*;

import java.util.*;


/**
 * The "Headhunter" class manages the projects and jobs in the
 * system. It contains methods for the headhunter to manage project
 * creation and deletion. This class is inherited from the "User"
 * class.
 *
 * @
author <a href="mailto:carlsen@pico.cs.auc.dk">Jeppe Carlsen</a>
 * @author <a href="mailto:bennett@pico.cs.auc.dk">Anders Bennett</a>
 * @version 1.0
 */
public class Headhunter extends User implements HeadhunterI{
    private int id = 0;
    private String loginName = "";
    private String password = "";
    private ProjectList projects;
    
    //DAO objects
    private ProjectDAO projectDAO;
    private HeadhunterDAO headhunterDAO;

    public Headhunter() throws DAOException, RemoteException {
	projectDAO = new ProjectDAO();
	headhunterDAO = new HeadhunterDAO();
	projects = new ProjectList();
    }
    
    /**
     * Tests for equality between two objects of the "Headhunter" class. 
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj){
	if (this == obj) return true;
	if (!(obj instanceof Headhunter)) return false;
	Headhunter objHeadhunter = (Headhunter) obj;
	boolean result = false;
	try{
	    result =
		(this.id == objHeadhunter.getID()) &&
		((this.loginName).equals(objHeadhunter.getLoginName())) &&
		((this.password).equals(objHeadhunter.getPassword())) &&
		((this.projects).equals((ProjectList) objHeadhunter.getProjects()));
	} catch(RMIException e){
	    //
	}
	return result;
    }

    
    /**
     * Makes an instance of the "MatchList" class.
     *
     * @exception RemoteException if an error occurs
     * @exception DAOException if an error occurs
     */
    public void initializeProjectList()throws RemoteException, DAOException {
	projects = new ProjectList(id);
    }
    
    /**
     * Finds a job reqested for by the GUI, makes instances of its
     * jobs and returns the project to the GUI.
     *
     * @param projectNo an <code>int</code> value
     * @return a <code>Project</code> value
     * @exception RMIException if an error occurs
     * @exception DAOException if an error occurs
     */
    public ProjectI selectProject(int projectNo)throws RMIException, DAOException {
	Project selectedProject = (Project)getProject(projectNo);
	selectedProject.initializeJobList();
	return (ProjectI)selectedProject;
    }

    /**
     * Returns a project from the project list at index projectNo.
     *
     * @param projectNo an <code>int</code> value
     * @return a <code>Project</code> value
     * @exception RMIException if an error occurs
     */
    public ProjectI getProject(int projectNo)throws RMIException{
	return ((ProjectI)projects.getProject(projectNo));
    }

    /**
     * Returns the length of the container in the associated
     * ProjectList object.
     *
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public int getProjectListLength()throws RMIException{
	return projects.getLength();
    }

    /**
     * Creates a new project in the database, sets some default
     * attribute values and adds it to the container in ProjectList.
     *
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void createProject() throws DAOException, RMIException{
	Project newProject = null;
	newProject = projectDAO.add();
	newProject.setHeadhunterID(id);
	newProject.setStatus("filled");
	newProject.setTitle("New Project");
	newProject.setDescription("Enter description here");
	newProject.setDateOfCreation(new Date());
	projectDAO.update(newProject);
	projects.addProject(newProject);
    }


    /**
     * Deletes a project from the headhunter's ProjectList. Before
     * deleting a project, all jobs that are contained in the project
     * must be deleted.  This method makes sure that all contained
     * jobs' status are different from "announced". If an "announced"
     * job is contained, an exception will be thrown, and the project
     * will not be deleted, nor will any jobs in the project.
     *
     * @param projectNo an <code>int</code> value
     * @exception AnnouncedJobException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     * @exception RemoteException if an error occurs
     * @exception Exception if a contained jobs status is "announced"
     */
    public void deleteProject(int projectNo) throws AnnouncedJobException, DAOException, RMIException, RemoteException{
	Project delProject = projects.getProject(projectNo);
	delProject.initializeJobList();
	int jobListLength = delProject.getJobListLength();
	for(int i = 0; i < jobListLength; i++){
	    if(((delProject.getJob(i)).getStatus()).equals("announced")){
		throw new AnnouncedJobException();
	    }
	}
	for(int i = 0; i < jobListLength; i++)
	    delProject.deleteJob(0);
	projects.removeProject(projectNo);
	projectDAO.delete(delProject.getID());
    }
    
    
    /**
     * Deletes all the projects in the headhunter's ProjectList. Each
     * project is deleted by first closing all jobs in the project, so
     * that the deleteProject method won't throw it's exception.
     *
     * @exception AnnouncedJobException if an error occurs
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     * @exception CloseException if an error occurs
     * @exception RemoteException if an error occurs
     * @exception Exception if an error occurs
     */
    public void deleteAllProjects() throws AnnouncedJobException, RMIException, DAOException, CloseException, RemoteException{
	int projectListLength = projects.getLength();	
	Project project;	
	for(int i = 0; i < projectListLength; i++){
	    project = projects.getProject(0);
	    project.closeAllJobs();
	    deleteProject(0);
	}
    }
    
    
    //Inherited method
    
    /**
     * Changes the user password. The new password is set if the GUI
     * finds the new password acceptable in accordance with the
     * conditions the password must comply with.
     *
     * @param newPassword a <code>String</code> value
     * @exception RMIException if an error occurs
     */
    public void changePassword(String newPassword)throws RMIException, DAOException {
	setPassword(newPassword);
	headhunterDAO.update(this);
    }

    /* SET AND GET METHODS
       -------------------*/

    /**
     * Gets the value of id
     *
     * @return the value of id
     * @exception RMIException if an error occurs
     */
    public int getID()  throws RMIException{
	return this.id;
    }

    /**
     * Sets the value of ID
     *
     * @param argID Value to assign to this.id
     * @exception RMIException if an error occurs
     */
    public void setID(int argID) throws RMIException{
	this.id = argID;
    }

    /**
     * Gets the value of loginName
     *
     * @return the value of loginName
     * @exception RMIException if an error occurs
     */
    public String getLoginName()  throws RMIException{
	return this.loginName;
    }

    /**
     * Sets the value of loginName
     *
     * @param argLoginName Value to assign to this.loginName
     * @exception RMIException if an error occurs
     */
    public void setLoginName(String argLoginName) throws RMIException{
	this.loginName = argLoginName;
    }

    /**
     * Gets the value of password
     *
     * @return the value of password
     * @exception RMIException if an error occurs
     */
    public String getPassword()  throws RMIException{
	return this.password;
    }

    /**
     * Sets the value of password
     *
     * @param argPassword Value to assign to this.password
     * @exception RMIException if an error occurs
     */
    public void setPassword(String argPassword) throws RMIException{
	this.password = argPassword;
    }

    
    /**
     * Gets the value of projects
     *
     * @return the value of projects
     */
    public ProjectList getProjects()  {
	return this.projects;
    }

    /**
     * Sets the value of projects
     *
     * @param argProjects Value to assign to this.projects
     */
    public void setProjects(ProjectList argProjects) {
	this.projects = argProjects;
    }



       
/**
 * The "ProjectList" class has a container with the projects created
 * by the headhunter and has methods for accessing and manipulating
 * this container. This class is only used by the "Headhunter" class.
 *
 * @author <a href="mailto:carlsen@pico.cs.auc.dk">Jeppe Carlsen</a>
 * @author <a href="mailto:bennett@pico.cs.auc.dk">Anders Bennett</a>
 * @version 1.0
 */
private class ProjectList {
    private List cont = new ArrayList();
    
    //DAO objects
    private ProjectDAO projectDAO;

    /**
     * When an empty ProjectList attribute is needed.     
     *
     */
    public ProjectList() throws DAOException {
	projectDAO = new ProjectDAO();
    }
    
    /**
     * Gets all projects associated with the headhunter from the database.
     *
     * @param headhunterID an <code>int</code> value
     * @exception RemoteException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public ProjectList(int headhunterID) throws RemoteException, DAOException{
	projectDAO = new ProjectDAO();
	cont = projectDAO.getProjects(headhunterID);
	for(int i = 0; i < cont.size(); i++){
	    ((Project) cont.get(i)).isFilled();
	}
    }
    
    /**
     * Compares to objects for equality from the "ProjectList" class
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj){
	boolean result = true;
	
	if (this == obj) return true;
	if (!(obj instanceof ProjectList)) return false;
	ProjectList objProjectList = (ProjectList) obj;
	if(this.getLength() != (objProjectList.getLength())) return false;
	for(int i = 0; i < this.getLength(); i++){
	    if(!(getProject(i).equals(objProjectList.getProject(i))))
		return false;
	}
	return true;
    }

    /**
     * Returns a project object from the container cont.
     *
     * @param projectNo an <code>int</code> value
     * @return a <code>Project</code> value
     */
    public Project getProject(int projectNo){
	return (Project)cont.get(projectNo);
    }
    
    /**
     * Returns the length of the ProjectList container cont.
     *
     * @return an <code>int</code> value
     */
    public int getLength(){
	return cont.size();
    }
        
    /**
     * Adds a project object to the ProjectList's container cont.
     *
     * @param newProject a <code>Project</code> value
     */
    public void addProject(Project newProject){
	cont.add(newProject);
    }

    /**
     * Removes a project object from the cont container at a certain index.
     *
     * @param projectNo an <code>int</code> value
     */
    public void removeProject(int projectNo){
	cont.remove(cont.get(projectNo));
    }
}
}
