package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.function.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.rmi.RMIException;

import java.util.*;
import java.util.Date;

import java.rmi.*;
import java.rmi.server.*;

/**
 * The "Job" class is responsible for maintaining the list of qualifications and
 * the applications related to it. ApplicationList attribute makes it possible
 * for the methods in the class to access the related applications, which lie in
 * a container in the "ApplicationList" class.
 *
 * @author <a href="mailto:carlsen@pico.cs.auc.dk">Jeppe Carlsen</a>
 * @version 1.0
 */


public class Job extends UnicastRemoteObject implements JobI{
    private int id = 0;
    private int projectID = 0;
    private Date dateOfAnnouncement = new Date(0);
    private Date dateOfOccupation = new Date(0);
    private Date dateOfCreation = new Date(0);
    private String status = "";
    private String title = "";
    private String description = "";
    private JobApplicationList applications;
    private JobQualificationList requirements;
    private GlobalQualificationList globalQualifications;

    //DAO objects   
    private ApplicantDAO applicantDAO;
    private ApplicationDAO applicationDAO;
    private JobDAO jobDAO;
    private QualificationDAO qualificationDAO;
    private ProjectDAO projectDAO;


    /**
     * Initializes dataaccess objects and list objects.
     *
     * @exception RemoteException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public Job() throws RemoteException, DAOException{
	applicantDAO = new ApplicantDAO();
	applicationDAO = new ApplicationDAO();
	jobDAO = new JobDAO();
	projectDAO = new ProjectDAO();
	qualificationDAO = new QualificationDAO();
	applications = new JobApplicationList();
	requirements = new JobQualificationList();
	//	globalQualifications = new GlobalQualificationList();
    }
    

    /**
     * Tests for equality between two objects of the "Job" class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj){
	if (this == obj) return true;
	if (!(obj instanceof Job)) return false;
	Job objJob = (Job) obj;
	boolean result = false;
	try{
	    result =
		(this.id == objJob.getID()) &&
		(this.projectID == objJob.getProjectID()) &&
		// ((this.dateOfCreation).equals(objJob.getDateOfCreation())) &&
		// ((this.dateOfAnnouncement).equals(objJob.getDateOfAnnouncement())) &&
		// ((this.dateOfOccupation).equals(objJob.getDateOfOccupation())) &&
		((this.status).equals(objJob.getStatus())) &&
		((this.title).equals(objJob.getTitle())) &&
		((this.description).equals(objJob.getDescription())) &&
		((this.applications).equals((JobApplicationList) objJob.getApplications())) &&
		((this.requirements).equals((JobQualificationList) objJob.getRequirements()));
	    //globalQualification is not included because its not 'a part' of a job.
	} catch(RMIException e){
	    //Do din mor
	}
	return result;
    }


    /**
     * Initializes the job's local requirement list.
     *
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public void initializeJobQualificationList() throws RMIException, DAOException {
	requirements = new JobQualificationList(id);
    }

    /**
     * Initializes the global qualification list.
     *
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void initializeGlobalQualificationList() throws DAOException, RMIException{
	try {
	    globalQualifications = new GlobalQualificationList();
	} catch (RemoteException e) {
	    throw new RMIException();
	}
    }

    /**
     * Initializes the job's application list.
     *
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void initializeJobApplicationList() throws DAOException, RMIException{
	applications = new JobApplicationList(id);
    }

    /**
     * Returns an application object to the client.
     *
     * @param applicationNo an <code>int</code> value
     * @return an <code>Application</code> value
     * @exception RMIException if an error occurs
     */
    public ApplicationI selectApplication(int applicationNo) throws RMIException{
	return (ApplicationI)getApplication(applicationNo);
    }

    /**
     * Garbage collects the applications and requirements related to the job,
     * along with the global qualification list, once this job is deselected.
     *
     * @exception RMIException if an error occurs
     */
    public void deselectJob() throws RMIException{
	applications = null;
	requirements = null;
	globalQualifications = null;
    }

    /**
     * Returns an application from its application number.
     *
     * @param applicationNo an <code>int</code> value
     * @return an <code>Application</code> value
     * @exception RMIException if an error occurs
     */
    public ApplicationI getApplication(int applicationNo) throws RMIException{
	return ((ApplicationI)applications.getApplication(applicationNo));
    }


    /**
     * Returns the parent-project of this Job.
     *
     * @return a <code>Project</code> value
     * @exception DAOException if an error occurs
     * @exception RMIException if a dataaccess error occurs
     */
    public ProjectI getProject() throws DAOException, RMIException{
	return ((ProjectI)projectDAO.getProject(this.projectID));
    }



    /**
     * Returns an application from its application number.
     *
     * @param requirementNo an <code>int</code> value
     * @return an <code>Application</code> value
     * @exception RMIException if an error occurs
     */
    public SkillLevelI getRequirement(int requirementNo) throws RMIException{
	return (SkillLevelI)requirements.getSkillLevel(requirementNo);
    }

    /**
     * Returns a qualification object from the global qualification list.
     *
     * @param qualNo an <code>int</code> value
     * @return a <code>Qualification</code> value
     * @exception RMIException if an error occurs
     */
    public QualificationI getGlobalQualification(int qualNo) throws RMIException{
	return ((QualificationI)globalQualifications.getQualification(qualNo));
    }

    /**
     * Returns the length of the JobApplicationList. 
     * Needed by the Project class, and by the client.
     *
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public int getJobApplicationListLength() throws RMIException{
	return applications.getLength();
    }
    
    /**
     * Returns the length of the JobQualificationList. 
     * Needed by the client.
     *
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public int getJobQualificationListLength() throws RMIException{
	return requirements.getLength();
    }

    /**
     * Returns the length of the GlobalQualificationList. 
     * Needed by the client.
     *
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public int getGlobalQualificationListLength() throws RMIException{
	return globalQualifications.getLength();
    }


    /**
     * Adds a requirement from the global qualification list to the job's local requirement list. 
     *
     * @param globalQualificationNo an <code>int</code> value
     * @param level an <code>int</code> value
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     * @exception RemoteException if an error occurs
     */
    public void addRequirement(int globalQualificationNo, int level) throws RMIException, DAOException, RemoteException{
	Qualification qual = (Qualification)globalQualifications.getQualification(globalQualificationNo);
	requirements.addQualification(qual, level);
    }


    /**
     * Removes a requirement from the job's local requirement list.
     *
     * @param qualificationNo an <code>int</code> value
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public void removeRequirement(int qualificationNo) throws RMIException, DAOException{
	requirements.removeRequirement(qualificationNo);
    }

    /**
     * Saves the changes made to this job object.
     *
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void save() throws DAOException, RMIException{
	jobDAO.update(this);
    }

    /**
     * Saves the changes made to the list of requirements. Is invoked
     * when the headhunter chooses "save" in his GUI.
     *
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void saveRequirements() throws DAOException, RMIException{
	requirements.save();
	//PerformMatch.matchJob(id);    
    }
    


    /**
     * Reopens a closed or cancelled job.
     * @exception DAOException if a dataaccess error occurs
     * @exception RemoteException if an error occurs
     * @exception ReopenException if the job's status is "not
     * announced" or "announced" the job cannot be reopened
     */
    public void reopen() throws DAOException, RemoteException, ReopenException{
	if(status.equals("not announced") || status.equals("announced")){
	    throw new ReopenException();
	}
	setStatus("not announced");
	save();
    }
    
    /**
     * Sets the job's attribute status to "closed" and invokes the method
     * rejectApplicant for all applicants who have submitted applications to
     * this job.
     *
     * @exception RemoteException if an error occurs
     * @exception DAOException if an error occurs
     * @exception CloseException if the job is not announced it cannot
     * be closed
     */
    public void close()  throws RemoteException, DAOException, CloseException{
	if(!(status.equals("announced"))){
	    throw new CloseException();
	}
	setStatus("closed");
	jobDAO.update(this);
	for(int i = 0; i < applications.getLength(); i++){
	    rejectApplication(i);
	}
	
	Project p = (Project)getProject();
	p.isFilled();
    }
    
    /**
     * Sets the job's attribute status to "occupied" and invokes the
     * method rejectApplicant for all applicants who have submitted
     * applications to this job. However, we have to prevent the
     * applicant who gets hired for the job from getting a
     * notification saying "application rejected". Therefore, we
     * extract him from the JobApplicationList via the application's
     * applicantID and removes him from the list.
     *
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public void occupy()  throws RMIException, DAOException{
	setStatus("occupied"); 
	setDateOfOccupation(new Date());
	jobDAO.update(this);
	for(int i = 0; i < applications.getLength(); i++)
	    rejectApplication(i);
   }
    
    /**
     * Gets the application related to the applicant in question by
     * the application's id, from where the applicant can be
     * retrieved. The applicant object, along with its related CV and
     * application, gets stored in a different system. This is
     * currently not implemented. Therefore, the applicant object with
     * CV and application get deleted from the database instead.
     *
     * @param applicationID an <code>int</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     * @exception HireException if the job is not announced an applicant cannot be hired for the job
     */
    public void hireApplicant(int applicationNo) throws DAOException, RemoteException, HireException{
	initializeJobApplicationList();
	Application application = applications.getApplication(applicationNo);
	if(!((application.getStatus()).equals("submitted"))){
	    throw new HireException();
	}
	Applicant storeApplicant = applicantDAO.getApplicant(application.getApplicantID());
	
	//Here should the applicant.storeApplicant() method be
	//invoked to store the applicant, his application (at
	//applicationNo) and his CV in a seperate database for hired
	//applicants.
	deleteApplication(applicationNo);
	storeApplicant.deleteApplicant();
	occupy();
	
    }

    /**
     * Creates a new application and sets the relevant attributes to default
     * values.
     *
     * @param applicantID an <code>int</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     * @exception AlreadyAppliedException if an error occurs
     * @exception RemoteException if an error occurs
     */
    public void createApplication(int applicantID) throws DAOException, RMIException, AlreadyAppliedException, RemoteException{
	acceptApplication(applicantID);

	Application newApplication = applicationDAO.add();
	newApplication.setJobID(id);
	newApplication.setApplicantID(applicantID);
	newApplication.setStatus("incomplete");
       	newApplication.setBodyText("Enter text here");
	newApplication.setDateOfCreation(new Date());
	applicationDAO.update(newApplication);
	applications.addApplication(newApplication);
    }

    /**
     * Check whether an application can be accepted. Depends on if the
     * applicant have already a submitted application to the job.
     *
     * @param applicantID an <code>int</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     * @exception AlreadyAppliedException if an error occurs
     * @exception RemoteException if an error occurs
     */
    private void acceptApplication(int applicantID) throws DAOException, RMIException, AlreadyAppliedException, RemoteException{
	initializeJobApplicationList();
	for(int i = 0; i < getJobApplicationListLength(); i++){
	    if(getApplication(i).getApplicantID() == applicantID){
		throw new AlreadyAppliedException();
	    }
	}
    }


    /**
     * Deletes an application if the application's status is not
     * "submitted".  Invokes the deleteApplication method to make the
     * actual deletion of the application.
     *
     * @param applicationNo an <code>int</code> value
     * @exception DAOException if an error occurs
     * @exception RMIException if an error occurs
     * @exception DeleteException if an error occurs
     * @exception RemoteException if an error occurs
     */
    public void deleteApplicationIfNotSubmitted(int applicationNo) throws DAOException, RMIException, DeleteException, RemoteException{
	if(((getApplication(applicationNo)).getStatus()).equals("submitted")){
	    throw new DeleteException();
	}
	deleteApplication(applicationNo);
    }

    /**
     * Deletes an application from the JobApplicationList and deletes
     * it physically from the database as well. Notifies the applicant
     * about the deletion of his or hers application.
     *
     * @param applicationNo an <code>int</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     * @exception DeleteException if the application is announced it must be rejected before deletion
     */
    protected void deleteApplication(int applicationNo) throws DAOException, RMIException{
	Application app = applications.getApplication(applicationNo);	
	Notify.makeNotification(app.getApplicantID(), id, "Application deleted");
	applicationDAO.delete(app.getID());
	applications.deleteApplication(applicationNo);
    }


    /**
     * Rejects an application from the JobApplicationList, if the
     * application's attribute status is "submitted", and notifies the
     * applicant who submitted it about the rejection.
     *
     * @param applicationNo an <code>int</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     * @see dk.auc.cs.whiner.model.Application#reject()
     */
    public void rejectApplication(int applicationNo)  throws DAOException, RMIException{
	Application app = applications.getApplication(applicationNo);
	app.reject();
    }
    
    
    /**
     * Creates a new qualification and adds it to the global qualification list. 
     *
     * @param argName a <code>String</code> value
     * @param argDescription a <code>String</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void createQualification(String argName, String argDescription) throws DAOException, RMIException{
	globalQualifications.createQualification(argName, argDescription);
    }
    
    /**
     * Deletes a global qualification from the database. The DAO object throws
     * an exception if the qualification cannot be deleted because it is used by
     * a job in the system.
     *
     * @param globalQualificationNo an <code>int</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void deleteQualification(int globalQualificationNo) throws DAOException, RMIException{
	globalQualifications.deleteQualification(globalQualificationNo);
    }
    

    /* SET AND GET METHODS
       ---------------------*/
    
    /**
     * Gets the value of id
     *
     * @return the value of id
     * @exception RMIException if an error occurs
     */
    public int getID()  throws RMIException {
	return this.id;
    }
    
    /**
     * Sets the value of id
     *
     * @param argID Value to assign to this.id
     * @exception RMIException if an error occurs
     */
    public void setID(int argID)  throws RMIException{
	this.id = argID;
    }
    
    /**
     * Gets the value of projectID
     *
     * @return the value of projectID
     * @exception RMIException if an error occurs
     */
    public int getProjectID()   throws RMIException{
	return this.projectID;
    }
    
    /**
     * Sets the value of projectID
     *
     * @param argProjectID Value to assign to this.projectID
     * @exception RMIException if an error occurs
     */
    public void setProjectID(int argProjectID)  throws RMIException{
	this.projectID = argProjectID;
    }
    
    /**
     * Gets the value of dateOfAnnouncement
     *
     * @return the value of dateOfAnnouncement
     * @exception RMIException if an error occurs
     */
    public Date getDateOfAnnouncement()   throws RMIException{
	return this.dateOfAnnouncement;
    }
    
    /**
     * Sets the value of dateOfAnnouncement
     *
     * @param argDateOfAnnouncement Value to assign to this.dateOfAnnouncement
     * @exception RMIException if an error occurs
     */
    public void setDateOfAnnouncement(Date argDateOfAnnouncement) throws RMIException {
	this.dateOfAnnouncement = argDateOfAnnouncement;
    }
    
    /**
     * Gets the value of dateOfOccupation
     *
     * @return the value of dateOfOccupation
     * @exception RMIException if an error occurs
     */
    public Date getDateOfOccupation() throws RMIException{
	return this.dateOfOccupation;
    }
    
    /**
     * Sets the value of dateOfOccupation
     *
     * @param argDateOfOccupation Value to assign to this.dateOfOccupation
     * @exception RMIException if an error occurs
     */
    public void setDateOfOccupation(Date argDateOfOccupation) throws RMIException {
	this.dateOfOccupation = argDateOfOccupation;
    }
    
    /**
     * Gets the value of dateOfCreation
     *
     * @return the value of dateOfCreation
     * @exception RMIException if an error occurs
     */
    public Date getDateOfCreation()  throws RMIException {
	return this.dateOfCreation;
    }
    
    /**
     * Sets the value of dateOfCreation
     *
     * @param argDateOfCreation Value to assign to this.dateOfCreation
     * @exception RMIException if an error occurs
     */
    public void setDateOfCreation(Date argDateOfCreation) throws RMIException {
	this.dateOfCreation = argDateOfCreation;
    }
    
    /**
     * Gets the value of status
     *
     * @return the value of status
     * @exception RMIException if an error occurs
     */
    public String getStatus()  throws RMIException {
	return this.status;
    }
    
    /**
     * Sets the value of status
     *
     * @param argStatus Value to assign to this.status
     * @exception RMIException if an error occurs
     */
    public void setStatus(String argStatus) throws RMIException {
	this.status = argStatus;
    }
    
    /**
     * Gets the value of title
     *
     * @return the value of title
     * @exception RMIException if an error occurs
     */
    public String getTitle()  throws RMIException {
	return this.title;
    }
    
    /**
     * Sets the value of title
     *
     * @param argTitle Value to assign to this.title
     * @exception RMIException if an error occurs
     */
    public void setTitle(String argTitle)  throws RMIException{
	this.title = argTitle;
    }
    
    /**
     * Gets the value of description
     *
     * @return the value of description
     * @exception RMIException if an error occurs
     */
    public String getDescription()   throws RMIException{
	return this.description;
    }
    
    /**
     * Sets the value of description
     *
     * @param argDescription Value to assign to this.description
     * @exception RMIException if an error occurs
     */
    public void setDescription(String argDescription)  throws RMIException{
	this.description = argDescription;
    }
    
    
    /**
     * Gets the value of applications
     *
     * @return the value of applications
     */
    public JobApplicationList getApplications()  {
	return this.applications;
    }

    /**
     * Sets the value of applications
     *
     * @param argApplications Value to assign to this.applications
     */
    public void setApplications(JobApplicationList argApplications) {
	this.applications = argApplications;
    }

    /**
     * Gets the value of requirements
     *
     * @return the value of requirements
     */
    public JobQualificationList getRequirements()  {
	return this.requirements;
    }

    /**
     * Sets the value of requirements
     *
     * @param argRequirements Value to assign to this.requirements
     */
    public void setRequirements(JobQualificationList argRequirements) {
	this.requirements = argRequirements;
    }

    /**
     * Gets the value of globalQualifications
     *
     * @return the value of globalQualifications
     */
    public GlobalQualificationList getGlobalQualifications()  {
	return this.globalQualifications;
    }

    /**
     * Sets the value of globalQualifications
     *
     * @param argGlobalQualifications Value to assign to this.globalQualifications
     */
    public void setGlobalQualifications(GlobalQualificationList argGlobalQualifications) {
	this.globalQualifications = argGlobalQualifications;
    }

    
    /**
     * Has a container with the applications related to the individual
     * job and methods for accessing and manipulating with these
     * applications. Is used by the "Job" class.
     *
     * @author <a href="mailto:bennett@fatboy"></a>
     * @version 1.0
     */
    private class JobApplicationList{
	private List cont = new ArrayList();
	
	//DAO objects
	private ApplicationDAO applicationDAO;
	
	/**
	 * Gets all applications associated with the job from the database.    
	 *
	 * @param jobID an <code>int</code> value
	 * @exception DAOException if a dataaccess error occurs
	 * @exception RMIException if an error occurs
	 */
	public JobApplicationList(int jobID) throws DAOException, RMIException{
	    List tempCont = new ArrayList();
	    applicationDAO = new ApplicationDAO();
	    
	    cont = applicationDAO.getApplicationsFromJobID(jobID);
	    
	     tempCont = applicationDAO.getApplicationsFromJobID(jobID);
	     cont = removeIncompleteApplications(tempCont);
	     //sortApplicationsByScore();
	}
	
	/**
	 * Is invoked when an empty JobApplicationList attribute is needed.
	 *
	 * @exception DAOException if a dataaccess error occurs
	 */
	public JobApplicationList() throws DAOException{
	    applicationDAO = new ApplicationDAO();    
	}
	
	
	/**
	 * Removes incomplete applicatoins, so they arent presented
	 * for the headhunter.
	 *
	 * @param tempList a <code>List</code> value
	 * @return a <code>List</code> value
	 * @exception RMIException if an error occurs
	 */
	private List removeIncompleteApplications(List tempList) throws RMIException{
	    for(int i = 0; i < tempList.size(); i++){
		Application app = (Application) tempList.get(i);
		if ((app.getStatus()).equals("incomplete")){
		    tempList.remove(app);
		    i--;
		}
	    }
	    return tempList;
	}

	
	/**
	 * Bubblesorts the applications by the match requirements
	 * scores.
	 *
	 * @exception DAOException if a dataaccess error occurs
	 * @exception RMIException if an error occurs
	 */
	private void sortApplicationsByScore() throws DAOException, RMIException{
	    for (int i = 0; i < cont.size()-1; i++){
		for(int j = 0; j < cont.size()-i-1; j++){
		    int score1 = getApplication(j).findRequirementScore();
		    int score2 = getApplication(j+1).findRequirementScore();
		    if (score1<score2)
			Collections.swap(cont, j, j + 1);
		}
	    }
	}

	public boolean equals(Object obj){
	    if (this == obj) 
		return true;
	    if (!(obj instanceof JobApplicationList)) 
		return false;
	    JobApplicationList objAppList = (JobApplicationList) obj;
	    if(this.getLength() != (objAppList.getLength())) 
		return false;
	    for(int i = 0; i < this.getLength(); i++){
		if(!(getApplication(i).equals(objAppList.getApplication(i))))
		    return false;
	    }
	    return true;
	}
	
	/**
	 * Calculates the size of the container cont.
	 *
	 * @return an <code>int</code> value
	 */
	public int getLength(){
	    return cont.size();
	}
    
	/**
	 * Adds an application object to the cont container.
	 *
	 * @param argApplication an <code>Application</code> value
	 */
	public void addApplication(Application argApplication){
	    cont.add(argApplication);
	}
	
	/**
	 * Removes an application from the cont container.
	 *
	 * @param applicationNo an <code>int</code> value
	 */
	public void deleteApplication(int applicationNo){	
	    cont.remove(cont.get(applicationNo));
	}
	
	/**
	 * Returns an application object from the container cont.
	 *
	 * @param applicationNo an <code>int</code> value
	 * @return an <code>Application</code> value
	 */
	public Application getApplication(int applicationNo){
	    return (Application)(cont.get(applicationNo));
	}
	
	
	/**
	 * Gets an application by its ID.
	 *
	 * @param applicationID an <code>int</code> value
	 * @return an <code>int</code> value
	 * @exception DAOException if a dataaccess error occurs
	 * @exception RMIException if an error occurs
	 */
	public Application getApplicationByID(int applicationID) throws DAOException, RMIException {
	    Application application = null;
	    for(int i = 0; i < cont.size(); i++){
		application = (Application) cont.get(i);
		if(application.getID() == applicationID); 		
	    } 
	    
	    return application;
	}
	
	
	/**
	 * Gets the id of the application at index equals applicationNo in the
	 * contJobQualifications container in the JobQualificationList.
	 *
	 * @param applicationNo an <code>int</code> value
	 * @return an <code>int</code> value
	 * @exception RMIException if an error occurs
	 */
	public int getApplicationID(int applicationNo) throws RMIException {
	    int result = 0;
	    result = ((Application) cont.get(applicationNo)).getID();
	    
	    return result;
	}
    }
    
    /**
     * Contains attributes and methods for maintaining a list of
     * qualifications. Is used by the "Job" class.
     *
     * @author <a href="mailto:carlsen@flatboy"></a>
     * @version 1.0
     */
    private class JobQualificationList{
	private List contJobQualifications = new ArrayList();
	private List contAddTemp  = new ArrayList();
	private List contRemoveTemp  = new ArrayList();
	private int jobID = -1; //used when storing to the database.
	
	//DAO objects
	JobDAO jobDAO;
	
	/**
	 * When an empty JobQualificationList attribute is needed.
	 *
	 * @exception DAOException if a dataaccess error occurs
	 */
	public JobQualificationList() throws DAOException{
	    jobDAO = new JobDAO();    
	}
	
	/**
	 * Creates a new "JobQualificationList" instance, and gets the skill-level
	 * objects for the contJobQualifications container from the database.
	 *
	 * @param argJobID an <code>int</code> value
	 * @exception DAOException if a dataaccess error occurs
	 */
	public JobQualificationList(int argJobID) throws DAOException{
	    jobDAO = new JobDAO();
	    contJobQualifications = jobDAO.getSkillLevels(argJobID); //NOTE: returnerer JobSkill objekter
	    jobID = argJobID;
	    contAddTemp = new ArrayList();
	    contRemoveTemp = new ArrayList();
	}
	
	/**
	 * Compares to objects for equality from the "JobQualificationList" class
	 *
	 * @param obj an <code>Object</code> value
	 * @return a <code>boolean</code> value
	 */
	public boolean equals(Object obj){
	    boolean result = true;
	    if (this == obj) return true;
	    if (!(obj instanceof JobQualificationList)) return false;
	    JobQualificationList objQualList = (JobQualificationList) obj;
	    if(this.getLength() != (objQualList.getLength())) return false;
	    for(int i = 0; i < this.getLength(); i++){
		if(!(getSkillLevel(i).equals(objQualList.getSkillLevel(i))))
		    return false;
	    }
	    return true;
	}
	
	
	/**
	 * 
	 * Invokes the fixTempLists method to fix a possible redundancy of
	 * an object (cf. fixTempList method for further information) and
	 * saves the edited job-qualification list in the database. This
	 * method is handy because we want the user to be able to cancel
	 * the changes made to the qualification-list, which is simply
	 * done by NOT invoking this method when the qualification-list
	 * has been edited.
	 *
	 * @exception DAOException if a dataaccess error occurs
	 */
	public void save() throws DAOException{
	    fixTempLists();
	    for(int i = 0; i < contAddTemp.size(); i++){
		SkillLevel skill = (SkillLevel) contAddTemp.get(i);
		jobDAO.insertSkillLevel(skill);
		contJobQualifications.add(skill);
	    }
	    contAddTemp = new ArrayList();
	    for(int i = 0; i < contRemoveTemp.size(); i++){
		SkillLevel skill = (SkillLevel) contRemoveTemp.get(i);
		jobDAO.deleteSkillLevel(skill);
		contJobQualifications.remove(skill);
	    }
	    contRemoveTemp = new ArrayList();
	}
	
	/**
	 * Adds a skill-level object to the job-qualification list.
	 *
	 * @param argQual a <code>Qualification</code> value
	 * @param level an <code>int</code> value
	 */
	public void addQualification(Qualification argQual, int level){
	    SkillLevel newSkillLevel = null;
	    try{
		newSkillLevel = new SkillLevel();
		newSkillLevel.setQualification(argQual);
		newSkillLevel.setLevel(level);
		newSkillLevel.setID(jobID);
	    } catch (Exception e) {
		//RMIException
	    }
	    contAddTemp.add(newSkillLevel);
	}
	
	
	
	/**
	 * Removes a skill-level object from the job-qualification list.
	 *
	 * @param qualificationNo an <code>int</code> value
	 */
	public void removeRequirement(int qualificationNo){
	    contRemoveTemp.add(contJobQualifications.get(qualificationNo));
	}
	
	
	/**
	 * Runs through contAddTemp for each object in conRemoveTemp to
	 * check whether or not the same object is added to both
	 * containers. The problem is this: If an applicant adds a
	 * skill-level object to the conAddTemp container, then decides to
	 * remove it and thereby adding it to the contRemoveTemp
	 * container, and once again changes his mind and adds it to the
	 * contAddTemp container, the same object will be contained twice
	 * in contAddTemp and once in the contRemoveTemp
	 * container. Therefore, it is necessary to run through all
	 * objects in one of the containers for each object in the other
	 * container to remove the redundant object.
	 *
	 */
	public void fixTempLists(){
	    for (int i = 0; i < contRemoveTemp.size(); i++){
		for (int j = 0; j < contAddTemp.size(); j++){
		    if ((contRemoveTemp.get(i)).equals(contAddTemp.get(j))){
			contRemoveTemp.remove(contRemoveTemp.get(i));
			contAddTemp.remove((contRemoveTemp.get(j)));
			i--;    //Is necessary, or else an element would be skipped!
			break;
		    }
		}
	    }
	}
	
	/**
	 * Gets a skill-level object from the contJobQualifications container.
	 *
	 * @param qualNo an <code>int</code> value
	 * @return a <code>Qualification</code> value
	 */
	public SkillLevel getSkillLevel(int skillNo){
	    return (SkillLevel) contJobQualifications.get(skillNo);
	}
	
	
	
	/**
	 * Calculates the size of the container contJobQualifications.
	 *
	 * @return an <code>int</code> value
	 */
	public int getLength(){
	    return contJobQualifications.size();
	}
    }
}
