package dk.auc.cs.whiner.model;

/* Simple exception class - basically just renaming... */


public class AlreadyAppliedException extends Exception {
 
    public AlreadyAppliedException(){
	super("Unknown exception");
    }

    public AlreadyAppliedException(String msg){
	super(msg);
    }

    public AlreadyAppliedException(String msg, Throwable cause){
	super(msg, cause);
    }

}
