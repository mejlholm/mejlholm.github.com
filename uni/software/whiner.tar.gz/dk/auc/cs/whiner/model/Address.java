package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.function.*;
import java.util.*;
import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.*;
import java.rmi.server.*;


/**
 * The "Address" class holds information on an applicant's residence(s).
 *
 * @author <a href="mailto:bennett@flatboy"></a>
 * @version 1.0
 */
public class Address extends UnicastRemoteObject implements AddressI{
    private String address1 = "";
    private String address2 = "";
    private String city = "";    
    private int postCode = 0;
    private String region = "";
    private String country = "";

    public Address() throws RemoteException{

    }

    /**
     * Tests for equality between two objects of the "Address" class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     * @exception RMIException if an error occurs
     */
    public boolean equals(Object obj){
	if(this == obj) 
	    return true;
	if(!(obj instanceof Address)) 
	    return false;
	Address objAddress = (Address) obj;
	boolean result = false;
	try{
	    result = 
		((this.address1).equals(objAddress.getAddress1())) &&
		((this.address2).equals(objAddress.getAddress2())) &&
		((this.city).equals(objAddress.getCity())) &&
		(this.postCode == objAddress.getPostCode()) &&
		((this.region).equals(objAddress.getRegion())) &&
		((this.country).equals(objAddress.getCountry())) ;
	} catch(RMIException e){
	    //do nothing, just for the test!
	}
	return result;
    }
    
    
    /*SET AND GET METHODS
      -------------------*/

    /**
     * Gets the value of address1
     *
     * @return the value of address1
     * @exception RMIException if an error occurs
     */
    public String getAddress1() throws RMIException {
	return this.address1;
    }

    /**
     * Sets the value of address1
     *
     * @param argAddress1 Value to assign to this.address1
     * @exception RMIException if an error occurs
     */
    public void setAddress1(String argAddress1) throws RMIException{
	this.address1 = argAddress1;
    }

    /**
     * Gets the value of address2
     *
     * @return the value of address2
     * @exception RMIException if an error occurs
     */
    public String getAddress2() throws RMIException {
	return this.address2;
    }

    /**
     * Sets the value of address2
     *
     * @param argAddress2 Value to assign to this.address2
     * @exception RMIException if an error occurs
     */
    public void setAddress2(String argAddress2) throws RMIException{
	this.address2 = argAddress2;
    }

    /**
     * Gets the value of city
     *
     * @return the value of city
     * @exception RMIException if an error occurs
     */
    public String getCity() throws RMIException {
	return this.city;
    }

    /**
     * Sets the value of city
     *
     * @param argCity Value to assign to this.city
     * @exception RMIException if an error occurs
     */
    public void setCity(String argCity) throws RMIException {
	this.city = argCity;
    }

    /**
     * Gets the value of postcode
     *
     * @return the value of postcode
     * @exception RMIException if an error occurs
     */
    public int getPostCode()  throws RMIException{
	return this.postCode;
    }

    /**
     * Sets the value of postcode
     *
     * @param argPostcode Value to assign to this.postcode
     * @exception RMIException if an error occurs
     */
    public void setPostCode(int argPostcode) throws RMIException{
	this.postCode = argPostcode;
    }

    /**
     * Gets the value of region
     *
     * @return the value of region
     * @exception RMIException if an error occurs
     */
    public String getRegion() throws RMIException {
	return this.region;
    }

    /**
     * Sets the value of region
     *
     * @param argRegion Value to assign to this.region
     * @exception RMIException if an error occurs
     */
    public void setRegion(String argRegion) throws RMIException{
	this.region = argRegion;
    }

    /**
     * Gets the value of country
     *
     * @return the value of country
     * @exception RMIException if an error occurs
     */
    public String getCountry()  throws RMIException{
	return this.country;
    }

    /**
     * Sets the value of country
     *
     * @param argCountry Value to assign to this.country
     * @exception RMIException if an error occurs
     */
    public void setCountry(String argCountry) throws RMIException{
	this.country = argCountry;
    }
}
