package dk.auc.cs.whiner.model;

/* Simple exception class - basically just renaming... */


public class HireException extends Exception {
    
    private int type = 0;

    public HireException(){
	super("Unknown exception");
    }

    public HireException(String msg){
	super(msg);
    }

    public HireException(String msg, Throwable cause){
	super(msg, cause);
    }

}
