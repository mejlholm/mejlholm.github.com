package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.function.*;
import java.util.*;
import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.*;
import java.rmi.server.*;



/**
 * The "PhoneNumber" class holds information on an applicant's phone
 * number(s).
 *
 * @author <a href="mailto:bennett@pico.cs.auc.dk">Anders Bennett-Therkildsen</a>
 * @version 1.0
 */
public class PhoneNumber extends UnicastRemoteObject implements PhoneNumberI{
    private int homePhone = 0;
    private int workPhone = 0;
    private int mobile = 0;
    private int fax = 0;

    public PhoneNumber() throws RemoteException{

    }
    /**
     * Tests for equality between two objects of the "PhoneNumber" class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     * @exception RMIException if an error occurs
     */
    public boolean equals(Object obj){
	if(this == obj) 
	    return true;
	if(!(obj instanceof PhoneNumber)) 
	    return false;
	PhoneNumber objPhone = (PhoneNumber) obj;
	boolean result = false;
	try{	
	    result = 
	    (this.homePhone == objPhone.getHomePhone()) &&
	    (this.workPhone == objPhone.getWorkPhone()) &&
	    (this.mobile == objPhone.getMobile()) &&
	    (this.fax == objPhone.getFax()) ;
	} catch(RMIException e){
	    //do nothing, just for the test!
	}
	return result;
    }
    
	
    /*SET AND GET METHODS
      -------------------*/
    
    
    /**
     * Gets the value of homePhone
     *
     * @return the value of homePhone
     * @exception RMIException if an error occurs
     */
    public int getHomePhone() throws RMIException{
	return this.homePhone;
    }


    /**
     * Sets the value of homePhone
     *
     * @param argHomePhone Value to assign to this.homePhone
     * @exception RMIException if an error occurs
     */
    public void setHomePhone(int argHomePhone) throws RMIException{
	this.homePhone = argHomePhone;
    }


    /**
     * Gets the value of workPhone
     *
     * @return the value of workPhone
     * @exception RMIException if an error occurs
     */
    public int getWorkPhone()throws RMIException{
	return this.workPhone;
    }


    /**
     * Sets the value of workPhone
     *
     * @param argWorkPhone Value to assign to this.workPhone
     * @exception RMIException if an error occurs
     */
    public void setWorkPhone(int argWorkPhone)throws RMIException{
	this.workPhone = argWorkPhone;
    }


    /**
     * Gets the value of mobilePhone
     *
     * @return the value of mobilePhone
     * @exception RMIException if an error occurs
     */
    public int getMobile()throws RMIException{
	return this.mobile;
    }


    /**
     * Sets the value of mobilePhone
     *
     * @param argMobile Value to assign to this.mobilePhone
     * @exception RMIException if an error occurs
     */
    public void setMobile(int argMobile)throws RMIException{
	this.mobile = argMobile;
    }


    /**
     * Gets the value of fax
     *
     * @return the value of fax
     * @exception RMIException if an error occurs
     */
    public int getFax()throws RMIException{
	return this.fax;
    }


    /**
     * Sets the value of fax
     *
     * @param argFax Value to assign to this.fax
     * @exception RMIException if an error occurs
     */
    public void setFax(int argFax)throws RMIException{
	this.fax = argFax;
    }
    
}
