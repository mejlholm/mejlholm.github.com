package dk.auc.cs.whiner.model;

/* Simple exception class - basically just renaming... */


public class ReopenException extends Exception {
    
    private int type = 0;

    public ReopenException(){
	super("Unknown exception");
    }

    public ReopenException(String msg){
	super(msg);
    }

    public ReopenException(String msg, Throwable cause){
	super(msg, cause);
    }

}
