package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.function.*;
import dk.auc.cs.whiner.interfaces.*;
import java.util.*;
import java.util.Date;


import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.*;
import java.rmi.server.*;

/**
 * This class contains information about an applicant who has logged
 * into the system. Each applicant object contains excactly one CV
 * object. The "Applicant" class is inherited from the "User" class.
 *
 * @author <a href="mailto:carlsen@flatboy"></a>
 * @version 1.0
 */
public class Applicant extends User implements ApplicantI{
    //Inherited attributes
    private int id = 0;
    private String loginName = "";
    private String password = "";

    private Date lastLogin = new Date();
    private Date dateOfInterest = new Date(0);
    public Name name = new Name();
    public Address address = new Address();
    public PhoneNumber phoneNumber = new PhoneNumber();
    private String email = "";
    private ApplicantApplicationList applications;
    private NotificationList notifications;
    private MatchList matches;
    private CV cv; 


    //DAO Objects
    private ApplicantDAO applicantDAO;
    private ApplicationDAO applicationDAO;
    private NotificationDAO notificationDAO;
    private MatchesDAO matchesDAO;    
    
    /**
     * Makes an instance of the "MatchList" class. Creates instances
     * of dataaccess objects and default empty inner List classes.
     *
     */

    public Applicant() throws RemoteException, DAOException{
	applicantDAO = new ApplicantDAO();
	applicationDAO = new ApplicationDAO();
	notificationDAO = new NotificationDAO();
	matchesDAO = new MatchesDAO();    
	applications = new ApplicantApplicationList();
	notifications = new NotificationList();
	matches = new MatchList();
	cv = new CV();
    }


    /**
     * Tests for equality between two objects of the "Applicant" class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     * @exception RMIException if an error occurs
     */
    public boolean equals(Object obj){
	if ( this == obj ) return true;
	if ( !(obj instanceof Applicant) ) return false;
	Applicant objApp = (Applicant) obj;
	boolean result = false;
	try {
	    result = 
		(this.id == objApp.getID()) &&
		((this.loginName).equals(objApp.getLoginName())) &&
		((this.password).equals(objApp.getPassword())) &&
		((this.name).equals(objApp.getName())) &&
		((this.address).equals(objApp.getAddress())) &&		
		((this.phoneNumber).equals(objApp.getPhoneNumber())) &&	
		((this.email).equals(objApp.getEmail())) &&
		((this.applications).equals(objApp.getApplications())) &&		
		((this.notifications).equals(objApp.getNotifications())) &&		
		((this.matches).equals(objApp.getMatches())) &&
		((this.cv).equals(objApp.getCV())) ;		
	    
	}    
        catch(RMIException e){
	    // do stuff!
	}
	return result;
    }



    /**
     * Makes an instance of the "MatchList" class
     *
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public void initializeMatchList() throws RMIException, DAOException{
	matches = new MatchList(id);
    }

    /**
     * Makes an instance of the "NotificationList" class.
     *
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public void initializeNotificationList() throws RMIException, DAOException{
	notifications = new NotificationList(id);
    }
    
    /**
     * Makes an instance of the "ApplicantApplicationList" class.
     *
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public void initializeApplicantApplicationList() throws RMIException, DAOException{
	applications = new ApplicantApplicationList(id);
    }
    

    /**
     * Initializes the cv attribute's local and global qualification list and
     * returns the CV to the GUI.
     *
     * @return a <code>CV</code> value
     * @exception RMIException if an error occurs
     * @exception DAOException if an error occurs
     */
    public CVI selectCV() throws RMIException, DAOException{
	cv.initializeQualificationList();
	cv.initializeGlobalQualificationList();
	return (CVI)cv;
    }


    /**
     * Gets a notification object from the notifications container. 
     * Returns the object to the GUI.
     *
     * @param notificationNo an <code>int</code> value
     * @return a <code>Notification</code> value
     * @exception RMIException if an error occurs
     */
    public NotificationI getNotification(int notificationNo) throws RMIException{
	return ((NotificationI)notifications.getNotification(notificationNo));
    }


    /**
     * Gets an application object from the applications container. 
     * Returns the object to the GUI. 
     *
     * @param applicationNo an <code>int</code> value
     * @return an <code>Application</code> value
     * @exception RMIException if an error occurs
     */
    public ApplicationI getApplication(int applicationNo) throws RMIException{
	return (ApplicationI)applications.getApplication(applicationNo);
    }


    /**
     * Gets a match object from the matches container. 
     * Returns the object to the GUI.
     *
     * @param matchNo an <code>int</code> value
     * @return a <code>Match</code> value
     * @exception RMIException if an error occurs
     */
    public MatchI getMatch(int matchNo) throws RMIException{
	return ((MatchI)this.matches.getMatch(matchNo));
    }


    /**
     * Gets the length of the notifications container.
     *
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public int getNotificationListLength() throws RMIException{
	return notifications.getLength();
    }


    /**
     * Gets the length of the applications container.
     *
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public int getApplicationListLength() throws RMIException{
	return applications.getLength();
    }


    /**
     * Gets the length of the matches container.
     *
     * @return an <code>int</code> value
     * @exception RMIException if an error occurs
     */
    public int getMatchListLength() throws RMIException{
	return matches.getLength();
    }
    

    /**
     * Deletes an application draft from the applicant's
     * applicationList. The method makes sure that the 
     * application selected for deletion is actually
     * incomplete (a draft).
     *
     * @param applicationNo an <code>int</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void deleteApplicationDraft(int applicationNo) throws DAOException, RMIException{
	if(((applications.getApplication(applicationNo)).getStatus()).equals("incomplete")){
		applicationDAO.delete(applications.getApplicationID(applicationNo));
		applications.deleteApplication(applicationNo);
	}
    }
    


    /**
     * Deletes the applicant, his CV, his incomplete applications and
     * cancels all his submitted applications.
     *
     * @exception DAOException if a dataaccess error occurs
     * @exception RemoteException if an error occurs
     * @exception RMIException if an error occurs
     */
    public void deleteApplicant() throws DAOException, RemoteException{
	initializeApplicantApplicationList();
	for(int i = 0; i < applications.getLength(); i++){
	    applicationDAO.delete(applications.getApplicationID(i));
	}

	//slet skill-levels
	cv.initializeQualificationList();
	for(int i = 0; i < cv.getApplicantQualificationListLength(); i++){
	    cv.removeQualification(i);
	}
	cv.saveQualifications();
	
	//slet matches
	initializeMatchList();
	for(int i = 0; i < getMatchListLength(); i++){
	    deleteMatch(0);
	}
	
	notificationDAO.deleteNotifications(id); //sletter alle med applicantID = id
	applicantDAO.delete(id);
	
    }
    
    


    /**
     * Deletes the selected notification from the database and from the notifications container.
     *
     * @param notificationNo an <code>int</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void deleteNotification(int notificationNo) throws DAOException, RMIException{
	notificationDAO.delete(notifications.getNotificationID(notificationNo));
	notifications.deleteNotification(notificationNo);
    }


    /**
     * Deletes the selected match from the database and from the matches container.
     *
     * @param matchNo an <code>int</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void deleteMatch(int matchNo) throws DAOException, RMIException{
	matchesDAO.delete(matches.getMatchID(matchNo));
	matches.deleteMatch(matchNo);
    }



    /**
     * Returns a search object to the client so that he can manipulate
     * its attributes.
     *
     * @param argSearchSpecs an <code>int[]</code> value
     * @return a <code>Search</code> value
     * @exception RMIException if an error occurs
     * @exception DAOException if an error occurs
     */
    public SearchI beginSearch(int[] argSearchSpecs)throws RMIException, DAOException{
	Search result;
	try{	
	    result = new Search(argSearchSpecs);
	} catch(RemoteException e){
	    throw new RMIException();
	}
	return (SearchI)result;
    }
    

    /**
     * Saves the changes made to the applicant's attributes.
     *
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void save() throws DAOException, RMIException{
	applicantDAO.update(this);
    }



    /**
     * Changes the user password. The new password is set if the GUI
     * finds the new password acceptable in accordance with the
     * conditions the password must comply with.
     *
     * @param newPassword a <code>String</code> value
     * @exception RMIException if an error occurs
     */
    public void changePassword(String newPassword)throws RMIException{
	setPassword(newPassword);
    }



    /*SET AND GET METHODS
      -------------------*/

    /**
     * Sets the cv attribute to a CV object
     *
     * @param argCV a <code>CV</code> value
     * @exception RMIException if an error occurs
     */
    public void setCV(CVI argCV) throws RMIException{
	this.cv = (CV)argCV;
    }

    /**
     * Describe <code>setCV</code> method here.
     *
     * @param argCV a <code>CV</code> value
     * @exception RMIException if an error occurs
     */
    public void setCV(CV argCV) throws RMIException{
	this.cv = (CV)argCV;
    }

    /**
     * Gets the value of cv
     *
     * @return a <code>CVI</code> value
     * @exception RMIException if an error occurs
     */
    public CVI getCV() throws RMIException{
	return (CVI)this.cv;
    }
        
    /**
     * Gets the value of id
     *
     * @return the value of id
     * @exception RMIException if an error occurs
     */
    public int getID()   throws RMIException{
	return this.id;
    }

    /**
     * Sets the value of id
     *
     * @param argId Value to assign to this.id
     * @exception RMIException if an error occurs
     */
    public void setID(int argId)  throws RMIException{
	this.id = argId;
	this.cv.setApplicantID(argId);
    }

    /**
     * Gets the value of lastLogin
     *
     * @return the value of lastLogin
     * @exception RMIException if an error occurs
     */
    public Date getLastLogin()   throws RMIException{
	return this.lastLogin;
    }

    /**
     * Sets the value of lastLogin
     *
     * @param argLastLogin Value to assign to this.lastLogin
     * @exception RMIException if an error occurs
     */
    public void setLastLogin(Date argLastLogin)  throws RMIException{
	this.lastLogin = argLastLogin;
    }

    /**
     * Gets the value of dateOfInterest
     *
     * @return the value of dateOfInterest
     * @exception RMIException if an error occurs
     */
    public Date getDateOfInterest()   throws RMIException{
	return this.dateOfInterest;
    }

    /**
     * Sets the value of dateOfInterest
     *
     * @param argDateOfInterest Value to assign to this.dateOfInterest
     * @exception RMIException if an error occurs
     */
    public void setDateOfInterest(Date argDateOfInterest)  throws RMIException{
	this.dateOfInterest = argDateOfInterest;
    }


    /**
     * Gets the value of name
     *
     * @return the value of name
     * @exception RMIException if an error occurs
     */
    public NameI getName() throws RMIException {
 	return this.name;
    }
    
    /**
     * Sets the value of name
     *
     * @param argName Value to assign to this.name
     * @exception RMIException if an error occurs
     */
    public void setName(NameI argName) throws RMIException{
 	this.name = (Name)argName;
    }

    /**
     * Gets the value of address
     *
     * @return the value of address
     * @exception RMIException if an error occurs
     */
    public AddressI getAddress() throws RMIException {
 	return (AddressI)this.address;
    }
    
    /**
     * Sets the value of address
     *
     * @param argAddress Value to assign to this.address
     * @exception RMIException if an error occurs
     */
    public void setAddress(AddressI argAddress) throws RMIException{
 	this.address = (Address)argAddress;
    }
    
    /**
     * Gets the value of phoneNumber
     *
     * @return the value of phoneNumber
     * @exception RMIException if an error occurs
     */
    public PhoneNumberI getPhoneNumber() throws RMIException {
 	return (PhoneNumberI)this.phoneNumber;
    }
    
    /**
     * Sets the value of phoneNumber
     *
     * @param argPhoneNumber Value to assign to this.phoneNumber
     * @exception RMIException if an error occurs
     */
    public void setPhoneNumber(PhoneNumberI argPhoneNumber) throws RMIException{
 	this.phoneNumber = (PhoneNumber)argPhoneNumber;
    }
    
    /**
     * Gets the value of email
     *
     * @return the value of email
     * @exception RMIException if an error occurs
     */
    public String getEmail()   throws RMIException{
	return this.email;
    }
    
    /**
     * Sets the value of email
     *
     * @param argEmail Value to assign to this.email
     * @exception RMIException if an error occurs
     */
    public void setEmail(String argEmail)  throws RMIException{
	this.email = argEmail;
    }
    
    /**
     * Gets the value of loginName
     *
     * @return the value of loginName
     * @exception RMIException if an error occurs
     */
    public String getLoginName()   throws RMIException{
	return this.loginName;
    }

    /**
     * Sets the value of loginName
     *
     * @param argLoginName Value to assign to this.loginName
     * @exception RMIException if an error occurs
     */
    public void setLoginName(String argLoginName)  throws RMIException{
	this.loginName = argLoginName;
    }

    /**
     * Gets the value of password
     *
     * @return the value of password
     * @exception RMIException if an error occurs
     */
    public String getPassword()   throws RMIException{
	return this.password;
    }

    /**
     * Sets the value of password
     *
     * @param argPassword Value to assign to this.password
     * @exception RMIException if an error occurs
     */
    public void setPassword(String argPassword)  throws RMIException{
	this.password = argPassword;
    }

    /**
     * Gets the value of applications
     *
     * @return the value of applications
     * @exception RMIException if an error occurs
     */
    public ApplicantApplicationList  getApplications()   throws RMIException{
	return this.applications;
    }

    /**
     * Sets the value of notifications
     *
     * @param argApplications an <code>ApplicantApplicationList</code> value
     * @exception RMIException if an error occurs
     */
    public void setApplications(ApplicantApplicationList argApplications)  throws RMIException{
	this.applications = argApplications;
    }

    /**
     * Gets the value of notifications
     *
     * @return the value of notifications
     * @exception RMIException if an error occurs
     */
    public NotificationList  getNotifications()   throws RMIException{
	return this.notifications;
    }

    /**
     * Sets the value of notifications
     *
     * @param argNotifications a <code>NotificationList</code> value
     * @exception RMIException if an error occurs
     */
    public void setNotifications(NotificationList argNotifications)  throws RMIException{
	this.notifications = argNotifications;
    }

    /**
     * Gets the value of matches
     *
     * @return the value of matches
     * @exception RMIException if an error occurs
     */
    public MatchList getMatches()   throws RMIException{
	return this.matches;
    }

    /**
     * Sets the value of matches
     *
     * @param argMatches a <code>MatchList</code> value
     * @exception RMIException if an error occurs
     */
    public void setMatches(MatchList argMatches)  throws RMIException{
	this.matches = argMatches;
    }




    /**
     *  The "NotificationList" class has a container with the 
     *  notifications attached to the applicant
     *  and methods for accessing and manipulating this container. This class
     *  is only used by the "Applicant" class.
     *
     * @author <a href="mailto:carlsen@flatboy"></a>
     * @version 1.0
     */
    private class NotificationList{
	List cont = new ArrayList();
	
	//DAO objects
	NotificationDAO notificationDAO;
	
	/**
	 * Creates an "NotificationList" without getting the list of
	 * notifications from the database.
	 *
	 */
	public NotificationList() throws DAOException{
	    notificationDAO = new NotificationDAO();
	}
	
	/**
	 * Creates a new "NotificationList" instance and gets a list of
	 * all the notifications in the job.
	 *
	 * @param applicantID an <code>int</code> value
	 * @exception DAOException if a dataaccess error occurs
	 */
	NotificationList(int applicantID) throws DAOException{
	notificationDAO = new NotificationDAO();
	cont = notificationDAO.getNotifications(applicantID);
	}
	
	/**
	 * Compares two objects for equality from the "NotificationList" class
	 *
	 * @param obj an <code>Object</code> value
	 * @return a <code>boolean</code> value
	 */
	public boolean equals(Object obj){
	    boolean result = true;
	    
	    if (this == obj) 
		return true;
	    if (!(obj instanceof NotificationList)) 
		return false;
	    NotificationList objNotList = (NotificationList) obj;
	    if(this.getLength() != (objNotList.getLength())) 
		return false;
	    for(int i = 0; i < this.getLength(); i++){
		if(!(getNotification(i).equals(objNotList.getNotification(i))))
		    return false;
	    }
	    return true;
	}
	
	/**
	 * Gets the selected notification object. 
	 * Is used by the Applicant.getNotification method.
	 *
	 * @param notificationNo an <code>int</code> value
	 * @return a <code>Notification</code> value
	 */
	public Notification getNotification(int notificationNo){
	    return (Notification) cont.get(notificationNo);
	}
	
	/**
	 * Gets the selected notification's id value.
	 *
	 * @param notificationNo an <code>int</code> value
	 * @return an <code>int</code> value
	 * @exception RMIException if an error occurs
	 */
	public int getNotificationID(int notificationNo) throws RMIException{
	    return((Notification) cont.get(notificationNo)).getID();
	}
	
	/**
	 * Gets the length of the cont container. Is used by the
	 * Applicant.getNotificationListLength method. 
	 *
	 * @return an <code>int</code> value
	 */
	public int getLength(){
	    return cont.size();
	}
	
	/**
	 * Deletes the selected notification from the applicant's 
	 * GUI list of notifications.
	 *
	 * @param notificationNo an <code>int</code> value
	 */
	public void deleteNotification(int notificationNo){
	    cont.remove(cont.get(notificationNo));
	}    
    }
    
    
    
    /**
     * The "ApplicantApplicationList" class has a container with the 
     * applications written by contained in the
     * job and methods for accessing and manipulating this container. This class
     * is only used by the "Job" class.
     *
     * @author <a href="mailto:bennett@flatboy"></a>
     * @version 1.0
     */
    private class ApplicantApplicationList{
	List cont = new ArrayList();
	
	//DAO objects
	ApplicationDAO applicationDAO;
	
	
	/**
	 * Creates an "ApplicantApplicationList" without getting the list
	 * of applications from the database.
	 *
	 * @exception DAOException if a dataaccess error occurs
	 */
	public ApplicantApplicationList() throws DAOException{
	    applicationDAO = new ApplicationDAO();
	}
	
	/**
	 * Creates a new "ApplicantApplicationList" instance and gets a list of
	 * all the applications written by the applicant.
	 *
	 * @param applicantID an <code>int</code> value
	 * @exception DAOException if a dataaccess error occurs
	 */
	ApplicantApplicationList(int applicantID) throws DAOException{
	    applicationDAO = new ApplicationDAO();
	    cont = applicationDAO.getApplicationsFromApplicantID(applicantID);
	}
	
	/**
	 * Compares to objects for equality from the "ApplicantApplicationList" class
	 *
	 * @param obj an <code>Object</code> value
	 * @return a <code>boolean</code> value
	 */
	public boolean equals(Object obj){
	    boolean result = true;
	    
	    if (this == obj) 
		return true;
	    if (!(obj instanceof ApplicantApplicationList)) 
		return false;
	    ApplicantApplicationList objAppList = (ApplicantApplicationList) obj;
	    if(this.getLength() != (objAppList.getLength())) 
		return false;
	    for(int i = 0; i < this.getLength(); i++){
		if(!(getApplication(i).equals(objAppList.getApplication(i))))
		    return false;
	    }
	    return true;
	}
	
	/**
	 * Gets an application object from the cont container. 
	 * Is used by the Applicant.getApplication method.
	 *
	 * @param appNo an <code>int</code> value
	 * @return an <code>Application</code> value
	 */
	public Application getApplication(int appNo){
	    return (Application) cont.get(appNo);
	}
	
	/**
	 * Gets the selected application's id. 
	 * Is used by the Applicant.deleteApplicationDraft and 
	 * Applicant.deleteApplicant methods. 
	 *
	 * @param appNo an <code>int</code> value
	 * @return an <code>int</code> value
	 */
	public int getApplicationID(int appNo) throws RMIException{
	    return ((Application) cont.get(appNo)).getID();
	}
	
	/**
	 * Gets the length of the cont container. Is used by the
	 * Applicant.getApplicationListLength method.
	 *
	 * @return an <code>int</code> value
	 */
	public int getLength(){
	    return cont.size();
	}
	
	/**
	 * Deletes the selected application from the applicant's GUI list
	 * of applications.
	 *
	 * @param appNo an <code>int</code> value
	 */
	public void deleteApplication(int appNo){
	    cont.remove(cont.get(appNo));
	}
    
    }

    /**
     * The "MatchList" class has a container with the matches between the
     * applicant and specific jobs and methods for accessing and
     * manipulating this container. This class is only used by the
     * "Applicant" class.
     *
     * @author <a href="mailto:bennett@flatboy"></a>
     * @version 1.0
     */
    private class MatchList{
	List cont = new ArrayList();
	
	//DAO objects
	MatchesDAO matchesDAO; 
	
	
	/**
	 * Creates an "MatchList" without getting the list of matches from
	 * the database.
	 *
	 */
	public MatchList() throws DAOException{
	    matchesDAO = new MatchesDAO();
	}
	
	/**
	 * Creates a new "MatchList" instance and gets a list of
	 * all the matches between the applicant and the specific jobs.
	 *
	 * @param applicantID an <code>int</code> value
	 * @exception DAOException if a dataaccess error occur
	 */
	public MatchList(int applicantID) throws DAOException{
	    matchesDAO = new MatchesDAO(); 
	    cont = matchesDAO.getMatches(applicantID);
	}
	
	/**
	 * Compares to objects for equality from the "MatchList" class
	 *
	 * @param obj an <code>Object</code> value
	 * @return a <code>boolean</code> value
	 */
	public boolean equals(Object obj){
	    boolean result = true;
	    
	    if (this == obj) 
		return true;
	    if (!(obj instanceof MatchList)) 
		return false;
	    MatchList objMatchList = (MatchList) obj;
	    if(this.getLength() != (objMatchList.getLength())) 
		return false;
	    for(int i = 0; i < this.getLength(); i++){
		if(!(getMatch(i).equals(objMatchList.getMatch(i))))
		    return false;
	    }
	    return true;
	}
	
	/**
	 * Gets the match object from the selected number on the
	 * applicant's GUI list of matches. Is used by the Appliant.getMatch
	 * method.
	 *
	 * @param matchNo an <code>int</code> value
	 * @return a <code>Match</code> value
	 */
	public Match getMatch(int matchNo){
	    return (Match) cont.get(matchNo);
	}
	
	/**
	 * Gets the length of the cont container. Is used by the
	 * Applicant.getMatchListLength method.
	 *
	 * @return an <code>int</code> value
	 */
	public int getLength(){
	    return cont.size();
	}
	
	/**
	 * Gets the selected match's id. Is used by the
	 * Applicant.deleteMatch method.
	 *
	 * @param matchNo an <code>int</code> value
	 * @return an <code>int</code> value
	 * @exception RMIException if an error occurs
	 */
	public int getMatchID(int matchNo) throws RMIException{
	    return ((Match) cont.get(matchNo)).getID();
	}
	
	/**
	 * Deletes the selected match object from the cont container.
	 *
	 * @param matchNo an <code>int</code> value
	 */
	public void deleteMatch(int matchNo){
	    cont.remove(cont.get(matchNo));
	}
    }
}
