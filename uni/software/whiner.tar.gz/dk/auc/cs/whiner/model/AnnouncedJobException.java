package dk.auc.cs.whiner.model;


public class AnnouncedJobException extends Exception {
    
    private int type = 0;

    public AnnouncedJobException(){
	super("Unknown exception");
    }

    public AnnouncedJobException(String msg){
	super(msg);
    }

    public AnnouncedJobException(String msg, Throwable cause){
	super(msg, cause);
    }

}
