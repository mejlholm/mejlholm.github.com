package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.function.*;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.rmi.RMIException;

/**
 * This class contains information about how the match between an
 * applicant and a job has happened.
 *
 * @author <a href="mailto:bennett@flatboy"></a>
 * @version 1.0
 */
public class MatchInformation{
    private int matchID = 0;
    private int levelJobSkillLevel = 0;
    private int levelApplicantSkillLevel = 0;
    private String qualificationName = "";

    
    /**
     * Tests the equality between two objects of this class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj){
	if (this == obj) return true;
	if (!(obj instanceof MatchInformation)) return false;
	MatchInformation  objMatchInfo = (MatchInformation) obj;
	boolean result = false;
	result = 
	    (this.matchID == objMatchInfo.getMatchID()) &&
	    (this.levelJobSkillLevel == objMatchInfo.getLevelJobSkillLevel()) &&
	    (this.levelApplicantSkillLevel == objMatchInfo.getLevelApplicantSkillLevel()) &&
	    (this.qualificationName == objMatchInfo.getQualificationName());
	
	return result;
    }
    


    /*SET AND GET METHODS
      -------------------*/

    /**
     * Gets the value of matchID
     *
     * @return the value of matchID
     */
    public int getMatchID()  {
	return this.matchID;
    }

    /**
     * Sets the value of matchID
     *
     * @param argMatchID Value to assign to this.matchID
     */
    public void setMatchID(int argMatchID) {
	this.matchID = argMatchID;
    }

    /**
     * Gets the value of levelJobSkillLevel
     *
     * @return the value of levelJobSkillLevel
     */
    public int getLevelJobSkillLevel()  {
	return this.levelJobSkillLevel;
    }

    /**
     * Sets the value of levelJobSkillLevel
     *
     * @param argLevelJobSkillLevel Value to assign to this.levelJobSkillLevel
     */
    public void setLevelJobSkillLevel(int argLevelJobSkillLevel) {
	this.levelJobSkillLevel = argLevelJobSkillLevel;
    }

    /**
     * Gets the value of levelApplicantSkillLevel
     *
     * @return the value of levelApplicantSkillLevel
     */
    public int getLevelApplicantSkillLevel()  {
	return this.levelApplicantSkillLevel;
    }

    /**
     * Sets the value of levelApplicantSkillLevel
     *
     * @param argLevelApplicantSkillLevel Value to assign to this.levelApplicantSkillLevel
     */
    public void setLevelApplicantSkillLevel(int argLevelApplicantSkillLevel) {
	this.levelApplicantSkillLevel = argLevelApplicantSkillLevel;
    }

    /**
     * Gets the value of qualificationName
     *
     * @return the value of qualificationName
     */
    public String getQualificationName()  {
	return this.qualificationName;
    }

    /**
     * Sets the value of qualificationName
     *
     * @param argQualificationName Value to assign to this.qualificationName
     */
    public void setQualificationName(String argQualificationName) {
	this.qualificationName = argQualificationName;
    }
}
