package dk.auc.cs.whiner.model;

import java.util.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.rmi.*;
import java.rmi.*;
import dk.auc.cs.whiner.dataaccess.*;

public class TestJob extends TestCase{

    public void setUp() throws RMIException, RemoteException, DAOException{	
	JobDAO jobDAO = new JobDAO();
	QualificationDAO qualDAO = new QualificationDAO();
	ApplicationDAO appDAO = new ApplicationDAO();

	Job job1 = jobDAO.add();
	job1.setProjectID(2);
	job1.setStatus("announced");
	job1.setTitle("a title");
	job1.setDescription("description");
	job1.setDateOfCreation(new Date(0));
	job1.setDateOfAnnouncement(new Date(0));
	job1.setDateOfOccupation(new Date(0));
	jobDAO.update(job1);
	
	Qualification qual1;
	Qualification qual2;

	qual1 = qualDAO.add();
	qual1.setName("a name");
	qual1.setDescription("a description");
	qualDAO.update(qual1);

	qual2 = qualDAO.add();
	qual2.setName("a name 2");
	qual2.setDescription("a description 2");
	qualDAO.update(qual2);

	SkillLevel skill1;
	SkillLevel skill2;

	skill1 = new SkillLevel();
	skill1.setID(job1.getID());
	skill1.setLevel(4);
	skill1.setQualification(qual1);

	skill2 = new SkillLevel();
	skill2.setID(job1.getID());
	skill2.setLevel(3);
	skill2.setQualification(qual2);	

	jobDAO.insertSkillLevel(skill1);
	jobDAO.insertSkillLevel(skill2);

	Application app1 = appDAO.add();
	app1.setJobID(job1.getID());
	app1.setApplicantID(5);
	app1.setStatus("submitted");
	app1.setBodyText("Enter text here");
	app1.setDateOfCreation(new Date());
	appDAO.update(app1);
	
	Application app2 = appDAO.add();
	app2.setJobID(job1.getID());
	app2.setApplicantID(6);
	app2.setStatus("rejected");
	app2.setBodyText("Enter text here");
	app2.setDateOfCreation(new Date());
	appDAO.update(app2);
	
    }

    public void tearDown() throws RMIException, RemoteException, DAOException{
	JobDAO jobDAO = new JobDAO();
	QualificationDAO qualDAO = new QualificationDAO();
	ApplicationDAO appDAO = new ApplicationDAO();
	
	SkillLevel skill1;
	SkillLevel skill2;

	skill1 = new SkillLevel();
	skill1.setID(0);
	skill1.setLevel(4);
	skill1.setQualification(qualDAO.getQualification(0));

	skill2 = new SkillLevel();
	skill2.setID(0);
	skill2.setLevel(3);
	skill2.setQualification(qualDAO.getQualification(1));	
	
	try{
	    jobDAO.delete(0);
	} catch(DAOException e){
	    System.out.println("Error.. tearDown could not delete something from the DB as it was supposed to!");
	}
	jobDAO.deleteSkillLevel(skill1);
	jobDAO.deleteSkillLevel(skill2);

       	qualDAO.delete(1);
	qualDAO.delete(0);
	appDAO.delete(1);
	appDAO.delete(0);
    }
    
    public void testEquals() throws RMIException, RemoteException, DAOException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);
	Job job2 = jobDAO.getJob(0);
	assertEquals("Two jobs with same attributes are expected to be equal", job1, job2);
	job1.setStatus("rejected");
	assertFalse("Two jobs with different attributes are expected not to be equal", job1.equals(job2));
	
    }

    //selectApplication kalder udelukkende denne metode, s� det er samme test.
    public void testGetApplication() throws RMIException, DAOException, RemoteException{
	ApplicationDAO appDAO = new ApplicationDAO();
	JobDAO jobDAO = new JobDAO();
	
	Job job1 = jobDAO.getJob(0);

	Application app1 = appDAO.getApplication(0);   //f�r dem direkete fra DB
	Application app2 = appDAO.getApplication(1);
	
	job1.initializeJobApplicationList();
	
	Application app1Select = (Application)job1.getApplication(0);
	Application app2Select = (Application)job1.getApplication(1);
	assertEquals("id should be same", app1.getID(), app1Select.getID());
	assertEquals("id should be same", app2.getID(), app2Select.getID());
	
	assertEquals("The job have two applications", job1.getJobApplicationListLength(), 2);
	assertTrue("The two applications should be equal", app1Select.equals(app1));
	assertTrue("The two applications should be equal", app2Select.equals(app2));
    }
    
    public void testGetRequirement() throws RMIException, DAOException, RemoteException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);
	
	List skills = jobDAO.getSkillLevels(job1.getID());
	SkillLevel skill1 = (SkillLevel) skills.get(0);   //f�r dem direkete fra DB
	SkillLevel skill2 = (SkillLevel) skills.get(1);

	job1.initializeJobQualificationList();

	assertTrue("The two skill level objects should be equal", job1.getRequirement(0).equals(skill1));
	assertTrue("The two skill level objects should be equal", job1.getRequirement(1).equals(skill2));
    }

    public void testGetJobQualificationListLength() throws RMIException, DAOException, RemoteException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);
	job1.initializeJobQualificationList();
	assertEquals("The length of the list should be 2", job1.getJobQualificationListLength(), 2);
    }
    
    public void testGetGlobalQualificationListLength() throws RMIException, DAOException, RemoteException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);
	job1.initializeGlobalQualificationList();
	assertEquals("The length of the list should be 2", job1.getGlobalQualificationListLength(), 2);
    }

    public void testGetJobApplicationListlength() throws RMIException, DAOException, RemoteException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);
	job1.initializeJobApplicationList();
	assertEquals("The length of the list should be 2", job1.getJobApplicationListLength(), 2);
    }


    //virker ikke
    public void testSaveRequirements() throws RMIException, DAOException, RemoteException{
	JobDAO jobDAO = new JobDAO();

	QualificationDAO qualDAO = new QualificationDAO();

	Job job1 = jobDAO.getJob(0);
	job1.initializeJobQualificationList();

	//	int lengthBeforeChanges = job1.getJobQualificationListLength();

	Qualification qual3 = qualDAO.add();
	qual3.setName("new qual");
	qual3.setDescription("a description xx");
	qualDAO.update(qual3);

	SkillLevel skill3 = new SkillLevel();
	skill3.setID(job1.getID());
	skill3.setLevel(3);
	skill3.setQualification(qual3);

	job1.initializeGlobalQualificationList();

	int i = 0;
	for(i = 0; qual3.getID() != (job1.getGlobalQualification(i)).getID(); i++);  //finds the global qualifications number in the jobs list of glo. quals

	int lengthBeforeChanges = job1.getJobQualificationListLength();

	job1.addRequirement(i, 3);

	job1.saveRequirements();
	
	//initializes the qualifications in the job again, to check whether the requirements have been saved or not.
	job1.initializeJobQualificationList();
	assertEquals("the jobs qualification list's length should now be one larger", lengthBeforeChanges+1, job1.getJobQualificationListLength());

	for(i = 0; job1.getRequirement(i).getQualification().getID() != qual3.getID(); i++); //finds the new added skill levels number in the jobs list of qual
	assertTrue("wrong skill-level in container after the save", job1.getRequirement(i).equals(skill3));

	
	//clean up
	jobDAO.deleteSkillLevel(skill3);
	qualDAO.delete(qual3.getID());
    }

    public void testSave() throws RMIException, DAOException, RemoteException{
	JobDAO jobDAO = new JobDAO();
	Job job3;
	Job job4;

	job3 = jobDAO.add();
	assertTrue("JobDAO must assign the job a valid id", job3.getID()>-1);
	job3.setProjectID(2);
	job3.setStatus("announced");
	job3.setTitle("a title xx");
	job3.setDescription("description xx");
	job3.setDateOfCreation(new Date(0));
	job3.setDateOfAnnouncement(new Date(0));
	job3.setDateOfOccupation(new Date(0));
	
	job3.save();
	
	job4 = jobDAO.getJob(job3.getID());
	
	assertTrue("The job attributes aren't saved correctly by the jobDAO", job3.equals(job4));

	//clean up
    	jobDAO.delete(job3.getID());
    }
    
    public void testAddRequirement() throws RMIException, DAOException, RemoteException{
	JobDAO jobDAO = new JobDAO();
	QualificationDAO qualDAO = new QualificationDAO();
	Job job1 = jobDAO.getJob(0);
	job1.initializeJobQualificationList();

	int lengthBeforeChanges = job1.getJobQualificationListLength();

	Qualification qual3 = qualDAO.add();
	qual3.setName("new qual");
	qual3.setDescription("a description xx");
	qualDAO.update(qual3);

	SkillLevel skill3 = new SkillLevel();
	skill3.setID(job1.getID());
	skill3.setLevel(5);
	skill3.setQualification(qual3);
	
	job1.initializeGlobalQualificationList();
	int i = 0;
	for(i = 0; qual3.getID() != (job1.getGlobalQualification(i)).getID(); i++);
	job1.addRequirement(i, 5);

	job1.saveRequirements();
	
	assertEquals("The length jobs list of qualifications should be one larger", lengthBeforeChanges+1, job1.getJobQualificationListLength());
	for(i = 0; job1.getRequirement(i).getQualification().getID() != qual3.getID(); i++); //finds the new added skill levels number in the jobs list of qual
	assertTrue("Wrong skill level object", job1.getRequirement(i).equals(skill3));

	//clean up
	jobDAO.deleteSkillLevel(skill3);
	qualDAO.delete(qual3.getID());
	}
    
    
    
    public void testReopen() throws RMIException, DAOException, RemoteException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);
	
	job1.setStatus("announced");
	//Testing an exception
	try{
	    job1.reopen();
	    fail("Job cannot be reopened! Exception exptected!");
	} catch(ReopenException e){
	    //test passed!!
	}
	
	job1.setStatus("closed");

	try{
	    job1.reopen();
	} catch(ReopenException e){
	    fail("ReopenException was not supposed to be thrown");
	}
	assertEquals("Job should have changed status to 'not announced'", job1.getStatus(), "not announced");
	job1 = jobDAO.getJob(0);
	assertEquals("The jobs new status is NOT stored in the database!", job1.getStatus(), "not announced");

	
	/*
	  //no longer used. We haved moved the reopen for applications to the announce job method!!
	  
	  int applicantID = app2.getApplicantID();
	
	  job1.initializeJobApplicationList();
	  Application app1 = job1.getApplication(0);
	  app1.setStatus("cancelled");
	  Application app2 = job1.getApplication(1);
	  app2.setStatus("rejected");	
	  assertEquals("Application app1 should still be cancelled", app1.getStatus(), "cancelled");
	  assertEquals("Application app2 should now be incomplete", app2.getStatus(), "incomplete");
	*/

    }

    public void testClose() throws RMIException, DAOException, RemoteException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);

	job1.setStatus("closed");
	//Testing an exception
	try{
	    job1.close();
	    fail("Job cannot be closed! Exception exptected!");
	} catch(CloseException e){
	    //test passed!!
	}
	
	job1.setStatus("announced");
	job1.initializeJobApplicationList();
	Application app1 = (Application)job1.getApplication(0);
	app1.setStatus("submitted");
	Application app2 = (Application)job1.getApplication(1);
	app2.setStatus("cancelled");
	try{
	    job1.close();
	} catch(CloseException e){
	    fail("CloseException was not supposed to be thrown");
	}
	assertEquals("Job should have changed status to 'closed'", job1.getStatus(), "closed");
	assertEquals("Application app1 should have changed status to rejected", app1.getStatus(), "rejected");
	assertEquals("Application app2 should still be cancelled", app2.getStatus(), "cancelled");

	NotificationDAO notDAO = new NotificationDAO();
	notDAO.delete(0);

    }
    
    public void testOccupy() throws RMIException, DAOException, RemoteException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);
	
	job1.setStatus("announced");
	job1.initializeJobApplicationList();
	Application app1 = (Application)job1.getApplication(0);
	app1.setStatus("submitted");
	Application app2 = (Application)job1.getApplication(1);
	app2.setStatus("cancelled");
	
	job1.occupy();
	assertEquals("Job should have changed status to 'occupied'", job1.getStatus(), "occupied");
	assertEquals("Application app2 should still be cancelled", app2.getStatus(), "cancelled");
	assertEquals("Application app1 should have changed status to rejected", app1.getStatus(), "rejected");

	NotificationDAO notDAO = new NotificationDAO();
	notDAO.delete(0);

    }

    public void testHireApplicant() throws RMIException, DAOException, RemoteException, HireException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);
	ApplicantDAO applicantDAO = new ApplicantDAO();
	ApplicationDAO applicationDAO = new ApplicationDAO();
	Applicant applicant = applicantDAO.add();

	job1.initializeJobApplicationList();
	Application app1 = (Application)job1.getApplication(0);
	app1.setStatus("cancelled");
	app1.setApplicantID(applicant.getID());
	applicationDAO.update(app1);
	Application app2 = (Application)job1.getApplication(1);
	app2.setStatus("cancelled");
	app2.setApplicantID(applicant.getID()+1);
	applicationDAO.update(app2);

	job1.setStatus("announced");
	
	app1.setStatus("rejected");
	applicationDAO.update(app1);

	int appNo = 0;
	for(appNo = 0; !( ((Application) job1.getApplication(appNo)).getApplicantID() == applicant.getID()) ; appNo++);


	job1.initializeJobApplicationList();
	assertEquals("length should be two", 2, job1.getJobApplicationListLength());
	
	//Testing an exception
	try{
	    job1.hireApplicant(appNo); //application 0 should equal app1
	    fail("Exception expected because the application is rejected");
	} catch(HireException e){
	    //test passed!!
	}

	app1.setStatus("submitted");
	applicationDAO.update(app1);
	//Testing an exception
	
	job1.initializeJobApplicationList();

	try{
	    job1.hireApplicant(appNo); //application 0 should equal app1
	    //test passed!!
	} catch(HireException e){
	    fail("Exception not expected because the application is submitted");
	}

	job1.initializeJobApplicationList();
	assertEquals("length should only be one", 1, job1.getJobApplicationListLength());
	assertEquals("Job should have changed status to 'occupied'", job1.getStatus(), "occupied");
	assertTrue("Application 0 should now be app2 because app1 was hired and deleted", job1.getApplication(0).equals(app2));
	
	
	//cleanup
	NotificationDAO notDAO = new NotificationDAO();
	notDAO.delete(0);


	/*
	//Tester at han har f�et den rigtigt notification! getNotifications i DAO virker tilsyneladende ikke!

	applicant.initializeNotificationList();
	//	assertEquals("The applicant should only have one notification", 1, applicant.getNotificationListLength());
	
	Notification not = new Notification();
	not.setID(applicant.getNotificationListLength()-1);
	not.setApplicantID(applicant.getID());
	not.setJobID(job1.getID());
	not.setNotificationType("Application rejected");
	not.setTitle(job1.getTitle());
	not.setBodyText("Hi, sorry to inform you but your application has been rejected");

	int i;
	for(i=0; !(applicant.getNotification(i).getID() == applicant.getNotificationListLength()-1);i++);
	assertTrue("wrong notification!!", not.equals(applicant.getNotification(i)));*/
	
	
    }
    
    public void testCreateApplication() throws RMIException, DAOException, RemoteException, AlreadyAppliedException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);
	ApplicantDAO applicantDAO = new ApplicantDAO();
	Applicant applicant = applicantDAO.add();
	ApplicationDAO applicationDAO = new ApplicationDAO();

	job1.initializeJobApplicationList();
	job1.createApplication(applicant.getID());
	
	assertEquals("the new (third) application should be added at this index", (job1.getApplication(2)).getApplicantID(), applicant.getID());
	//	job1.initializeJobApplicationList();
	//	assertEquals("the new application should still be there after a new initialization", (job1.getApplication(2)).getApplicantID(), applicant.getID());
	
	//clean up
	applicantDAO.delete(applicant.getID());
	applicationDAO.delete((job1.getApplication(2)).getID());
    }
    
    public void testDeleteApplicationIfNotSubmitted() throws RMIException, DAOException, RemoteException, DeleteException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);
	ApplicationDAO appDAO = new ApplicationDAO();
	Application app1 = appDAO.getApplication(0);
	Application app2 = appDAO.getApplication(1);
	app1.setStatus("submitted");
	appDAO.update(app1);

	job1.initializeJobApplicationList();
	try{
	    job1.deleteApplicationIfNotSubmitted(0);
	    fail("DeleteException expected because the applications status is 'announced'");
	} catch(DeleteException e){
	    //test passed!
	}
	app1.setStatus("rejected");
	appDAO.update(app1);

	job1.initializeJobApplicationList();
	try{
	    job1.deleteApplicationIfNotSubmitted(0);
	    //test passed!
	} catch(DeleteException e){
	    fail("Exception not expected! Application is NOT announced!");   
	}
	
	assertEquals("The length of the applicationlist should now be only one because an application is deleted", job1.getJobApplicationListLength(), 1);
	assertEquals("The application at index 0 should now be the 'second' application", job1.getApplication(0), app2);
	job1.initializeJobApplicationList();
	assertEquals("changes shold still be stored after an initialization", job1.getJobApplicationListLength(), 1);
	assertEquals("changes shold still be stored after an initialization", job1.getApplication(0), app2);
	
	//clean up
	appDAO.add(); //again its needed for tearDown to work 
	NotificationDAO notDAO = new NotificationDAO();
	notDAO.delete(0);
    }

    public void testRejectApplication() throws RMIException, DAOException, RemoteException, DeleteException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);
	ApplicationDAO appDAO = new ApplicationDAO();
	Application app1 = appDAO.getApplication(0);
	Application app2 = appDAO.getApplication(1);
	app1.setStatus("submitted");
	appDAO.update(app1);
	app2.setStatus("cancelled");
	appDAO.update(app2);

	job1.initializeJobApplicationList();
	assertEquals("Job should only have two applications", 2, job1.getJobApplicationListLength());
	
	job1.rejectApplication(0);
	job1.rejectApplication(1);

	job1.initializeJobApplicationList();
	Application app3;
	Application app4;
	int i;
	for(i=0; !(job1.getApplication(i).getID() == app1.getID()); i++);  //app3 should now be equal app1
	app3 = (Application)job1.getApplication(i);
	for(i=0; !(job1.getApplication(i).getID() == app2.getID()); i++);  //app4 should now be equal app2
	app4 = (Application)job1.getApplication(i);

	assertEquals("should have changed status to 'rejected'", "rejected", app3.getStatus());
	assertEquals("should still be cancelled", "cancelled", app4.getStatus());

	//notifications?
	NotificationDAO notDAO = new NotificationDAO();
	List notifications = notDAO.getNotifications(app1.getApplicantID());
	assertEquals("The test requires the database to be default initialized (not notifications!)", 1, notifications.size());
	Notification not = (Notification) notifications.get(0);

	assertEquals("!!ID!!", 0, not.getID());
	assertEquals("!!app ID!!", app1.getApplicantID(), not.getApplicantID());
	assertEquals("!!job ID!!", job1.getID(), not.getJobID());
	assertEquals("!!Type!!", "Application rejected", not.getNotificationType());

	//clean up
	notDAO.delete(0);
    
    }

    public void testCreateQualification() throws RMIException, DAOException, RemoteException, DeleteException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);
	QualificationDAO qualDAO = new QualificationDAO();
	
	job1.initializeGlobalQualificationList();
	
	int listLengthBefore = job1.getGlobalQualificationListLength();
	job1.createQualification("Java", "Knowledge in the Java coding enviroment");

	job1.initializeGlobalQualificationList();
	assertEquals("The jobs list of qualifications should now be one larger", listLengthBefore + 1, job1.getGlobalQualificationListLength());
	
	int i=0;
	for(i = 0; !((job1.getGlobalQualification(i).getName()).equals("Java")); i++); //finds the new created qualification number in the jobs list of glo. qual
	Qualification tempQual = (Qualification)job1.getGlobalQualification(i);
	assertEquals("the Qualifications name should be 'Java'", "Java", tempQual.getName());
	assertEquals("the Qualifications name should be 'Knowledge in the Java coding enviroment'", "Knowledge in the Java coding enviroment", tempQual.getDescription());

	//clean up
	qualDAO.delete(tempQual.getID());
    }
    
    public void testDeleteQualification() throws RMIException, DAOException, RemoteException, DeleteException{
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.getJob(0);
	
	job1.initializeGlobalQualificationList();
	

	Qualification tempQual = (Qualification)job1.getGlobalQualification(0);
	
	try{
	    job1.deleteQualification(0);
	    fail("Exception should be thrown because skill levels objects in 'set up' uses this Qualification");
	} catch(Exception e){
	    //test passed!!
	}
	
	job1.createQualification("Java", "Knowledge in the Java coding enviroment");
	int listLengthBefore = job1.getGlobalQualificationListLength();
	
	int i = 0;
	for(i = 0; !((job1.getGlobalQualification(i).getName()).equals("Java")); i++); //finds the new created qualification number in the jobs list of glo. qual
	job1.deleteQualification(i);
	
	job1.initializeGlobalQualificationList();
	assertEquals("The jobs list of qualifications should now be one smaller", listLengthBefore - 1, job1.getGlobalQualificationListLength());
	
	for(int j = 0; j < listLengthBefore - 1; j++){
	    if ((job1.getGlobalQualification(j).getName()).equals("Java"))
		fail("The deleted Qualification is still between the global qualificaitons!!!");
	}
    }
	
}
