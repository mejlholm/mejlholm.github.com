package dk.auc.cs.whiner.model;

/* Simple exception class - basically just renaming... */


public class DeleteException extends Exception {
 
    public DeleteException(){
	super("Unknown exception");
    }

    public DeleteException(String msg){
	super(msg);
    }

    public DeleteException(String msg, Throwable cause){
	super(msg, cause);
    }

}
