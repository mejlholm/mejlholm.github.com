package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.function.*;
import java.util.*;
import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.*;
import java.rmi.server.*;


/**
 * The "Name" class holds information on an applicant's name.
 *
 * @author <a href="mailto:bennett@flatboy"></a>
 * @version 1.0
 */
public class Name extends UnicastRemoteObject implements NameI{
    private String firstName = "";
    private String middleName = "";
    private String lastName = "";

    public Name() throws RemoteException{

    }


    /**
     * Tests for equality between two objects of the "Name" class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     * @exception RMIException if an error occurs
     */
    public boolean equals(Object obj){
	if(this == obj) 
	    return true;
	if(!(obj instanceof Name)) 
	    return false;
	Name objName = (Name) obj;
	boolean result = false;
	try{
	    result = 
		((this.firstName).equals(objName.getFirstName())) &&
		((this.middleName).equals(objName.getMiddleName())) &&
		((this.lastName).equals(objName.getLastName())) ;
	} catch(RMIException e){
	    //do nothing, just for the test!
	}
	return result;
    }
    
	
    
    
    /*SET AND GET METHODS
      -------------------*/
    
	
    
    /**
     * Gets the value of firstName
     *
     * @return the value of firstName
     * @exception RMIException if an error occurs
     */
    public String getFirstName() throws RMIException {
	return this.firstName;
    }

    /**
     * Sets the value of firstName
     *
     * @param argFirstName Value to assign to this.firstName
     * @exception RMIException if an error occurs
     */
    public void setFirstName(String argFirstName) throws RMIException{
	this.firstName = argFirstName;
    }

    /**
     * Gets the value of middleName
     *
     * @return the value of middleName
     * @exception RMIException if an error occurs
     */
    public String getMiddleName() throws RMIException {
	return this.middleName;
    }

    /**
     * Sets the value of middleName
     *
     * @param argMiddleName Value to assign to this.middleName
     * @exception RMIException if an error occurs
     */
    public void setMiddleName(String argMiddleName) throws RMIException{
	this.middleName = argMiddleName;
    }

    /**
     * Gets the value of lastName
     *
     * @return the value of lastName
     * @exception RMIException if an error occurs
     */
    public String getLastName() throws RMIException {
	return this.lastName;
    }

    /**
     * Sets the value of lastName
     *
     * @param argLastName Value to assign to this.lastName
     * @exception RMIException if an error occurs
     */
    public void setLastName(String argLastName) throws RMIException{
	this.lastName = argLastName;
    }
}
