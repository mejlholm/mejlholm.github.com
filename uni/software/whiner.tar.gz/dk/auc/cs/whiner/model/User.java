package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.function.*;
import dk.auc.cs.whiner.dataaccess.*; //DAOExceptions
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.rmi.RMIException;

import java.util.*;
import java.lang.String;
import java.lang.Character;

import java.rmi.*;
import java.rmi.server.*;
/**
 * The "User" class is the base class for the "Administrator",
 * "Headhunter", and "Applicant" class. It contains three attributes
 * and one method to be inherited by the Applicant, Headhunter and
 * Administrator: a login name, password, and an id. The method is
 * changePassword, which all user classes contain so that all users of
 * the system have the option to change their password once
 * registered.
 * @author <a href="mailto:carlsen@cs.auc.dk"></a>
 * @author <a href="mailto:bennett@cs.auc.dk"></a>
 * @version 1.0
 */
public abstract class User extends UnicastRemoteObject implements UserI{
    private int id = -1;   
    private String loginName = "";
    private String password = "";
   
    
    /**
     * Default constructor.
     *
     * @exception RemoteException if an error occurs
     */
    public User() throws RemoteException{
	super();
    }

    /**
     * Tests for equality between two objects of the "User" class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj){
	if ( this == obj ) 
	    return true;
	if ( !(obj instanceof User) ) 
	    return false;
	User objUser = (User) obj;
	boolean result = false;
	try{
	    result = 
		(this.id == objUser.getID()) &&
		(this.loginName == objUser.getLoginName()) &&
		(this.password == objUser.getPassword()) ;
	} catch(RMIException e){
	    //necessary to keep the compiler from whining
	}	
	return result;
    }
    
    /**
     * Changes the user password. The new password is set if the GUI
     * finds the new password acceptable in accordance with the
     * conditions the password must comply with.
     *
     * @param newPassword a <code>String</code> value
     * @exception RMIException if an error occurs
     */
    public void changePassword(String newPassword) throws RMIException, DAOException{
	setPassword(newPassword);
    }
    

    /* SET AND GET METHODS
       -------------------*/

    /**
     * Gets the value of loginName
     *
     * @return the value of loginName
     * @exception RMIException if an error occurs
     */
    public String getLoginName()  throws RMIException {
	return this.loginName;
    }

    /**
     * Sets the value of loginName
     *
     * @param argLoginName Value to assign to this.loginName
     * @exception RMIException if an error occurs
     */
    public void setLoginName(String argLoginName)  throws RMIException{
	this.loginName = argLoginName;
    }

    /**
     * Gets the value of password
     *
     * @return the value of password
     * @exception RMIException if an error occurs
     */
    public String getPassword()   throws RMIException{
	return this.password;
    }


    /**
     * Sets the value of password 
     *
     * @param argPassword a <code>String</code> value
     * @exception RMIException if an error occurs
     */
    public void setPassword(String argPassword) throws RMIException{
	this.password = argPassword;
    }

    /**
     * Gets the value of id
     *
     * @return the value of id
     * @exception RMIException if an error occurs
     */
    public int getID()   throws RMIException{
	return this.id;
    }

    /**
     * Sets the value of id
     *
     * @param argID Value to assign to this.id
     * @exception RMIException if an error occurs
     */
    public void setID(int argID)  throws RMIException{
	this.id = argID;
    }

}
