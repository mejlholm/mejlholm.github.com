package dk.auc.cs.whiner.model;

import java.util.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.rmi.*;
import java.rmi.*;
import dk.auc.cs.whiner.dataaccess.*;

public class TestProject extends TestCase{

    public void testEquals() throws RMIException, RemoteException, DAOException{
	Project pro1 = new Project();
	Project pro2 = new Project();
	assertTrue("Two projects with same attributes are expected to be equal", pro1.equals(pro2));
	pro1.setTitle("Super Project");
	assertFalse("Two projects with different attributes are expected not to be equal", pro1.equals(pro2));
	
    }

    public void testGetJobListLength() throws RMIException, RemoteException, DAOException{
	ProjectDAO proDAO = new ProjectDAO();
	Project pro1 = proDAO.add();
	JobDAO jobDAO = new JobDAO();

	Job job1 = jobDAO.add();
	job1.setProjectID(pro1.getID());
	jobDAO.update(job1);
	Job job2 = jobDAO.add();
	job2.setProjectID(pro1.getID());
	jobDAO.update(job2);
	Job job3 = jobDAO.add();
	job3.setProjectID(pro1.getID()+1);
	jobDAO.update(job3);

	pro1.initializeJobList();
	
	assertEquals("The project should have 2 jobs", 2, pro1.getJobListLength());
    
	//clean up
	proDAO.delete(pro1.getID());
	jobDAO.delete(job1.getID());
	jobDAO.delete(job2.getID());
	jobDAO.delete(job3.getID());


    }

    public void testGetJob() throws RMIException, RemoteException, DAOException{
	ProjectDAO proDAO = new ProjectDAO();
	Project pro1 = proDAO.add();
	JobDAO jobDAO = new JobDAO();
	
	Job job1 = jobDAO.add();
	job1.setProjectID(pro1.getID());
	job1.setTitle("new job1");
	jobDAO.update(job1);
	Job job2 = jobDAO.add();
	job2.setProjectID(pro1.getID());
	job2.setTitle("new job2");
	jobDAO.update(job2);
	
	pro1.initializeJobList();
	
	Job getJob1;
	Job getJob2;

	getJob1 = (Job)pro1.getJob(0);
	if(getJob1.getID() == job1.getID()){  //we dont know the order.
	    getJob2 = (Job)pro1.getJob(1);
	}
	else {
	    getJob1 = (Job)pro1.getJob(1);
	    getJob2 = (Job)pro1.getJob(0);
	}
	
	assertTrue("the two jobs should be equal", getJob1.equals(job1));
	assertTrue("the two jobs should be equal", getJob2.equals(job2));

	//clean up
	proDAO.delete(pro1.getID());
	jobDAO.delete(job1.getID());
	jobDAO.delete(job2.getID());


    }

    public void testCreateJob() throws RMIException, RemoteException, DAOException{
	ProjectDAO proDAO = new ProjectDAO();
	Project pro1 = proDAO.add();

	pro1.createJob();
	assertEquals("The project Should contain 1 job!", 1, pro1.getJobListLength());
	Job job1 = (Job)pro1.getJob(0); //the job has been added to the projects joblist
	JobDAO jobDAO = new JobDAO();
	Job job2 = jobDAO.getJob(job1.getID());
	assertTrue("The created job in the projects joblist is not the same in the database!", job1.equals(job2));

	//clean up
	proDAO.delete(pro1.getID());
	jobDAO.delete(job1.getID());
    }


    //large test. Deleting a job should also delete associated applications and skill level objects!!
    public void testDeleteJobIfNotAnnounced() throws RMIException, RemoteException, DAOException, DeleteException, AnnouncedJobException, AlreadyAppliedException{
	ProjectDAO proDAO = new ProjectDAO();
	ApplicationDAO appDAO = new ApplicationDAO();
	Project pro1 = proDAO.add();
	
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.add();
	job1.setProjectID(pro1.getID());
	jobDAO.update(job1);
	Job job2 = jobDAO.add();
	job2.setProjectID(pro1.getID());
	jobDAO.update(job2);

	Application appTemp = appDAO.add();
	appTemp.setStatus("submitted");
	appTemp.setJobID(job1.getID());
	appDAO.update(appTemp);
	appTemp = appDAO.add();
	appTemp.setStatus("submitted");
	appTemp.setJobID(job1.getID());
	appDAO.update(appTemp);
	appTemp = appDAO.add();
	appTemp.setStatus("submitted");
	appTemp.setJobID(job1.getID());
	appDAO.update(appTemp);
	appTemp = appDAO.add();
	appTemp.setStatus("submitted");
	appTemp.setJobID(job2.getID());
	appDAO.update(appTemp);

	job1.initializeJobApplicationList();
	assertEquals("Should contain 3 applications", 3, job1.getJobApplicationListLength());

	QualificationDAO qualDAO = new QualificationDAO();
	Qualification qual = qualDAO.add();
	qual.setName("Fez!!");
	qualDAO.update(qual);
	
	job1.initializeGlobalQualificationList();
	job2.initializeGlobalQualificationList();

	job1.initializeJobQualificationList();
	job2.initializeJobQualificationList();

	job1.addRequirement(qual.getID(), 3);
	job1.saveRequirements();
	job2.addRequirement(qual.getID(), 2);
	job2.saveRequirements();

	pro1.initializeJobList();
	assertEquals("The project should contain two jobs at beginning of test!", 2, pro1.getJobListLength());
	int job3No = 0;
	for(job3No = 0; pro1.getJob(job3No).getID() != job1.getID(); job3No++);
	Job job3 = (Job)pro1.getJob(job3No);
	int job4No = 0;
	for(job4No = 0; pro1.getJob(job4No).getID() != job2.getID(); job4No++);
	Job job4 = (Job)pro1.getJob(job4No);

	job3.initializeJobQualificationList();
	job4.initializeJobQualificationList();

	job3.setStatus("announced");
	try{
	    pro1.deleteJobIfNotAnnounced(job3No); //deletes job3
	    fail("job is announced. Exception excpected!");
	} catch(AnnouncedJobException e){
	    //test passed!
	}
	
	job3.setStatus("closed");
	try{
	    pro1.deleteJobIfNotAnnounced(job3No); //deletes job3
	    //test passed!
	} catch(AnnouncedJobException e){
	    fail("job is not announced. Exception not excpected!");
	}
	
	assertEquals("The project should contain one job after deleting one job", 1, pro1.getJobListLength());
	pro1.initializeJobList();  //Or else the equals will fail.
	assertEquals("The job does not seem to be deleted from the database correctly", 1, pro1.getJobListLength());
	
	Job jobTemp = (Job)pro1.getJob(0);
	jobTemp.initializeJobQualificationList();
	assertTrue("Wrong job in container", job4.equals(jobTemp));
	
	job3.initializeJobApplicationList();  //remember that job3 is deleted but the variable (instance) still exist here! Therefore it makes sense to do this!
       	assertTrue("The job should no longer have any applications!", job3.getJobApplicationListLength() == 0);
	
	job3.initializeJobQualificationList();
	
	assertTrue("The job should no longer have any requirements (skill level objects in the database)!", job3.getJobQualificationListLength() == 0);
	
	job4.initializeJobQualificationList();
	assertTrue("The job should no longer have any requirements (skill level objects in the database)!", job4.getJobQualificationListLength() == 1);
	
	
	//clean up
	proDAO.delete(pro1.getID());
	jobDAO.delete(job4.getID());
	job4.initializeJobApplicationList();
	appDAO.delete(job4.getApplication(0).getID());
	job4.initializeJobQualificationList();
	jobDAO.deleteSkillLevel(((SkillLevel)job4.getRequirement(0)));
	qualDAO.delete(qual.getID());
	NotificationDAO notDAO = new NotificationDAO();
	notDAO.delete(0);
	notDAO.delete(1);
	notDAO.delete(2);

    }

    public void testSave() throws RMIException, RemoteException, DAOException{
	ProjectDAO proDAO = new ProjectDAO();
	Project pro1 = proDAO.add();
	
	pro1.setTitle("Test Project !!!");
	
	pro1.save();

	Project pro1Test = proDAO.getProject(pro1.getID());
	
	assertTrue("The save method does not store the project in the database", pro1.equals(pro1Test));

	//clean up
	proDAO.delete(pro1.getID());
    }


    public void testAnnounceCheckedJobs() throws DAOException, RMIException, RemoteException{
	ProjectDAO proDAO = new ProjectDAO();
	Project pro1 = proDAO.add();
	
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.add();
	job1.setProjectID(pro1.getID());
	job1.setStatus("not announced");
	jobDAO.update(job1);
	Job job2 = jobDAO.add();
	job2.setProjectID(pro1.getID());
	job2.setStatus("not announced");
	jobDAO.update(job2);
	Job job3 = jobDAO.add();
	job3.setProjectID(pro1.getID());
	job3.setStatus("not announced");
	jobDAO.update(job3);
	
	pro1.initializeJobList();

	int job1No = 0;
	for(job1No = 0; pro1.getJob(job1No).getID() != 0; job1No++);
	job1 = (Job) pro1.getJob(job1No);
	int job2No = 0;
	for(job2No = 0; pro1.getJob(job2No).getID() != 1; job2No++);
	job2 = (Job) pro1.getJob(job2No);
	int job3No = 0;
	for(job3No = 0; pro1.getJob(job3No).getID() != 2; job3No++);
	job3 = (Job) pro1.getJob(job3No);

	int[] checked = {job1No , job3No};

	pro1.announceCheckedJobs(checked);

	assertTrue("Job 1 should now be announced", job1.getStatus().equals("announced"));
	assertTrue("Job 2 should still be not announced", job2.getStatus().equals("not announced"));
	assertTrue("Job 3 should now be announced", job3.getStatus().equals("announced"));

	//clean up
	proDAO.delete(pro1.getID());
	jobDAO.delete(job1.getID());
	jobDAO.delete(job2.getID());
	jobDAO.delete(job3.getID());


    }

    public void testCloseAllJobs() throws DAOException, CloseException, RemoteException {
	ProjectDAO proDAO = new ProjectDAO();
	Project pro1 = proDAO.add();
	
	JobDAO jobDAO = new JobDAO();
	Job job1 = jobDAO.add();
	job1.setProjectID(pro1.getID());
	job1.setStatus("occupied");
	jobDAO.update(job1);
	Job job2 = jobDAO.add();
	job2.setProjectID(pro1.getID());
	job2.setStatus("announced");
	jobDAO.update(job2);
	Job job3 = jobDAO.add();
	job3.setProjectID(pro1.getID());
	job3.setStatus("not announced");
	jobDAO.update(job3);


	pro1.initializeJobList();
	
	pro1.closeAllJobs();

	int i = 0;
	for(i = 0; pro1.getJob(i).getID() != 0; i++);
	job1 = (Job) pro1.getJob(i);
	for(i = 0; pro1.getJob(i).getID() != 1; i++);
	job2 = (Job) pro1.getJob(i);
	for(i = 0; pro1.getJob(i).getID() != 2; i++);
	job3 = (Job) pro1.getJob(i);

	assertTrue("Job 1 should still be occupied!!!", job1.getStatus().equals("occupied"));
	assertTrue("Job 2 should have changed status to closed", job2.getStatus().equals("closed"));
	assertTrue("Job 3 should still be not announced!!!", job3.getStatus().equals("not announced"));

	//clean up
	proDAO.delete(pro1.getID());
	jobDAO.delete(job1.getID());
	jobDAO.delete(job2.getID());
	jobDAO.delete(job3.getID());

    }
}
