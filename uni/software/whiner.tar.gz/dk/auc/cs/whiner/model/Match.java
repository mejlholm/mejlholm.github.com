package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.dataaccess.DAOException;
import java.util.*;
import java.util.Date;

import java.rmi.*;
import java.rmi.server.*;

import dk.auc.cs.whiner.rmi.RMIException;


/**
 * This class holds information about a match between an applicant's
 * qualifications and a job's requirements. The class uses an array of
 * qualifications to store which requirements were met.
 *
 * @author <a href="mailto:carlsen@pico.cs.auc.dk">Jeppe Carlsen</a>
 * @version 1.0
 */
// extends UnicastRemoteObject
public class Match extends UnicastRemoteObject implements MatchI{
    private int id = 0;
    private int applicantID = 0;
    private int jobID = 0;
    private int requirementScore = 0;
    private List metRequirements = new ArrayList();
    private Date dateOfMatch = new Date(0);

    //DAO objects
    MatchesDAO matchesDAO;
    JobDAO jobDAO;

    /**
     * Initializes the DAO objects.
     *
     * @exception RemoteException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public Match() throws RemoteException, DAOException{
	matchesDAO = new MatchesDAO();
	jobDAO = new JobDAO();
    }

    /**
     * Tests the equality between two objects of this class
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj){
	if (this == obj) return true;
	if (!(obj instanceof Match)) return false;
	Match objMatch = (Match) obj;
	boolean result = false;
	try{
	    result = 
		(this.id == objMatch.getID()) &&
		(this.jobID == objMatch.getJobID()) &&
		(this.applicantID == objMatch.getApplicantID()) &&
		(this.requirementScore == objMatch.getRequirementScore()) &&
		((this.metRequirements).equals(objMatch.getMetRequirements()));
	}catch (RMIException r){
	    //result = false;
	}
	return result;
    }


    /**
     * Returns a job object related to this match.
     *
     * @return a <code>Job</code> value
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public JobI getJob() throws DAOException, RMIException{
	return ((JobI)jobDAO.getJob(jobID));
    }


    /**
     * Initializes the array of requirements metRequirements.
     *
     * @exception RMIException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public void initializeMetRequirements()throws RMIException, DAOException{
	metRequirements = matchesDAO.getMetRequirements(id);
    }
    
 
    /*SET AND GET METHODS
      -------------------*/


    /**
     * Returns the metRequirements ArrayList of qualification objects to the GUI.
     *
     * @return a <code>List</code> value
     * @exception RMIException if an error occurs
     */
    public List getMetRequirements()throws RMIException{
	return metRequirements;
    }


    /**
     * Sets the value of metRequirements
     *
     * @param argMetReqs a <code>List</code> value
     */
    public void setMetRequirements(List argMetReqs){
	metRequirements = argMetReqs;
    }

    /**
     * Gets the value of id
     *
     * @return the value of id
     * @exception RMIException if an error occurs
     */
    public int getID()  throws RMIException{
	return this.id;
    }

    /**
     * Sets the value of id
     *
     * @param argId Value to assign to this.id
     * @exception RMIException if an error occurs
     */
    public void setID(int argId) throws RMIException{
	this.id = argId;
    }

    /**
     * Gets the value of applicantID
     *
     * @return the value of applicantID
     * @exception RMIException if an error occurs
     */
    public int getApplicantID()  throws RMIException{
	return this.applicantID;
    }

    /**
     * Sets the value of applicantID
     *
     * @param argApplicantID Value to assign to this.applicantID
     * @exception RMIException if an error occurs
     */
    public void setApplicantID(int argApplicantID) throws RMIException{
	this.applicantID = argApplicantID;
    }

    /**
     * Gets the value of jobID
     *
     * @return the value of jobID
     * @exception RMIException if an error occurs
     */
    public int getJobID()  throws RMIException{
	return this.jobID;
    }

    /**
     * Sets the value of jobID
     *
     * @param argJobID Value to assign to this.jobID
     * @exception RMIException if an error occurs
     */
    public void setJobID(int argJobID) throws RMIException{
	this.jobID = argJobID;
    }

    /**
     * Gets the value of requirementScore
     *
     * @return the value of requirementScore
     * @exception RMIException if an error occurs
     */
    public int getRequirementScore()  throws RMIException{
	return this.requirementScore;
    }

    /**
     * Sets the value of requirementScore
     *
     * @param argRequirementScore Value to assign to this.requirementScore
     * @exception RMIException if an error occurs
     */
    public void setRequirementScore(int argRequirementScore) throws RMIException{
	this.requirementScore = argRequirementScore;
    }

    
    /**
     * Gets the value of dateOfMatch
     *
     * @return the value of dateOfMatch
     * @exception RMIException if an error occurs
     */
    public Date getDateOfMatch()  throws RMIException{
	return this.dateOfMatch;
    }

    /**
     * Sets the value of dateOfMatch
     *
     * @param argDateOfMatch Value to assign to this.dateOfMatch
     * @exception RMIException if an error occurs
     */
    public void setDateOfMatch(Date argDateOfMatch) throws RMIException{
	this.dateOfMatch = argDateOfMatch;
    }
}
