package dk.auc.cs.whiner.model;

import java.util.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.rmi.*;
import java.rmi.*;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.function.*;

public class TestAdministrator extends TestCase{


    public void testEquals() throws RemoteException, DAOException{

	Administrator admin1 = new Administrator();
	
        Administrator admin2 = new Administrator();
	
	assertTrue("Two administrators with same attributes are expected to be equal", admin1.equals(admin2));
	admin1.setLoginName("mamaosama");
	assertFalse("Two administrators with different attributes are expected not to be equal", admin1.equals(admin2));
	
	
    }

    public void testInitializeHeadhunterList() throws RemoteException, DAOException{
	Administrator admin1 = new Administrator();
	HeadhunterDAO hhDAO = new HeadhunterDAO();
	Headhunter hh = hhDAO.add();
	hh = hhDAO.add();
	hh = hhDAO.add();
	
	admin1.initializeHeadhunterList();
	assertEquals("Length should be 3", 3, admin1.getHeadhunterListLength());
	
	//cleanup
	hhDAO.delete(1);
	hhDAO.delete(2);
	hhDAO.delete(3);
	
    }

    public void testInitializeApplicantList() throws RemoteException, DAOException{
	Administrator admin1 = new Administrator();
	ApplicantDAO appDAO = new ApplicantDAO();
	Applicant app = appDAO.add();
	app = appDAO.add();
	app = appDAO.add();
	
	admin1.initializeApplicantList();
	assertEquals("Length should be 3", 3, admin1.getApplicantListLength());
	
	//cleanup
	appDAO.delete(1);
	appDAO.delete(2);
	appDAO.delete(3);
	
    }
    
    public void testDeleteApplicant() throws RemoteException, DAOException{
	Administrator admin1 = new Administrator();
	ApplicantDAO appDAO = new ApplicantDAO();
	Applicant app1 = appDAO.add();
	app1.setLoginName("app1");
	appDAO.update(app1);
	Applicant app2 = appDAO.add();
	app2.setLoginName("app2");
	appDAO.update(app2);
	Applicant app3 = appDAO.add();
	app3.setLoginName("app3");
	appDAO.update(app3);

	admin1.initializeApplicantList();
	int appNo = 0;
	for(appNo = 0; !(admin1.getApplicant(appNo).equals(app2.getLoginName())); appNo++);
	admin1.deleteApplicant(admin1.getApplicant(appNo));
	admin1.initializeApplicantList();

	assertEquals("Should only have two applicants", 2, admin1.getApplicantListLength());

	if(!(((admin1.getApplicant(0).equals("app1")) || (admin1.getApplicant(0).equals("app3"))) &&
	     ((admin1.getApplicant(1).equals("app1")) || (admin1.getApplicant(1).equals("app3")))))
	    fail("Applicant 1 and 3 should be the two applicants in the admin applicant list");

	//clean up
	appDAO.delete(app1.getID());
	appDAO.delete(app3.getID());
    }



    public void testCreateHeadhunter() throws RemoteException, DAOException, LoginNameException{
	Administrator admin = new Administrator();
	HeadhunterDAO headhunterDAO = new HeadhunterDAO();

	admin.createHeadhunter("bennett", "fisk");	    

	Headhunter headhunter = new Headhunter();
	headhunter.setID(1);
	headhunter.setLoginName("bennett");
	headhunter.setPassword("fisk");

	assertTrue("Headhunters are expected to be identical", headhunter.equals(headhunterDAO.getHeadhunter(1)));

	//clean up
	headhunterDAO.delete(1);
    }

    public void testDeleteHeadhunter() throws CloseException, AnnouncedJobException, RemoteException, DAOException, LoginNameException{
	Administrator admin = new Administrator();
	HeadhunterDAO headhunterDAO = new HeadhunterDAO();
	admin.createHeadhunter("bennett1", "fisk1");
	admin.createHeadhunter("bennett2", "fisk2");
	admin.createHeadhunter("bennett3", "fisk3");
	
	admin.initializeHeadhunterList();
	admin.deleteHeadhunter("bennett2");
	assertEquals("should only have two headhunters in his list", 2, admin.getHeadhunterListLength());
	admin.initializeHeadhunterList();
	int hhNo = 0;
	for(hhNo = 0; (hhNo < 2) && (!((admin.getHeadhunter(hhNo))).equals("bennett1")); hhNo++);
	if(hhNo > 1)
	    fail("The headhunter bennett1 is no logner in the list");
	for(hhNo = 0; (hhNo < 2) && (!((admin.getHeadhunter(hhNo))).equals("bennett3")); hhNo++);
	if(hhNo > 1)
	    fail("The headhunter bennett1 is no logner in the list");
    
	//clean up
	headhunterDAO.delete(1);
	headhunterDAO.delete(3);
    }
    

}
