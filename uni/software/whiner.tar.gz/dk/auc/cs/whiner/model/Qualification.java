package dk.auc.cs.whiner.model;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.rmi.RMIException;
import java.util.*;
import java.rmi.*;
import java.rmi.server.*;
/**
 * The "Qualification" class contains information about a global
 * qualification in the system. Is used when someone requests for the
 * global qualification list, or as a part of a skill-level object.
 *
 * @author <a href="mailto:carlsen@pico.cs.auc.dk">Jeppe Carlsen</a>
 * @version 1.0
 */
public class Qualification extends UnicastRemoteObject implements QualificationI{
    private int id = 0;
    private String name = "";
    private String description = "";

    //DAO objects
    QualificationDAO qualificationDAO;

    /**
     * Creates a new Qualification instance.
     *
     * @exception RemoteException if an error occurs
     * @exception DAOException if a dataaccess error occurs
     */
    public  Qualification() throws RemoteException, DAOException{
	qualificationDAO = new QualificationDAO();
    }

    /**
     * Tests for equality between two objects of the "Qualification" class.
     *
     * @param obj an <code>Object</code> value
     * @return a <code>boolean</code> value
     */
    public boolean equals(Object obj){
	if ( this == obj ) return true;
	if ( !(obj instanceof Qualification) ) return false;
	Qualification objQual = (Qualification) obj;
	boolean result = false;
	try {
	    result = 
		(this.id == objQual.getID()) &&
		((this.name).equals(objQual.getName())) &&
		((this.description).equals(objQual.getDescription())) ;
	} catch(RMIException e){
	    //do stuff!
	}
	return result;
    }
    
    

    /**
     * Saves the qualification object in the database.
     *
     * @exception DAOException if a dataaccess error occurs
     * @exception RMIException if an error occurs
     */
    public void save() throws DAOException, RMIException{
	qualificationDAO.update(this);
    }


    /*SET AND GET METHODS
      -------------------*/
    
    /**
     * Gets the value of id
     *
     * @return the value of id
     * @exception RMIException if an error occurs
     */
    public int getID()  throws RMIException{
	return this.id;
    }

    /**
     * Sets the value of id
     *
     * @param argId Value to assign to this.id
     * @exception RMIException if an error occurs
     */
    public void setID(int argId) throws RMIException{
	this.id = argId;
    }
    
    /**
     * Gets the value of name
     *
     * @return the value of name
     * @exception RMIException if an error occurs
     */
    public String getName()  throws RMIException{
	return this.name;
    }
    
    /**
     * Sets the value of name
     *
     * @param argName Value to assign to this.name
     * @exception RMIException if an error occurs
     */
    public void setName(String argName) throws RMIException{
	this.name = argName;
    }
    
    /**
     * Gets the value of description
     *
     * @return the value of description
     * @exception RMIException if an error occurs
     */
    public String getDescription()  throws RMIException{
	return this.description;
    }
    
    /**
     * Sets the value of description
     *
     * @param argDescription Value to assign to this.description
     * @exception RMIException if an error occurs
     */
    public void setDescription(String argDescription) throws RMIException{
	this.description = argDescription;
    }
}