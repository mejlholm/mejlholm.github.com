import java.security.*;
import dk.auc.cs.whiner.gui.share.*;

public class Pass {

    public static void main(String[] args){

	try{
	    CryptPassword pwd = new CryptPassword(args[0]);
	    String password = pwd.cryptSHA();
	    System.out.println(password);
	} catch (NoSuchAlgorithmException e) {
	    System.out.println("SWIN");
	}



    }

}
