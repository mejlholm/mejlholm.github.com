package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import java.util.*;
import java.rmi.*;

/**
 * The <code>CVI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.model.CV} and is used for remote
 * communication between W.H.I.N.E.R severs and clients.
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface CVI extends Remote{
    public void initializeGlobalQualificationList() throws RemoteException;
    public void initializeQualificationList() throws RemoteException, DAOException;
    public int getApplicantQualificationListLength() throws RemoteException;
    public void deselectCV() throws RemoteException;
    public void addQualification(int globalQualificationNo, int level) throws RemoteException;
    public void removeQualification(int qualificationNo) throws RemoteException;
    public QualificationI getGlobalQualification(int globalQualNo) throws RemoteException; 
    public int getGlobalQualificationListLength() throws RemoteException;
    public SkillLevelI getQualification(int qualNo) throws RemoteException;
    public void save() throws RemoteException, DAOException;
    public void saveQualifications() throws RemoteException, DAOException;
    public int getApplicantID() throws RemoteException;
    public void setApplicantID(int argApplicantID) throws RemoteException;
    public Date getDateOfBirth() throws RemoteException;
    public void setDateOfBirth(Date argDateOfBirth) throws RemoteException;
    public String getSex() throws RemoteException;
    public void setSex(String argSex) throws RemoteException;
    public String getMaritalStatus() throws RemoteException;
    public void setMaritalStatus(String argMaritalStatus) throws RemoteException;
    public String getEducation() throws RemoteException;
    public void setEducation(String argEducation) throws RemoteException;
    public String getWorkingExperience() throws RemoteException;
    public void setWorkingExperience(String argWorkingExperience) throws RemoteException;
    public String getReEducation() throws RemoteException;
    public void setReEducation(String argReEducation) throws RemoteException;
    public String getLanguageSkills() throws RemoteException;
    public void setLanguageSkills(String argLanguageSkills) throws RemoteException;
    public String getOtherITKnowledge() throws RemoteException;
    public void setOtherITKnowledge(String argOtherITKnowledge) throws RemoteException;
    public String getSpareTimeInterests() throws RemoteException;
    public void setSpareTimeInterests(String argSpareTimeInterests) throws RemoteException;
}
