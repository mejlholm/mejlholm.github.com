package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import java.util.*;
import java.rmi.*;

/**
 * The <code>JobI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.model.Job} and is used for remote
 * comminucation between W.H.I.N.E.R severs and clients.
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface JobI extends Remote{
    public void initializeJobQualificationList() throws RemoteException, DAOException;
    public void initializeGlobalQualificationList() throws DAOException, RemoteException;
    public void initializeJobApplicationList() throws DAOException, RemoteException;
    public void deselectJob() throws RemoteException;
    public ProjectI getProject() throws DAOException, RemoteException;
    public SkillLevelI getRequirement(int requirementNo) throws RemoteException;
    public QualificationI getGlobalQualification(int qualNo) throws RemoteException;    
    public ApplicationI getApplication(int applicationNo) throws RemoteException;
    public int getJobApplicationListLength() throws RemoteException;
    public int getJobQualificationListLength() throws RemoteException;
    public int getGlobalQualificationListLength() throws RemoteException;
    public void addRequirement(int globalQualificationNo, int level) throws RemoteException, DAOException;
    public void removeRequirement(int qualificationNo) throws RemoteException, DAOException;
    public void save() throws DAOException, RemoteException;
    public void saveRequirements() throws DAOException, RemoteException;
    public void reopen() throws DAOException, RemoteException, ReopenException;
    public void close() throws RemoteException, DAOException, CloseException;
    public void hireApplicant(int applicationNo) throws DAOException, RemoteException, HireException;
    public void createApplication(int applicantID) throws DAOException, RemoteException, AlreadyAppliedException;
    public void deleteApplicationIfNotSubmitted(int applicationNo) throws DAOException, RemoteException, DeleteException;
    public void rejectApplication(int applicationNo)  throws DAOException, RemoteException;
    public void createQualification(String argName, String argDescription) throws DAOException, RemoteException;
    public void deleteQualification(int globalQualificationNo) throws DAOException, RemoteException;
    public int getID() throws RemoteException;
    public void setID(int argID) throws RemoteException;
    public int getProjectID() throws RemoteException;
    public void setProjectID(int argProjectID) throws RemoteException;
    public Date getDateOfAnnouncement() throws RemoteException;
    public void setDateOfAnnouncement(Date argDateOfAnnouncement) throws RemoteException;
    public Date getDateOfOccupation() throws RemoteException;
    public void setDateOfOccupation(Date argDateOfOccupation) throws RemoteException;
    public Date getDateOfCreation() throws RemoteException;
    public void setDateOfCreation(Date argDateOfCreation) throws RemoteException;
    public String getStatus() throws RemoteException;
    public void setStatus(String argStatus) throws RemoteException;
    public String getTitle() throws RemoteException;
    public void setTitle(String argTitle) throws RemoteException;
    public String getDescription() throws RemoteException;
    public void setDescription(String argDescription) throws RemoteException;
}
