package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*; 
import java.util.*; 
import java.rmi.*; 

/**
 * The <code>GlobalQualificationListI</code> interfaceis implemented
 * by {@link dk.auc.cs.whiner.model.GlobalQualificationList} and is
 * used for remote communication between W.H.I.N.E.R severs and
 * clients..
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface GlobalQualificationListI extends Remote{
    public QualificationI getQualification(int qualNo) throws RemoteException;
    public int getLength() throws RemoteException;
    public void createQualification(String argName, String argDescription) throws DAOException, RemoteException;
    public void deleteQualification(int qualificationNo) throws DAOException, RemoteException;
    public void updateQualification(int qualificationNo, String argName, String argDescription) throws DAOException, RemoteException;	
}  
