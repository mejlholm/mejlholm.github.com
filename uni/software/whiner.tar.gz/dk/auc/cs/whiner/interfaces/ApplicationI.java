package dk.auc.cs.whiner.interfaces; 

import dk.auc.cs.whiner.dataaccess.*; 
import dk.auc.cs.whiner.model.*; 
import java.util.*; 
import java.rmi.*; 

/**
 * The <code>ApplicationI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.model.Application} and is used for remote
 * communication between W.H.I.N.E.R severs and clients
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface ApplicationI extends Remote{
    public String getApplicantName(int applicantID) throws RemoteException, DAOException;
    public JobI getJob(int jobID) throws RemoteException, DAOException;
    public ApplicantI getApplicant(int applicantID) throws RemoteException, DAOException;
    public void save() throws DAOException, RemoteException;
    public void cancelApplication() throws DAOException, RemoteException;
    public void submitApplication() throws DAOException, RemoteException, Exception;
    public void reject() throws DAOException, RemoteException;
    public int getID()  throws RemoteException;
    public void setID(int argID) throws RemoteException;
    public int getJobID()  throws RemoteException;
    public void setJobID(int argJobID) throws RemoteException;
    public int getApplicantID() throws RemoteException;
    public void setApplicantID(int argApplicantID) throws RemoteException;
    public String getStatus()  throws RemoteException;
    public void setStatus(String argStatus) throws RemoteException;
    public String getBodyText()  throws RemoteException;
    public void setBodyText(String argBodyText) throws RemoteException;
    public void setDateOfCreation(Date argDate)throws RemoteException;
    public Date getDateOfCreation()throws RemoteException;
    public Date getDateOfSubmission() throws RemoteException;
    public void setDateOfSubmission(Date argDateOfSubmission) throws RemoteException;
    public Date getDateOfRejection()  throws RemoteException;
    public void setDateOfRejection(Date argDateOfRejection) throws RemoteException;
    public int findRequirementScore() throws DAOException, RemoteException;
}  
