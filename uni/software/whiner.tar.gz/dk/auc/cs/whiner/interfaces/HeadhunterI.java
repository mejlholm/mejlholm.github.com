package dk.auc.cs.whiner.interfaces; 

import dk.auc.cs.whiner.interfaces.UserI;
import dk.auc.cs.whiner.dataaccess.*; 
import dk.auc.cs.whiner.model.*; 
import java.util.*; 
import java.rmi.*; 

/**
 * The <code>HeadhunterI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.model.Headhunter} and is used for remote
 * communication between W.H.I.N.E.R severs and clients.
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface HeadhunterI extends UserI {
    public void initializeProjectList() throws RemoteException, DAOException;
    public ProjectI selectProject(int projectNo) throws RemoteException, DAOException;
    public ProjectI getProject(int projectNo) throws RemoteException;
    public int getProjectListLength() throws RemoteException;
    public void createProject() throws DAOException, RemoteException;
    public void deleteProject(int projectNo) throws AnnouncedJobException, DAOException, RemoteException;
    public void deleteAllProjects() throws AnnouncedJobException, RemoteException, DAOException, CloseException;
    public void changePassword(String newPassword) throws RemoteException, DAOException;
    public int getID()  throws RemoteException;
    public void setID(int argID) throws RemoteException;
    public String getLoginName() throws RemoteException;
    public void setLoginName(String argLoginName) throws RemoteException;
    public String getPassword() throws RemoteException;
    public void setPassword(String argPassword) throws RemoteException;
}  
