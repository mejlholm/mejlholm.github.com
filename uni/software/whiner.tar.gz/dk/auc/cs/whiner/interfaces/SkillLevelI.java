package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import java.util.*;
import java.rmi.*;

/**
 * The <code>SkillLevelI</code> interface is implemented by 
  * {@link dk.auc.cs.whiner.model.SkillLevel} and is used for remote
 * communication between W.H.I.N.E.R severs and clients.
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface SkillLevelI extends Remote{
    public int getID()throws RemoteException;
    public void setID(int argID)throws RemoteException;
    public QualificationI getQualification()  throws RemoteException;
    public void setQualification(QualificationI argQualification) throws RemoteException;
    public int getLevel()  throws RemoteException;
    public void setLevel(int argLevel) throws RemoteException;
}  
