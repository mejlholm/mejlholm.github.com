package dk.auc.cs.whiner.interfaces; 

import dk.auc.cs.whiner.dataaccess.*; 
import dk.auc.cs.whiner.model.*; 
import java.util.*; 
import java.rmi.*; 

/**
 * The <code>MatchI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.model.Match} and is used for remote
 * communication between W.H.I.N.E.R severs and clients.
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface MatchI extends Remote {
    public void initializeMetRequirements()throws RemoteException, DAOException;
    public JobI getJob() throws RemoteException, DAOException;
    public List getMetRequirements()throws RemoteException;
    public int getID()  throws RemoteException;
    public void setID(int argId) throws RemoteException;
    public int getApplicantID()  throws RemoteException;
    public void setApplicantID(int argApplicantID) throws RemoteException;
    public int getJobID()  throws RemoteException;
    public void setJobID(int argJobID) throws RemoteException;
    public int getRequirementScore()  throws RemoteException;
    public void setRequirementScore(int argRequirementScore) throws RemoteException;
    public Date getDateOfMatch()  throws RemoteException;
    public void setDateOfMatch(Date argDateOfMatch) throws RemoteException;
}  
