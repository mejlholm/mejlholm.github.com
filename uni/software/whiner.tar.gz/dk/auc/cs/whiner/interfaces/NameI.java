package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import java.util.*;
import java.rmi.*;

/**
 * The <code>NameI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.model.Name} and is used for remote
 * communication between W.H.I.N.E.R severs and clients.
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface NameI extends Remote{
    public void setFirstName(String argFirstName) throws RemoteException;
    public String getFirstName() throws RemoteException;
    public void setMiddleName(String argMiddleName) throws RemoteException;
    public String getMiddleName() throws RemoteException;
    public void setLastName(String argLastName) throws RemoteException;
    public String getLastName() throws RemoteException;
}
