package dk.auc.cs.whiner.interfaces; 

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*; 
import dk.auc.cs.whiner.rmi.RMIException; 
import java.util.*; 
import java.rmi.*; 

/**
 * The <code>NotificationI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.model.Notification} and is used for remote
 * communication between W.H.I.N.E.R severs and clients..
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface NotificationI extends Remote{
    public String getJobName() throws DAOException, RemoteException;
    public int getID()  throws RemoteException;
    public void setID(int argID) throws RemoteException;
    public int getApplicantID()  throws RemoteException;
    public void setApplicantID(int argApplicantID) throws RemoteException;
    public int getJobID()  throws RemoteException;
    public void setJobID(int argJobID) throws RemoteException;
    public String getNotificationType()  throws RemoteException;
    public void setNotificationType(String argNotificationType) throws RemoteException;
    public String getTitle()  throws RemoteException;
    public void setTitle(String argTitle) throws RemoteException;
    public String getBodyText() throws RemoteException;
    public void setBodyText(String argBodyText) throws RemoteException;
    public Date getDateOfDispatch() throws RemoteException;
    public void setDateOfDispatch(Date argDateOfDispatch) throws RemoteException;
}  
