package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.interfaces.UserI;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.function.*; //for exception types
import java.util.*;
import java.rmi.*;


 /**
  * Interface <code>AdministratorI</code> is implemented by 
  * {@link dk.auc.cs.whiner.model.Administrator} and is used for remote
  * communication between W.H.I.N.E.R severs and clients
  *
  * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
  * @version 1.0
  */
     public interface AdministratorI extends UserI {
    public void initializeHeadhunterList() throws RemoteException, DAOException;
    public void initializeApplicantList() throws RemoteException, DAOException;
    public int getHeadhunterListLength()throws RemoteException;
    public int getApplicantListLength()throws RemoteException;
    public void deleteApplicant(String appLginName)throws RemoteException, DAOException, CloseException;
    public void createHeadhunter(String argLoginName, String argPassword) throws RemoteException, DAOException, LoginNameException;
    public String getHeadhunter(int HHNo) throws RemoteException, DAOException;
    public String getApplicant(int appNo) throws RemoteException, DAOException;
    public void deleteHeadhunter(String hhLginName) throws DAOException, RemoteException, CloseException, AnnouncedJobException;
    public void changeHeadhunterPassword(String newPassword, String hhLginName) throws RemoteException, DAOException;
}
