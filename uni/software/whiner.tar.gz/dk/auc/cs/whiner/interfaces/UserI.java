package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.dataaccess.DAOException;
import java.rmi.*;

/**
 * The <code>UserI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.model.User} and is used for remote
 * communication between W.H.I.N.E.R severs and clients.
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface UserI extends Remote{
    public void changePassword(String newPassword) throws RemoteException, DAOException;
    public String getLoginName()   throws RemoteException;
    public void setLoginName(String argLoginName)  throws RemoteException;
    public String getPassword()   throws RemoteException;
    public void setPassword(String argPassword) throws RemoteException;
    public int getID()   throws RemoteException;
    public void setID(int argID)  throws RemoteException;
}
