package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.interfaces.UserI;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.function.Search;
import java.util.*;
import java.rmi.*;

/**
 * The <code>ApplicantI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.model.Applicant} and is used for remote
 * communication between W.H.I.N.E.R severs and clients
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface ApplicantI extends UserI{
    public void initializeMatchList()throws RemoteException, DAOException;
    public void initializeNotificationList()throws RemoteException, DAOException;
    public void initializeApplicantApplicationList()throws RemoteException, DAOException;
    public CVI selectCV()throws RemoteException, DAOException;
    public ApplicationI getApplication(int applicationNo)throws RemoteException;
    public NotificationI getNotification(int notificationNo)throws RemoteException;
    public MatchI getMatch(int matchNo)throws RemoteException;
    public int getNotificationListLength()throws RemoteException;
    public int getApplicationListLength()throws RemoteException;
    public int getMatchListLength()throws RemoteException;
    public void deleteApplicationDraft(int applicationNo) throws DAOException, RemoteException;
    public void changePassword(String newPassword) throws RemoteException;
    public void deleteApplicant()throws DAOException, RemoteException;
    public void deleteNotification(int notificationNo) throws DAOException, RemoteException;
    public void deleteMatch(int matchNo) throws DAOException, RemoteException;
    public void save() throws DAOException, RemoteException;
    public SearchI beginSearch(int[] agrSearchSpecs)throws RemoteException, DAOException;
    public void setName(NameI argName) throws RemoteException;
    public NameI getName() throws RemoteException;
    public void setAddress(AddressI argAddress) throws RemoteException;
    public AddressI getAddress() throws RemoteException;
    public void setPhoneNumber(PhoneNumberI argPhoneNumber) throws RemoteException;
    public PhoneNumberI getPhoneNumber() throws RemoteException;
    public void setCV(CVI argCV)throws RemoteException;
    public CVI getCV()throws RemoteException;
    public int getID()  throws RemoteException;
    public void setID(int argId) throws RemoteException;
    public Date getLastLogin()  throws RemoteException;
    public void setLastLogin(Date argLastLogin) throws RemoteException;
    public Date getDateOfInterest()  throws RemoteException;
    public void setDateOfInterest(Date argDateOfInterest) throws RemoteException;
    public String getEmail()  throws RemoteException;
    public void setEmail(String argEmail) throws RemoteException;
    public String getLoginName()  throws RemoteException;
    public void setLoginName(String argLoginName) throws RemoteException;
    public String getPassword()  throws RemoteException;
    public void setPassword(String argPassword) throws RemoteException;
}
