package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import java.util.*;
import java.rmi.*;

/**
 * The <code>PhoneNumberI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.model.PhoneNumber} and is used for remote
 * communication between W.H.I.N.E.R severs and clients.
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface PhoneNumberI extends Remote{
    public int getHomePhone() throws RemoteException;
    public void setHomePhone(int argHomePhone) throws RemoteException;
    public int getWorkPhone() throws RemoteException;
    public void setWorkPhone(int argWorkPhone) throws RemoteException;
    public int getMobile() throws RemoteException;
    public void setMobile(int argMobile) throws RemoteException;
    public int getFax() throws RemoteException;
    public void setFax(int argFax) throws RemoteException;
}
