package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.dataaccess.*; 
import dk.auc.cs.whiner.model.*;

import java.util.*; 
import java.rmi.*; 

/**
 * The <code>SearchI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.function.Search} and is used for remote
 * communication between W.H.I.N.E.R severs and clients.
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface SearchI extends Remote{
    public JobI getJob(int jobNo) throws RemoteException;
    public int getLength()throws RemoteException;
}  
