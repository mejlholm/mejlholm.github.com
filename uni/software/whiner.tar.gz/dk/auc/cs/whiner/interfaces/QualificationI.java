package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*; 
import java.util.*; 
import java.rmi.*; 

/**
 * The <code>QualificationI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.model.Qualification} and is used for remote
 * communication between W.H.I.N.E.R severs and clients.
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface QualificationI extends Remote{
    public int getID()  throws RemoteException;
    public void setID(int argId) throws RemoteException;
    public String getName()  throws RemoteException;
    public void setName(String argName) throws RemoteException;
    public void save() throws RemoteException, DAOException;
    public String getDescription()  throws RemoteException;
    public void setDescription(String argDescription) throws RemoteException;
}  
