package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.dataaccess.DAOException;
import dk.auc.cs.whiner.dataaccess.WrongPasswordOrUsernameException;
import java.util.*;
import java.rmi.Remote;

/**
 * The <code>LoginI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.function.Login} and is used for remote
 * communication between W.H.I.N.E.R severs and clients.
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface LoginI extends Remote{
    public UserI login(String userLginName, String userPassword) throws Exception, DAOException, WrongPasswordOrUsernameException;
}

