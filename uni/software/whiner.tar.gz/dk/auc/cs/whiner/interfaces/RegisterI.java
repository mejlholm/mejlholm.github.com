package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.function.*;
import java.util.*;
import java.rmi.*;

/**
 * The <code>RegisterI</code> interface is implemented by 
 * {@link dk.auc.cs.whiner.function.Register} and is used for remote
 * communication between W.H.I.N.E.R severs and clients.
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface RegisterI extends Remote{
    public ApplicantI activateApplicant(String argLoginName, String argPassword) throws DAOException, RemoteException, LoginNameException;
}
										   
