package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import java.util.*;
import java.rmi.*;

/**
 * The interface <code>AddressI</code> is implemented by 
 * {@link dk.auc.cs.whiner.model.Address} and is used for remote
 * communication between W.H.I.N.E.R severs and clients
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface AddressI extends Remote{
    public String getAddress1() throws RemoteException; 
    public void setAddress1(String argAddress1) throws RemoteException;
    public String getAddress2()  throws RemoteException;
    public void setAddress2(String argAddress2) throws RemoteException;
    public String getCity()  throws RemoteException;
    public void setCity(String argCity) throws RemoteException;
    public int getPostCode()  throws RemoteException;
    public void setPostCode(int argPostcode) throws RemoteException;
    public String getRegion()  throws RemoteException;
    public void setRegion(String argRegion) throws RemoteException;
    public String getCountry()  throws RemoteException;
    public void setCountry(String argCountry) throws RemoteException;
}
