package dk.auc.cs.whiner.interfaces;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import java.util.*;
import java.rmi.*;

/**
 * The <code>ProjectI</code> interface is implemented by 
  * {@link dk.auc.cs.whiner.model.Project} and is used for remote
 * communication between W.H.I.N.E.R severs and clients.
 *
 * @author <a href="mailto:soren@5o5.dk">S�ren 'Pengman' Pedersen</a>
 * @version 1.0
 */
public interface ProjectI extends Remote{
    public void initializeJobList() throws RemoteException, DAOException;
    public JobI selectJob(int jobNo) throws DAOException, RemoteException;
    public void deselectProject()throws RemoteException;
    public JobI getJob(int jobNo)throws RemoteException;
    public int getJobListLength()throws RemoteException;
    public JobI createJob() throws DAOException, RemoteException;
    public void deleteJobIfNotAnnounced(int jobNo) throws DAOException, AnnouncedJobException, RemoteException ;
    public void save() throws DAOException, RemoteException;
    public void announceCheckedJobs(int[] checked) throws DAOException, RemoteException;
    public void closeAllJobs() throws RemoteException, DAOException, CloseException;
    public int getID() throws RemoteException;
    public void setID(int argID) throws RemoteException;
    public int getHeadhunterID()  throws RemoteException;
    public void setHeadhunterID(int argHeadhunterID) throws RemoteException;
    public Date getDateOfCreation()  throws RemoteException;
    public void setDateOfCreation(Date argDateOfCreation) throws RemoteException;
    public String getStatus()  throws RemoteException;
    public void setStatus(String argStatus) throws RemoteException;
    public String getDescription()  throws RemoteException;
    public void setDescription(String argDescription) throws RemoteException;
    public String getTitle()throws RemoteException;
    public void setTitle(String argTitle)throws RemoteException;
}
