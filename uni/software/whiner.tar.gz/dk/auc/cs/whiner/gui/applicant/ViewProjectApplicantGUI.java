/**
 *
 * @author  Jesper Kristensen
 * @version $Revision: 1.14 $
 */
package dk.auc.cs.whiner.gui.applicant;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;

import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

public class ViewProjectApplicantGUI extends JApplet {  
    private MsgErrorWarning msgErrorWarning;
    private Container cp;
    private String applicationName;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JPanel westPanel;
    private JPanel mainTopPanel;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JPanel eastPanel;
    private JLabel titleLabel;
    private JLabel descriptionLabel;
    private JLabel jobLabel;
    private JButton logoutButton;
    private JScrollPane projectScrollPanel;
    private JTextArea projectTextArea;
    private JButton backButton;
    private int applicantName;
    private JList jobList;
    private DefaultListModel jobListModel;
    private JScrollPane	jobListScrollPanel;
    private JButton applicationButton;
    private ProjectI project;
    private SearchI search;
    private JobI job;
    private ApplicantI applicant;
    private boolean backFlag = false;
    private int jobNo = -1;

    public ViewProjectApplicantGUI(ProjectI project, SearchI search, JobI job, ApplicantI applicant, boolean backFlag) {
	this.project = project;
	this.search = search;
	this.job = job;
	this.applicant = applicant;
	this.backFlag = backFlag;
        initComponents();
    }

   public ViewProjectApplicantGUI(ProjectI project, JobI job, int jobNo, ApplicantI applicant) {
	this.project = project;
	this.job = job;
	this.jobNo = jobNo;
	this.applicant = applicant;
        initComponents();
    }

    private void initComponents() {
	applicationButton = new JButton();
	backButton = new JButton();
        buttomPanel = new JPanel();
	cp = getContentPane();
	descriptionLabel = new JLabel();
        eastPanel = new JPanel();
	jobLabel = new JLabel();
        jobList = new JList();
	jobListScrollPanel = new JScrollPane();
	logoutButton = new JButton();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
	projectScrollPanel = new JScrollPane();
	projectTextArea = new JTextArea();
	titleLabel = new JLabel();
        topPanel = new JPanel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

	mainTopPanel.add(titleLabel, new AbsoluteConstraints(20, 20, -1, -1));

	descriptionLabel.setText("Project description:");
	mainTopPanel.add(descriptionLabel, new AbsoluteConstraints(20, 40, -1, -1));

	projectScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        projectScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        projectTextArea.setEditable(false);
        projectTextArea.setLineWrap(true);
	projectTextArea.setBackground(new Color(233,233,242));
        projectScrollPanel.setViewportView(projectTextArea);
        mainTopPanel.add(projectScrollPanel, new AbsoluteConstraints(20, 60, 520, 170));

	jobLabel.setText("Jobs relate to this project:");
	mainTopPanel.add(jobLabel, new AbsoluteConstraints(20, 240, -1, -1));

        jobListScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
	jobListModel = new DefaultListModel();
        jobList.setModel(jobListModel);
        jobList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        jobList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseJobList(evt);
            }
        });
        jobListScrollPanel.setViewportView(jobList);
        mainTopPanel.add(jobListScrollPanel, new AbsoluteConstraints(20, 260, 520, 170));

	mainTopPanel.setBackground(new Color(233,233,242));
	mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 450));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());
        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());
	
	backButton.setText("Back");
        backButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseBackButton();
		}
	    });
        buttomPanel.add(backButton,  new AbsoluteConstraints(0, 0, -1, -1));

	applicationButton.setText("Application");
	applicationButton.setToolTipText("Write an application for the selected job");
        applicationButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseApplicationButton();
		}
	    });
        buttomPanel.add(applicationButton,  new AbsoluteConstraints(70, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	mainJPanel.setBackground(new Color(233,233,242));
	cp.add(mainJPanel, BorderLayout.CENTER);
	
	// Get project information
	getInformation();
    }

    private void getInformation() {
	try {
	    titleLabel.setText("Title: " + project.getTitle());
	    projectTextArea.setText(project.getDescription());
	    // Load jobs relate to the project
	    project.initializeJobList();
	    for (int i = 0; i < project.getJobListLength(); i++) {
		String argToList = new String(((JobI)project.getJob(i)).getTitle());
		jobListModel.insertElementAt(argToList, i);
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void mouseBackButton() {
	if (backFlag) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new ViewSearchJobApplicantGUI(job, search, applicant));
	    setContentPane(cp);
	} else {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new ViewJobApplicantGUI(job, jobNo, applicant));
	    setContentPane(cp);
	}
    }

    private void mouseJobList(MouseEvent evt) {
 	if (evt.getClickCount() == 2) {
	    mouseApplicationButton();
	}
    }

    private void mouseApplicationButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new ViewAppApplicantGUI("new", -1, job, applicant));
	setContentPane(cp);	
    }
}
