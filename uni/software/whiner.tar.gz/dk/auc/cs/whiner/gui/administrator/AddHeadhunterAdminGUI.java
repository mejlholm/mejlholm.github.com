/**
 *
 * @author  Jesper Kristensen
 * @Version $Revision: 1.12 $
 */
package dk.auc.cs.whiner.gui.administrator;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import java.security.*;
import java.rmi.RemoteException;

import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.function.*;
import dk.auc.cs.whiner.dataaccess.DAOException;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

public class AddHeadhunterAdminGUI extends JApplet {  
    private MsgErrorWarning msgErrorWarning;
    private Container cp;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JPanel westPanel;
    private JPanel mainTopPanel;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JPanel eastPanel;
    private JButton logoutButton;
    private JButton backButton;
    private String passwordSHA;
    private String loginName;
    private String password;
    private JLabel loginNameLabel;
    private JLabel passwordLabel;
    private JPasswordField passwordField;
    private JTextField loginNameText;
    private JButton addButton;
    private AdministratorI admin;

    public AddHeadhunterAdminGUI(AdministratorI admin) {
	this.admin = admin;
        initComponents();
    }

    private void initComponents() {
	backButton = new JButton();
        buttomPanel = new JPanel();
	cp = getContentPane();
        eastPanel = new JPanel();
	logoutButton = new JButton();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
        topPanel = new JPanel();
        westPanel = new JPanel();
	loginNameLabel = new JLabel();
	passwordLabel = new JLabel();
	passwordField = new JPasswordField();
	loginNameText = new JTextField();
	addButton = new JButton();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));


	loginNameLabel.setText("User name:");
	mainTopPanel.add(loginNameLabel, new AbsoluteConstraints(140, 180, -1, -1));

	passwordLabel.setText("Password:");
	mainTopPanel.add(passwordLabel, new AbsoluteConstraints(140, 205, -1, -1));

        mainTopPanel.add(loginNameText, new AbsoluteConstraints(220, 180, 200, -1));

        mainTopPanel.add(passwordField, new AbsoluteConstraints(220, 205, 200, -1));

	addButton.setText("Add headhunter");
        addButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseAddButton();
		}
	    });
        mainTopPanel.add(addButton, new AbsoluteConstraints(240, 235, -1, -1));

	mainTopPanel.setBackground(new Color(233,233,242));
	mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 450));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());
        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
       topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());
	
	backButton.setText("Back to main");
        backButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseBackButton();
		}
	    });
        buttomPanel.add(backButton,  new AbsoluteConstraints(0, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	mainJPanel.setBackground(new Color(233,233,242));
	cp.add(mainJPanel, BorderLayout.CENTER);
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void mouseBackButton() {
	cp.removeAll();
	try {
	    cp.add(BorderLayout.CENTER, new MainAdminGUI(admin));
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	setContentPane(cp);
    }

    private void mouseAddButton() {
	boolean ok = true;
	// Test if a login name has been given
	if (((loginNameText.getText()).equals("")) && (ok == true)) {
	    loginNameText.setBackground(new Color(255,255,104));
	    msgErrorWarning = new MsgErrorWarning("You need to give a user name, to create a new headhunter.");
	    msgErrorWarning.msgError();
	    ok = false;
	}
	// Test if a password has been given
	if (((new String(passwordField.getPassword())).equals("")) && (ok == true)) {
	    passwordField.setBackground(new Color(255,255,104));
	    msgErrorWarning = new MsgErrorWarning("You need to give a password, to create a new headhunter.");
	    msgErrorWarning.msgError();
	    ok = false;
	}

	if (ok) {
	    try {
		CryptPassword pwdSHA = new CryptPassword(new String(passwordField.getPassword()));
		passwordSHA = pwdSHA.cryptSHA();
	    } catch (NoSuchAlgorithmException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the password funktion.\n The applet will exit.");
		msgErrorWarning.msgError();
		System.exit(-1);
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return; 
	    }

	    // Make the headhunter in the database
	    try {
		admin.createHeadhunter(loginNameText.getText(), passwordSHA);
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (LoginNameException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error, with the user database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return; 
	    }

	    cp.removeAll();
	    try {
		cp.add(BorderLayout.CENTER, new MainAdminGUI(admin));
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;
	    }
	    setContentPane(cp);
	}
    }
}
