/**
 *
 * @author  Jesper Kristensen
 * @version $Revision: 1.11 $
 */

package dk.auc.cs.whiner.gui.headhunter;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

public class ReportHeadhunterGUI extends JApplet {
    private MsgErrorWarning msgErrorWarning;
    private Container cp;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JPanel westPanel;
    private JButton backButton;
    private JTextArea reportViewArea;
    private JPanel mainTopPanel;
    private JButton logoutButton;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JButton saveButton;
    private JScrollPane reportScrollPanel;
    private JButton printButton;
    private JPanel eastPanel;
    private JLabel reportLabel;
    private HeadhunterI hh;

    public ReportHeadhunterGUI(HeadhunterI hh) {
	this.hh = hh;
        initComponents();
    }
    
    private void initComponents() {
	cp = getContentPane();
	mainJPanel = new JPanel();
	mainPanel = new JPanel();
        mainTopPanel = new JPanel();
        reportScrollPanel = new JScrollPane();
        reportViewArea = new JTextArea();
        reportLabel = new JLabel();
        topPanel = new JPanel();
        logoutButton = new JButton();
        buttomPanel = new JPanel();
        backButton = new JButton();
        saveButton = new JButton();
        printButton = new JButton();
        eastPanel = new JPanel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));
        reportScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        reportScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        reportViewArea.setBackground(new Color(233, 233, 242));
        reportViewArea.setEditable(false);
        reportViewArea.setLineWrap(true);
        reportViewArea.setWrapStyleWord(true);
        reportScrollPanel.setViewportView(reportViewArea);

        mainTopPanel.add(reportScrollPanel, new AbsoluteConstraints(20, 40, 525, 390));

        reportLabel.setText("Statistic report");
        mainTopPanel.add(reportLabel, new AbsoluteConstraints(250, 20, -1, -1));

	mainTopPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 450));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());

        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());

        backButton.setText("Back to main");
        backButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseBackButton();
		}
	    });
        buttomPanel.add(backButton, new AbsoluteConstraints(0, 0, -1, -1));

        saveButton.setText("Save");
        saveButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseSaveButton();
		}
	    });
        buttomPanel.add(saveButton, new AbsoluteConstraints(130, 0, -1, -1));

        printButton.setText("Print");
        printButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mousePrintButton();
		}
	    });
        buttomPanel.add(printButton, new AbsoluteConstraints(195, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	mainJPanel.setBackground(new Color(233,233,242));
	cp.add(mainJPanel, BorderLayout.CENTER);
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void mouseBackButton() {
	cp.removeAll();
	try {
	    cp.add(BorderLayout.CENTER, new MainHeadhunterGUI(hh));
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	setContentPane(cp);
    }

    private void mouseSaveButton() {
	//
	// SAVE THE REPORT IN SOME FORM
	//
    }

    private void mousePrintButton() {
	//
	// MAKE SOME CODE THAT PRINTS OUT THE REPORT ON THE CLINTS PRINTER
	//
    }
}
