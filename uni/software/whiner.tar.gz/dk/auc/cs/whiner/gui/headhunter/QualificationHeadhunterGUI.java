/**
 *
 * @author  Jesper Kristensen
 * @version $Revision: 1.42 $
 */
package dk.auc.cs.whiner.gui.headhunter;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

public class QualificationHeadhunterGUI extends JApplet {
    private MsgErrorWarning msgErrorWarning;
    private String qualificationTitleTextBackup;
    private String qualificationTextAreaBackup;
    private int jobNo;
    private boolean newQualificationFlag;
    private Container cp;
    private JPanel mainJPanel;
    private JTextArea qualificationTextArea;
    private JPanel topPanel;
    private JButton qualificationEditButton;
    private JButton qualificationDelButton;
    private JPanel westPanel;
    private JPanel mainCenterPanel;
    private JLabel qualificationEditTitleLabel;
    private JPanel mainTopPanel;
    private JButton globalQualificationDelButton;
    private JButton logoutButton;
    private JButton qualificationCancelButton;
    private JButton backButton;
    private JPanel mainPanel;
    private JList qualificationList;
    private JPanel buttomPanel;
    private JScrollPane qualificationListScrollPanel;
    private JPanel mainButtomPanel;
    private JPanel eastPanel;
    private JList globalQualificationList;
    private JTextField qualificationEditTitleText;
    private JScrollPane qualificationTextScrollPanel;
    private JButton globalQualificationNewButton;
    private JButton qualificationAddToJobButton;
    private JButton skillLevelButton;
    private DefaultListModel globalQualificationListModel;
    private DefaultListModel qualificationListModel;
    private JScrollPane globalQualificationListScrollPanel;
    private JLabel globalQualificationLabel;
    private JLabel qualificationLabel;
    private JLabel qualificationSkillLevelLabel;
    private ButtonGroup skillButtonGroup;
    private JRadioButton skill1Radio;
    private JRadioButton skill2Radio;
    private JRadioButton skill3Radio;
    private JRadioButton skill4Radio;
    private JRadioButton skill5Radio;
    private boolean skillFlag;
    private HeadhunterI hh;
    private ProjectI selectedProject;
    private JobI selectedJob;
    private int selectedLevel;

    public QualificationHeadhunterGUI(ProjectI selectedProject, int jobNo, HeadhunterI hh, JobI selectedJob) {
	this.hh = hh;
	this.selectedJob = selectedJob;
	this.selectedProject = selectedProject;
	this.jobNo = jobNo;
        initComponents();
    }

    private void initComponents() {
        backButton = new JButton();
        buttomPanel = new JPanel();
	cp = getContentPane();
        eastPanel = new JPanel();
        globalQualificationDelButton = new JButton();
	globalQualificationLabel = new JLabel();
        globalQualificationList = new JList();
        globalQualificationListScrollPanel = new JScrollPane();
        globalQualificationNewButton = new JButton();
        logoutButton = new JButton();
        mainButtomPanel = new JPanel();
        mainCenterPanel = new JPanel();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
	newQualificationFlag = false;
        qualificationAddToJobButton = new JButton();
	qualificationCancelButton = new JButton();
        qualificationDelButton = new JButton();
        qualificationEditButton = new JButton();
        qualificationEditTitleLabel = new JLabel();
        qualificationEditTitleText = new JTextField();
	qualificationLabel = new JLabel();
	qualificationLabel = new JLabel();
        qualificationList = new JList();
        qualificationListScrollPanel = new JScrollPane();
	qualificationSkillLevelLabel = new JLabel();
        qualificationTextArea = new JTextArea();
	qualificationTextAreaBackup = new String();
        qualificationTextScrollPanel = new JScrollPane();
	qualificationTitleTextBackup = new String();
	selectedLevel = -1;
	skill1Radio = new JRadioButton();
	skill2Radio = new JRadioButton();
	skill3Radio = new JRadioButton();
	skill4Radio = new JRadioButton();
	skill5Radio = new JRadioButton();
	skillButtonGroup = new ButtonGroup();
	skillFlag = false;
	skillLevelButton = new JButton();
        topPanel = new JPanel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));
        qualificationEditButton.setText("Edit");
        qualificationEditButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseEditButton(evt);
            }
        });
        mainTopPanel.add(qualificationEditButton, new AbsoluteConstraints(460, 106, 87, -1));

        qualificationCancelButton.setText("Cancel");
        qualificationCancelButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseCancelButton();
            }
        });
        mainTopPanel.add(qualificationCancelButton, new AbsoluteConstraints(460, 76, 87, -1));

        qualificationTextScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        qualificationTextArea.setLineWrap(true);
        qualificationTextScrollPanel.setViewportView(qualificationTextArea);
        mainTopPanel.add(qualificationTextScrollPanel, new AbsoluteConstraints(20, 50, 420, 80));

        qualificationEditTitleLabel.setText("Title:");
        mainTopPanel.add(qualificationEditTitleLabel, new AbsoluteConstraints(20, 20, -1, -1));

        mainTopPanel.add(qualificationEditTitleText, new AbsoluteConstraints(60, 20, 380, -1));

	mainTopPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 145));

        mainCenterPanel.setLayout(new AbsoluteLayout());
        mainCenterPanel.setBorder(new BevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

        globalQualificationLabel.setText("Global qualification list:");
        mainCenterPanel.add(globalQualificationLabel, new AbsoluteConstraints(20, 20, -1, -1));

        globalQualificationDelButton.setText("Delete");
        globalQualificationDelButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseGlobalQualificationDelButton();
            }
        });
        mainCenterPanel.add(globalQualificationDelButton, new AbsoluteConstraints(460, 106, 87, -1));

        globalQualificationNewButton.setText("New");
        globalQualificationNewButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseGlobalQualificationNewButton();
            }
        });
        mainCenterPanel.add(globalQualificationNewButton, new AbsoluteConstraints(460, 76, 87, -1));

        qualificationAddToJobButton.setText("Add");
        qualificationAddToJobButton.setToolTipText("Add to job");
        qualificationAddToJobButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseQualificationAddToJobButton();
            }
        });
        mainCenterPanel.add(qualificationAddToJobButton, new AbsoluteConstraints(460, 46, 87, -1));

        globalQualificationListScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	globalQualificationListModel = new DefaultListModel();
        globalQualificationList.setModel(globalQualificationListModel);
        globalQualificationList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        globalQualificationList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseGlobalQualificationList(evt);
            }
        });
        globalQualificationListScrollPanel.setViewportView(globalQualificationList);
        mainCenterPanel.add(globalQualificationListScrollPanel, new AbsoluteConstraints(20, 40, 420, 90));

	mainCenterPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainCenterPanel, new AbsoluteConstraints(2, 167, 566, 145));

        mainButtomPanel.setLayout(new AbsoluteLayout());
        mainButtomPanel.setBorder(new BevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

        skillLevelButton.setText("Experience");
	skillLevelButton.setToolTipText("Set the experience level.");
	skillLevelButton.setEnabled(false);
        skillLevelButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseSkillLevelButton();
            }
        });
        mainButtomPanel.add(skillLevelButton, new AbsoluteConstraints(460, 76, 87, -1));

        qualificationDelButton.setText("Delete");
        qualificationDelButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseQualificationDelButton();
            }
        });
        mainButtomPanel.add(qualificationDelButton, new AbsoluteConstraints(460, 105, 87, -1));

        qualificationLabel.setText("Qualification required by the job:");
        mainButtomPanel.add(qualificationLabel, new AbsoluteConstraints(20, 20, -1, -1));

	qualificationSkillLevelLabel.setText("Experience: ");
        mainButtomPanel.add(qualificationSkillLevelLabel, new AbsoluteConstraints(355, 20, -1, -1));

        skill1Radio.setText("1 Month");
	skillButtonGroup.add(skill1Radio);
        skill1Radio.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
		selectedLevel = 1;
            }
        });
	skill1Radio.setBackground(new Color(233,233,242));
        mainButtomPanel.add(skill1Radio, new AbsoluteConstraints(355, 32, -1, -1));
	
	skill2Radio.setText("6 Months");
	skillButtonGroup.add(skill2Radio);
        skill2Radio.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
		selectedLevel = 2;
            }
        });
	skill2Radio.setBackground(new Color(233,233,242));
        mainButtomPanel.add(skill2Radio, new AbsoluteConstraints(355, 52, -1, -1));

        skill3Radio.setText("12 Months");
	skillButtonGroup.add(skill3Radio); 
	skill3Radio.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
		selectedLevel = 3;
            }
        });
	skill3Radio.setBackground(new Color(233,233,242));
        mainButtomPanel.add(skill3Radio, new AbsoluteConstraints(355, 72, -1, -1));

        skill4Radio.setText("18 Months");
	skillButtonGroup.add(skill4Radio);
        skill4Radio.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
		selectedLevel = 4;
            }
        });
	skill4Radio.setBackground(new Color(233,233,242));
        mainButtomPanel.add(skill4Radio, new AbsoluteConstraints(355, 92, -1, -1));

        skill5Radio.setText("18+ Months");
	skillButtonGroup.add(skill5Radio);
        skill5Radio.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
		selectedLevel = 5;
            }
        });
	skill5Radio.setBackground(new Color(233,233,242));
        mainButtomPanel.add(skill5Radio, new AbsoluteConstraints(355, 112, -1, -1));

	skill1Radio.setEnabled(false);
	skill2Radio.setEnabled(false);
	skill3Radio.setEnabled(false);
	skill4Radio.setEnabled(false);
	skill5Radio.setEnabled(false);

        qualificationListScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	qualificationListModel = new DefaultListModel();
        qualificationList.setModel(qualificationListModel);
        qualificationList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        qualificationListScrollPanel.setViewportView(qualificationList);
        mainButtomPanel.add(qualificationListScrollPanel, new AbsoluteConstraints(20, 40, 330, 90));

	mainButtomPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainButtomPanel, new AbsoluteConstraints(2, 320, 566, 145));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());

        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new BorderLayout());

        backButton.setText("Back to job info");
        backButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseBackButton();
            }
        });
        buttomPanel.add(backButton, BorderLayout.WEST);

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	mainJPanel.setBackground(new Color(233,233,242));
	cp.add(mainJPanel, BorderLayout.CENTER);

	// Makes som setup off the screen
	qualificationEditPanelOnOff(0);

	// Loads information in to the screen
	getInformation();
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }
   
    private void  mouseQualificationAddToJobButton() {
	// Check if the button isenabled
	if (qualificationAddToJobButton.isEnabled() == false) {return;}
	if (globalQualificationList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't add, when no qualification is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Make add warning to the user
	msgErrorWarning = new MsgErrorWarning("Warning do you want to add: " + (String)globalQualificationList.getSelectedValue());
	int selected = msgErrorWarning.msgWarning();
	// Check the answer from the user, if it's 0 add the globel qualification eles do nothing
	if (selected == 0) {
	    // make the an request for an skill level
	    skill1Radio.setEnabled(true);
	    skill2Radio.setEnabled(true);
	    skill3Radio.setEnabled(true);
	    skill4Radio.setEnabled(true);
	    skill5Radio.setEnabled(true);
	    globalQualificationPanelOnOff(0);
	    qualificationPanelOnOff(0);
	    skillLevelButton.setEnabled(true);
	    skillFlag = true;
	}
    }
    
    private void mouseSkillLevelButton() {
	// Check fi the button is active
	if (skillLevelButton.isEnabled() == false) {return;}
	if (skillFlag == false)	 {
	    msgErrorWarning = new MsgErrorWarning("You can't add experience, when no qualification is selected.");
	    msgErrorWarning.msgError();
	    return;
	} else  if (selectedLevel == -1) {
	    msgErrorWarning = new MsgErrorWarning("You can't add expetience, when no expetience-level is selected.");
	    msgErrorWarning.msgError();
	    return;
	}


	// Add the quaification to the list
	int sizeOfList = qualificationListModel.getSize();
	// Convert experience level
	String skillLevelString;
	if (selectedLevel == 1) {
	    skillLevelString = new String("1 Month");
	} else if(selectedLevel == 2) {
	    skillLevelString = new String("6 Months");
	} else if(selectedLevel == 3) {
	    skillLevelString = new String("12 Months");
	} else if(selectedLevel == 4) {
	    skillLevelString = new String("18 Months");
	} else {
	    skillLevelString = new String("18+ Months");
	}
	String argStr = new String((String)qualificationEditTitleText.getText() + 
				   " (" +
				   skillLevelString +
				   ")");
	qualificationListModel.insertElementAt(argStr, sizeOfList);
	// Move focus onto the newly made element
	qualificationList.setSelectedIndex(sizeOfList);
	// add the new qualification to the database
	try {
	    selectedJob.addRequirement(globalQualificationList.getSelectedIndex(), selectedLevel);
	    selectedJob.saveRequirements();
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	// Change how things look and feel on the screen
	skill1Radio.setEnabled(false);
	skill2Radio.setEnabled(false);
	skill3Radio.setEnabled(false);
	skill4Radio.setEnabled(false);
	skill5Radio.setEnabled(false);
	globalQualificationPanelOnOff(1);
	qualificationPanelOnOff(1);
	skillFlag = false;
}

    private void mouseGlobalQualificationNewButton() {
	// Check if the button isenabled
	if (globalQualificationNewButton.isEnabled() == false) {return;}
	// Empty the fields to edit the new qualification
	qualificationEditTitleText.setText("");
	qualificationTextArea.setText("");
	// Enableds the fileds
	qualificationEditTitleText.setEditable(true);
	qualificationEditTitleText.setBackground(new Color(255,255,255));
	qualificationTextArea.setEditable(true);
	qualificationTextArea.setBackground(new Color(255,255,255));
	qualificationEditButton.setEnabled(true);
	qualificationEditButton.setText("Save");
	// Disable the other fields
	globalQualificationPanelOnOff(0);
	qualificationPanelOnOff(0);
	newQualificationFlag = true;
    }

    private void mouseGlobalQualificationDelButton() {
	// Check if the button isenabled
	if (globalQualificationDelButton.isEnabled() == false) {return;}
	if (globalQualificationList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't delete, when no qualification is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Make delete warning to the user
	msgErrorWarning = new MsgErrorWarning("Warning do you want to delete: " + (String)globalQualificationList.getSelectedValue());
	int selected = msgErrorWarning.msgWarning();
	// Check the answer from the user, if it's 0 delete the globel qualification
	if (selected == 0) {
	    int indexInList = globalQualificationList.getSelectedIndex();
	    try { // remove it form the database
		selectedJob.deleteQualification(indexInList);
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("The qualification, can't be delete, it used by some one else.");
		msgErrorWarning.msgError();
		return;
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	    // Remove from the global list
	    globalQualificationListModel.remove(indexInList);
	}
    }

    private void mouseQualificationDelButton() {
	// Check if the button isenabled
	if (qualificationDelButton.isEnabled() == false) {return;}
	// Check if an item has be seletec in the list
	if (qualificationList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't delete, when no qulification is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Makes a msg box to verfiy the deletion
	msgErrorWarning = new MsgErrorWarning("Warning do you want to remove qualification: " + (String)qualificationList.getSelectedValue());
	int selected = msgErrorWarning.msgWarning();
	// Check the answer from the user, if it's 0 delete the qualification eles do nothing
	if (selected == 0) {
	    // Delete selected qualification from the project list
	    int indexInList = qualificationList.getSelectedIndex();
	    qualificationListModel.remove(indexInList);
	    qualificationEditTitleText.setText("");
	    qualificationTextArea.setText("");
	    // Disable qualificationEditPanel
	    qualificationEditPanelOnOff(0);
	    // Remove the qualification from the job in the database
	    try {
		selectedJob.removeRequirement(indexInList);
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	} else {
	    return;
	}
    }

    private void mouseBackButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new JobInformationHeadhunterGUI(jobNo, selectedProject, "view", hh));
	setContentPane(cp);
    }

    private void mouseGlobalQualificationList(MouseEvent evt) {
	if (evt.getClickCount() == 1) {
	    // Load information about selected qualification
	    String description = new String();
	    try {
		QualificationI qualification = selectedJob.getGlobalQualification(globalQualificationList.getSelectedIndex());
		description = qualification.getDescription();
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	    // Change the title text
	    qualificationEditTitleText.setText((String)globalQualificationList.getSelectedValue());
	    // Change the dedscription test
	    qualificationTextArea.setText(description);
	    // Make the edit panel available
	    qualificationEditButton.setEnabled(true);
	} else if (evt.getClickCount() == 2) {
	    // Add the qualification
	    mouseQualificationAddToJobButton();
	}
    }

    private void mouseEditButton(MouseEvent evt) {
	// Check if the button isenabled
	if (qualificationEditButton.isEnabled() == false) {return;}
	// Check if a title is given
	if (((String)qualificationEditTitleText.getText()).equals("")) {
	    msgErrorWarning = new MsgErrorWarning("You can't save, when no title is written.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Check to see which stat the button is in
	if (((JButton)evt.getSource()).getText().equals("Edit")) {
	    // Enableds the fileds
	    qualificationEditTitleText.setEditable(true);
	    qualificationEditTitleText.setBackground(new Color(255,255,255));
	    qualificationTextArea.setEditable(true);
	    qualificationCancelButton.setEnabled(true);
	    qualificationTextArea.setBackground(new Color(255,255,255));
	    // Change the text on the editButton
	    qualificationEditButton.setText("Save");
	    // Make backup of the text to the cancel function
	    qualificationTitleTextBackup = qualificationEditTitleText.getText();
	    qualificationTextAreaBackup = qualificationTextArea.getText();
	    // Disable the other things in this screen
	    qualificationEditPanelOnOff(1);
	    qualificationPanelOnOff(0);
	    globalQualificationPanelOnOff(0);
	} else {
	    // Disableds the fileds
	    qualificationEditTitleText.setEditable(false);
	    qualificationEditTitleText.setBackground(new Color(233,233,242));
	    qualificationTextArea.setEditable(false);
	    qualificationCancelButton.setEnabled(false);
	    qualificationTextArea.setBackground(new Color(233,233,242));
	    // Change the text on the editButton
	    qualificationEditButton.setText("Edit");
	    // Chanege the value of the element in the List's, if title is changed
	    if (newQualificationFlag == true) {// New qualification has been made
		// Add new project to the end of the quali list
		int sizeOfList = globalQualificationListModel.getSize();
		globalQualificationListModel.insertElementAt((String)qualificationEditTitleText.getText(), sizeOfList);
		// Move focus onto the newly made element
		globalQualificationList.setSelectedIndex(sizeOfList);
		// Change the button text
		qualificationEditButton.setText("Edit");
		// Cahnge the flag
		newQualificationFlag = false;
		// Add new global qualification to the database
		try {
		    selectedJob.createQualification((String)qualificationEditTitleText.getText(), 
						    (String)qualificationTextArea.getText());
		} catch (RemoteException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		    msgErrorWarning.msgError();
		    return;
		} catch (DAOException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		    msgErrorWarning.msgError();
		    return;
		} catch (Exception e) {
		    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		    msgErrorWarning.msgError();
		    return;   
		}
	    } else {
		int indexInList = globalQualificationList.getSelectedIndex();
		globalQualificationListModel.remove(indexInList);
		globalQualificationListModel.insertElementAt(qualificationEditTitleText.getText(), indexInList);
		// Update the database with new information
		try {
		    QualificationI qualification = (QualificationI)selectedJob.getGlobalQualification(indexInList);
		    qualification.setName(qualificationEditTitleText.getText());
		    qualification.setDescription(qualificationTextArea.getText());
		    qualification.save();
		} catch (RemoteException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		    msgErrorWarning.msgError();
		    return;
		} catch (DAOException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		    msgErrorWarning.msgError();
		    return;
		} catch (Exception e) {
		    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		    msgErrorWarning.msgError();
		    return;   
		}
	    }
	    // Enable the other things in this screen
	    qualificationPanelOnOff(1);
	    globalQualificationPanelOnOff(1);
	}
    }

    private void mouseCancelButton() {
	// Check if the button isenabled
	if (qualificationCancelButton.isEnabled() == false) {return;}
	// Put in the text agian
	qualificationEditTitleText.setText(qualificationTitleTextBackup);
	qualificationTextArea.setText(qualificationTextAreaBackup);
	// Disable edit and cancel button
	qualificationCancelButton.setEnabled(false);
	qualificationEditButton.setEnabled(false);
	qualificationEditButton.setText("Edit");
	// Change whats is able on the screen
	qualificationEditPanelOnOff(0);
	qualificationPanelOnOff(1);
	globalQualificationPanelOnOff(1);
	
    }

    private void globalQualificationPanelOnOff(int onOff) {
	if (onOff == 1) {
	    globalQualificationListScrollPanel.setEnabled(true);
	    qualificationAddToJobButton.setEnabled(true);
	    globalQualificationNewButton.setEnabled(true);
	    globalQualificationDelButton.setEnabled(true);
	    globalQualificationList.setEnabled(true);
	    globalQualificationList.setBackground(new Color(255,255,255));
	} else {
	    globalQualificationListScrollPanel.setEnabled(false);
	    qualificationAddToJobButton.setEnabled(false);
	    globalQualificationNewButton.setEnabled(false);
	    globalQualificationDelButton.setEnabled(false);
	    globalQualificationList.setEnabled(false);
	    globalQualificationList.setBackground(new Color(233,233,242));
	}
    }

    private void qualificationPanelOnOff(int onOff) {
	if (onOff == 1) {
	    qualificationDelButton.setEnabled(true);
	    qualificationList.setEnabled(true);
	    skillLevelButton.setEnabled(false);
	    qualificationListScrollPanel.setEnabled(true);    
	    qualificationList.setBackground(new Color(255,255,255));
	} else {
	    qualificationListScrollPanel.setEnabled(false);
	    qualificationDelButton.setEnabled(false);
	    qualificationList.setEnabled(false);
	    skillLevelButton.setEnabled(false);
	    qualificationList.setBackground(new Color(233,233,242));
	}
    }
    
    private void qualificationEditPanelOnOff(int onOff) {
	if (onOff == 1) {
	    qualificationEditButton.setEnabled(true);
	} else {
	    qualificationEditTitleText.setEditable(false);
	    qualificationEditTitleText.setBackground(new Color(233,233,242));
	    qualificationTextArea.setEditable(false);
	    qualificationCancelButton.setEnabled(false);
	    qualificationEditButton.setEnabled(false);
	    qualificationTextArea.setBackground(new Color(233,233,242));
	}
    }

    private void getInformation() {
	try { // Get qualifications for the job
	    selectedJob.initializeJobQualificationList();
	    for (int i = 0; i < selectedJob.getJobQualificationListLength(); i++) {
		String skillLevelString;
		if (((SkillLevelI)selectedJob.getRequirement(i)).getLevel() == 1) {
		    skillLevelString = new String("1 Month");
		} else if(((SkillLevelI)selectedJob.getRequirement(i)).getLevel() == 2) {
		    skillLevelString = new String("6 Months");
		} else if(((SkillLevelI)selectedJob.getRequirement(i)).getLevel() == 3) {
		    skillLevelString = new String("12 Months");
		} else if(((SkillLevelI)selectedJob.getRequirement(i)).getLevel() == 4) {
		    skillLevelString = new String("18 Months");
		} else {
		    skillLevelString = new String("18+ Months");
		}
		QualificationI qualification = ((SkillLevelI)selectedJob.getRequirement(i)).getQualification();
		String argToList = new String(qualification.getName() + " (" + skillLevelString +")");
		qualificationListModel.insertElementAt(argToList, i);
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}

	try { // Get global qualifications list
	    selectedJob.initializeGlobalQualificationList();
	    for (int i = 0; i < selectedJob.getGlobalQualificationListLength(); i++) {
		QualificationI qualification = selectedJob.getGlobalQualification(i);
		String argToList = new String(qualification.getName());
		globalQualificationListModel.insertElementAt(argToList, i);
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
    }
}
