/**
 *
 * @author  Jesper Kristensen
 * @version $Revision: 1.13 $
 *
 */
package dk.auc.cs.whiner.gui.applicant;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;

import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;


public class ViewNotificationApplicantGUI extends JApplet {  
    private MsgErrorWarning msgErrorWarning;
    private Container cp;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JPanel westPanel;
    private JPanel mainTopPanel;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JPanel eastPanel;
    private JLabel titleLabel;
    private JLabel datoLabel;
    private JButton logoutButton;
    private JScrollPane notificationScrollPanel;
    private JTextArea notificationTextArea;
    private JButton backButton;
    private JButton removeButton;
    private NotificationI notification;
    private ApplicantI applicant;
    private int notificationNo;

    public ViewNotificationApplicantGUI(NotificationI notification, int notificationNo, ApplicantI applicant) {
	this.notificationNo = notificationNo;
	this.notification = notification;
	this.applicant = applicant;
        initComponents();
    }

    private void initComponents() {
	backButton = new JButton();
        buttomPanel = new JPanel();
	cp = getContentPane();
	datoLabel = new JLabel();
        eastPanel = new JPanel();
	logoutButton = new JButton();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
	notificationScrollPanel = new JScrollPane();
	notificationTextArea = new JTextArea();
	removeButton = new JButton();
	titleLabel = new JLabel();
        topPanel = new JPanel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

	mainTopPanel.add(titleLabel, new AbsoluteConstraints(20, 20, -1, -1));

	mainTopPanel.add(datoLabel, new AbsoluteConstraints(20, 40, -1, -1)); 

	notificationScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        notificationScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        notificationTextArea.setEditable(false);
        notificationTextArea.setLineWrap(true);
	notificationTextArea.setBackground(new Color(233,233,242));
        notificationScrollPanel.setViewportView(notificationTextArea);
        mainTopPanel.add(notificationScrollPanel, new AbsoluteConstraints(20, 60, 520, 365));

	mainTopPanel.setBackground(new Color(233,233,242));
	mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 450));

        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());
        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());
	
	backButton.setText("Back to main");
        backButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseBackButton();
		}
	    });
        buttomPanel.add(backButton,  new AbsoluteConstraints(0, 0, -1, -1));

	removeButton.setText("Remove");
	removeButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseRemoveButton();
		}
	    });
	buttomPanel.add(removeButton,  new AbsoluteConstraints(120, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	mainJPanel.setBackground(new Color(233,233,242));
	cp.add(mainJPanel, BorderLayout.CENTER);

	// Get information about the notification
	getInformation();
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }
    
    private void mouseBackButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new MainApplicantGUI(applicant));
	setContentPane(cp);
    }
    
    private void mouseRemoveButton() {
	int selected = -1;
 	try {
	    // Makes a msg box to verfiy the deletion
	    msgErrorWarning = new MsgErrorWarning("Warning do you want to remove: " + notification.getTitle());
	    selected = msgErrorWarning.msgWarning();
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	// Check the answer from the user, if it's 0 remove the notification eles do nothing
	if (selected == 0) {
	    try {
		applicant.deleteNotification(notificationNo);
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	} else {
	    return;
	}
	// Return to main screen
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new MainApplicantGUI(applicant));
	setContentPane(cp);
    }


    private void getInformation() {
	try {
	    titleLabel.setText("Title: " + notification.getJobName());
	    WDate wdate = new WDate(notification.getDateOfDispatch());
	    datoLabel.setText("Date: " + wdate.getDay() + "/" + wdate.getMonth() + "/" + wdate.getYear());
	    notificationTextArea.setText(notification.getBodyText());
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
    }
}
