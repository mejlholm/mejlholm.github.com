/**
 *
 * @author  Jesper Kristensen
 * @version $Revision: 1.27 $
 */
package dk.auc.cs.whiner.gui.headhunter;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;
import dk.auc.cs.whiner.model.HireException;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

public class ViewApplicationHeadhunterGUI extends JApplet {  
    private int jobNo;
    private MsgErrorWarning msgErrorWarning;
    private Container cp;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JTextArea applicationTextArea;
    private JPanel westPanel;
    private JButton backButton;
    private JPanel mainTopPanel;
    private JButton rejectButton;
    private JButton logoutButton;
    private JScrollPane applicationScrollPanel;
    private JPanel mainPanel;
    private JButton hireButton;
    private JPanel buttomPanel;
    private JPanel eastPanel;
    private JLabel viewAppApplicationLabel;
    private HeadhunterI hh;
    private ApplicationI selectedApplication;
    private ProjectI selectedProject;
    private JButton profileButton;
    private int appNo;
    private JLabel jobLabel;
    private JScrollPane jobScrollPanel;
    private JTextArea jobTextArea;
    private JLabel qualificationLabel;
    private JList qualificationList;
    private DefaultListModel qualificationListModel;
    private JScrollPane qualificationScrollPanel;

    
    public ViewApplicationHeadhunterGUI(int jobNo, ApplicationI selectedApplication, HeadhunterI hh, ProjectI selectedProject, int appNo) {
	this.hh = hh;
	this.appNo = appNo;
	this.jobNo = jobNo;
	this.selectedApplication = selectedApplication;
	this.selectedProject = selectedProject;
        initComponents();
    }
    
    public ViewApplicationHeadhunterGUI() {
        initComponents();
    }

    private void initComponents() {
        applicationScrollPanel = new JScrollPane();
        applicationTextArea = new JTextArea();
        backButton = new JButton();
	qualificationLabel = new JLabel();
        qualificationList = new JList();
        qualificationScrollPanel = new JScrollPane();
        buttomPanel = new JPanel();
	cp = getContentPane();
        eastPanel = new JPanel();
        hireButton = new JButton();
	jobLabel = new JLabel();
	jobScrollPanel = new JScrollPane();
	jobTextArea = new JTextArea();
        logoutButton = new JButton();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
	profileButton = new JButton();
        rejectButton = new JButton();
        topPanel = new JPanel();
        viewAppApplicationLabel = new JLabel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

	mainTopPanel.add(jobLabel, new AbsoluteConstraints(20, 20, -1, -1));

	jobScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        jobScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        jobTextArea.setEditable(false);
        jobTextArea.setLineWrap(true);
	jobTextArea.setBackground(new Color(233,233,242));
        jobScrollPanel.setViewportView(jobTextArea);
        mainTopPanel.add(jobScrollPanel, new AbsoluteConstraints(20, 40, 525, 80));

	qualificationLabel.setText("Job Requirements:");
	mainTopPanel.add(qualificationLabel, new AbsoluteConstraints(20, 125, -1, -1));

        qualificationScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	qualificationListModel = new DefaultListModel();
        qualificationList.setModel(qualificationListModel);
	qualificationList.setBackground(new Color(233,233,242));
	qualificationList.setEnabled(false);
	qualificationScrollPanel.setEnabled(false);
        qualificationScrollPanel.setViewportView(qualificationList);
        mainTopPanel.add(qualificationScrollPanel, new AbsoluteConstraints(20, 145, 525, 100));

	mainTopPanel.add(viewAppApplicationLabel, new AbsoluteConstraints(20, 250, -1, -1));

        applicationScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        applicationScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        applicationTextArea.setEditable(false);
        applicationTextArea.setLineWrap(true);
        applicationTextArea.setWrapStyleWord(true);
	applicationTextArea.setBackground(new Color(233,233,242));
        applicationScrollPanel.setViewportView(applicationTextArea);
        mainTopPanel.add(applicationScrollPanel, new AbsoluteConstraints(20, 265, 525, 160));

	mainTopPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 450));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());

        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());

        backButton.setText("Back to job info");
        backButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseBackButton();
            }
        });
        buttomPanel.add(backButton, new AbsoluteConstraints(0, 0, -1, -1));

        profileButton.setText("Profile");
	profileButton.setToolTipText("See the relate profile");
        profileButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseProfileButton();
            }
        });
        buttomPanel.add(profileButton, new AbsoluteConstraints(137, 0, -1, -1));

        hireButton.setText("Hire");
        hireButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseHireButton();
            }
        });
        buttomPanel.add(hireButton, new AbsoluteConstraints(215, 0, -1, -1));

        rejectButton.setText("Reject");
        rejectButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseRejectButton();
            }
        });
	buttomPanel.add(rejectButton, new AbsoluteConstraints(278, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	mainJPanel.setBackground(new Color(233,233,242));
	cp.add(mainJPanel, BorderLayout.CENTER);

	// Add information to this screen
	getInformation();
    }    

    private void mouseProfileButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new ViewProfileHeadhunterGUI(jobNo, selectedProject, selectedApplication, hh, appNo));
	setContentPane(cp);
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }
    
    private void mouseRejectButton() {
	// Check button status
	if (rejectButton.isEnabled() == false) {return;}	
	// Makes a msg box to verfiy the deletion
	try {
	    msgErrorWarning = new MsgErrorWarning("Warning: are you sure you want to reject: " 
						  + selectedApplication.getApplicantName(selectedApplication.getApplicantID()));
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}

	int selected = msgErrorWarning.msgWarning();
	if (selected == 0) {
	    // Reject the application
	    try {
		((JobI)selectedProject.getJob(jobNo)).rejectApplication(appNo);
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	    // Back to main screen
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new JobInformationHeadhunterGUI(jobNo, selectedProject, "view", hh));
	    setContentPane(cp);
	} else {
	    // Do nothing
	}
    }

    private void mouseHireButton() {
	// Check button status
	if (hireButton.isEnabled() == false) {return;}	
	// Hire the applicant
	try {
	    ((JobI)selectedProject.getJob(jobNo)).hireApplicant(appNo);
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (HireException e) {
	    msgErrorWarning = new MsgErrorWarning("You can't hire this applicant.");
	    msgErrorWarning.msgError();
	    return;
	}catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	// Back to main screen
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new JobInformationHeadhunterGUI(jobNo, selectedProject, "view", hh));
	setContentPane(cp);
    }

    private void mouseBackButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new JobInformationHeadhunterGUI(jobNo, selectedProject, "view", hh));
	setContentPane(cp);
    }

    private void getInformation() {
	try {
	    applicationTextArea.setText(selectedApplication.getBodyText());
	    viewAppApplicationLabel.setText("Application: " + selectedApplication.getApplicantName(selectedApplication.getApplicantID()));
	    jobTextArea.setText(((JobI)selectedApplication.getJob(selectedApplication.getJobID())).getDescription());
	    jobLabel.setText("Job title: " + ((JobI)selectedApplication.getJob(selectedApplication.getJobID())).getTitle());
	    JobI selectedJob = (JobI)selectedApplication.getJob(selectedApplication.getJobID());
	    selectedJob.initializeJobQualificationList();
	    for (int i = 0; i < selectedJob.getJobQualificationListLength(); i++) {
		String skillLevelString;
		if (((SkillLevelI)selectedJob.getRequirement(i)).getLevel() == 1) {
		    skillLevelString = new String("1 Month");
		} else if(((SkillLevelI)selectedJob.getRequirement(i)).getLevel() == 2) {
		    skillLevelString = new String("6 Months");
		} else if(((SkillLevelI)selectedJob.getRequirement(i)).getLevel() == 3) {
		    skillLevelString = new String("12 Months");
		} else if(((SkillLevelI)selectedJob.getRequirement(i)).getLevel() == 4) {
		    skillLevelString = new String("18 Months");
		} else {
		    skillLevelString = new String("18+ Months");
		}
		QualificationI qualification = ((SkillLevelI)selectedJob.getRequirement(i)).getQualification();
		String argToList = new String(qualification.getName() + " (" + skillLevelString +")");
		qualificationListModel.insertElementAt(argToList, i);
		// The status of the application
		if ((selectedApplication.getStatus()).equals("rejected")) {
		    hireButton.setEnabled(false);
		    rejectButton.setEnabled(false);
		}
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
    }
}
