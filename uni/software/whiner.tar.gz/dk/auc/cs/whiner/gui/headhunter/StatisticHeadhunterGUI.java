package dk.auc.cs.whiner.gui.headhunter;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

/**
 *
 * @author <a href="mailto:cableman@cs,auc.dk"></a>
 * @version $Revision: 1.14 $
 *
 */
public class StatisticHeadhunterGUI extends JApplet {
    private Container cp;
    private MsgErrorWarning msgErrorWarning;
    private JPanel mainJPanel;
    private JList typeSpecifyList;
    private JPanel topPanel;
    private JPanel westPanel;
    private JButton backButton;
    private JPanel mainTopPanel;
    private JButton logoutButton;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JButton compileButton;
    private JPanel eastPanel;
    private JList typeList;
    private JScrollPane typeScrollPanel;
    private JLabel viewAppApplicationLabel;
    private JScrollPane typeSpecifyScrollPanel;
    private JLabel viewAppProfileLabel;
    private HeadhunterI hh;
    
    public StatisticHeadhunterGUI(HeadhunterI hh) {
	this.hh = hh;
        initComponents();
    }

    private void initComponents() {
        backButton = new JButton();
        buttomPanel = new JPanel();
        compileButton = new JButton();
	cp = getContentPane();
        eastPanel = new JPanel();
        logoutButton = new JButton();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
        topPanel = new JPanel();
        typeList = new JList();
        typeScrollPanel = new JScrollPane();
        typeSpecifyList = new JList();
        typeSpecifyScrollPanel = new JScrollPane();
        viewAppApplicationLabel = new JLabel();
        viewAppProfileLabel = new JLabel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));
        typeScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        typeScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        typeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        typeScrollPanel.setViewportView(typeList);

        mainTopPanel.add(typeScrollPanel, new AbsoluteConstraints(20, 40, 525, 130));

        typeSpecifyScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        typeSpecifyScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        typeSpecifyScrollPanel.setViewportView(typeSpecifyList);

        mainTopPanel.add(typeSpecifyScrollPanel, new AbsoluteConstraints(20, 200, 525, 230));

        viewAppApplicationLabel.setText("Selected type specifed:");
        mainTopPanel.add(viewAppApplicationLabel, new AbsoluteConstraints(20, 180, -1, -1));

        viewAppProfileLabel.setText("Select type:");
        mainTopPanel.add(viewAppProfileLabel, new AbsoluteConstraints(20, 20, -1, -1));

	mainTopPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 450));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());

        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());

        backButton.setText("Back to main");
        backButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseBackButton();
		}
	    });
        buttomPanel.add(backButton, new AbsoluteConstraints(0, 0, -1, -1));

        compileButton.setText("Compile statistic");
        compileButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseCompileButton();
		}
	    });

        buttomPanel.add(compileButton, new AbsoluteConstraints(120, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	mainJPanel.setBackground(new Color(233,233,242));
	cp.add(mainJPanel, BorderLayout.CENTER);

	// make message
	msgErrorWarning = new MsgErrorWarning("The statistical functions are not implemented");
	msgErrorWarning.msgError();
    }    

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void mouseCompileButton() {
	//
	// COMPILE SELETCED DATA AND SEND IT WHIT THIS FUNCTION IN SOME WAY
	//
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new ReportHeadhunterGUI(hh));
	setContentPane(cp);
    }

    private void mouseBackButton() {
	cp.removeAll();
	try {
	    cp.add(BorderLayout.CENTER, new MainHeadhunterGUI(hh));
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	setContentPane(cp);
    }
}
