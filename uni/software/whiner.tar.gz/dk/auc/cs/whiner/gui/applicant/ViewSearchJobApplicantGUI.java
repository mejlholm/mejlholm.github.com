/**
 * @author  Jesper Kristensen
 * @version $Revision: 1.9 $
 */
package dk.auc.cs.whiner.gui.applicant;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;

import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

public class ViewSearchJobApplicantGUI extends JApplet {  
    private MsgErrorWarning msgErrorWarning;
    private int applicantName;
    private Container cp;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JPanel westPanel;
    private JPanel mainTopPanel;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JPanel eastPanel;
    private JLabel titleLabel;
    private JLabel datoLabel;
    private JButton logoutButton;
    private JScrollPane jobScrollPanel;
    private JList qualificationList;
    private DefaultListModel qualificationListModel;
    private JScrollPane	qualificationListScrollPanel;
    private JLabel qualificationLabel;
    private JTextArea jobTextArea;
    private JButton backButton;
    private JButton projectButton;
    private JButton applicationButton;
    private JButton backSearchButton;
    private ApplicantI applicant;
    private JobI job;
    private SearchI search;
    private ProjectI project;

     public ViewSearchJobApplicantGUI(JobI job, SearchI search, ApplicantI applicant) {
	this.job = job; // This is the selected match, but has this name because it's past to view app later
	this.applicant = applicant;
	this.search = search;
        initComponents();
    }

    private void initComponents() {
	applicationButton = new JButton();
	backButton = new JButton();
	backSearchButton = new JButton();
        buttomPanel = new JPanel();
	cp = getContentPane();
	datoLabel = new JLabel();
        eastPanel = new JPanel();
	jobScrollPanel = new JScrollPane();
	jobTextArea = new JTextArea();
	logoutButton = new JButton();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
	projectButton = new JButton();
	qualificationLabel = new JLabel();
        qualificationList = new JList();
	qualificationListScrollPanel = new JScrollPane();
	titleLabel = new JLabel();
        topPanel = new JPanel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

	mainTopPanel.add(titleLabel, new AbsoluteConstraints(20, 20, -1, -1));

	mainTopPanel.add(datoLabel, new AbsoluteConstraints(20, 40, -1, -1));

	jobScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        jobScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        jobTextArea.setEditable(false);
        jobTextArea.setLineWrap(true);
	jobTextArea.setBackground(new Color(233,233,242));
        jobScrollPanel.setViewportView(jobTextArea);
        mainTopPanel.add(jobScrollPanel, new AbsoluteConstraints(20, 60, 520, 170));

	qualificationLabel.setText("Job requirements:");
	mainTopPanel.add(qualificationLabel, new AbsoluteConstraints(20, 240, -1, -1));

        qualificationListScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
	qualificationListModel = new DefaultListModel();
        qualificationList.setModel(qualificationListModel);
        qualificationList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	qualificationList.setBackground(new Color(233,233,242));
        qualificationListScrollPanel.setViewportView(qualificationList);
        mainTopPanel.add(qualificationListScrollPanel, new AbsoluteConstraints(20, 260, 520, 170));

	mainTopPanel.setBackground(new Color(233,233,242));
	mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 450));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());
        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());
	
	backButton.setText("Back to main");
        backButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseBackButton();
		}
	    });
        buttomPanel.add(backButton,  new AbsoluteConstraints(0, 0, -1, -1));

	applicationButton.setText("Application");
	applicationButton.setToolTipText("Write an application");
	applicationButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseApplicationButton();
		}
	    });
	buttomPanel.add(applicationButton,  new AbsoluteConstraints(120, 0, -1, -1));

	projectButton.setText("Project");
	projectButton.setToolTipText("Read the related project description");
	projectButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseProjectButton();
		}
	    });
	buttomPanel.add(projectButton,  new AbsoluteConstraints(230, 0, -1, -1));

	backSearchButton.setText("Back to search");
	backSearchButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseBackToSearchButton();
		}
	    });
	buttomPanel.add(backSearchButton,  new AbsoluteConstraints(310, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	mainJPanel.setBackground(new Color(233,233,242));
	cp.add(mainJPanel, BorderLayout.CENTER);

	// Load job information
	getInformation();
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void getInformation() {
	try {
	    titleLabel.setText("Title: " + job.getTitle());
	    datoLabel.setText("Date: " + job.getDateOfCreation());
	    jobTextArea.setText(job.getDescription());
	    // Get qualification to the job
	    job.initializeJobQualificationList();
	    int size = job.getJobQualificationListLength();
	    for (int i = 0; i < size; i++) {
		SkillLevelI skillLevel = job.getRequirement(i);
		QualificationI qualification = skillLevel.getQualification();
		String skillLevelString;
		// Convert the skill-level
		if (skillLevel.getLevel() == 1) {
		    skillLevelString = new String("1 Month");
		} else if(skillLevel.getLevel() == 2) {
		    skillLevelString = new String("6 Months");
		} else if(skillLevel.getLevel() == 3) {
		    skillLevelString = new String("12 Months");
		} else if(skillLevel.getLevel() == 4) {
		    skillLevelString = new String("18 Months");
		} else {
		    skillLevelString = new String("18+ Months");
		}
		String argToList = new String(qualification.getName() + " (" +  skillLevelString +")");
		qualificationListModel.insertElementAt(argToList, i);
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
    }

    private void mouseBackButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new MainApplicantGUI(applicant));
	setContentPane(cp);
    }

    private void mouseBackToSearchButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new SearchApplicantGUI(applicant, search));
	setContentPane(cp);
    }

    private void mouseProjectButton() {
	// Get project object
	try {
	    project = (ProjectI)job.getProject();
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	// Change the screen
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new ViewProjectApplicantGUI(project, search, job, applicant, true));
	setContentPane(cp);
    }
    
    private void mouseApplicationButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new ViewAppApplicantGUI("new", -1, job, applicant));
	setContentPane(cp);
    }
}
