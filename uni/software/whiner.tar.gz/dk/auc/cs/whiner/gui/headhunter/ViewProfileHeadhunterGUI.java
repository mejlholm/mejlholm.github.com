/**
 *
 * @author  Jesper Kristensen
 * @Version $Revision: 1.17 $
 */
package dk.auc.cs.whiner.gui.headhunter;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import java.util.Date;
import java.security.*;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

public class ViewProfileHeadhunterGUI extends JApplet {  
    private MsgErrorWarning msgErrorWarning;
    private Container cp;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JPanel westPanel;
    private JPanel mainTopPanel;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JPanel eastPanel;
    private JButton logoutButton;
    private JScrollPane mainScrollPanel;
    private JButton backButton;
    private String setup;
    private JLabel postcodeText;
    private JLabel otherITKnowledgeLabel;
    private JLabel passwordLabel;
    private JTextArea otherITKnowledgeTextArea;
    private JLabel lastnameLabel;
    private JScrollPane workingExperienceScrollPane;
    private JLabel cityText;
    private JLabel workPhoneLabel;
    private JTextArea reEducationTextArea;
    private JLabel homePhoneLabel;
    private JLabel address2Label;
    private JLabel countryLabel;
    private JLabel emailLabel;
    private JLabel regionLabel;
    private JLabel languageSkillsLabel;
    private JLabel sexText;
    private JLabel countryText;
    private JLabel workPhoneText;
    private JScrollPane educationScrollPane1;
    private JLabel homePhoneText;
    private JScrollPane spareTimeInterestsScrollPane;
    private JLabel middleNameText;
    private JLabel mobilePhoneText;
    private JLabel maritialLabel;
    private JLabel spareTimeInterestsLabel;
    private JTextArea languageSkillsTextArea;
    private JLabel reEducationLabel;
    private JTextArea educationTextArea1;
    private JLabel dateText;
    private JTextArea spareTimeInterestsTextArea;
    private JLabel addressInformationLabel;
    private JScrollPane languageSkillsScrollPane;
    private JLabel passwordInformationLabel;
    private JLabel firstNameText;
    private JLabel otherInformationLabel;
    private JPasswordField passwordField;
    private JLabel emailText;
    private JLabel maritialText;
    private JLabel workingExperienceLabel;
    private JLabel dateOfBirthLabel;
    private JLabel address1Label;
    private JLabel address2Text;
    private JLabel personelLabel;
    private JLabel cityLabel;
    private JScrollPane otherITKnowledgeScrollPane;
    private JTextArea workingExperienceTextArea;
    private JLabel postcodeLabel;
    private JLabel faxNumberLabel;
    private JLabel middleNameLabel;
    private JLabel faxNumberText;
    private JLabel contactInformationLabel;
    private JScrollPane reEducationScrollPane;
    private JLabel firstnameLabel;
    private JLabel educationLabel;
    private JLabel regionText;
    private JPasswordField rePasswordField;
    private JLabel mobilePhoneLabel;
    private JLabel lastNameText;
    private JLabel address1Text;
    private JLabel rePasswordLabel;
    private JLabel buttomLabel;
    private JLabel loginNameLabel;
    private JLabel loginNameText;
    private int jobNo;
    private ProjectI selectedProject;
    private ApplicationI selectedApplication;
    private HeadhunterI hh;
    private JLabel sexLabel;
    private int appNo;

    public ViewProfileHeadhunterGUI(int jobNo, ProjectI selectedProject, ApplicationI selectedApplication, HeadhunterI hh, int appNo) {
	this.appNo = appNo;
	this.jobNo = jobNo;
	this.selectedProject = selectedProject;
	this.selectedApplication = selectedApplication;
	this.hh = hh;
	initComponents();
    }

    public ViewProfileHeadhunterGUI() {
	initComponents();
    }

    private void initComponents() {
        address1Label = new JLabel();
        address1Text = new JLabel();
        address2Label = new JLabel();
        address2Text = new JLabel();
        addressInformationLabel = new JLabel();
	backButton = new JButton();
        buttomLabel = new JLabel();
        buttomPanel = new JPanel();
        cityLabel = new JLabel();
        cityText = new JLabel();
        contactInformationLabel = new JLabel();
        countryLabel = new JLabel();
        countryText = new JLabel();
	cp = getContentPane();
        dateText = new JLabel();
        eastPanel = new JPanel();
        educationLabel = new JLabel();
        educationScrollPane1 = new JScrollPane();
        educationTextArea1 = new JTextArea();
        emailLabel = new JLabel();
        emailText = new JLabel();
        faxNumberLabel = new JLabel();
	dateOfBirthLabel = new JLabel();
        faxNumberText = new JLabel();
        firstNameText = new JLabel();
        firstnameLabel = new JLabel();
        homePhoneLabel = new JLabel();
        homePhoneText = new JLabel();
        languageSkillsLabel = new JLabel();
        languageSkillsScrollPane = new JScrollPane();
        languageSkillsTextArea = new JTextArea();
        lastNameText = new JLabel();
        lastnameLabel = new JLabel();
        loginNameLabel = new JLabel();
        loginNameText = new JLabel();
	logoutButton = new JButton();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
	mainScrollPanel = new JScrollPane();
        mainTopPanel = new JPanel();
        maritialLabel = new JLabel();
        maritialText = new JLabel();
        middleNameLabel = new JLabel();
        middleNameText = new JLabel();
        mobilePhoneLabel = new JLabel();
        mobilePhoneText = new JLabel();
        otherITKnowledgeLabel = new JLabel();
        otherITKnowledgeScrollPane = new JScrollPane();
        otherITKnowledgeTextArea = new JTextArea();
        otherInformationLabel = new JLabel();
        passwordField = new JPasswordField();
        passwordInformationLabel = new JLabel();
        passwordLabel = new JLabel();
        personelLabel = new JLabel();
        postcodeLabel = new JLabel();
        postcodeText = new JLabel();
        reEducationLabel = new JLabel();
        reEducationScrollPane = new JScrollPane();
        reEducationTextArea = new JTextArea();
        rePasswordField = new JPasswordField();
        rePasswordLabel = new JLabel();
        regionLabel = new JLabel();
        regionText = new JLabel();
	sexLabel = new JLabel();
        sexText = new JLabel();
        spareTimeInterestsLabel = new JLabel();
        spareTimeInterestsScrollPane = new JScrollPane();
        spareTimeInterestsTextArea = new JTextArea();
        topPanel = new JPanel();
        westPanel = new JPanel();
        workPhoneLabel = new JLabel();
        workPhoneText = new JLabel();
        workingExperienceLabel = new JLabel();
        workingExperienceScrollPane = new JScrollPane();
        workingExperienceTextArea = new JTextArea();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());
	mainPanel.setBackground(new Color(233,233,242));

        mainTopPanel.setLayout(new AbsoluteLayout());

	mainTopPanel.setBackground(new Color(233,233,242));
        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

	firstnameLabel.setText("Firstname:");
	firstnameLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(firstnameLabel, new AbsoluteConstraints(20, 40, -1, -1));

        personelLabel.setFont(new Font("Dialog", 3, 12));
        personelLabel.setText("Personal information");
        mainTopPanel.add(personelLabel, new AbsoluteConstraints(20, 20, -1, -1));

        mainTopPanel.add(firstNameText, new AbsoluteConstraints(100, 40, 150, -1));

        lastnameLabel.setText("Lastname:");
	lastnameLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(lastnameLabel, new AbsoluteConstraints(20, 80, -1, -1));

        mainTopPanel.add(lastNameText, new AbsoluteConstraints(100, 80, 150, -1));

        middleNameLabel.setText("Middlename:");
	middleNameLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(middleNameLabel, new AbsoluteConstraints(20, 60, -1, -1));

        mainTopPanel.add(middleNameText, new AbsoluteConstraints(100, 60, 150, -1));

        dateOfBirthLabel.setText("Date of birth:");
	dateOfBirthLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(dateOfBirthLabel, new AbsoluteConstraints(270, 40, -1, -1));

        sexLabel.setText("Sex::");
	sexLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(sexLabel, new AbsoluteConstraints(270, 80, -1, -1));

        mainTopPanel.add(sexText, new AbsoluteConstraints(370, 80, 110, -1));

        maritialLabel.setText("Maritial Status:");
	maritialLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(maritialLabel, new AbsoluteConstraints(270, 60, -1, -1));

        mainTopPanel.add(maritialText, new AbsoluteConstraints(370, 60, 110, -1));

        mainTopPanel.add(contactInformationLabel, new AbsoluteConstraints(20, 290-70, -1, -1));

        address1Label.setText("Address 1:");
	address1Label.setForeground(new Color(100,100,100));
        mainTopPanel.add(address1Label, new AbsoluteConstraints(20, 200-70, -1, -1));

        mainTopPanel.add(address1Text, new AbsoluteConstraints(90, 200-70, 315, -1));

        address2Label.setText("Address 2:");
	address2Label.setForeground(new Color(100,100,100));
        mainTopPanel.add(address2Label, new AbsoluteConstraints(20, 220-70, -1, -1));

        mainTopPanel.add(address2Text, new AbsoluteConstraints(90, 220-70, 315, -1));

        postcodeLabel.setText("Post code:");
	postcodeLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(postcodeLabel, new AbsoluteConstraints(20, 240-70, -1, -1));

        mainTopPanel.add(postcodeText, new AbsoluteConstraints(90, 240-70, 60, -1));

        cityLabel.setText("City:");
	cityLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(cityLabel, new AbsoluteConstraints(160, 240-70, -1, -1));

        mainTopPanel.add(cityText, new AbsoluteConstraints(190, 240-70, 215, -1));

        regionLabel.setText("Region:");
	regionLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(regionLabel, new AbsoluteConstraints(20, 260-70, -1, -1));

        mainTopPanel.add(regionText, new AbsoluteConstraints(90, 260-70, 60, -1));

        countryLabel.setText("Country:");
	countryLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(countryLabel, new AbsoluteConstraints(160, 260-70, -1, -1));

        mainTopPanel.add(countryText, new AbsoluteConstraints(220, 260-70, 185, -1));

        mainTopPanel.add(addressInformationLabel, new AbsoluteConstraints(20, 180-70, -1, -1));

        homePhoneLabel.setText("Home Phone:");
	homePhoneLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(homePhoneLabel, new AbsoluteConstraints(20, 310-70, -1, -1));

        mainTopPanel.add(homePhoneText, new AbsoluteConstraints(110, 310-70, 150, -1));

        workPhoneLabel.setText("Work Phone:");
	workPhoneLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(workPhoneLabel, new AbsoluteConstraints(270, 310-70, -1, -1));

        mainTopPanel.add(workPhoneText, new AbsoluteConstraints(350, 310-70, 150, -1));

        mobilePhoneLabel.setText("Moblie Phone:");
	mobilePhoneLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(mobilePhoneLabel, new AbsoluteConstraints(20, 330-70, -1, -1));

        mainTopPanel.add(mobilePhoneText, new AbsoluteConstraints(110, 330-70, 150, -1));

        faxNumberLabel.setText("Fax number:");
	faxNumberLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(faxNumberLabel, new AbsoluteConstraints(270, 330-70, -1, -1));

        mainTopPanel.add(faxNumberText, new AbsoluteConstraints(350, 330-70, 150, -1));

        emailLabel.setText("E-mail:");
	emailLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(emailLabel, new AbsoluteConstraints(20, 350-70, -1, -1));

        mainTopPanel.add(emailText, new AbsoluteConstraints(70, 350-70, 190, -1));

        otherInformationLabel.setFont(new Font("Dialog", 3, 12));
        otherInformationLabel.setText("Other information");
        mainTopPanel.add(otherInformationLabel, new AbsoluteConstraints(20, 380-70, -1, -1));

        educationLabel.setText("Education:");
	educationLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(educationLabel, new AbsoluteConstraints(20, 400-70, -1, -1));

        workingExperienceLabel.setText("Working experience:");
	workingExperienceLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(workingExperienceLabel, new AbsoluteConstraints(20, 470-70, -1, -1));

        reEducationLabel.setText("Re-education:");
	reEducationLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(reEducationLabel, new AbsoluteConstraints(20, 610-70, -1, -1));

        languageSkillsLabel.setText("Language Skills:");
	languageSkillsLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(languageSkillsLabel, new AbsoluteConstraints(20, 540-70, -1, -1));

        otherITKnowledgeLabel.setText("Other IT knowledge:");
	otherITKnowledgeLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(otherITKnowledgeLabel, new AbsoluteConstraints(20, 680-70, -1, -1));

        spareTimeInterestsLabel.setText("Spare time interests:");
	spareTimeInterestsLabel.setForeground(new Color(100,100,100));
        mainTopPanel.add(spareTimeInterestsLabel, new AbsoluteConstraints(20, 760-70, -1, -1));

        educationScrollPane1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        educationTextArea1.setLineWrap(true);
	educationTextArea1.setEnabled(false);
	educationTextArea1.setDisabledTextColor(new Color(0,0,0));
	educationTextArea1.setBackground(new Color(233,233,242));
        educationScrollPane1.setViewportView(educationTextArea1);
        mainTopPanel.add(educationScrollPane1, new AbsoluteConstraints(20, 420-70, 500, 50));

        workingExperienceScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        workingExperienceTextArea.setLineWrap(true);
	workingExperienceTextArea.setEnabled(false);
	workingExperienceTextArea.setDisabledTextColor(new Color(0,0,0));
	workingExperienceTextArea.setBackground(new Color(233,233,242));
        workingExperienceScrollPane.setViewportView(workingExperienceTextArea);
        mainTopPanel.add(workingExperienceScrollPane, new AbsoluteConstraints(20, 490-70, 500, 50));

        languageSkillsScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        languageSkillsTextArea.setLineWrap(true);
	languageSkillsTextArea.setEnabled(false);
	languageSkillsTextArea.setDisabledTextColor(new Color(0,0,0));
	languageSkillsTextArea.setBackground(new Color(233,233,242));
        languageSkillsScrollPane.setViewportView(languageSkillsTextArea);
        mainTopPanel.add(languageSkillsScrollPane, new AbsoluteConstraints(20, 560-70, 500, 50));

        reEducationScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        reEducationTextArea.setLineWrap(true);
	reEducationTextArea.setEnabled(false);
	reEducationTextArea.setDisabledTextColor(new Color(0,0,0));
	reEducationTextArea.setBackground(new Color(233,233,242));
        reEducationScrollPane.setViewportView(reEducationTextArea);
        mainTopPanel.add(reEducationScrollPane, new AbsoluteConstraints(20, 630-70, 500, 50));

        otherITKnowledgeScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        otherITKnowledgeTextArea.setLineWrap(true);
	otherITKnowledgeTextArea.setEnabled(false);
	otherITKnowledgeTextArea.setDisabledTextColor(new Color(0,0,0));
	otherITKnowledgeTextArea.setBackground(new Color(233,233,242));
        otherITKnowledgeScrollPane.setViewportView(otherITKnowledgeTextArea);
        mainTopPanel.add(otherITKnowledgeScrollPane, new AbsoluteConstraints(20, 700-70, 500, 60));

        spareTimeInterestsScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        spareTimeInterestsTextArea.setLineWrap(true);
	spareTimeInterestsTextArea.setEnabled(false);
	spareTimeInterestsTextArea.setDisabledTextColor(new Color(0,0,0));
	spareTimeInterestsTextArea.setBackground(new Color(233,233,242));
        spareTimeInterestsScrollPane.setViewportView(spareTimeInterestsTextArea);
        mainTopPanel.add(spareTimeInterestsScrollPane, new AbsoluteConstraints(20, 780-70, 500, 60));

        mainTopPanel.add(dateText, new AbsoluteConstraints(370, 40, 110, -1));

        mainTopPanel.add(buttomLabel, new AbsoluteConstraints(15, 840-70, -1, 20));

	mainScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        mainScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        mainScrollPanel.setViewportView(mainTopPanel);
	mainPanel.add(mainScrollPanel, new AbsoluteConstraints(2, 12, 566, 450));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());
        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());

	backButton.setText("Back to the application");
        backButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseBackButton();
		}
	    });
        buttomPanel.add(backButton,  new AbsoluteConstraints(0, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	cp.add(mainJPanel, BorderLayout.CENTER);

	// Get information to fill out the screen
	getInformation();
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void getInformation() {
	ApplicantI applicant;
	try { // get the applicant
	    applicant = (ApplicantI)selectedApplication.getApplicant(selectedApplication.getApplicantID());
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}

	try { // get infomation on the applicant object
	    applicant = (ApplicantI)selectedApplication.getApplicant(selectedApplication.getApplicantID());
	    firstNameText.setText(" " + ((NameI)applicant.getName()).getFirstName());
	    middleNameText.setText(" " + ((NameI)applicant.getName()).getMiddleName());
	    lastNameText.setText(" " + ((NameI)applicant.getName()).getLastName());
	    // Load the cv
	    CVI cv = (CVI)applicant.getCV();
	    WDate wdate = new WDate(cv.getDateOfBirth());

	    dateText.setText("" + wdate.getDay() + "/" + wdate.getMonth() + "/" + wdate.getYear());
	    maritialText.setText(cv.getMaritalStatus());
	    sexText.setText(cv.getSex());
	    // Get address
	    address1Text.setText((applicant.getAddress()).getAddress1());
	    address2Text.setText((applicant.getAddress()).getAddress2());
	    cityText.setText((applicant.getAddress()).getCity());
	    postcodeText.setText("" + (applicant.getAddress()).getPostCode());
	    regionText.setText((applicant.getAddress()).getRegion());
	    countryText.setText((applicant.getAddress()).getCountry());
	    // Get phone
	    homePhoneText.setText("" + (applicant.getPhoneNumber()).getHomePhone());
	    workPhoneText.setText("" + (applicant.getPhoneNumber()).getWorkPhone());
	    mobilePhoneText.setText("" + (applicant.getPhoneNumber()).getMobile());
	    faxNumberText.setText("" + (applicant.getPhoneNumber()).getFax());
	    emailText.setText(applicant.getEmail());
	    // Getting all other information from the cv
	    educationTextArea1.setText(cv.getEducation());
	    workingExperienceTextArea.setText(cv.getWorkingExperience());
	    reEducationTextArea.setText(cv.getReEducation());
	    languageSkillsTextArea.setText(cv.getLanguageSkills());
	    otherITKnowledgeTextArea.setText(cv.getOtherITKnowledge());
	    spareTimeInterestsTextArea.setText(cv.getSpareTimeInterests());
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
    }

    private void mouseBackButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new ViewApplicationHeadhunterGUI(jobNo, selectedApplication, hh,selectedProject, appNo));
	setContentPane(cp);
    }
}
