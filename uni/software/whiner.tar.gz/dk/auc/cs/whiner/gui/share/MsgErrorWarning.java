package dk.auc.cs.whiner.gui.share;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

/**
 * This class <code>MsgErrorWarning</code> is used to handle all of
 * the dialog windows in the graphic user interface.
 *
 * @author <a href="mailto:cableman@cs.auc.dk"></a>
 * @version $Revision: 1.3 $
 */
public class MsgErrorWarning {
    private String message;
    private int answer;
    private Object[] options = { "OK", "CANCEL" };
    private Object[] options1 = { "Yes", "No" };
    private JOptionPane warning = new JOptionPane();

    public MsgErrorWarning (String message) {
	this.message = message;
    }

    /**
     * This <code>msgError</code> method is used to make an error
     * dialog, with a "ok" button.
     *
     */
    public void msgError() {
	JOptionPane.showMessageDialog(null,
				      message,
				      "Error",
				      JOptionPane.ERROR_MESSAGE);
    }

    /**
     * This <code>msgWarning</code> method is used to make and display
     * a warring dialog, with to buttons, "ok" and "cancel". It return
     * 1 or 0 if "ok" is chosen it retrun 0.
     *
     * @return an <code>int</code> value
     */
    public int msgWarning() {
	answer = warning.showOptionDialog(null, message, "Warning",
					  JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
					  null, options, options[0]);
	return answer;
    }

    /**
     * This <code>msgLogout</code> method makes a dialog window whit
     * an "yes" and "no" button.
     *
     * @return an <code>int</code> value
     */
    public int msgLogout() {
	answer = warning.showOptionDialog(null, message, "Warning",
					  JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
					  null, options1, options1[0]);
	return answer;
    }


    /**
     * This dialog window can be used to type in a string.
     *
     * @return a <code>String</code> value
     */
    public String msgInput() {
	String s = JOptionPane.showInputDialog(null, 
					       message,
					       "Change password",
					       JOptionPane.PLAIN_MESSAGE);
	return s;
    }
}
