SPATH=/home/aaby/uni/dat1/cvs/programming/dk/auc/cs/whiner/gui/

touch ${SPATH}empty.class
rm ${SPATH}*.class 
touch ${SPATH}administrator/empty.class
rm ${SPATH}administrator/*.class 
touch ${SPATH}applicant/empty.class
rm ${SPATH}applicant/*.class
touch ${SPATH}headhunter/empty.class
rm ${SPATH}headhunter/*.class
touch ${SPATH}share/empty.class
rm ${SPATH}share/*.class 