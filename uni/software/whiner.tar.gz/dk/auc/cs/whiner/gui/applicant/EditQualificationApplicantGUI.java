/**
 *
 * @author  Jesper Kristensen
 * @version $Revision: 1.15 $
 *
 */
package dk.auc.cs.whiner.gui.applicant;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;

import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

public class EditQualificationApplicantGUI extends JApplet {
    private MsgErrorWarning msgErrorWarning;
    private Container cp;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JPanel westPanel;
    private JPanel mainTopPanel;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JPanel mainButtomPanel;
    private JPanel eastPanel;
    private JButton logoutButton;
    private ApplicantI applicant;
    private JButton backButton;
    private JList qualificationList;
    private JScrollPane qualificationListScrollPanel;
    private DefaultListModel qualificationListModel;
    private JLabel qualificationLabel;
    private JButton removeButton;
    private JList globalQualificationList;
    private JScrollPane globalQualificationListScrollPanel;
    private DefaultListModel globalQualificationListModel;
    private JLabel globalQualificationLabel;
    private JButton addButton;
    private JButton saveButton;
    private JLabel qualificationSkillLevelLabel;
    private ButtonGroup skillButtonGroup;
    private JRadioButton skill1Radio;
    private JRadioButton skill2Radio;
    private JRadioButton skill3Radio;
    private JRadioButton skill4Radio;
    private JRadioButton skill5Radio;
    private int selectedLevel;
    private CVI cv;

    public EditQualificationApplicantGUI(ApplicantI applicant) {
	this.applicant = applicant;
        initComponents();
    }

    private void initComponents() {
	addButton = new JButton();
	backButton = new JButton();
        buttomPanel = new JPanel();
	cp = getContentPane();
        eastPanel = new JPanel();
	globalQualificationLabel = new JLabel();
        globalQualificationList = new JList();
        globalQualificationListScrollPanel = new JScrollPane();
        logoutButton = new JButton();
        mainButtomPanel = new JPanel();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
	qualificationLabel = new JLabel();
        qualificationList = new JList();
        qualificationListScrollPanel = new JScrollPane();
	qualificationSkillLevelLabel = new JLabel();
	removeButton = new JButton();
	saveButton = new JButton();
	selectedLevel = -1;
	skill1Radio = new JRadioButton();
	skill2Radio = new JRadioButton();
	skill3Radio = new JRadioButton();
	skill4Radio = new JRadioButton();
	skill5Radio = new JRadioButton();
	skillButtonGroup = new ButtonGroup();
        topPanel = new JPanel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());
	mainTopPanel.setBackground(new Color(233,233,242));
        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

	qualificationLabel.setText("Qualifications in your profile:");
	mainTopPanel.add(qualificationLabel, new AbsoluteConstraints(20, 20, -1, -1));

        qualificationListScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	qualificationListModel = new DefaultListModel();
        qualificationList.setModel(qualificationListModel);
        qualificationList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        qualificationListScrollPanel.setViewportView(qualificationList);
        mainTopPanel.add(qualificationListScrollPanel, new AbsoluteConstraints(20, 40, 420, 155));

        saveButton.setText("Save");
        saveButton.setToolTipText("Save the qualification to you profile.");
        saveButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseSaveButton();
		}
	    });
        mainTopPanel.add(saveButton, new AbsoluteConstraints(460, 142, 87, -1));

        removeButton.setText("Remove");
        removeButton.setToolTipText("Remove the selected qualification form you profile.");
        removeButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseRemoveButton();
		}
	    });
        mainTopPanel.add(removeButton, new AbsoluteConstraints(460, 170, 87, -1));

        mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 215));

        mainButtomPanel.setLayout(new AbsoluteLayout());
        mainButtomPanel.setBorder(new BevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

	globalQualificationLabel.setText("Qualifications list:");
	mainButtomPanel.add(globalQualificationLabel, new AbsoluteConstraints(20, 20, -1, -1));

        globalQualificationListScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	globalQualificationListModel = new DefaultListModel();
        globalQualificationList.setModel(globalQualificationListModel);
        globalQualificationList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        globalQualificationListScrollPanel.setViewportView(globalQualificationList);
        mainButtomPanel.add(globalQualificationListScrollPanel, new AbsoluteConstraints(20, 40, 420, 155));

        addButton.setText("Add");
        addButton.setToolTipText("Add selected qualification to your profile.");
        addButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseAddButton();
		}
	    });
        mainButtomPanel.add(addButton, new AbsoluteConstraints(460, 170, 87, -1));

	qualificationSkillLevelLabel.setText("Experience: ");
        mainButtomPanel.add(qualificationSkillLevelLabel, new AbsoluteConstraints(450, 20, -1, -1));

        skill1Radio.setText("1 Month");
	skillButtonGroup.add(skill1Radio);
        skill1Radio.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
		selectedLevel = 1;
            }
        });
	skill1Radio.setBackground(new Color(233,233,242));
        mainButtomPanel.add(skill1Radio, new AbsoluteConstraints(450, 40, -1, -1));
	
	skill2Radio.setText("6 Months");
	skillButtonGroup.add(skill2Radio);
        skill2Radio.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
		selectedLevel = 2;
            }
        });
	skill2Radio.setBackground(new Color(233,233,242));
        mainButtomPanel.add(skill2Radio, new AbsoluteConstraints(450, 60, -1, -1));

        skill3Radio.setText("12 Months");
	skillButtonGroup.add(skill3Radio); 
	skill3Radio.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
		selectedLevel = 3;
            }
        });
	skill3Radio.setBackground(new Color(233,233,242));
        mainButtomPanel.add(skill3Radio, new AbsoluteConstraints(450, 80, -1, -1));

        skill4Radio.setText("18 Months");
	skillButtonGroup.add(skill4Radio);
        skill4Radio.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
		selectedLevel = 4;
            }
        });
	skill4Radio.setBackground(new Color(233,233,242));
        mainButtomPanel.add(skill4Radio, new AbsoluteConstraints(450, 100, -1, -1));

        skill5Radio.setText("18+ Months");
	skillButtonGroup.add(skill5Radio);
        skill5Radio.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
		selectedLevel = 5;
            }
        });
	skill5Radio.setBackground(new Color(233,233,242));
        mainButtomPanel.add(skill5Radio, new AbsoluteConstraints(450, 120, -1, -1));

	mainButtomPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainButtomPanel, new AbsoluteConstraints(2, 240, 566, 215));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());
        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());

	backButton.setText("Back to main");
        backButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseBackButton();
		}
	    });
        buttomPanel.add(backButton,  new AbsoluteConstraints(0, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	cp.add(mainJPanel, BorderLayout.CENTER);

	// Load information about the qualifications
	getInformation();
    }

    private void getInformation() {
	try { // Get global qualifications list
	    cv = (CVI)applicant.selectCV();
	    cv.initializeGlobalQualificationList();
	    for (int i = 0; i < cv.getGlobalQualificationListLength(); i++) {
		QualificationI qualification = cv.getGlobalQualification(i);
		String argToList = new String(qualification.getName());
		globalQualificationListModel.insertElementAt(argToList, i);
	    } // Get qualification list
	    cv.initializeQualificationList();
	    for (int i = 0; i < cv.getApplicantQualificationListLength(); i++) {
		String skillLevelString;
		if (((SkillLevelI)cv.getQualification(i)).getLevel() == 1) {
		    skillLevelString = new String("1 Month");
		} else if(((SkillLevelI)cv.getQualification(i)).getLevel() == 2) {
		    skillLevelString = new String("6 Months");
		} else if(((SkillLevelI)cv.getQualification(i)).getLevel() == 3) {
		    skillLevelString = new String("12 Months");
		} else if(((SkillLevelI)cv.getQualification(i)).getLevel() == 4) {
		    skillLevelString = new String("18 Months");
		} else {
		    skillLevelString = new String("18+ Months");
		}
		String argToList = new String(((QualificationI)((SkillLevelI)cv.getQualification(i)).getQualification()).getName());
		qualificationListModel.insertElementAt(argToList + "(" + skillLevelString + ")", i);
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
    }

    private void mouseSaveButton() {
	msgErrorWarning = new MsgErrorWarning("Save qualifications to your profile");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    try {
		cv.saveQualifications();
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;
	    }
    	} else {
	    // Do nothing
	}	
	
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void mouseBackButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new MainApplicantGUI(applicant));
	setContentPane(cp);
    }

    private void mouseRemoveButton() {
	// Test to se if a qualification has been selected
	if ((String)qualificationList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't remove, when no qualification is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Makes a msg box to verfiy the removel
	msgErrorWarning = new MsgErrorWarning("Warning do you want to remove: " + (String)qualificationList.getSelectedValue());
	int selected = msgErrorWarning.msgWarning();
	// Check the answer from the user, if it's 0 remove the qualification eles do nothing
	if (selected == 0) {
	    int indexInList = qualificationList.getSelectedIndex();
	    try {
		cv.removeQualification(indexInList);
		cv.saveQualifications();
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	    qualificationListModel.remove(indexInList);
	} else {
	    return;
	}
    }

    private void mouseAddButton() {
	// Test to se if a qualification has been selected
	if ((String)globalQualificationList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't add, when no qualification is selected.");
	    msgErrorWarning.msgError();
	    return;
	} else if (selectedLevel == -1) {
	    msgErrorWarning = new MsgErrorWarning("You can't add, when no level of experience is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Add qualification to the list
	int sizeOfList = qualificationListModel.getSize();
	try {
	    cv.addQualification(globalQualificationList.getSelectedIndex(), selectedLevel);
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}

	String skillLevelString;
	if (selectedLevel == 1) {
	    skillLevelString = new String("1 Month");
	} else if(selectedLevel == 2) {
	    skillLevelString = new String("6 Months");
	} else if(selectedLevel == 3) {
	    skillLevelString = new String("12 Months");
	} else if(selectedLevel == 4) {
	    skillLevelString = new String("18 Months");
	} else {
	    skillLevelString = new String("18+ Months");
	}
	
	qualificationListModel.insertElementAt((String)globalQualificationList.getSelectedValue() + 
					       "(" + skillLevelString+ ")", sizeOfList);
    }
}
