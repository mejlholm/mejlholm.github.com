#!/bin/sh

grep -v "*"  *.java applicant/*.java administrator/*.java share/*.java headhunter/*.java | grep -v "//" | wc -l
