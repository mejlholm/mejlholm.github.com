// This is an Junit test suite to run all the test in the GUI

package dk.auc.cs.whiner.gui;

// Load the junit packages
import junit.framework.Test;
import junit.framework.TestSuite;
import junit.framework.TestCase;

import java.security.*;

// Load the GUI packages
import dk.auc.cs.whiner.gui.headhunter.*;
import dk.auc.cs.whiner.gui.administrator.*;
import dk.auc.cs.whiner.gui.applicant.*;
import dk.auc.cs.whiner.gui.share.*;

public class TestGUI extends TestCase {
    public static Test suite() {
	TestSuite suite = new TestSuite();
	// Add all the test in the GUI
	suite.addTest(new TestCryptPassword());

	return suite;
    }
}
