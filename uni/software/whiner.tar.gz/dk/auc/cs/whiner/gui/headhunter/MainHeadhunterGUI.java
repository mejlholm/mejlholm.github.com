/**
 *
 * @author  Jesper Kristensen
 * @version $Revision: 1.57 $
 */
package dk.auc.cs.whiner.gui.headhunter;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import java.io.*;
import java.util.*;
import java.security.*;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;

import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

public class MainHeadhunterGUI extends JApplet {
    private String descriptionTitleTextBackup;
    private String descriptionTextAreaBackup;
    private int indexInList;
    private MsgErrorWarning msgErrorWarning;
    private DefaultListModel projectListModel;
    private DefaultListModel jobListModel;
    private Container cp;
    private JButton descriptionCancelButton;
    private JOptionPane jobWarning;
    private JButton jobsAddButton;
    private JList projectList;
    private JLabel descriptionTitleLabel;
    private JPanel topPanel;
    private JPanel mainJPanel;
    private JTextField descriptionTitleText;
    private JPanel westPanel;
    private JButton jobsDelButton;
    private JButton jobsReopenButton;
    private JButton projectViewButton;
    private JScrollPane projectScrollPanel;
    private JPanel mainCenterPanel;
    private JPanel mainTopPanel;
    private JButton jobsCloseButton;
    private JButton descriptionEditButton;
    private JButton logoutButton;
    private JButton projectNewButton;
    private JPanel mainPanel;
    private JButton statButton;
    private JPanel buttomPanel;
    private JTextArea descriptionTextArea;
    private JPanel mainButtomPanel;
    private JScrollPane descriptionScrollPanel;
    private JPanel eastPanel;
    private JButton jobsAnnounceButton;
    private JButton projectDelButton;
    private JButton changePasswordButton;
    private JButton jobsViewButton;
    private JLabel projectLabel;
    private JList jobList;
    private JScrollPane jobsScrollPanel;
    private HeadhunterI hh;
    private ProjectI selectedProject;

    public MainHeadhunterGUI(HeadhunterI hh) throws RemoteException {
	this.hh = hh;
	initGUI();
    }

    private void initGUI() {
        buttomPanel = new JPanel();
	cp = getContentPane();
	projectLabel = new JLabel();
	descriptionCancelButton = new JButton();
        descriptionEditButton = new JButton();
        descriptionScrollPanel = new JScrollPane();
        descriptionTextArea = new JTextArea();
	descriptionTextAreaBackup = new String();
        descriptionTitleLabel = new JLabel();
        descriptionTitleText = new JTextField();
	descriptionTitleTextBackup = new String();
        eastPanel = new JPanel();
        jobList = new JList();
        jobsAddButton = new JButton();
        jobsAnnounceButton = new JButton();
        jobsCloseButton = new JButton();
        jobsDelButton = new JButton();
        jobsReopenButton = new JButton();
        changePasswordButton = new JButton();
        jobsScrollPanel = new JScrollPane();
        jobsViewButton = new JButton();
        logoutButton = new JButton();
        mainButtomPanel = new JPanel();
        mainCenterPanel = new JPanel();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
        projectDelButton = new JButton();
        projectList = new JList();
        projectNewButton = new JButton();
        projectScrollPanel = new JScrollPane();
        projectViewButton = new JButton();
        statButton = new JButton();
        topPanel = new JPanel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());
        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

        projectNewButton.setText("New");
        projectNewButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseNewProjectButton();
		}
	    });
        mainTopPanel.add(projectNewButton, new AbsoluteConstraints(460, 46, 87, -1));

        projectDelButton.setText("Delete");
        projectDelButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseDelProjectButton();
		}
	    });
        mainTopPanel.add(projectDelButton, new AbsoluteConstraints(460, 106, 87, -1));

        projectViewButton.setText("View");
        projectViewButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseViewButtonList();
		}
	    });
        mainTopPanel.add(projectViewButton, new AbsoluteConstraints(460, 76, 87, -1));

        projectLabel.setText("Projects:");
        mainTopPanel.add(projectLabel, new AbsoluteConstraints(20, 20, -1, -1));

        projectScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	projectListModel = new DefaultListModel();
        projectList.setModel(projectListModel);
        projectList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        projectList.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseListDblClicked(evt);
		}
	    });
        projectScrollPanel.setViewportView(projectList);
        mainTopPanel.add(projectScrollPanel, new AbsoluteConstraints(20, 40, 420, 90));

	mainTopPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 145));

        mainCenterPanel.setLayout(new AbsoluteLayout());

        mainCenterPanel.setBorder(new BevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));
	descriptionTitleText.setEditable(false);
	descriptionTitleText.setBackground(new Color(233,233,242));
        mainCenterPanel.add(descriptionTitleText, new AbsoluteConstraints(60, 20, 380, -1));

        descriptionTitleLabel.setText("Title:");
        mainCenterPanel.add(descriptionTitleLabel, new AbsoluteConstraints(20, 20, -1, -1));

        descriptionEditButton.setText("Edit");
	descriptionEditButton.setEnabled(false);
        descriptionEditButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseEditDescriptionButton(evt);
		}
	    });
        mainCenterPanel.add(descriptionEditButton, new AbsoluteConstraints(460, 106, 87, -1));

        descriptionCancelButton.setText("Cancel");
	descriptionCancelButton.setEnabled(false);
        descriptionCancelButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseCancelDescriptionButton();
		}
	    });
        mainCenterPanel.add(descriptionCancelButton, new AbsoluteConstraints(460, 76, 87, -1));

	descriptionScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        descriptionScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        descriptionTextArea.setEditable(false);
        descriptionTextArea.setLineWrap(true);
	descriptionTextArea.setBackground(new Color(233,233,242));
        descriptionScrollPanel.setViewportView(descriptionTextArea);

        mainCenterPanel.add(descriptionScrollPanel, new AbsoluteConstraints(20, 50, 420, 80));

	mainCenterPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainCenterPanel, new AbsoluteConstraints(2, 167, 566, 145));

        mainButtomPanel.setLayout(new AbsoluteLayout());

        mainButtomPanel.setBorder(new BevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));
        jobsReopenButton.setText("Re-open");
        jobsReopenButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseJobsReopenButton();
		}
	    });
        mainButtomPanel.add(jobsReopenButton, new AbsoluteConstraints(360, 105, 96, -1));

        jobsAnnounceButton.setText("Announce");
        jobsAnnounceButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseJobsAnnounceButton();
		}
	    });
        mainButtomPanel.add(jobsAnnounceButton, new AbsoluteConstraints(460, 105, 96, -1));

        jobsViewButton.setText("View");
        jobsViewButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseJobsViewButton();
		}
	    });
        mainButtomPanel.add(jobsViewButton, new AbsoluteConstraints(360, 76, 96, -1));

        jobsCloseButton.setText("Close");
        jobsCloseButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseJobsCloseButton();
		}
	    });
        mainButtomPanel.add(jobsCloseButton, new AbsoluteConstraints(460, 76, 96, -1));

        jobsDelButton.setText("Delete");
        jobsDelButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseJobsDelButton();
		}
	    });
        mainButtomPanel.add(jobsDelButton, new AbsoluteConstraints(460, 46, 96, -1));

        jobsAddButton.setText("Add");
        jobsAddButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseJobsAddButton();
		}
	    });
        mainButtomPanel.add(jobsAddButton, new AbsoluteConstraints(360, 46, 96, -1));

        jobsScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	jobListModel = new DefaultListModel();
        jobList.setModel(jobListModel);
        jobList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        jobList.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    if (evt.getClickCount() == 2) {
			mouseJobsViewButton();
		    }
		}
	    });
        jobsScrollPanel.setViewportView(jobList);

        mainButtomPanel.add(jobsScrollPanel, new AbsoluteConstraints(20, 20, 330, 110));

	mainButtomPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainButtomPanel, new AbsoluteConstraints(2, 320, 566, 145));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());

        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());

        statButton.setText("Statistics");
	statButton.setToolTipText("This function is not implanted");
        statButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseStatButton();
		}
	    });
        buttomPanel.add(statButton,  new AbsoluteConstraints(0, 0, -1, -1));

        changePasswordButton.setText("Password");
	changePasswordButton.setToolTipText("Change password");
        changePasswordButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseChangePassword();
		}
	    });
        buttomPanel.add(changePasswordButton,  new AbsoluteConstraints(95, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	mainJPanel.setBackground(new Color(233,233,242));
	cp.add(mainJPanel, BorderLayout.CENTER);

	// This call get all the information for this screen realte to the logged in headhunte
	getProjectInformation();
    }

    // The reste of this file handels the driffent event trick around in the GUI
    private void mouseListDblClicked(MouseEvent evt) {
	if (evt.getClickCount() == 2) {
	    mouseViewButtonList(); // This function is shared between the list and view button
	}
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void mouseChangePassword() {
	// Aske for a new password from the user
	msgErrorWarning = new MsgErrorWarning("Insert a new password");
       	String newPassword = msgErrorWarning.msgInput();
	// Hash and save the new password
	if (!(newPassword == null)) {
	    try {
		CryptPassword pwd = new CryptPassword(newPassword);
		newPassword = pwd.cryptSHA();
		hh.changePassword(newPassword);
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (NoSuchAlgorithmException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the password funktion.\n The applet will exit.");
		msgErrorWarning.msgError();
		System.exit(-1);
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	}
    }

    private void mouseStatButton() {
	// Check to see if the description shall be saved first
	if (descriptionTitleText.isEditable()) {
	    // Send a warning msg to the use aboudt the delete job
	    msgErrorWarning = new MsgErrorWarning("Warning do you want to save the description first.");
	    int selected = msgErrorWarning.msgWarning();
	    // Check the answer from the user, if it's 0 save the description
	    if (selected == 0) {
		try {
		    selectedProject.setTitle(descriptionTitleText.getText());
		    selectedProject.setDescription(descriptionTextArea.getText());
		    selectedProject.save();
		} catch (RemoteException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		    msgErrorWarning.msgError();
		    return;
		} catch (DAOException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		    msgErrorWarning.msgError();
		    return;
		} catch (Exception e) {
		    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		    msgErrorWarning.msgError();
		    return;   
		}
		// Change the screen
		cp.removeAll();
		cp.add(BorderLayout.CENTER, new StatisticHeadhunterGUI(hh));
		setContentPane(cp);
	    } else {
		// Do nothing
		return;
	    }
	} else {
	    // Change the screen
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new StatisticHeadhunterGUI(hh));
	    setContentPane(cp);
	}
    }

    private void mouseNewProjectButton() {
	// Check if the button isenabled
	if (projectNewButton.isEnabled() == false) {return;}
	int sizeOfList = projectListModel.getSize();
	// Eable the description and move focus
	descriptionTitleText.setEditable(true);
	descriptionTitleText.setBackground(new Color(255,255,255));
	descriptionTitleText.setText("New project");
	descriptionTextArea.setText("");
	descriptionTextArea.setEditable(true);    
	descriptionTextArea.setBackground(new Color(255,255,255));
	descriptionEditButton.setText("Save");
	descriptionEditButton.setEnabled(true);
	// disable the new, view and delete  button
	projectPanelOnOff(0);
	// DisAble jobPanel
	jobPanelOnOff(0);
	// initialize project
	try {
	    hh.createProject();
	    selectedProject = hh.getProject(hh.getProjectListLength() - 1);
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	// Add new project to the end of the project list
	projectListModel.insertElementAt("New project (filled)", sizeOfList);
	indexInList = sizeOfList;
	// Move focus onto the newly made element
	projectList.setSelectedIndex(sizeOfList);
    }
   
    private void mouseDelProjectButton() {
	// Check if the button isenabled in relate to new
	if (projectNewButton.isEnabled() == false) {return;}
	// Check to se if any project is selected
	if (projectList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't delete, when no project is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Makes a msg box to verfiy the deletion
	msgErrorWarning = new MsgErrorWarning("Warning do you want to delete: " + (String)projectList.getSelectedValue());
	int selected = msgErrorWarning.msgWarning();
	// Check the answer from the user, if it's 0 delete the project eles do nothing
	if (selected == 0) {
	    // Remove project from the database
	    try {
		indexInList = projectList.getSelectedIndex();
		hh.deleteProject(indexInList);
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (AnnouncedJobException e) {
		msgErrorWarning = new MsgErrorWarning("Announced error: You can't delete the project, jobs are open.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	    // Delete selected project from the project list
	    indexInList = projectList.getSelectedIndex();
	    projectListModel.remove(indexInList);
	    descriptionTitleText.setText("");
	    descriptionTextArea.setText("");
	    descriptionEditButton.setEnabled(false);
	    // DisAble jobPanel
	    jobPanelOnOff(0);
	    // Empty the list's
	    for (int i = 0; i < jobListModel.size(); i++) {
		jobListModel.remove(0);
	    }
	} else {
	    return;
	}
    }

    private void mouseViewButtonList() {
	// Check if the button isenabled in relate to new
	if (projectNewButton.isEnabled() == false) {return;}
	// Check to see if the description shall be saved first
	if (descriptionTitleText.isEditable()) {
	    // Send a warning msg to the use aboudt the delete job
	    msgErrorWarning = new MsgErrorWarning("Warning do you want to save the description first.");
	    int selected = msgErrorWarning.msgWarning();
	    // Check the answer from the user, if it's 0 save the description
	    if (selected == 0) {
		try {
		    selectedProject.setTitle(descriptionTitleText.getText());
		    selectedProject.setDescription(descriptionTextArea.getText());
		    selectedProject.save();
		} catch (RemoteException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		    msgErrorWarning.msgError();
		    return;
		} catch (DAOException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		    msgErrorWarning.msgError();
		    return;
		} catch (Exception e) {
		    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		    msgErrorWarning.msgError();
		    return;
		}
		// Call the help function
		helpMouseViewButtonList();
	    } else {
		// Do nothing
		return;
	    }
	} else {
	    // Call the help function
	    helpMouseViewButtonList();
	}
    }

    private void helpMouseViewButtonList() {
	// Check to se if any project is selected
	if (projectList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't view, when no project is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Project is selected make jobPanel on
	jobPanelOnOff(1);
	// Open relate job and view project description from selected project list
	indexInList = projectList.getSelectedIndex(); // This is use when the save is pressed
	descriptionTitleText.setText((String)projectList.getSelectedValue());
	descriptionEditButton.setEnabled(true);
	// Resets the joblist, so there are no job which is not realete to current selected project
	jobList.removeAll();
	jobListModel = new DefaultListModel();
	jobList.setModel(jobListModel);
	// Get jobs and project description from the databas
	try { // make a job list relate to the selected project
	    selectedProject = (ProjectI)hh.getProject(indexInList);	    
	    selectedProject.initializeJobList();
	    String jobString = new String();
	    for (int i = 0; i < selectedProject.getJobListLength(); i++) {
		jobString = ((JobI)selectedProject.selectJob(i)).getTitle() + 
		            " (" + ((JobI)selectedProject.selectJob(i)).getStatus() + ")";
		jobListModel.insertElementAt(jobString, i);
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}

	try {// get the project description
	    descriptionTitleText.setText(selectedProject.getTitle());
	    descriptionTextArea.setText(selectedProject.getDescription());
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
    }

    private void mouseEditDescriptionButton(MouseEvent evt) {
	if (((JButton)evt.getSource()).getText().equals("Edit")) {
	    // This linie dos that you can press the button when not able
	    if (descriptionEditButton.isEnabled() == false) {return;}
	    // This makes the project description editable and enable the cancel button
	    descriptionTitleText.setEditable(true);
	    descriptionTextArea.setEditable(true);
	    descriptionCancelButton.setEnabled(true);
	    descriptionTitleText.setBackground(new Color(255,255,255));
	    descriptionTextArea.setBackground(new Color(255,255,255));
	    descriptionEditButton.setText("Save");
	    // Makes the backup to the cancel function
	    descriptionTitleTextBackup = descriptionTitleText.getText();
	    descriptionTextAreaBackup = descriptionTextArea.getText();
	    // Disable the other things in this screen
	    jobPanelOnOff(0);
	    projectPanelOnOff(0);
	} else { 
	    // This is used when the user press save
	    // Save the changes in the database
	    try {
		selectedProject.setTitle(descriptionTitleText.getText());
		selectedProject.setDescription(descriptionTextArea.getText());
		selectedProject.save();
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;
	    }
	    // Changes the screen
	    descriptionTitleText.setEditable(false);
	    descriptionTextArea.setEditable(false);	    
	    descriptionTitleText.setBackground(new Color(233,233,242));
	    descriptionTextArea.setBackground(new Color(233,233,242));
	    descriptionEditButton.setText("Edit");
	    // Chanege the value of the element in the projectList
	    projectListModel.remove(indexInList);
	    projectListModel.insertElementAt(descriptionTitleText.getText(), indexInList);
	    // Able the new, del, view button if it's and new project
	    if (projectNewButton.isEnabled() == false) {
		projectPanelOnOff(1);
	    }
	    // Able the jobPanel and projectPanel
	    jobPanelOnOff(1);
	    projectPanelOnOff(1);
	    // Disable the cancel button
	    descriptionCancelButton.setEnabled(false);
	}
    }

    private void mouseCancelDescriptionButton() {
	// Check if the button isenabled in relate to new
	if (descriptionCancelButton.isEnabled() == false) {return;}
	// Restore the content of the description area
	descriptionTitleText.setText(descriptionTitleTextBackup);
	descriptionTextArea.setText(descriptionTextAreaBackup);
	descriptionCancelButton.setEnabled(false);
	// Disable the description fields and chang the edit button
	descriptionTitleText.setEditable(false);
	descriptionTitleText.setBackground(new Color(233,233,242));
	descriptionTextArea.setEditable(false);	    
	descriptionTextArea.setBackground(new Color(233,233,242));
	descriptionEditButton.setText("Edit");
	// Enabeld the other things on the screen
	jobPanelOnOff(1);
	projectPanelOnOff(1);
    }

    private void mouseJobsAddButton() {
	// Check if the button isenabled
	if (jobsAddButton.isEnabled() == false) {return;}
	// Check to see if the description shall be saved first
	if (descriptionTitleText.isEditable()) {
	    // Send a warning msg to the use aboudt the delete job
	    msgErrorWarning = new MsgErrorWarning("Warning do you want to save the description first.");
	    int selected = msgErrorWarning.msgWarning();
	    // Check the answer from the user, if it's 0 save the description
	    if (selected == 0) {
		try {
		    selectedProject.setTitle(descriptionTitleText.getText());
		    selectedProject.setDescription(descriptionTextArea.getText());
		    selectedProject.save();
		} catch (RemoteException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		    msgErrorWarning.msgError();
		    return;
		} catch (DAOException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		    msgErrorWarning.msgError();
		    return;
		} catch (Exception e) {
		    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		    msgErrorWarning.msgError();
		    return;
		}
		// Change the screen
		cp.removeAll();
		cp.add(BorderLayout.CENTER, new JobInformationHeadhunterGUI(0, selectedProject, "add", hh));
		setContentPane(cp);   
	    } else {
		// Do nothing
		return;
	    }
	} else {
	    // Change the screen
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new JobInformationHeadhunterGUI(0, selectedProject, "add", hh));
	    setContentPane(cp);   
	}
    }
    
    private void mouseJobsCloseButton() {
	// Check if the button isenabled
	if (jobsCloseButton.isEnabled() == false) {return;}
	// Get selected job
	String selectedJob = (String)jobList.getSelectedValue();
	// Test to see if a job is selected, if not make error
	if (selectedJob == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't close, when no job is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	try { // Change the job status
	    (selectedProject.selectJob(jobList.getSelectedIndex())).close();
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (CloseException e) {
	    msgErrorWarning = new MsgErrorWarning("You can't close this job.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	// Update the screen
	try {
	    // Update job string
	    int i = jobList.getSelectedIndex();
	    String jobString = new String(((JobI)selectedProject.selectJob(i)).getTitle() + 
					  " (" + ((JobI)selectedProject.selectJob(i)).getStatus() + ")");
	    jobListModel.remove(i);
	    jobListModel.insertElementAt(jobString, i);
	    // Update project status in GUI
	    int j = projectList.getSelectedIndex();
	    String projectString = new String(((ProjectI)hh.getProject(j)).getTitle() + 
					      " (" + ((ProjectI)hh.getProject(j)).getStatus() + 
					      ")");
	    projectListModel.remove(j);
	    projectListModel.insertElementAt(projectString, j);
	    projectList.setSelectedIndex(j);
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
    }
    
    private void mouseJobsDelButton() {
	// Check if the button isenabled
	if (jobsDelButton.isEnabled() == false) {return;}
	String selectedJob = (String)jobList.getSelectedValue();
	// Test to see if a job is selected, if not make error
	if (selectedJob == null) {
	    msgErrorWarning = new MsgErrorWarning( "You can't delete, when no job is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Send a warning msg to the use aboudt the delete job
	msgErrorWarning = new MsgErrorWarning("Warning do you want to delete: " + selectedJob);
	int selected = msgErrorWarning.msgWarning();
	// Check the answer from the user, if it's 0 delete the job eles do nothing
	if (selected == 0) {
	    try { // Remove the job 
		selectedProject.deleteJobIfNotAnnounced(jobList.getSelectedIndex()); //Captain. Jeg har rettet!!!!!!!!!!!!
		// Update the project string
		int i = projectList.getSelectedIndex();
		String projectString = new String(((ProjectI)hh.getProject(i)).getTitle() + 
						  " (" + ((ProjectI)hh.getProject(i)).getStatus() + 
						  ")");
		projectListModel.remove(i);
		projectListModel.insertElementAt(projectString, i);
		projectList.setSelectedIndex(i);
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (AnnouncedJobException e) {
		msgErrorWarning = new MsgErrorWarning("You can't delete this job, it's announced.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	    jobListModel.remove(jobList.getSelectedIndex());
	} else {
	    return;
	}
    }
    
    private void mouseJobsViewButton() {
	// Check if the button isenabled
	if (jobsViewButton.isEnabled() == false) {return;}
	// May a check to se if description has been  saved
	if (descriptionTitleText.isEditable()) {
	    // Send a warning msg to the use aboudt the delete job
	    msgErrorWarning = new MsgErrorWarning("Warning do you want to save the description first.");
	    int selected = msgErrorWarning.msgWarning();
	    // Check the answer from the user, if it's 0 save the description
	    if (selected == 0) {
		try {
		    selectedProject.setTitle(descriptionTitleText.getText());
		    selectedProject.setDescription(descriptionTextArea.getText());
		    selectedProject.save();
		} catch (RemoteException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		    msgErrorWarning.msgError();
		    return;
		} catch (DAOException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		    msgErrorWarning.msgError();
		    return;
		} catch (Exception e) {
		    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		    msgErrorWarning.msgError();
		    return;
		}
		// Get slected job and change screen
		int selectedJob = jobList.getSelectedIndex();
		// Test to see if a job is selected, if not make error
		if ((String)jobList.getSelectedValue() == null) {
		    msgErrorWarning = new MsgErrorWarning("You can't view, when no job is selected.");
		    msgErrorWarning.msgError();
		    return;
		}
		// Change the screen
		cp.removeAll();
		cp.add(BorderLayout.CENTER, new JobInformationHeadhunterGUI(selectedJob, selectedProject, "view", hh));
		setContentPane(cp);
	    } else {
		// Do nothing
		return;
	    }
	} else {
	    // Get slected job and change screen
	    int selectedJob = jobList.getSelectedIndex();
	    // Test to see if a job is selected, if not make error
	    if ((String)jobList.getSelectedValue() == null) {
		msgErrorWarning = new MsgErrorWarning("You can't view, when no job is selected.");
		msgErrorWarning.msgError();
		return;
	    }
	    // Change the screen
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new JobInformationHeadhunterGUI(selectedJob, selectedProject, "view", hh));
	    setContentPane(cp);
	}
    }
    
    private void mouseJobsReopenButton() {
	// Check if the button isenabled
	if (jobsReopenButton.isEnabled() == false) {return;}
	// Get the slected job to reopen
	String selectedJob = (String)jobList.getSelectedValue();
	// Test to see if a job is selected, if not make error
	if (selectedJob == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't reopen, when no job is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	try { // Reopen the job 
	    (selectedProject.selectJob(jobList.getSelectedIndex())).reopen();	    
	    // Update the project string
	    int i = projectList.getSelectedIndex();
	    String projectString = new String(((ProjectI)hh.getProject(i)).getTitle() + 
					      " (" + ((ProjectI)hh.getProject(i)).getStatus() + 
					      ")");
	    projectListModel.remove(i);
	    projectListModel.insertElementAt(projectString, i);
	    projectList.setSelectedIndex(i);
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (ReopenException e) {
	    msgErrorWarning = new MsgErrorWarning("You can't re-open this job.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	// Change the status in the GUI
	try {
	    int i = jobList.getSelectedIndex();
	    String jobString = new String(((JobI)selectedProject.selectJob(i)).getTitle() + 
					  " (" + ((JobI)selectedProject.selectJob(i)).getStatus() + ")");
	    jobListModel.remove(i);
	    jobListModel.insertElementAt(jobString, i);
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
    }
    
    private void mouseJobsAnnounceButton() {
	// Check if the button is enabled
	if (jobsAnnounceButton.isEnabled() == false) {return;}
	// check that a project is selected
	if (projectList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't announce, when no project is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// May a check to se if description has been  saved
	if (descriptionTitleText.isEditable()) {
	    // Send a warning msg to the use aboudt the delete job
	    msgErrorWarning = new MsgErrorWarning("Warning do you want to save the description first.");
	    int selected = msgErrorWarning.msgWarning();
	    // Check the answer from the user, if it's 0 save the description
	    if (selected == 0) {
		try {
		    selectedProject.setTitle(descriptionTitleText.getText());
		    selectedProject.setDescription(descriptionTextArea.getText());
		    selectedProject.save();
		} catch (RemoteException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		    msgErrorWarning.msgError();
		    return;
		} catch (DAOException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		    msgErrorWarning.msgError();
		    return;
		} catch (Exception e) {
		    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		    msgErrorWarning.msgError();
		    return;   
		}
		// Change the screen
		cp.removeAll();
		cp.add(BorderLayout.CENTER, new AnnounceHeadhunterGUI(selectedProject, hh));
		setContentPane(cp);
	    } else {
		// Do nothing
		return;
	    }
	} else {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new AnnounceHeadhunterGUI(selectedProject, hh));
	    setContentPane(cp);
	}   
    }    

    // The next function is to able and disable the job options in the GUI
    private void jobPanelOnOff(int onOff) {
	if (onOff == 1) {
	    jobsAddButton.setEnabled(true);
	    jobsDelButton.setEnabled(true);
	    jobsCloseButton.setEnabled(true);
	    jobsReopenButton.setEnabled(true);
	    jobsViewButton.setEnabled(true);
	    jobsAnnounceButton.setEnabled(true);
	    jobList.setEnabled(true);
	    jobList.setBackground(new Color(255,255,255));
	} else {
	    jobsAddButton.setEnabled(false);
	    jobsDelButton.setEnabled(false);
	    jobsCloseButton.setEnabled(false);
	    jobsReopenButton.setEnabled(false);
	    jobsViewButton.setEnabled(false);
	    jobsAnnounceButton.setEnabled(false);
	    jobList.setEnabled(false);
	    jobList.setBackground(new Color(233,233,242));
	}
    }
    private void projectPanelOnOff(int onOff) {
	if (onOff == 1) {
	    projectNewButton.setEnabled(true);
	    projectDelButton.setEnabled(true);
	    projectViewButton.setEnabled(true);
	    projectList.setEnabled(true);
	} else {
	    projectNewButton.setEnabled(false);
	    projectDelButton.setEnabled(false);
	    projectViewButton.setEnabled(false);
	    projectList.setEnabled(false);
	}
    }

    private void getProjectInformation() {
	// Get all the project 
	try {
	    hh.initializeProjectList();
	    if (hh.getProjectListLength() == 0) {
		jobPanelOnOff(0);		
	    } else {
		int size = hh.getProjectListLength();
		for (int i = 0; i < size; i++) {
		    String argStr = new String(((ProjectI)hh.getProject(i)).getTitle() + 
					       " (" + ((ProjectI)hh.getProject(i)).getStatus()  +")");
		    projectListModel.insertElementAt(argStr, i);
		}
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;
	}
	// Turns job panel off
	jobPanelOnOff(0);
    }
}
