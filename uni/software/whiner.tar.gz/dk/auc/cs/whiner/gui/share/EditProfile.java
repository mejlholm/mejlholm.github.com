package dk.auc.cs.whiner.gui.share;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.security.*;
import java.util.*;

import java.rmi.*;

import dk.auc.cs.whiner.function.LoginNameException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;

import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.applicant.*;
import dk.auc.cs.whiner.gui.*;

/**
 *
 * @author <a href="mailto:cableman@cs.auc.dk"></a>
 * @version $Revision: 1.42 $
 *
 */
public class EditProfile extends JApplet {  
    private MsgErrorWarning msgErrorWarning;
    private Container cp;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JPanel westPanel;
    private JPanel mainTopPanel;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JPanel eastPanel;
    private JButton logoutButton;
    private JScrollPane mainScrollPanel;
    private JButton backButton;
    private String setup;
    private JTextField postcodeText;
    private JLabel otherITKnowledgeLabel;
    private JLabel passwordLabel;
    private JComboBox dateDayComboBox;
    private JTextArea otherITKnowledgeTextArea;
    private JLabel lastnameLabel;
    private JScrollPane workingExperienceScrollPane;
    private JTextField cityText;
    private JLabel workPhoneLabel;
    private JTextArea reEducationTextArea;
    private JLabel homePhoneLabel;
    private JLabel address2Label;
    private JLabel countryLabel;
    private JLabel emailLabel;
    private JLabel regionLabel;
    private JLabel languageSkillsLabel;
    private JRadioButton sexMaleRadioButton;
    private JTextField workPhoneText;
    private JScrollPane educationScrollPane1;
    private JComboBox dateMounthComboBox;
    private JTextField homePhoneText;
    private JScrollPane spareTimeInterestsScrollPane;
    private JTextField middleNameText;
    private JTextField mobilePhoneText;
    private JLabel maritialLabel;
    private JLabel spareTimeInterestsLabel;
    private JTextArea languageSkillsTextArea;
    private JLabel reEducationLabel;
    private JTextArea educationTextArea1;
    private JComboBox dateYearComboBox;
    private JTextArea spareTimeInterestsTextArea;
    private JLabel addressInformationLabel;
    private JScrollPane languageSkillsScrollPane;
    private JLabel passwordInformationLabel;
    private JTextField firstNameText;
    private JLabel otherInformationLabel;
    private JPasswordField passwordField;
    private JTextField emailText;
    private JComboBox maritialComboBox;
    private JLabel workingExperienceLabel;
    private JLabel dateOfBirthLabel;
    private JLabel address1Label;
    private JTextField address2Text;
    private JLabel personelLabel;
    private JLabel cityLabel;
    private JRadioButton sexFemaleRadioButton;
    private JScrollPane otherITKnowledgeScrollPane;
    private JTextArea workingExperienceTextArea;
    private JLabel postcodeLabel;
    private JLabel faxNumberLabel;
    private JLabel middleNameLabel;
    private JTextField faxNumberText;
    private JLabel contactInformationLabel;
    private JScrollPane reEducationScrollPane;
    private JLabel firstnameLabel;
    private JLabel educationLabel;
    private JTextField regionText;
    private JPasswordField rePasswordField;
    private JLabel mobilePhoneLabel;
    private JTextField lastNameText;
    private JTextField address1Text;
    private JLabel topLabel;
    private JLabel rePasswordLabel;
    private JLabel buttomLabel;
    private JButton cancelButton;
    private JButton saveButton;
    private String passwordSHA;
    private JLabel loginNameLabel;
    private JTextField loginNameText;
    private JComboBox countryComboBox;
    private ApplicantI applicant;
    private ButtonGroup sexButtonGroup;
    private int selectedSex;
    private String connectionString;
    private RegisterI whinerRegistryServer;

    public EditProfile(String setup) {
	this.setup = setup;
        initComponents();
    }

    public EditProfile(String setup, ApplicantI applicant) {
	this.setup = setup;
	this.applicant = applicant;
        initComponents();
    }

    private void initComponents() {
	address1Label = new JLabel();
        address1Text = new JTextField();
        address2Label = new JLabel();
        address2Text = new JTextField();
        addressInformationLabel = new JLabel();
	backButton = new JButton();
        buttomLabel = new JLabel();
        buttomPanel = new JPanel();
	cancelButton = new JButton();
        cityLabel = new JLabel();
        cityText = new JTextField();
	connectionString = new String("//130.225.194.15:2002/WhinerRegistryServer");
        contactInformationLabel = new JLabel();
	countryComboBox = new JComboBox();
        countryLabel = new JLabel();
	cp = getContentPane();
        dateDayComboBox = new JComboBox();
        dateMounthComboBox = new JComboBox();
        dateOfBirthLabel = new JLabel();
        dateYearComboBox = new JComboBox();
        eastPanel = new JPanel();
        educationLabel = new JLabel();
        educationScrollPane1 = new JScrollPane();
        educationTextArea1 = new JTextArea();
        emailLabel = new JLabel();
        emailText = new JTextField();
        faxNumberLabel = new JLabel();
        faxNumberText = new JTextField();
        firstNameText = new JTextField();
        firstnameLabel = new JLabel();
        homePhoneLabel = new JLabel();
        homePhoneText = new JTextField();
        languageSkillsLabel = new JLabel();
        languageSkillsScrollPane = new JScrollPane();
        languageSkillsTextArea = new JTextArea();
        lastNameText = new JTextField();
        lastnameLabel = new JLabel();
        loginNameLabel = new JLabel();
        loginNameText = new JTextField();
	logoutButton = new JButton();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
	mainScrollPanel = new JScrollPane();
        mainTopPanel = new JPanel();
        maritialComboBox = new JComboBox();
        maritialLabel = new JLabel();
        middleNameLabel = new JLabel();
        middleNameText = new JTextField();
        mobilePhoneLabel = new JLabel();
        mobilePhoneText = new JTextField();
        otherITKnowledgeLabel = new JLabel();
        otherITKnowledgeScrollPane = new JScrollPane();
        otherITKnowledgeTextArea = new JTextArea();
        otherInformationLabel = new JLabel();
        passwordField = new JPasswordField();
        passwordInformationLabel = new JLabel();
        passwordLabel = new JLabel();
	passwordSHA = new String();
        personelLabel = new JLabel();
        postcodeLabel = new JLabel();
        postcodeText = new JTextField();
        reEducationLabel = new JLabel();
        reEducationScrollPane = new JScrollPane();
        reEducationTextArea = new JTextArea();
        rePasswordField = new JPasswordField();
        rePasswordLabel = new JLabel();
        regionLabel = new JLabel();
        regionText = new JTextField();
	saveButton = new JButton();
	selectedSex = -1;
	sexButtonGroup = new ButtonGroup();
        sexFemaleRadioButton = new JRadioButton();
        sexMaleRadioButton = new JRadioButton();
        spareTimeInterestsLabel = new JLabel();
        spareTimeInterestsScrollPane = new JScrollPane();
        spareTimeInterestsTextArea = new JTextArea();
        topLabel = new JLabel();
        topPanel = new JPanel();
        westPanel = new JPanel();
        workPhoneLabel = new JLabel();
        workPhoneText = new JTextField();
        workingExperienceLabel = new JLabel();
        workingExperienceScrollPane = new JScrollPane();
        workingExperienceTextArea = new JTextArea();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());
	mainPanel.setBackground(new Color(233,233,242));

        mainTopPanel.setLayout(new AbsoluteLayout());

	mainTopPanel.setBackground(new Color(233,233,242));
        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

	firstnameLabel.setText("Firstname:");
        mainTopPanel.add(firstnameLabel, new AbsoluteConstraints(20, 40, -1, -1));

        personelLabel.setFont(new Font("Dialog", 3, 12));
        personelLabel.setText("Personal information");
        mainTopPanel.add(personelLabel, new AbsoluteConstraints(20, 20, -1, -1));

        mainTopPanel.add(firstNameText, new AbsoluteConstraints(100, 40, 150, -1));

        lastnameLabel.setText("Lastname:");
        mainTopPanel.add(lastnameLabel, new AbsoluteConstraints(20, 80, -1, -1));

        mainTopPanel.add(lastNameText, new AbsoluteConstraints(100, 80, 150, -1));

        middleNameLabel.setText("Middlename:");
        mainTopPanel.add(middleNameLabel, new AbsoluteConstraints(20, 60, -1, -1));

        mainTopPanel.add(middleNameText, new AbsoluteConstraints(100, 60, 150, -1));

        dateOfBirthLabel.setText("Date of birth:");
        mainTopPanel.add(dateOfBirthLabel, new AbsoluteConstraints(270, 40, -1, -1));

        sexMaleRadioButton.setText("Male");
        sexMaleRadioButton.setSelected(true);
	sexButtonGroup.add(sexMaleRadioButton);
        sexMaleRadioButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
		selectedSex = 1;
            }
        });
	sexMaleRadioButton.setBackground(new Color(233,233,242));
        mainTopPanel.add(sexMaleRadioButton, new AbsoluteConstraints(300, 85, -1, -1));

        sexFemaleRadioButton.setText("Female");
	sexButtonGroup.add(sexFemaleRadioButton);
	sexFemaleRadioButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
		selectedSex = 2;
            }
        });
	sexFemaleRadioButton.setBackground(new Color(233,233,242));
        mainTopPanel.add(sexFemaleRadioButton, new AbsoluteConstraints(370, 85, -1, -1));

        maritialLabel.setText("Maritial Status:");
        mainTopPanel.add(maritialLabel, new AbsoluteConstraints(270, 60, -1, -1));

        maritialComboBox.setModel(new DefaultComboBoxModel(new String[] {"single", "engaged", "married", "seperated", "widowed"}));
	maritialComboBox.setBackground(new Color(233,233,242));
        mainTopPanel.add(maritialComboBox, new AbsoluteConstraints(370, 60, -1, -1));

        contactInformationLabel.setFont(new Font("Dialog", 3, 12));
        contactInformationLabel.setText("Contact information");
        mainTopPanel.add(contactInformationLabel, new AbsoluteConstraints(20, 290, -1, -1));

        address1Label.setText("Address 1:");
        mainTopPanel.add(address1Label, new AbsoluteConstraints(20, 200, -1, -1));

        mainTopPanel.add(address1Text, new AbsoluteConstraints(90, 200, 315, -1));

        address2Label.setText("Address 2:");
        mainTopPanel.add(address2Label, new AbsoluteConstraints(20, 220, -1, -1));

        mainTopPanel.add(address2Text, new AbsoluteConstraints(90, 220, 315, -1));

        postcodeLabel.setText("Post code:");
        mainTopPanel.add(postcodeLabel, new AbsoluteConstraints(20, 240, -1, -1));

        mainTopPanel.add(postcodeText, new AbsoluteConstraints(90, 240, 60, -1));

        cityLabel.setText("City:");
        mainTopPanel.add(cityLabel, new AbsoluteConstraints(160, 240, -1, -1));

        mainTopPanel.add(cityText, new AbsoluteConstraints(190, 240, 215, -1));

        regionLabel.setText("Region:");
        mainTopPanel.add(regionLabel, new AbsoluteConstraints(20, 260, -1, -1));

        mainTopPanel.add(regionText, new AbsoluteConstraints(90, 260, 60, -1));

        countryLabel.setText("Country:");
        mainTopPanel.add(countryLabel, new AbsoluteConstraints(160, 260, -1, -1));

        countryComboBox.setModel(new DefaultComboBoxModel(Countries.countries)); // Get the countries list form Countries.class
	countryComboBox.setBackground(new Color(233,233,242));
        mainTopPanel.add(countryComboBox, new AbsoluteConstraints(220, 260, -1, -1));

        addressInformationLabel.setFont(new Font("Dialog", 3, 12));
        addressInformationLabel.setText("Address information");
        mainTopPanel.add(addressInformationLabel, new AbsoluteConstraints(20, 180, -1, -1));

        homePhoneLabel.setText("Home Phone:");
        mainTopPanel.add(homePhoneLabel, new AbsoluteConstraints(20, 310, -1, -1));

        mainTopPanel.add(homePhoneText, new AbsoluteConstraints(110, 310, 150, -1));

        workPhoneLabel.setText("Work Phone:");
        mainTopPanel.add(workPhoneLabel, new AbsoluteConstraints(270, 310, -1, -1));

        mainTopPanel.add(workPhoneText, new AbsoluteConstraints(350, 310, 150, -1));

        mobilePhoneLabel.setText("Mobile Phone:");
        mainTopPanel.add(mobilePhoneLabel, new AbsoluteConstraints(20, 330, -1, -1));

        mainTopPanel.add(mobilePhoneText, new AbsoluteConstraints(110, 330, 150, -1));

        faxNumberLabel.setText("Fax number:");
        mainTopPanel.add(faxNumberLabel, new AbsoluteConstraints(270, 330, -1, -1));

        mainTopPanel.add(faxNumberText, new AbsoluteConstraints(350, 330, 150, -1));

        emailLabel.setText("E-mail:");
        mainTopPanel.add(emailLabel, new AbsoluteConstraints(20, 350, -1, -1));

        mainTopPanel.add(emailText, new AbsoluteConstraints(70, 350, 190, -1));

        otherInformationLabel.setFont(new Font("Dialog", 3, 12));
        otherInformationLabel.setText("Other information");
        mainTopPanel.add(otherInformationLabel, new AbsoluteConstraints(20, 380, -1, -1));

        educationLabel.setText("Education:");
        mainTopPanel.add(educationLabel, new AbsoluteConstraints(20, 400, -1, -1));

        workingExperienceLabel.setText("Working experience:");
        mainTopPanel.add(workingExperienceLabel, new AbsoluteConstraints(20, 470, -1, -1));

        reEducationLabel.setText("Re-education:");
        mainTopPanel.add(reEducationLabel, new AbsoluteConstraints(20, 610, -1, -1));

        languageSkillsLabel.setText("Language Skills:");
        mainTopPanel.add(languageSkillsLabel, new AbsoluteConstraints(20, 540, -1, -1));

        otherITKnowledgeLabel.setText("Other IT knowledge:");
        mainTopPanel.add(otherITKnowledgeLabel, new AbsoluteConstraints(20, 680, -1, -1));

        spareTimeInterestsLabel.setText("Spare time interests:");
        mainTopPanel.add(spareTimeInterestsLabel, new AbsoluteConstraints(20, 760, -1, -1));

        educationScrollPane1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        educationTextArea1.setLineWrap(true);
        educationScrollPane1.setViewportView(educationTextArea1);

        mainTopPanel.add(educationScrollPane1, new AbsoluteConstraints(20, 420, 500, 50));

        workingExperienceScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        workingExperienceScrollPane.setViewportView(workingExperienceTextArea);

        mainTopPanel.add(workingExperienceScrollPane, new AbsoluteConstraints(20, 490, 500, 50));

        languageSkillsScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        languageSkillsScrollPane.setViewportView(languageSkillsTextArea);

        mainTopPanel.add(languageSkillsScrollPane, new AbsoluteConstraints(20, 560, 500, 50));

        reEducationScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        reEducationScrollPane.setViewportView(reEducationTextArea);

        mainTopPanel.add(reEducationScrollPane, new AbsoluteConstraints(20, 630, 500, 50));

        otherITKnowledgeScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        otherITKnowledgeScrollPane.setViewportView(otherITKnowledgeTextArea);

        mainTopPanel.add(otherITKnowledgeScrollPane, new AbsoluteConstraints(20, 700, 500, 60));

        spareTimeInterestsScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        spareTimeInterestsScrollPane.setViewportView(spareTimeInterestsTextArea);

        mainTopPanel.add(spareTimeInterestsScrollPane, new AbsoluteConstraints(20, 780, 500, 60));

        passwordInformationLabel.setFont(new Font("Dialog", 3, 12));
        passwordInformationLabel.setText("User Information");
        mainTopPanel.add(passwordInformationLabel, new AbsoluteConstraints(20, 110, -1, -1));

        loginNameLabel.setText("Login name:");
        mainTopPanel.add(loginNameLabel, new AbsoluteConstraints(20, 130, -1, -1));
	
	if (setup.equals("edit")) {
	    loginNameText.setEnabled(false);
	    loginNameText.setEditable(false);
	}
	mainTopPanel.add(loginNameText, new AbsoluteConstraints(100, 130, 130, -1));

        passwordLabel.setText("Password:");
        mainTopPanel.add(passwordLabel, new AbsoluteConstraints(260, 130, -1, -1));

        rePasswordLabel.setText("Re-type password:");
        mainTopPanel.add(rePasswordLabel, new AbsoluteConstraints(260, 150, -1, -1));

        mainTopPanel.add(passwordField, new AbsoluteConstraints(380, 150, 150, -1));

        mainTopPanel.add(rePasswordField, new AbsoluteConstraints(380, 130, 150, -1));

	Integer[] dateMounth = new Integer[12];
	for (int i = 1; i < 13; i++) {
	    dateMounth[i-1] = new Integer(i);
	}
        dateMounthComboBox.setModel(new DefaultComboBoxModel(dateMounth));
	dateMounthComboBox.setBackground(new Color(233,233,242));
        mainTopPanel.add(dateMounthComboBox, new AbsoluteConstraints(415, 35, -1, -1));

	Integer[] dateDays = new Integer[31];
	for (int i = 1; i < 32; i++) {
	    dateDays[i-1] = new Integer(i);
	}
        dateDayComboBox.setModel(new DefaultComboBoxModel(dateDays));
	dateDayComboBox.setBackground(new Color(233,233,242));
        mainTopPanel.add(dateDayComboBox, new AbsoluteConstraints(370, 35, -1, -1));

	Integer[] dateYear = new Integer[60];
	int year = 1960; // Start year
	for (int i = 1; i < 61; i++) {
	    year++;
	    dateYear[i-1] = new Integer(year);
	}
        dateYearComboBox.setModel(new DefaultComboBoxModel(dateYear));
	dateYearComboBox.setBackground(new Color(233,233,242));
        mainTopPanel.add(dateYearComboBox, new AbsoluteConstraints(460, 35, -1, -1));

        mainTopPanel.add(buttomLabel, new AbsoluteConstraints(15, 840, -1, 20));

	mainScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        mainScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        mainScrollPanel.setViewportView(mainTopPanel);

	mainPanel.add(mainScrollPanel, new AbsoluteConstraints(2, 12, 566, 450));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

	if (setup.equals("edit")) {
	    topPanel.setLayout(new BorderLayout());
	    logoutButton.setText("Logout");
	    logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
	    topPanel.add(logoutButton, BorderLayout.EAST);
	} else {
	    topPanel.setLayout(new AbsoluteLayout());
	    topPanel.add(topLabel, new AbsoluteConstraints(-1, 2, 450, 20));
	}

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());

	cancelButton.setText("Cancel");
        cancelButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseCancelButton();
		}
	    });
	if (setup.equals("edit")) {
	    buttomPanel.add(cancelButton,  new AbsoluteConstraints(130, 0, -1, -1));
	}

	saveButton.setText("Save");
        saveButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseSaveButton();
		}
	    });
        buttomPanel.add(saveButton,  new AbsoluteConstraints(65, 0, -1, -1));

	backButton.setText("Back");
        backButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseBackButton();
		}
	    });
        buttomPanel.add(backButton,  new AbsoluteConstraints(0, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	cp.add(mainJPanel, BorderLayout.CENTER);

	if (setup.equals("edit")) {
	    // get infomation and fill it in the form
	    getInformation();
	} else {
	    // new application
	    saveButton.setText("Create");
	}
    }

    private void getInformation() {
 	try { // get infomation on the applicant object
	    firstNameText.setText(((NameI)applicant.getName()).getFirstName());
	    middleNameText.setText(((NameI)applicant.getName()).getMiddleName());
	    lastNameText.setText(((NameI)applicant.getName()).getLastName());
	    loginNameText.setText(applicant.getLoginName());
	    // Load the cv
	    CVI cv = (CVI)applicant.getCV();
	    Date birth = cv.getDateOfBirth();
	    WDate wdate = new WDate(birth);
	    dateDayComboBox.setSelectedItem(new Integer(wdate.getDay()));
	    dateMounthComboBox.setSelectedItem(new Integer(wdate.getMonth()));
	    dateYearComboBox.setSelectedItem(new Integer(wdate.getYear()));
	    if ((cv.getMaritalStatus()).equals("single")) {
		maritialComboBox.setSelectedIndex(0);
	    } else if ((cv.getMaritalStatus()).equals("engaged")) {
		maritialComboBox.setSelectedIndex(1);
	    } else if ((cv.getMaritalStatus()).equals("married")) {
		maritialComboBox.setSelectedIndex(2);
	    } else if ((cv.getMaritalStatus()).equals("seperated")) {
		maritialComboBox.setSelectedIndex(3);
	    } else {
		maritialComboBox.setSelectedIndex(4);
	    }

	    if ((cv.getSex()).equals("female")) {
		sexFemaleRadioButton.setSelected(true);
	    } else {
		sexMaleRadioButton.setSelected(true);
	    }  	    
	    // Get address
	    address1Text.setText((applicant.getAddress()).getAddress1());
	    address2Text.setText((applicant.getAddress()).getAddress2());
	    cityText.setText((applicant.getAddress()).getCity());
	    postcodeText.setText("" + (applicant.getAddress()).getPostCode());
	    regionText.setText((applicant.getAddress()).getRegion());
	    countryComboBox.setSelectedItem((String)(applicant.getAddress()).getCountry());
	    // Get phone
	    homePhoneText.setText("" + (applicant.getPhoneNumber()).getHomePhone());
	    workPhoneText.setText("" + (applicant.getPhoneNumber()).getWorkPhone());
	    mobilePhoneText.setText("" + (applicant.getPhoneNumber()).getMobile());
	    faxNumberText.setText("" + (applicant.getPhoneNumber()).getFax());
	    emailText.setText(applicant.getEmail());
	    // Getting all other information from the cv
	    educationTextArea1.setText(cv.getEducation());
	    workingExperienceTextArea.setText(cv.getWorkingExperience());
	    reEducationTextArea.setText(cv.getReEducation());
	    languageSkillsTextArea.setText(cv.getLanguageSkills());
	    otherITKnowledgeTextArea.setText(cv.getOtherITKnowledge());
	    spareTimeInterestsTextArea.setText(cv.getSpareTimeInterests());
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknow error: " + e.getMessage());
	    msgErrorWarning.msgError();
	    return;
	}
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void mouseBackButton() {
	cp.removeAll();
	if (setup.equals("edit")) {
	    cp.add(BorderLayout.CENTER, new MainApplicantGUI(applicant));
	} else {
	    cp.add(BorderLayout.CENTER, new Login());
	}
	setContentPane(cp);
    }

    private void mouseSaveButton()  {
	boolean result = false;
	// Check and crypt the password
	result = checkPassword();
	// Check that the fields has been filled out
	if (result == true) {
	    result = checkFields();
	}
	// Return if error with fields
	if (result == false) {
	    return;
	}

	if (setup.equals("edit")) {
	    try { // get infomation on the applicant object
		((NameI)applicant.getName()).setFirstName(firstNameText.getText());
		((NameI)applicant.getName()).setMiddleName(middleNameText.getText());
		((NameI)applicant.getName()).setLastName(lastNameText.getText());
		// Load the cv
		CVI cv = (CVI)applicant.getCV();
		WDate wdate = new WDate();
		Integer day = (Integer)dateDayComboBox.getSelectedItem();
		Integer month = (Integer)dateMounthComboBox.getSelectedItem();
		Integer year = (Integer)dateYearComboBox.getSelectedItem();
		try {
		    cv.setDateOfBirth(wdate.setDate(day.intValue(), month.intValue(), year.intValue()));
		} catch(Exception e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error, with converting the data.");
		    msgErrorWarning.msgError();
		    return;
		}
		cv.setMaritalStatus((String)maritialComboBox.getSelectedItem());
		if (selectedSex == 1) {
		    cv.setSex("male");
		} else {
		    cv.setSex("female");
		}  	    
		// Get address
		(applicant.getAddress()).setAddress1(address1Text.getText());
		(applicant.getAddress()).setAddress2(address2Text.getText());
		(applicant.getAddress()).setCity(cityText.getText());
		(applicant.getAddress()).setPostCode(new Integer(postcodeText.getText()).intValue());
		(applicant.getAddress()).setRegion(regionText.getText());
		(applicant.getAddress()).setCountry((String)countryComboBox.getSelectedItem());
		// Get phone
		if ((homePhoneText.getText()).equals("")) {
		    (applicant.getPhoneNumber()).setHomePhone(0);
		} else {
		    (applicant.getPhoneNumber()).setHomePhone(new Integer(homePhoneText.getText()).intValue());
		}

		if ((workPhoneText.getText()).equals("")) {
		    (applicant.getPhoneNumber()).setWorkPhone(0);
		} else {
		    (applicant.getPhoneNumber()).setWorkPhone(new Integer(workPhoneText.getText()).intValue());
		}

		if ((mobilePhoneText.getText()).equals("")) {
		    (applicant.getPhoneNumber()).setMobile(0);
		} else {
		    (applicant.getPhoneNumber()).setMobile(new Integer(mobilePhoneText.getText()).intValue());
		}

		if ((faxNumberText.getText()).equals("")) {
		    (applicant.getPhoneNumber()).setFax(0);
		} else {
		    (applicant.getPhoneNumber()).setFax(new Integer(faxNumberText.getText()).intValue());
		}
		applicant.setEmail(emailText.getText());
		// Getting all other information from the cv
		cv.setEducation(educationTextArea1.getText());
		cv.setWorkingExperience(workingExperienceTextArea.getText());
		cv.setReEducation(reEducationTextArea.getText());
		cv.setLanguageSkills(languageSkillsTextArea.getText());
		cv.setOtherITKnowledge(otherITKnowledgeTextArea.getText());
		cv.setSpareTimeInterests(spareTimeInterestsTextArea.getText());
		// Save alle the data
		cv.save();
		applicant.save();
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (NumberFormatException e) {
		msgErrorWarning = new MsgErrorWarning("Some of the numbers was not numbers.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknow error: " + e.getMessage());
		msgErrorWarning.msgError();
		return;
	    }
	} else {
	    // Starting the RMI security manager
	    if (System.getSecurityManager() == null){
		System.setSecurityManager(new RMISecurityManager());
	    }

	    // Make the RMI connection 	    
	    try {
		whinerRegistryServer = (RegisterI) Naming.lookup(connectionString);
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    }
	    // Trying to make the new applicant
	    try {
		applicant = (ApplicantI)whinerRegistryServer.activateApplicant(loginNameText.getText(), passwordSHA);
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (LoginNameException e) {
		msgErrorWarning = new MsgErrorWarning("The login name was in use by the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknow error: " + e.getMessage());
		msgErrorWarning.msgError();
		return;
	    }
	    CVI cv = null;
		try{
		    cv = (CVI)applicant.getCV();
		}catch(RemoteException e){
		    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		    msgErrorWarning.msgError();
		    System.out.println("Failed with CV");
		    e.printStackTrace();
		    return;
		} catch (Exception e) {
		    msgErrorWarning = new MsgErrorWarning("Unknow error: " + e.getMessage());
		    msgErrorWarning.msgError();
		    return;
		}
 	    // Get day
	    WDate wdate = new WDate();
	    Integer day = (Integer)dateDayComboBox.getSelectedItem();
	    Integer month = (Integer)dateMounthComboBox.getSelectedItem();
	    Integer year = (Integer)dateYearComboBox.getSelectedItem();
	    try {
		cv.setDateOfBirth(wdate.setDate(day.intValue(), month.intValue(), year.intValue()));
	    } catch(Exception e) {
		msgErrorWarning = new MsgErrorWarning("There was an error, with converting the data.");
		msgErrorWarning.msgError();
		return;
	    }
	    try { // get infomation on the applicant object
		((NameI)applicant.getName()).setFirstName(firstNameText.getText());
		((NameI)applicant.getName()).setMiddleName(middleNameText.getText());
		((NameI)applicant.getName()).setLastName(lastNameText.getText());
		// Load the cv
		cv = applicant.selectCV();
		cv.setMaritalStatus((String)maritialComboBox.getSelectedItem());
		if (selectedSex == 1) {
		    cv.setSex("male");
		} else {
		    cv.setSex("female");
		}  	    
		// Get address
		(applicant.getAddress()).setAddress1(address1Text.getText());
		(applicant.getAddress()).setAddress2(address2Text.getText());
		(applicant.getAddress()).setCity(cityText.getText());
		(applicant.getAddress()).setPostCode(new Integer(postcodeText.getText()).intValue());
		(applicant.getAddress()).setRegion(regionText.getText());
		(applicant.getAddress()).setCountry((String)countryComboBox.getSelectedItem());
		// Get phone
		if ((homePhoneText.getText()).equals("")) {
		    (applicant.getPhoneNumber()).setHomePhone(0);
		} else {
		    (applicant.getPhoneNumber()).setHomePhone(new Integer(homePhoneText.getText()).intValue());
		}

		if ((workPhoneText.getText()).equals("")) {
		    (applicant.getPhoneNumber()).setWorkPhone(0);
		} else {
		    (applicant.getPhoneNumber()).setWorkPhone(new Integer(workPhoneText.getText()).intValue());
		}

		if ((mobilePhoneText.getText()).equals("")) {
		    (applicant.getPhoneNumber()).setMobile(0);
		} else {
		    (applicant.getPhoneNumber()).setMobile(new Integer(mobilePhoneText.getText()).intValue());
		}

		if ((faxNumberText.getText()).equals("")) {
		    (applicant.getPhoneNumber()).setFax(0);
		} else {
		    (applicant.getPhoneNumber()).setFax(new Integer(faxNumberText.getText()).intValue());
		}
		applicant.setEmail(emailText.getText());
		// Getting all other information from the cv
		cv.setEducation(educationTextArea1.getText());
		cv.setWorkingExperience(workingExperienceTextArea.getText());
		cv.setReEducation(reEducationTextArea.getText());
		cv.setLanguageSkills(languageSkillsTextArea.getText());
		cv.setOtherITKnowledge(otherITKnowledgeTextArea.getText());
		cv.setSpareTimeInterests(spareTimeInterestsTextArea.getText());
		// Save alle the data
		cv.save();
		applicant.save();
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (NumberFormatException e) {
		msgErrorWarning = new MsgErrorWarning("Some of the numbers was not numbers.");
		msgErrorWarning.msgError();
		// Removes the half applicant
		try {
		    applicant.deleteApplicant();
		} catch (Exception expe) {
		    msgErrorWarning = new MsgErrorWarning("Unknow error: " + expe.getMessage());
		    msgErrorWarning.msgError();
		    return;
		}
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknow error: " + e.getMessage());
		msgErrorWarning.msgError();
		// Removes the half applicant
		try {
		    applicant.deleteApplicant();
		} catch (Exception expe) {
		    msgErrorWarning = new MsgErrorWarning("Unknow error: " + expe.getMessage());
		    msgErrorWarning.msgError();
		    return;
		}
		return;
	    }
	    msgErrorWarning = new MsgErrorWarning("Remember to edit your qulifications, " +
						  "in the buttom of the screen, when your logged in.");
	    msgErrorWarning.msgError();
	}
	// return to the page the user came from
	if (result) {
	    mouseBackButton();
	}
    }
    
    private void mouseCancelButton() {
	getInformation();
    }
    
    private boolean checkFields() {
	boolean result = true;

	if ((firstNameText.getText()).equals("")) {
		firstNameText.setBackground(new Color(255,255,104));
	    	msgErrorWarning = new MsgErrorWarning("You have to give a firstname, re-type your firstname");
		msgErrorWarning.msgError();
		result = false;
	} else if (((lastNameText.getText()).equals("")) && (result == true)) {
		lastNameText.setBackground(new Color(255,255,104));
	    	msgErrorWarning = new MsgErrorWarning("You have to give a lastname, re-type your lastname");
		msgErrorWarning.msgError();
		result = false;
	} else if (((loginNameText.getText()).equals("")) && (result == true)) {
		loginNameText.setBackground(new Color(255,255,104));
	    	msgErrorWarning = new MsgErrorWarning("You have to give a login name, re-type your login name");
		msgErrorWarning.msgError();
		result = false;
	} else if (((address1Text.getText()).equals("")) && (result == true)) {
		address1Text.setBackground(new Color(255,255,104));
	    	msgErrorWarning = new MsgErrorWarning("You have to give an address , re-type your address");
		msgErrorWarning.msgError();
		result = false;
	} else if (((postcodeText.getText()).equals("")) && (result == true)) {
		postcodeText.setBackground(new Color(255,255,104));
	    	msgErrorWarning = new MsgErrorWarning("You have to give a postal code , re-type your postal code");
		msgErrorWarning.msgError();
		result = false;
	} else if (((cityText.getText()).equals("")) && (result == true)) {
		cityText.setBackground(new Color(255,255,104));
	    	msgErrorWarning = new MsgErrorWarning("You have to give a city name , re-type your city name");
		msgErrorWarning.msgError();
		result = false;
	} else if (((countryComboBox.getSelectedItem()).equals("Select a country")) && (result = true)) {
		countryComboBox.setBackground(new Color(255,255,104));
	    	msgErrorWarning = new MsgErrorWarning("You have to give a country , re-type your country");
		msgErrorWarning.msgError();
		result = false;
	} else if (((homePhoneText.getText()).equals("")) && (result == true)) {
	    if ((workPhoneText.getText()).equals("")) {
		if ((mobilePhoneText.getText()).equals("")) {
		    if ((faxNumberText.getText()).equals("")) {
			homePhoneText.setBackground(new Color(255,255,104));
			workPhoneText.setBackground(new Color(255,255,104));
			mobilePhoneText.setBackground(new Color(255,255,104));
			faxNumberText.setBackground(new Color(255,255,104));
			msgErrorWarning = new MsgErrorWarning("You have to give a phone number , re-type your phone number");
			msgErrorWarning.msgError();
			result = false;
		    }
		}
	    }
	} else if (((emailText).equals("")) && (result = true)) {
		emailText.setBackground(new Color(255,255,104));
	    	msgErrorWarning = new MsgErrorWarning("You have to give an e-mail address, re-type your e-mail address");
		msgErrorWarning.msgError();
		result = false;
	}
	return result;
    }

    private boolean checkPassword() {
	boolean result = false;
	String pwd = new String(passwordField.getPassword());
	String repwd = new String(rePasswordField.getPassword());
	
	if (pwd.equals(repwd)) {
	    if (pwd.length() >= 8) {
		// the password is okay
		try {
		    CryptPassword pwdSHA = new CryptPassword(new String(passwordField.getPassword()));
		    passwordSHA = pwdSHA.cryptSHA();
		} catch (NoSuchAlgorithmException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the password funktion.\n The applet will exit.");
		    msgErrorWarning.msgError();
		    System.exit(-1);
		}
		result = true;
	    } else {
		passwordField.setText("");
		rePasswordField.setText("");
		passwordField.setBackground(new Color(255,255,104));
		rePasswordField.setBackground(new Color(255,255,104));
		msgErrorWarning = new MsgErrorWarning("The password's was less then 8 char, re-type password");
		msgErrorWarning.msgError();
	    }
	} else {
	    passwordField.setText("");
	    rePasswordField.setText("");
	    passwordField.setBackground(new Color(255,255,104));
	    rePasswordField.setBackground(new Color(255,255,104));
	    msgErrorWarning = new MsgErrorWarning("The password's was not the same, re-type password");
	    msgErrorWarning.msgError();
	}

	return result;
    }
}
