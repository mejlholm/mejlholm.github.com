package dk.auc.cs.whiner.gui.share;

import java.util.*;
import java.text.SimpleDateFormat;

/**
 * This class <code>WDate</code> is used to convert between the date
 * format used in the model and the date format used inside the
 * graphic user interface.
 *
 * @author <a href="mailto:cableman@cs.auc.dk"></a>
 * @version $Revision: 1.3 $
 */
public class WDate {
    private Date date;
    private SimpleDateFormat dateYear;
    private SimpleDateFormat dateMonth;
    private SimpleDateFormat dateDay;
    private SimpleDateFormat int2date;
    private String dateString;
    private Integer dDay;
    private Integer dMonth;
    private Integer dYear;

    public WDate(Date date) {
	this();
	this.date = date;
	dateYear = new SimpleDateFormat("yyyy");
	dateMonth = new SimpleDateFormat("MM");
	dateDay = new SimpleDateFormat("dd");
    }

    public WDate() {
	int2date = new SimpleDateFormat("dd MM yyyy");
    }

    /**
     * Retrive the current day form the date sendt to the constructor.
     *
     * @return an <code>int</code> value
     */
    public int getDay() {
	dateString = dateDay.format(date);
	dDay = new Integer(dateString);

	return dDay.intValue();
    }

    /**
     * Retrive the current month form the date sendt to the
     * constructor.
     *
     * @return an <code>int</code> value
     */
    public int getMonth() {
	dateString = dateMonth.format(date);
	dMonth = new Integer(dateString);

	return dMonth.intValue();
    }

    /**
     * Retrive the current year form the date sendt to the
     * constructor.
     *
     * @return an <code>int</code> value
     */
    public int getYear() {
	dateString = dateYear.format(date);
	dYear = new Integer(dateString);

	return dYear.intValue();
    }

    /**
     * This convert <code>day, month, year</code> to java.util.Date
     * format
     *
     * @param day an <code>int</code> value
     * @param month an <code>int</code> value
     * @param year an <code>int</code> value
     * @return a <code>Date</code> value
     * @exception Exception if an error occurs
     */
    public Date setDate(int day, int month, int year) throws Exception {
	dateString = new String("" + day + " " + month + " " + year);
	date = int2date.parse(dateString);
	
	return date;
    }
}
