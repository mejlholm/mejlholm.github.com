// This is a JUnit test case to test the person

package dk.auc.cs.whiner.gui.share;

import junit.framework.Test;
import junit.framework.TestCase;

import java.security.*;

public class TestCryptPassword extends TestCase {
    public void testCrypt() {
	String pwd1 = new String();
	String pwd2 = new String();

	CryptPassword p1 = new CryptPassword("Test Password");
	CryptPassword p2 = new CryptPassword("Test Password");
	try {
	    pwd1 = p1.cryptSHA();
	    pwd2 = p2.cryptSHA();
	} catch (NoSuchAlgorithmException e) {
	    System.out.println("No SHA algoritme found!");
	}
	// The test
	assertEquals("Test to see if the metode makes the same cryption every time", pwd1, pwd2);
    }
}
