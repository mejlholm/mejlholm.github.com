/**
 *
 * @author  Jesper Kristensen
 * @version $Revision: 1.34 $
 *
 */
package dk.auc.cs.whiner.gui;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import java.io.*;
import java.util.*;
import java.security.*;

import java.rmi.*;

import dk.auc.cs.whiner.gui.headhunter.*;
import dk.auc.cs.whiner.gui.administrator.*;
import dk.auc.cs.whiner.gui.applicant.*;
import dk.auc.cs.whiner.gui.share.*;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.WrongPasswordOrUsernameException;
import dk.auc.cs.whiner.interfaces.*;

/**
 * This class handels the login screen in the GUI
 */
public class Login extends JApplet {  
    private MsgErrorWarning msgErrorWarning;
    private Container cp;
    private String userType;
    private String username;
    private String password;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JPanel westPanel;
    private JPanel mainTopPanel;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JPanel eastPanel;
    private JLabel topLabel;
    private JLabel nameLabel;
    private JLabel passwordLabel;
    private JLabel headLabel;
    private JLabel subHeadLabel;
    private JTextField nameText;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton newButton;
    private CryptPassword pwd;
    private String connectionString;
    private LoginI whinerLoginServer;
    private UserI currentUser;

    public Login() {
        initComponents();
    }

    /**
     * Puts all the components on the diffrent panel's and displays the components on the screen.
     */
    private void initComponents() {
        buttomPanel = new JPanel();
	connectionString = new String("//130.225.194.15:2002/WhinerLoginServer");
	cp = getContentPane();
        eastPanel = new JPanel();
	headLabel = new JLabel();
	loginButton = new JButton();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
	nameLabel = new JLabel();
	nameText = new JTextField();
	newButton = new JButton();
	passwordField = new JPasswordField();
	passwordLabel = new JLabel();
	subHeadLabel = new JLabel();
        topLabel = new JLabel();
        topPanel = new JPanel();
	userType = new String();
	username = new String();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());

	mainTopPanel.setBackground(new Color(233,233,242));
        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

	headLabel.setText("W.H.I.N.E.R");
	headLabel.setFont(new Font("Dialog", 1, 24));
	mainTopPanel.add(headLabel, new AbsoluteConstraints(222, 110, -1, -1));

	subHeadLabel.setText("Worker Hiring InterNet Enterprise Ressource");
	mainTopPanel.add(subHeadLabel, new AbsoluteConstraints(145, 140, -1, -1));

	nameLabel.setText("User name:");
	mainTopPanel.add(nameLabel, new AbsoluteConstraints(140, 200, -1, -1));

	passwordLabel.setText("Password:");
	mainTopPanel.add(passwordLabel, new AbsoluteConstraints(140, 225, -1, -1));

        mainTopPanel.add(nameText, new AbsoluteConstraints(220, 200, 200, -1));

	passwordField.addKeyListener(new KeyAdapter() {
		public void keyPressed(KeyEvent evt) {
		    int keycode = evt.getKeyCode();
		    if (keycode == KeyEvent.VK_ENTER) {
			mouseLoginButton();
		    }		
		}
	
	    });
        mainTopPanel.add(passwordField, new AbsoluteConstraints(220, 225, 200, -1));

        loginButton.setText("Login");
        loginButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLoginButton();
		}
	    });
        mainTopPanel.add(loginButton, new AbsoluteConstraints(170, 250, 100, -1));

        newButton.setText("New User");
        newButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseNewButton();
		}
	    });
        mainTopPanel.add(newButton, new AbsoluteConstraints(290, 250, 100, -1));

	mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 450));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new AbsoluteLayout());

        topPanel.add(topLabel, new AbsoluteConstraints(-1, 2, 450, 20));

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	mainJPanel.setBackground(new Color(233,233,242));
	cp.add(mainJPanel, BorderLayout.CENTER);
    }

    private void mouseNewButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new EditProfile("new"));
	setContentPane(cp);
    }

    private void mouseLoginButton() {
	username = nameText.getText();
	try {
	    pwd = new CryptPassword(new String(passwordField.getPassword()));
	    password = pwd.cryptSHA();
	} catch (NoSuchAlgorithmException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the password funktion.\n The applet will exit.");
	    msgErrorWarning.msgError();
	    System.exit(-1);
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unkow exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}

	if (System.getSecurityManager() == null){
	    System.setSecurityManager(new RMISecurityManager());
	}

	// Connect to the server and veryfi the user
	try {
	   whinerLoginServer = (LoginI) Naming.lookup(connectionString);
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    e.printStackTrace();
	    return;
	}

	// Testing the username and password
	try {
	    currentUser = (UserI)whinerLoginServer.login(username, password);
	} catch (WrongPasswordOrUsernameException e){ // Wrong user or password
	    msgErrorWarning = new MsgErrorWarning(e.getMessage());
	    msgErrorWarning.msgError();
	    return;
	}  catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknow error: In checking username and password!");
	    msgErrorWarning.msgError();
	    return;
	}

	// Change to the main screen of the user's type
	if (((currentUser.getClass()).getName()).equals("dk.auc.cs.whiner.model.Administrator_Stub")) {
	    cp.removeAll();
	    try {
		cp.add(BorderLayout.CENTER, new MainAdminGUI((AdministratorI)currentUser));
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    }
	    setContentPane(cp);
	} else if (((currentUser.getClass()).getName()).equals("dk.auc.cs.whiner.model.Headhunter_Stub")) {
	    cp.removeAll();
	    try {
		cp.add(BorderLayout.CENTER, new MainHeadhunterGUI((HeadhunterI)currentUser));
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unkow exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	    setContentPane(cp);
	} else if (((currentUser.getClass()).getName()).equals("dk.auc.cs.whiner.model.Applicant_Stub")) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new MainApplicantGUI((ApplicantI)currentUser));
	    setContentPane(cp);
	}
    }

    public static void main(String[] args) {
	Console.run(new Login(), 590, 545);
    }
}
