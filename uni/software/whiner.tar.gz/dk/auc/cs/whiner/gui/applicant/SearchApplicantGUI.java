/**
 *
 * @author  Jesper Kristensen
 * @version $Revision: 1.17 $
 */
package dk.auc.cs.whiner.gui.applicant;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;

import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

public class SearchApplicantGUI extends JApplet {
    private MsgErrorWarning msgErrorWarning;
    private Container cp;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JPanel westPanel;
    private JPanel mainTopPanel;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JPanel mainButtomPanel;
    private JPanel eastPanel;
    private JButton logoutButton;
    private ApplicantI applicant;
    private JButton backButton;
    private JList searchResultList;
    private JScrollPane searchResultListScrollPanel;
    private DefaultListModel searchResultListModel;
    private JLabel searchResultLabel;
    private JButton viewButton;
    private JList globalQualificationList;
    private JScrollPane globalQualificationListScrollPanel;
    private DefaultListModel globalQualificationListModel;
    private JLabel globalQualificationLabel;
    private JButton searchButton;
    private ArrayList selectedItems;
    private int[] items ;
    private CVI cv;
    private SearchI search;

    public SearchApplicantGUI(ApplicantI applicant) {
	this.applicant = applicant;
	search = null;
        initComponents();
    }

    public SearchApplicantGUI(ApplicantI applicant, SearchI search) {
	this.applicant = applicant;
	this.search = search;
        initComponents();
    }

    private void initComponents() {
	searchButton = new JButton();
	backButton = new JButton();
        buttomPanel = new JPanel();
	cp = getContentPane();
        eastPanel = new JPanel();
	globalQualificationLabel = new JLabel();
        globalQualificationList = new JList();
	items = new int[0];
        globalQualificationListScrollPanel = new JScrollPane();
        logoutButton = new JButton();
        mainButtomPanel = new JPanel();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
	searchResultLabel = new JLabel();
        searchResultList = new JList();
        searchResultListScrollPanel = new JScrollPane();
	selectedItems = new ArrayList();
	viewButton = new JButton();
        topPanel = new JPanel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());
	mainTopPanel.setBackground(new Color(233,233,242));
        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

	searchResultLabel.setText("Search results:");
	mainTopPanel.add(searchResultLabel, new AbsoluteConstraints(20, 20, -1, -1));

        searchResultListScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	searchResultListModel = new DefaultListModel();
        searchResultList.setModel(searchResultListModel);
        searchResultList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        searchResultList.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    if (evt.getClickCount() == 2) {
			mouseViewButton();
		    }
		}
	    });
        searchResultListScrollPanel.setViewportView(searchResultList);
        mainTopPanel.add(searchResultListScrollPanel, new AbsoluteConstraints(20, 40, 420, 155));

        viewButton.setText("View");
        viewButton.setToolTipText("View the selected job.");
        viewButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseViewButton();
		}
	    });
        mainTopPanel.add(viewButton, new AbsoluteConstraints(460, 170, 87, -1));

        mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 215));

        mainButtomPanel.setLayout(new AbsoluteLayout());
        mainButtomPanel.setBorder(new BevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

	globalQualificationLabel.setText("Qualifications list:");
	mainButtomPanel.add(globalQualificationLabel, new AbsoluteConstraints(20, 20, -1, -1));

        globalQualificationListScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	globalQualificationListModel = new DefaultListModel();
        globalQualificationList.setModel(globalQualificationListModel);
        globalQualificationList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        globalQualificationList.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    // Makes the selected value to and object
		    Integer itemObj = new Integer(globalQualificationList.getSelectedIndex());
		    // init varibales
		    boolean test = true;
		    // Test to see if the item is unselected
		    for (int i = 0; i < selectedItems.size(); i++) {
			if (itemObj.intValue() == (((Integer)selectedItems.get(i)).intValue())) {
			    test = false;
			    selectedItems.remove(i);
			}
		    }
		    // Add the new selection
		    if (test) {
			selectedItems.add(itemObj);
		    }
		    // Update the list
		    items = new int[selectedItems.size()];
		    for (int i = 0; i < selectedItems.size(); i++) {
			try {
			    items[i] = ((QualificationI)cv.getGlobalQualification(((Integer)selectedItems.get(i)).intValue())).getID();
			} catch (RemoteException e) {
			    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
			    msgErrorWarning.msgError();
			    return;
			}
		    }
		    globalQualificationList.setSelectedIndices(items);
		}
	    });
        globalQualificationListScrollPanel.setViewportView(globalQualificationList);
        mainButtomPanel.add(globalQualificationListScrollPanel, new AbsoluteConstraints(20, 40, 420, 155));

        searchButton.setText("Search");
        searchButton.setToolTipText("Search the job database, with the selected qualifications.");
        searchButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseSearchButton();
		}
	    });
        mainButtomPanel.add(searchButton, new AbsoluteConstraints(460, 170, 87, -1));

	mainButtomPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainButtomPanel, new AbsoluteConstraints(2, 240, 566, 215));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());
        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());

	backButton.setText("Back to main");
        backButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseBackButton();
		}
	    });
        buttomPanel.add(backButton,  new AbsoluteConstraints(0, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	cp.add(mainJPanel, BorderLayout.CENTER);

	// Load information to preform the search by
	getInformation();
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void mouseBackButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new MainApplicantGUI(applicant));
	setContentPane(cp);
    }

    private void mouseViewButton() {
	int selectedJob = searchResultList.getSelectedIndex();
	if (selectedJob == -1) {
	    msgErrorWarning = new MsgErrorWarning("You can't make a search, when no qualifications is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	cp.removeAll();
	try { // Start the search
	    cp.add(BorderLayout.CENTER, new ViewSearchJobApplicantGUI((JobI)search.getJob(selectedJob), search, applicant));
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	setContentPane(cp);
    }

    private void mouseSearchButton() {
	if (items.length == 0) {
	    try {
		int size = cv.getGlobalQualificationListLength();
		items = new int[size];
		for (int i = 0; i < size; i++) {
		    items[i] = ((QualificationI)cv.getGlobalQualification(i)).getID();
		}
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	}
	// Remove Last search
	int size = searchResultListModel.getSize();
	for (int i = 0; i < size; i++) {
	    searchResultListModel.remove(0);
	}

	try { // Start the search
	    search = (SearchI)applicant.beginSearch(items);
	    for (int i = 0; i < search.getLength(); i++) {
		searchResultListModel.insertElementAt(((JobI)search.getJob(i)).getTitle(), i);
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
    }

    private void getInformation() {
	try { // Get global qualifications list
	    cv = (CVI)applicant.selectCV();
	    cv.initializeGlobalQualificationList();
	    for (int i = 0; i < cv.getGlobalQualificationListLength(); i++) {
		QualificationI qualification = cv.getGlobalQualification(i);
		String argToList = new String(qualification.getName());
		globalQualificationListModel.insertElementAt(argToList, i);
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	// Check if back it comes from back
	if (!(search == null)) {
	    try {
		for (int i = 0; i < search.getLength(); i++) {
		    searchResultListModel.insertElementAt(((JobI)search.getJob(i)).getTitle(), i);
		}
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	}
    }
}
