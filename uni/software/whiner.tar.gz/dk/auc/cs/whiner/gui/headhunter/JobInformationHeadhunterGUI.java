/**
 *
 * @author  Jesper Kristensen
 * @version $Revision: 1.44 $
 */
package dk.auc.cs.whiner.gui.headhunter;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.model.DeleteException;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

public class JobInformationHeadhunterGUI extends JApplet {
    private MsgErrorWarning msgErrorWarning;
    private String jobDescriptionTitleBackup;
    private String jobDescriptionTextBackup;
    private String pastForJob;
    private int jobNo;
    private Container cp;
    private ListSelectionModel rowSelectModel;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JPanel westPanel;
    private JTable applicationTable;
    private JButton jobDescriptionCancelButton;
    private JButton backButton;
    private JPanel mainCenterPanel;
    private JButton qualificationEditButton;
    private JPanel mainTopPanel;
    private JTextArea jobDescriptionTextArea;
    private JButton logoutButton;
    private JScrollPane applicationScrollPanel;
    private JPanel mainPanel;
    private JList qualificationList;
    private DefaultListModel qualificationListModel; 
    private JScrollPane qualificationScrollPanel;
    private String skillLevelString;
    private JPanel buttomPanel;
    private JTextField jobDescriptionTitleText;
    private JButton applicationViewButton;
    private JPanel mainButtomPanel;
    private JPanel eastPanel;
    private JLabel jobDescriptionTitleLabel;
    private JLabel qualificationLabel;
    private JButton jobDescriptionEditButton;
    private JScrollPane jobDescriptionScrollPanel;
    private HeadhunterI hh;
    private JButton applicationDelButton;
    private ProjectI selectedProject;
    private JobI selectedJob;
    private Object[][] data;
    private int selectedApplication;

    public JobInformationHeadhunterGUI(int jobNo, ProjectI selectedProject, String pastForJob, HeadhunterI hh) {
	this.hh = hh;
	this.jobNo = jobNo;
	this.selectedProject = selectedProject;
	this.pastForJob = pastForJob;
        initComponents();
    }
    
    private void initComponents() {
	applicationDelButton = new JButton();
        applicationScrollPanel = new JScrollPane();
        applicationViewButton = new JButton();
        backButton = new JButton();
        buttomPanel = new JPanel();
	cp = getContentPane();
        eastPanel = new JPanel();
	jobDescriptionCancelButton = new JButton();
        jobDescriptionEditButton = new JButton();
        jobDescriptionScrollPanel = new JScrollPane();
        jobDescriptionTextArea = new JTextArea();
	jobDescriptionTextBackup = new String();
	jobDescriptionTitleBackup = new String();
        jobDescriptionTitleLabel = new JLabel();
        jobDescriptionTitleText = new JTextField();
        logoutButton = new JButton();
        mainButtomPanel = new JPanel();
        mainCenterPanel = new JPanel();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
        qualificationEditButton = new JButton();
	qualificationLabel = new JLabel();
        qualificationList = new JList();
        qualificationScrollPanel = new JScrollPane();
	selectedApplication = -1;
        topPanel = new JPanel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));
      
	jobDescriptionEditButton.setText("Edit");
        jobDescriptionEditButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseDescriptionEditButton(evt);
		}
	    });
        mainTopPanel.add(jobDescriptionEditButton, new AbsoluteConstraints(460, 106, 87, -1));

	jobDescriptionCancelButton.setText("Cancel");
        jobDescriptionCancelButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseDescriptionCancelButton();
		}
	    });
        mainTopPanel.add(jobDescriptionCancelButton, new AbsoluteConstraints(460, 76, 87, -1));

        jobDescriptionTitleLabel.setText("Title:");
        mainTopPanel.add(jobDescriptionTitleLabel, new AbsoluteConstraints(20, 20, -1, -1));

	jobDescriptionTitleText.setEditable(false);
        mainTopPanel.add(jobDescriptionTitleText, new AbsoluteConstraints(60, 20, 380, -1));

        jobDescriptionScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        jobDescriptionScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        jobDescriptionTextArea.setLineWrap(true);
	jobDescriptionTextArea.setEditable(false);
        jobDescriptionScrollPanel.setViewportView(jobDescriptionTextArea);

        mainTopPanel.add(jobDescriptionScrollPanel, new AbsoluteConstraints(20, 50, 420, 80));

	mainTopPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 145));

        mainCenterPanel.setLayout(new AbsoluteLayout());

        mainCenterPanel.setBorder(new BevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

        qualificationEditButton.setText("Edit");
	qualificationEditButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseQualificationEditButton();
		}
	    });
        mainCenterPanel.add(qualificationEditButton, new AbsoluteConstraints(460, 106, 87, -1));

        qualificationLabel.setText("Job requirements:");
        mainCenterPanel.add(qualificationLabel, new AbsoluteConstraints(20, 20, -1, -1));

        qualificationScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	qualificationListModel = new DefaultListModel();
        qualificationList.setModel(qualificationListModel);
        qualificationScrollPanel.setViewportView(qualificationList);

        mainCenterPanel.add(qualificationScrollPanel, new AbsoluteConstraints(20, 40, 420, 90));

	mainCenterPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainCenterPanel, new AbsoluteConstraints(2, 167, 566, 145));

        mainButtomPanel.setLayout(new AbsoluteLayout());

        mainButtomPanel.setBorder(new BevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));
        applicationViewButton.setText("View");
	applicationViewButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseApplicationViewButton();
		}
	    });
        mainButtomPanel.add(applicationViewButton, new AbsoluteConstraints(460, 105, 87, -1));

        applicationDelButton.setText("Delete");
        applicationDelButton.setToolTipText("Delete application from the system");
	applicationDelButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseApplicationDelButton();
		}
	    });
        mainButtomPanel.add(applicationDelButton, new AbsoluteConstraints(460, 76, 87, -1));

	// Setting up the tabel
        String[] columnNames = {"Applications",
				"Matched",
				"Status"};

	// Fill in the data to the tabel
	if ((pastForJob.equals("edit")) || (pastForJob.equals("view"))) {
	    try {
		selectedJob = (JobI)selectedProject.selectJob(jobNo);
		selectedJob.initializeJobApplicationList();
		int sizeOfList = selectedJob.getJobApplicationListLength();
		data = new Object[sizeOfList][3];
		for (int i = 0; i < sizeOfList; i++) {
		    int id = ((ApplicationI)selectedJob.getApplication(i)).getApplicantID();
		    data[i][0] = new String(((ApplicationI)selectedJob.getApplication(i)).getApplicantName(id));
		    data[i][1] = new Integer(((ApplicationI)selectedJob.getApplication(i)).findRequirementScore());
		    data[i][2] = new String(((ApplicationI)selectedJob.getApplication(i)).getStatus());
		}
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown error: " + e);
		msgErrorWarning.msgError();
		return;
	    }
	} else {
	    data = new Object[0][3];
	}
	// Add the data and columns to the table and put ir on the screen
	applicationTable = new JTable(data, columnNames);
	applicationTable.setColumnSelectionAllowed(false);
	applicationTable.setRowSelectionAllowed(true);
	applicationTable.setDragEnabled(false);
	applicationTable.setShowGrid(false);
	applicationTable.setShowHorizontalLines(true);
	applicationTable.setFocusable(false);
	applicationTable.setBackground(new Color(233,233,242));
        applicationTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	// Setting up the column width and resizeAble
	TableColumn column = null;
	column = applicationTable.getColumnModel().getColumn(0);
	column.setPreferredWidth(240);
	column.setResizable(false);
	column = applicationTable.getColumnModel().getColumn(1);
	column.setPreferredWidth(10);
	column.setResizable(false);
	column = applicationTable.getColumnModel().getColumn(2);
	column.setPreferredWidth(50);
	column.setResizable(false);
	// Show which row has been selected in the table
	rowSelectModel = applicationTable.getSelectionModel();
	rowSelectModel.addListSelectionListener(new ListSelectionListener() {
		public void valueChanged(ListSelectionEvent evt) {
                    // Ignore extra messages.
                    if (evt.getValueIsAdjusting()) return;
		    ListSelectionModel lsm = (ListSelectionModel)evt.getSource();
		    int selectedRow = lsm.getMinSelectionIndex();
    		    selectedApplication = applicationTable.getSelectedRow();
		}
	    });
	applicationScrollPanel.setBackground(new Color(233,233,242));
	applicationScrollPanel.setViewportView(applicationTable);

        mainButtomPanel.add(applicationScrollPanel, new AbsoluteConstraints(20, 20, 420, 110));

	mainButtomPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainButtomPanel, new AbsoluteConstraints(2, 320, 566, 145));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());

        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new BorderLayout());

        backButton.setText("Back to main");
        backButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseBackButton();
            }
        });
        buttomPanel.add(backButton, BorderLayout.WEST);

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	mainJPanel.setBackground(new Color(233,233,242));
	cp.add(mainJPanel, BorderLayout.CENTER);
	
	// Check to see who has call for this screen and make some setup and load information
	setLayoutOnOff();
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void mouseBackButton() {
	cp.removeAll();
	try {
	    cp.add(BorderLayout.CENTER, new MainHeadhunterGUI(hh));
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	}
	setContentPane(cp);
    }

    private void mouseApplicationDelButton() {
	// Check if the button isenabled
	if (applicationDelButton.isEnabled() == false) {return;}
	// Check if something os selected
	if (selectedApplication == -1) {
	    msgErrorWarning = new MsgErrorWarning("You can't delete, when no application is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Makes a msg box to verfiy the deletion
	String appString = (String)applicationTable.getValueAt(selectedApplication, 0);
	msgErrorWarning = new MsgErrorWarning("Warning do you want to delete applicantion: " + appString);
	int selected = msgErrorWarning.msgWarning();
	// Check the answer from the user, if it's 0 delete the qualification eles do nothing
	if (selected == 0) {
	    try {
		selectedJob.deleteApplicationIfNotSubmitted(selectedApplication);
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (DeleteException e) {
		msgErrorWarning = new MsgErrorWarning("The selected application can't be delete.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown error: " + e);
		msgErrorWarning.msgError();
		return;
	    }
	    
	    // Reload the hole table
	    String[] columnNames = {"Applications",
				"Matched",
				"Status"};

	    // Fill in the data to the tabel
	    if ((pastForJob.equals("edit")) || (pastForJob.equals("view"))) {
		try {
		    selectedJob = (JobI)selectedProject.selectJob(jobNo);
		    selectedJob.initializeJobApplicationList();
		    int sizeOfList = selectedJob.getJobApplicationListLength();
		    data = new Object[sizeOfList][3];
		    for (int i = 0; i < sizeOfList; i++) {
			int id = ((ApplicationI)selectedJob.getApplication(i)).getApplicantID();
			data[i][0] = new String(((ApplicationI)selectedJob.getApplication(i)).getApplicantName(id));
			data[i][1] = new Integer(((ApplicationI)selectedJob.getApplication(i)).findRequirementScore());
			data[i][2] = new String(((ApplicationI)selectedJob.getApplication(i)).getStatus());
		    }
		} catch (RemoteException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		    msgErrorWarning.msgError();
		    return;
		} catch (DAOException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		    msgErrorWarning.msgError();
		    return;
		} catch (Exception e) {
		    msgErrorWarning = new MsgErrorWarning("Unknown error: " + e);
		    msgErrorWarning.msgError();
		    return;
		}
	    } else {
		data = new Object[0][3];
	    }
	    // Add the data and columns to the table and put ir on the screen
	    applicationTable = new JTable(data, columnNames);
	    applicationTable.setColumnSelectionAllowed(false);
	    applicationTable.setRowSelectionAllowed(true);
	    applicationTable.setDragEnabled(false);
	    applicationTable.setShowGrid(false);
	    applicationTable.setShowHorizontalLines(true);
	    applicationTable.setFocusable(false);
	    applicationTable.setBackground(new Color(233,233,242));
	    applicationTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    // Setting up the column width and resizeAble
	    TableColumn column = null;
	    column = applicationTable.getColumnModel().getColumn(0);
	    column.setPreferredWidth(240);
	    column.setResizable(false);
	    column = applicationTable.getColumnModel().getColumn(1);
	    column.setPreferredWidth(10);
	    column.setResizable(false);
	    column = applicationTable.getColumnModel().getColumn(2);
	    column.setPreferredWidth(50);
	    column.setResizable(false);
	    // Show which row has been selected in the table
	    rowSelectModel = applicationTable.getSelectionModel();
	    rowSelectModel.addListSelectionListener(new ListSelectionListener() {
		    public void valueChanged(ListSelectionEvent evt) {
			// Ignore extra messages.
			if (evt.getValueIsAdjusting()) return;
			ListSelectionModel lsm = (ListSelectionModel)evt.getSource();
			int selectedRow = lsm.getMinSelectionIndex();
			selectedApplication = applicationTable.getSelectedRow();
		    }
		});
	    applicationScrollPanel.setBackground(new Color(233,233,242));
	    applicationScrollPanel.setViewportView(applicationTable);
	} else {
	    return;
	}
    }

    private void mouseQualificationEditButton() {
	// Check if the button isenabled
	if (qualificationEditButton.isEnabled() == false) {return;}
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new QualificationHeadhunterGUI(selectedProject, jobNo, hh, selectedJob));
	setContentPane(cp);
    }

    private void mouseApplicationViewButton() {
	// Test if the users as slected a application
	if (selectedApplication == -1) {
	    msgErrorWarning = new MsgErrorWarning("You can't view, when no application is selected.");
	    msgErrorWarning.msgError();
	    return;
	}

	cp.removeAll();
	try {
	cp.add(BorderLayout.CENTER, new ViewApplicationHeadhunterGUI(jobNo, selectedJob.getApplication(selectedApplication), 
								     hh, selectedProject, selectedApplication));
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown error: " + e);
	    msgErrorWarning.msgError();
	    return;
	}
	setContentPane(cp);
    }

    private void mouseDescriptionCancelButton() {
	// Check if the button isenabled
	if (jobDescriptionCancelButton.isEnabled() == false) {return;}
	// This linie dos that you can press the button when not able
	if (jobDescriptionCancelButton.isEnabled() == false) {return;}
	// Set the text back to it's old self agian
	jobDescriptionTitleText.setText(jobDescriptionTitleBackup);
	jobDescriptionTextArea.setText(jobDescriptionTextBackup);
	// Change the edit/save button and disable the cancel button
	jobDescriptionCancelButton.setEnabled(false);
	// Disable the job descriptiontion and the cancel button
	jobDescriptionTitleText.setEditable(false);
	jobDescriptionTitleText.setBackground(new Color(233,233,242));
	jobDescriptionTextArea.setEditable(false);
	jobDescriptionTextArea.setBackground(new Color(233,233,242));
	jobDescriptionCancelButton.setEnabled(false);
	jobDescriptionEditButton.setText("Edit");
	// Enable the Application Panel and Qualification Panel
	applicationPanelOnOff(1);
	qualificationPanelOnOff(1);
    }

    private void mouseDescriptionEditButton(MouseEvent evt) {
	if (((JButton)evt.getSource()).getText().equals("Edit")) {
	    // This linie dos that you can press the button when not able
	    if (jobDescriptionEditButton.isEnabled() == false) {return;}
	    // This makes the project description editable and enable the cancel button
	    jobDescriptionTitleText.setEditable(true);
	    jobDescriptionTextArea.setEditable(true);
	    jobDescriptionTextArea.setBackground(new Color(255,255,255));
	    jobDescriptionCancelButton.setEnabled(true);
	    jobDescriptionEditButton.setText("Save");
	    // Makes the backup to the cancel function
	    jobDescriptionTitleBackup = jobDescriptionTitleText.getText();
	    jobDescriptionTextBackup = jobDescriptionTextArea.getText();	    
	    // Disable the other things in this screen
	    applicationPanelOnOff(0);
	    qualificationPanelOnOff(0);
	} else {
	    // This is used when the user press save
	    // Check if a title is given
	    if (((String)jobDescriptionTitleText.getText()).equals("")) {
		msgErrorWarning = new MsgErrorWarning("You can't save, when no job title is written.");
		msgErrorWarning.msgError();
		return;
	    }
	    // Disable the job description and the cancel button
	    jobDescriptionTitleText.setEditable(false);
	    jobDescriptionTitleText.setBackground(new Color(233,233,242));
	    jobDescriptionTextArea.setEditable(false);
	    jobDescriptionTextArea.setBackground(new Color(233,233,242));
	    jobDescriptionCancelButton.setEnabled(false);
	    jobDescriptionEditButton.setText("Edit");
	    // Enable the Application Panel and Qualification Panel
	    applicationPanelOnOff(1);
	    qualificationPanelOnOff(1);
	    // Disable the cancel button
	    jobDescriptionCancelButton.setEnabled(false);
	    if (pastForJob.equals("add")) {
		try { // create and save the job
		    JobI newJob = (JobI)selectedProject.createJob();
		    newJob.setTitle(jobDescriptionTitleText.getText());
		    newJob.setDescription(jobDescriptionTextArea.getText());
		    newJob.save();
		    selectedJob = newJob;
		} catch (RemoteException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		    msgErrorWarning.msgError();
		    return;
		} catch (DAOException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		    msgErrorWarning.msgError();
		    return;
		} catch (Exception e) {
		    msgErrorWarning = new MsgErrorWarning("Unknown error: " + e);
		    msgErrorWarning.msgError();
		    return;
		}
	    } else {
		try { // Select job and save the new information
		    JobI newJob = (JobI)selectedProject.selectJob(jobNo);
		    newJob.setTitle(jobDescriptionTitleText.getText());
		    newJob.setDescription(jobDescriptionTextArea.getText());
		    newJob.save();
		} catch (RemoteException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		    msgErrorWarning.msgError();
		    return;
		} catch (DAOException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		    msgErrorWarning.msgError();
		    return;
		} catch (Exception e) {
		    msgErrorWarning = new MsgErrorWarning("Unknown error: " + e);
		    msgErrorWarning.msgError();
		    return;
		}
	    }
	}
    }

    private void applicationPanelOnOff(int onOff) {
	if (onOff == 1) {
	    applicationViewButton.setEnabled(true);
	    applicationDelButton.setEnabled(true);
	    applicationScrollPanel.setEnabled(true);
	    applicationTable.setEnabled(true);
	    applicationTable.setBackground(new Color(255,255,255));
	} else {
	    applicationViewButton.setEnabled(false);
	    applicationDelButton.setEnabled(false);
	    applicationScrollPanel.setEnabled(false);
	    applicationTable.setEnabled(false);
	    applicationTable.setBackground(new Color(233,233,242));
	}
    }

    private void qualificationPanelOnOff(int onOff) {
	if (onOff == 1) {
	    qualificationEditButton.setEnabled(true);
	    qualificationScrollPanel.setEnabled(true);
	    qualificationList.setEnabled(true);
	    qualificationList.setBackground(new Color(255,255,255));
	} else {
	    qualificationEditButton.setEnabled(false);
	    qualificationScrollPanel.setEnabled(false);
	    qualificationList.setEnabled(false);
	    qualificationList.setBackground(new Color(233,233,242));
	}
    }

    private void setLayoutOnOff() {
	if (pastForJob.equals("add")) {
	    // Disable the application and qualification panels
	    applicationPanelOnOff(0);
	    qualificationPanelOnOff(0);
	    // Make the textarea enable for editing
	    jobDescriptionTitleText.setEditable(true);
	    jobDescriptionTextArea.setEditable(true);
	    jobDescriptionCancelButton.setEnabled(false);
	    jobDescriptionEditButton.setText("Save");
	} else if (pastForJob.equals("view")) {
	    // get the jobs status
	    String status = new String();
	    try {
		status = ((JobI)selectedProject.selectJob(jobNo)).getStatus();
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown error: " + e);
		msgErrorWarning.msgError();
		return;
	    }
	    // Check the status
	    if (status.equals("not announced")) {
		applicationPanelOnOff(1);
		qualificationPanelOnOff(1);
		jobDescriptionTextArea.setBackground(new Color(233,233,242));
		try { // Select job and get information
		    // Get job title and description
		    jobDescriptionTitleText.setText(selectedJob.getTitle());
		    jobDescriptionTextArea.setText(selectedJob.getDescription());
		    // Get qualification to the job
		    selectedJob = (JobI)selectedProject.selectJob(jobNo);
		    selectedJob.initializeJobQualificationList();
		    for (int i = 0; i < selectedJob.getJobQualificationListLength(); i++) {
			SkillLevelI skillLevel = selectedJob.getRequirement(i);
			QualificationI qualification = (QualificationI)skillLevel.getQualification();
			// Convert the skill-level
			if (skillLevel.getLevel() == 1) {
			    skillLevelString = new String("1 Month");
			} else if(skillLevel.getLevel() == 2) {
			    skillLevelString = new String("6 Months");
			} else if(skillLevel.getLevel() == 3) {
			    skillLevelString = new String("12 Months");
			} else if(skillLevel.getLevel() == 4) {
			    skillLevelString = new String("18 Months");
			} else {
			    skillLevelString = new String("18+ Months");
			}
			String argToList = new String(qualification.getName() + " (" +  skillLevelString +")");
			qualificationListModel.insertElementAt(argToList, i);
		    }
		} catch (RemoteException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		    msgErrorWarning.msgError();
		    return;
		} catch (DAOException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		    msgErrorWarning.msgError();
		    return;
		} catch (Exception e) {
		    msgErrorWarning = new MsgErrorWarning("Unknown error: " + e);
		    msgErrorWarning.msgError();
		    return;
		}
	    } else {
		applicationPanelOnOff(1);
		qualificationPanelOnOff(0);
		jobDescriptionTextArea.setBackground(new Color(233,233,242));
		jobDescriptionCancelButton.setEnabled(false);
		jobDescriptionEditButton.setEnabled(false);
		try { // Select job and get information
		    // Get job title and description
		    jobDescriptionTitleText.setText(selectedJob.getTitle());
		    jobDescriptionTextArea.setText(selectedJob.getDescription());
		    // Get qualification to the job
		    selectedJob = (JobI)selectedProject.selectJob(jobNo);
		    selectedJob.initializeJobQualificationList();
		    for (int i = 0; i < selectedJob.getJobQualificationListLength(); i++) {
			SkillLevelI skillLevel = selectedJob.getRequirement(i);
			QualificationI qualification = (QualificationI)skillLevel.getQualification();
			// Convert the skill-level
			if (skillLevel.getLevel() == 1) {
			    skillLevelString = new String("1 Month");
			} else if(skillLevel.getLevel() == 2) {
			    skillLevelString = new String("6 Months");
			} else if(skillLevel.getLevel() == 3) {
			    skillLevelString = new String("12 Months");
			} else if(skillLevel.getLevel() == 4) {
			    skillLevelString = new String("18 Months");
			} else {
			    skillLevelString = new String("18+ Months");
			}
			String argToList = new String(qualification.getName() + " (" +  skillLevelString +")");
			qualificationListModel.insertElementAt(argToList, i);
		    }
		} catch (RemoteException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		    msgErrorWarning.msgError();
		    return;
		} catch (DAOException e) {
		    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		    msgErrorWarning.msgError();
		    return;
		} catch (Exception e) {
		    msgErrorWarning = new MsgErrorWarning("Unknown error: " + e);
		    msgErrorWarning.msgError();
		    return;
		}
	    }
	}
    }
}
