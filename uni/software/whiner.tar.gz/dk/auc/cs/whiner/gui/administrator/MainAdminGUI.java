/**
 *
 * @author  Jesper Kristensen
 * @version $Revision: 1.30 $
 */
package dk.auc.cs.whiner.gui.administrator;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

import java.io.*;
import java.util.*;
import java.security.*;

import dk.auc.cs.whiner.gui.share.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;
import dk.auc.cs.whiner.gui.Login;

import java.rmi.*;

public class MainAdminGUI extends JApplet {
    private MsgErrorWarning msgErrorWarning;
    private Container cp;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JPanel westPanel;
    private JPanel mainTopPanel;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JPanel mainButtomPanel;
    private JPanel eastPanel;
    private JButton logoutButton;
    private JScrollPane applicantScrollPanel;
    private JList applicantList;
    private DefaultListModel applicantListModel;
    private JList headhunterList;
    private JScrollPane headhunterScrollPanel;
    private DefaultListModel headhunterListModel;
    private JButton applicantRemoveButton;
    private JLabel applicantLabel;
    private JLabel headhunterLabel;
    private JButton headhunterResetButton;
    private JButton headhunterAddButton;
    private JButton headhunterRemoveButton;
    private String newPassword;
    private CryptPassword pwd;
    private String selectedHeadhunter;
    private AdministratorI admin;

    public MainAdminGUI(AdministratorI admin) throws RemoteException {
	this.admin = admin;
        initComponents();
    }

    private void initComponents() throws RemoteException {
	applicantLabel = new JLabel();
        applicantList = new JList();
	applicantRemoveButton = new JButton();
        applicantScrollPanel = new JScrollPane();
        buttomPanel = new JPanel();
	cp = getContentPane();
        eastPanel = new JPanel();
	headhunterAddButton = new JButton();
	headhunterLabel = new JLabel();
        headhunterList = new JList();
	headhunterRemoveButton = new JButton();
	headhunterResetButton = new JButton();
        headhunterScrollPanel = new JScrollPane();
        logoutButton = new JButton();
        mainButtomPanel = new JPanel();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
	newPassword = new String();
	selectedHeadhunter = new String();
        topPanel = new JPanel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());
	mainTopPanel.setBackground(new Color(233,233,242));
        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

        applicantLabel.setText("Applicants in the system:");
        mainTopPanel.add(applicantLabel, new AbsoluteConstraints(20, 20, -1, -1));

        applicantScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	applicantListModel = new DefaultListModel();
        applicantList.setModel(applicantListModel);
        applicantList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	applicantList.setBackground(new Color(255,255,255));
        applicantScrollPanel.setViewportView(applicantList);
        mainTopPanel.add(applicantScrollPanel, new AbsoluteConstraints(20, 40, 420, 155));

        applicantRemoveButton.setText("Remove");
        applicantRemoveButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseApplicantRemoveButton();
		}
	    });
        mainTopPanel.add(applicantRemoveButton, new AbsoluteConstraints(460, 170, 87, -1));

        mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 215));

        mainButtomPanel.setLayout(new AbsoluteLayout());
        mainButtomPanel.setBorder(new BevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

        headhunterLabel.setText("Headhunters in the system:");
        mainButtomPanel.add(headhunterLabel, new AbsoluteConstraints(20, 20, -1, -1));

        headhunterAddButton.setText("Add");
        headhunterAddButton.setToolTipText("Add new headhunter");
        headhunterAddButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseHeadhunterAddButton();
		}
	    });
        mainButtomPanel.add(headhunterAddButton, new AbsoluteConstraints(460, 110, 87, -1));

        headhunterResetButton.setText("Reset");
        headhunterResetButton.setToolTipText("Reset the password");
        headhunterResetButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseHeadhunterResetButton();
		}
	    });
        mainButtomPanel.add(headhunterResetButton, new AbsoluteConstraints(460, 140, 87, -1));

        headhunterRemoveButton.setText("Remove");
        headhunterRemoveButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseHeadhunterRemoveButton();
		}
	    });
        mainButtomPanel.add(headhunterRemoveButton, new AbsoluteConstraints(460, 170, 87, -1));

        headhunterScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	headhunterListModel = new DefaultListModel();
        headhunterList.setModel(headhunterListModel);
        headhunterList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        headhunterScrollPanel.setViewportView(headhunterList);
        mainButtomPanel.add(headhunterScrollPanel, new AbsoluteConstraints(20, 40, 420, 155));

	mainButtomPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainButtomPanel, new AbsoluteConstraints(2, 240, 566, 215));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());
        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new BorderLayout());

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	cp.add(mainJPanel, BorderLayout.CENTER);

	// Getting the information
	try { // get all headhunters in the system
	    admin.initializeHeadhunterList();
	    int size = admin.getHeadhunterListLength();
	    for (int i = 0; i < size; i++) {
		headhunterListModel.insertElementAt(admin.getHeadhunter(i), i);
	    }
	} catch (RMIException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}

	try { // get all applicants in the system
	    admin.initializeApplicantList();
	    int size = admin.getApplicantListLength();
	    for (int i = 0; i < size; i++) {
		applicantListModel.insertElementAt(admin.getApplicant(i), i);
	    }
	} catch (RMIException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
    }

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void mouseApplicantRemoveButton() {
	// Test to see if the user has selected some thing in the list
	if (applicantList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't remove, when no applicant is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Makes a msg box to verfiy the deletion
	msgErrorWarning = new MsgErrorWarning("Warning do you want to delete: " + (String)applicantList.getSelectedValue());
	int selected = msgErrorWarning.msgWarning();
	// Check the answer from the user, if it's 0 delete the applicant eles do nothing
	if (selected == 0) {
	    // Delete selected project from the project list
	    try {
		admin.deleteApplicant((String)applicantList.getSelectedValue());
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown error: " + e);
		msgErrorWarning.msgError();
		return;
	    }
	    int indexInList = applicantList.getSelectedIndex();
	    applicantListModel.remove(indexInList);
	    //
	    // AND CODE TO REMOVE APPLICANT FROM DATABASE HERE
	    //
	} else {
	    return;
	}	
    }

    private void mouseHeadhunterAddButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new AddHeadhunterAdminGUI(admin));
	setContentPane(cp);
    }

    private void mouseHeadhunterRemoveButton() {
	// Test to see if the user has selected some thing in the list
	if (headhunterList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't remove, when no headhunter is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Makes a msg box to verfiy the deletion
	msgErrorWarning = new MsgErrorWarning("Warning do you want to delete: " + (String)headhunterList.getSelectedValue());
	int selected = msgErrorWarning.msgWarning();
	// Check the answer from the user, if it's 0 delete the headhunter eles do nothing
	if (selected == 0) {
	    try {
		admin.deleteHeadhunter((String)headhunterList.getSelectedValue());
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (AnnouncedJobException e) {
		msgErrorWarning = new MsgErrorWarning("The headhunter has announced job, can't be delete.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	    int indexInList = headhunterList.getSelectedIndex();
	    headhunterListModel.remove(indexInList);   
	} else {
	    return;
	}	
    }

    private void mouseHeadhunterResetButton() {
	// Test to see if the user has selected some thing in the list
	if (headhunterList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't reset password, when no headhunter is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Aske for a new password from the user
	msgErrorWarning = new MsgErrorWarning("Insert a new password");
	newPassword = msgErrorWarning.msgInput();
	// Hash and save the new password
	if (!(newPassword == null)) {
	    try {
		pwd = new CryptPassword(newPassword);
		newPassword = pwd.cryptSHA();
		admin.changeHeadhunterPassword(newPassword, (String)headhunterList.getSelectedValue());
	    } catch (NoSuchAlgorithmException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the password funktion.\n The applet will exit.");
		msgErrorWarning.msgError();
		System.exit(-1);
		return;
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	}

    }
}
