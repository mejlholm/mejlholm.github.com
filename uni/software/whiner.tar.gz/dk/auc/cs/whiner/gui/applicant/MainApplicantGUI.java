/**
 *
 * @author  Jesper Kristensen
 * @version $Revision: 1.40 $
 *
 */
package dk.auc.cs.whiner.gui.applicant;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;

import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

public class MainApplicantGUI extends JApplet {
    private MsgErrorWarning msgErrorWarning;
    private Container cp;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JPanel westPanel;
    private JPanel mainCenterPanel;
    private JPanel mainTopPanel;
    private JButton logoutButton;
    private JButton editProfileButton;
    private JButton searchButton;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JPanel mainButtomPanel;
    private JPanel eastPanel;
    private JList matchList;
    private DefaultListModel matchListModel;
    private JScrollPane matchListScrollPanel;
    private JScrollPane applicationScrollPanel;
    private JLabel matchLabel;
    private JLabel notificationLabel;
    private JButton matchViewButton;
    private JButton matchRemoveButton;
    private JList notificationList;
    private DefaultListModel notificationListModel;
    private JScrollPane notificationListScrollPanel;
    private JButton notificationViewButton;
    private JButton notificationRemoveButton;
    private JTable applicationTable;
    private ListSelectionModel rowSelectModel;
    private int selectedApplication;
    private JButton applicationViewButton;
    private JButton matchNewButton;
    private JButton delApplicantButton;
    private JButton applicationEditButton;
    private JButton applicationCancelButton;
    private JButton editQualificationButton;
    private Object[][] data;
    private ApplicantI applicant;
    private JButton applicationDeleteButton;
    
    public MainApplicantGUI(ApplicantI applicant) {
	this.applicant = applicant;
	initComponents();
    }

    private void initComponents() {
	applicationCancelButton = new JButton();
	applicationDeleteButton = new JButton();
	applicationEditButton = new JButton();
	applicationScrollPanel = new JScrollPane();
	applicationViewButton = new JButton();
        buttomPanel = new JPanel();
	cp = getContentPane();
	delApplicantButton = new JButton();
        eastPanel = new JPanel();
        editProfileButton = new JButton();
	editQualificationButton = new JButton();
        logoutButton = new JButton();
        mainButtomPanel = new JPanel();
        mainCenterPanel = new JPanel();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
	matchLabel = new JLabel();
        matchList = new JList();
        matchListScrollPanel = new JScrollPane();
	matchNewButton = new JButton();
	matchRemoveButton = new JButton();
	matchViewButton = new JButton();
	notificationLabel = new JLabel();
        notificationList = new JList();
        notificationListScrollPanel = new JScrollPane();
	notificationRemoveButton = new JButton();
	notificationViewButton = new JButton();
        searchButton = new JButton();
        topPanel = new JPanel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());
        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

	matchLabel.setText("Jobs matched to your profile:");
	mainTopPanel.add(matchLabel, new AbsoluteConstraints(20, 20, -1, -1));

        matchListScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	matchListModel = new DefaultListModel();
        matchList.setModel(matchListModel);
        matchList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        matchList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseMatchList(evt);
            }
        });
        matchListScrollPanel.setViewportView(matchList);
        mainTopPanel.add(matchListScrollPanel, new AbsoluteConstraints(20, 40, 420, 90));

        matchNewButton.setText("Apply");
        matchNewButton.setToolTipText("Make new application to the selected match");
        matchNewButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseMatchNewButton();
		}
	    });
        mainTopPanel.add(matchNewButton, new AbsoluteConstraints(460, 46, 87, -1));

        matchViewButton.setText("View");
        matchViewButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseMatchViewButton();
		}
	    });
        mainTopPanel.add(matchViewButton, new AbsoluteConstraints(460, 105, 87, -1));

        matchRemoveButton.setText("Remove");
        matchRemoveButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseMatchRemoveButton();
		}
	    });
        mainTopPanel.add(matchRemoveButton, new AbsoluteConstraints(460, 76, 87, -1));

	mainTopPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 145));

        mainCenterPanel.setLayout(new AbsoluteLayout());
        mainCenterPanel.setBorder(new BevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

	// Setting up the tabel
        String[] columnNames = {"Applications", "Status"};

	try {
	    applicant.initializeApplicantApplicationList();
	    int sizeOfList = applicant.getApplicationListLength();
	    data = new Object[sizeOfList][3];
	    for (int i = 0; i < sizeOfList; i++) {
		ApplicationI application = (ApplicationI)applicant.getApplication(i);
		data[i][0] = new String(((JobI)application.getJob(application.getJobID())).getTitle());
		data[i][1] = new String((application.getStatus()));
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	// Add the data and columns to the table and put ir on the screen
	applicationTable = new JTable(data, columnNames);
	applicationTable.setColumnSelectionAllowed(false);
	applicationTable.setRowSelectionAllowed(true);
	applicationTable.setDragEnabled(false);
	applicationTable.setShowGrid(false);
	applicationTable.setShowHorizontalLines(true);
	applicationTable.setFocusable(false);
        applicationTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	applicationTable.setBackground(new Color(233,233,242));
	// Setting up the column width and resizeAble
	TableColumn column = null;
	column = applicationTable.getColumnModel().getColumn(0);
	column.setPreferredWidth(240);
	column.setResizable(false);
	column = applicationTable.getColumnModel().getColumn(1);
	column.setPreferredWidth(50);
	column.setResizable(false);
	// Show which row has been selected in the table
	rowSelectModel = applicationTable.getSelectionModel();
	rowSelectModel.addListSelectionListener(new ListSelectionListener() {
		public void valueChanged(ListSelectionEvent evt) {
                    //Ignore extra messages.
                    if (evt.getValueIsAdjusting()) return;
		    ListSelectionModel lsm = (ListSelectionModel)evt.getSource();
		    int selectedRow = lsm.getMinSelectionIndex();
		    selectedApplication = applicationTable.getSelectedRow();
		    // Check the status and make the buttons change state
		    String status = (String)applicationTable.getValueAt(selectedRow, 1);
		    if (status.equals("incomplete")) {
			applicationViewButton.setEnabled(true);
			applicationEditButton.setEnabled(true);
			applicationDeleteButton.setEnabled(true);
			applicationCancelButton.setEnabled(false);
		    } else if(status.equals("submitted")) {
			applicationViewButton.setEnabled(true);
			applicationEditButton.setEnabled(false);
			applicationDeleteButton.setEnabled(false);
			applicationCancelButton.setEnabled(true);
		    } else {
			applicationViewButton.setEnabled(true);
			applicationDeleteButton.setEnabled(false);
			applicationEditButton.setEnabled(false);
			applicationCancelButton.setEnabled(false);
		    }
		}
	    });
	applicationScrollPanel.setViewportView(applicationTable);
	applicationScrollPanel.setBackground(new Color(233,233,242));
        mainCenterPanel.add(applicationScrollPanel, new AbsoluteConstraints(20, 20, 420, 110));

        applicationCancelButton.setText("Cancel");
        applicationCancelButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseApplicationCancelButton();
		}
	    });
        mainCenterPanel.add(applicationCancelButton, new AbsoluteConstraints(460, 105, 87, -1));
 
       applicationViewButton.setText("View");
       applicationViewButton.addMouseListener(new MouseAdapter() {
	       public void mouseClicked(MouseEvent evt) {
		    mouseApplicationViewButton();
	       }
	   });
        mainCenterPanel.add(applicationViewButton, new AbsoluteConstraints(460, 77, 87, -1));

        applicationDeleteButton.setText("Delete");
	applicationDeleteButton.setToolTipText("Delete incomplete application");
        applicationDeleteButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseApplicationDeleteButton();
		}
	    });
        mainCenterPanel.add(applicationDeleteButton, new AbsoluteConstraints(460, 20, 87, -1));

        applicationEditButton.setText("Edit");
        applicationEditButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseApplicationEditButton();
		}
	    });
        mainCenterPanel.add(applicationEditButton, new AbsoluteConstraints(460, 49, 87, -1));

	mainCenterPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainCenterPanel, new AbsoluteConstraints(2, 167, 566, 145));

        mainButtomPanel.setLayout(new AbsoluteLayout());
        mainButtomPanel.setBorder(new BevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

        notificationListScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	notificationListModel = new DefaultListModel();
        notificationList.setModel(notificationListModel);
        notificationList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        notificationList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseNotificationList(evt);
            }
        });
        notificationListScrollPanel.setViewportView(notificationList);
        mainButtomPanel.add(notificationListScrollPanel, new AbsoluteConstraints(20, 40, 420, 90));

	notificationLabel.setText("Notifications:");
	mainButtomPanel.add(notificationLabel, new AbsoluteConstraints(20, 20, -1, -1));

        notificationViewButton.setText("View");
        notificationViewButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseNotificationViewButton();
		}
	    });
        mainButtomPanel.add(notificationViewButton, new AbsoluteConstraints(460, 105, 87, -1));

        notificationRemoveButton.setText("Remove");
        notificationRemoveButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseNotificationRemoveButton();
		}
	    });
        mainButtomPanel.add(notificationRemoveButton, new AbsoluteConstraints(460, 76, 87, -1));

	mainButtomPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainButtomPanel, new AbsoluteConstraints(2, 320, 566, 145));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());

        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);
	
	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());

        editProfileButton.setText("Edit your profile");
        editProfileButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseEditProfileButton();
            }
        });
        buttomPanel.add(editProfileButton, new AbsoluteConstraints(0, 0, -1, -1));

        editQualificationButton.setText("Qualifications");
        editQualificationButton.setToolTipText("Edit/add qualifications to you profile");
        editQualificationButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseEditQualificationButton();
            }
        });
        buttomPanel.add(editQualificationButton,  new AbsoluteConstraints(139, 0, -1, -1));

        searchButton.setText("Search for job");
        searchButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseSearchButton();
            }
        });
        buttomPanel.add(searchButton,  new AbsoluteConstraints(265, 0, -1, -1));

        delApplicantButton.setText("Del profile");
        delApplicantButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                mouseDelApplicantButton();
            }
        });
        buttomPanel.add(delApplicantButton,  new AbsoluteConstraints(490, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	cp.add(mainJPanel, BorderLayout.CENTER);


	// Disable buttons
	applicationViewButton.setEnabled(false);
	applicationDeleteButton.setEnabled(false);
	applicationEditButton.setEnabled(false);
	applicationCancelButton.setEnabled(false);

	// Loads information in to the screen
	getInformation();
    }
   
    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void mouseDelApplicantButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to DELETE your profile!!!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    // Remove the applicant from the system
	    try {
		applicant.deleteApplicant();
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	    // Logout
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
	} else {
	    return;
	}
    }

    private void mouseEditProfileButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new EditProfile("edit", applicant));
	setContentPane(cp);
    }

    private void mouseEditQualificationButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new EditQualificationApplicantGUI(applicant));
	setContentPane(cp);
    }

    private void mouseSearchButton() {
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new SearchApplicantGUI(applicant));
	setContentPane(cp);
    }

    private void mouseMatchNewButton() {
	// Test to se if a match has been selected
	if (matchList.getSelectedIndex() == -1) {
	    msgErrorWarning = new MsgErrorWarning("You can't make a new application, when no match is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// change screen to view the application
	cp.removeAll();
	try {
	    cp.add(BorderLayout.CENTER, new ViewAppApplicantGUI("new", 
								-1, 
								(JobI)((MatchI)applicant.getMatch(matchList.getSelectedIndex())).getJob(),
								applicant));
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	setContentPane(cp);
    }

    private void mouseApplicationDeleteButton() {
	// Check button status
	if (applicationDeleteButton.isEnabled() == false) {return;}	
	try {
	    applicant.deleteApplicationDraft(selectedApplication);
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}

	// Reload the hole table agian
        String[] columnNames = {"Applications", "Status"};

	try {
	    applicant.initializeApplicantApplicationList();
	    int sizeOfList = applicant.getApplicationListLength();
	    data = new Object[sizeOfList][3];
	    for (int i = 0; i < sizeOfList; i++) {
		ApplicationI application = (ApplicationI)applicant.getApplication(i);
		data[i][0] = new String(((JobI)application.getJob(application.getJobID())).getTitle());
		data[i][1] = new String((application.getStatus()));
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	// Add the data and columns to the table and put ir on the screen
	applicationTable = new JTable(data, columnNames);
	applicationTable.setColumnSelectionAllowed(false);
	applicationTable.setRowSelectionAllowed(true);
	applicationTable.setDragEnabled(false);
	applicationTable.setShowGrid(false);
	applicationTable.setShowHorizontalLines(true);
	applicationTable.setFocusable(false);
        applicationTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	applicationTable.setBackground(new Color(233,233,242));
	// Setting up the column width and resizeAble
	TableColumn column = null;
	column = applicationTable.getColumnModel().getColumn(0);
	column.setPreferredWidth(240);
	column.setResizable(false);
	column = applicationTable.getColumnModel().getColumn(1);
	column.setPreferredWidth(50);
	column.setResizable(false);
	// Show which row has been selected in the table
	rowSelectModel = applicationTable.getSelectionModel();
	rowSelectModel.addListSelectionListener(new ListSelectionListener() {
		public void valueChanged(ListSelectionEvent evt) {
                    //Ignore extra messages.
                    if (evt.getValueIsAdjusting()) return;
		    ListSelectionModel lsm = (ListSelectionModel)evt.getSource();
		    int selectedRow = lsm.getMinSelectionIndex();
		    selectedApplication = applicationTable.getSelectedRow();
		    // Check the status and make the buttons change state
		    String status = (String)applicationTable.getValueAt(selectedRow, 1);
		    if (status.equals("incomplete")) {
			applicationViewButton.setEnabled(true);
			applicationEditButton.setEnabled(true);
			applicationDeleteButton.setEnabled(true);
			applicationCancelButton.setEnabled(false);
		    } else if(status.equals("submitted")) {
			applicationViewButton.setEnabled(true);
			applicationEditButton.setEnabled(false);
			applicationDeleteButton.setEnabled(false);
			applicationCancelButton.setEnabled(true);
		    } else {
			applicationViewButton.setEnabled(true);
			applicationDeleteButton.setEnabled(false);
			applicationEditButton.setEnabled(false);
			applicationCancelButton.setEnabled(false);
		    }
		}
	    });
	applicationScrollPanel.setViewportView(applicationTable);
	applicationScrollPanel.setBackground(new Color(233,233,242));
        mainCenterPanel.add(applicationScrollPanel, new AbsoluteConstraints(20, 20, 420, 110));
	// Disable buttons
	applicationDeleteButton.setEnabled(false);
	applicationEditButton.setEnabled(false);
	applicationViewButton.setEnabled(false);
    }

    private void mouseApplicationCancelButton() {
	// Check button status
	if (applicationCancelButton.isEnabled() == false) {return;}	
	try {
	    ((ApplicationI)applicant.getApplication(selectedApplication)).cancelApplication();
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	applicationTable.setValueAt(new String("Canceled"), selectedApplication, 1);
    }

    private void mouseApplicationEditButton() {
	// Check button status
	if (applicationEditButton.isEnabled() == false) {return;}	
	// Test to se if a application has been selected
	if (selectedApplication == -1) {
	    msgErrorWarning = new MsgErrorWarning("You can't edit, when no application is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// make varibales to be used for parsing
	JobI job = null;
	// change screen to view the application
	try {
	    ApplicationI app = (ApplicationI)applicant.getApplication(selectedApplication);
	    job = (JobI)app.getJob(app.getJobID());
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new ViewAppApplicantGUI("edit", selectedApplication, job, applicant));
	setContentPane(cp);
    }

    private void mouseApplicationViewButton() {
	// Check button status
	if (applicationViewButton.isEnabled() == false) {return;}	
	// Test to se if a application has been selected
	if (selectedApplication == -1) {
	    msgErrorWarning = new MsgErrorWarning("You can't view, when no application is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// make varibales to be used for parsing
	JobI job = null;
	// change screen to view the application
	try {
	    ApplicationI app = (ApplicationI)applicant.getApplication(selectedApplication);
	    job = (JobI)app.getJob(app.getJobID());
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new ViewAppApplicantGUI("view", selectedApplication, job, applicant));
	setContentPane(cp);
    }

    private void mouseMatchList(MouseEvent evt) {
 	if (evt.getClickCount() == 2) {
	    mouseMatchViewButton();
	}
    }

    private void mouseNotificationList(MouseEvent evt) {
 	if (evt.getClickCount() == 2) {
	    mouseNotificationViewButton();
	}
    }

    private void mouseMatchViewButton() {
	// test to se if a match has been selected
	if (matchList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't view, when no match is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// change screen to view the notification
	int indexInList = matchList.getSelectedIndex();
	JobI job = null;
	try {
	    job = (JobI)((MatchI)applicant.getMatch(indexInList)).getJob();
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new ViewJobApplicantGUI(job, indexInList, applicant));
	setContentPane(cp);
    }

    private void mouseMatchRemoveButton() {
	// test to se if a match has been selected
	if (matchList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't remove, when no match is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Makes a msg box to verfiy the deletion
	msgErrorWarning = new MsgErrorWarning("Warning do you want to remove: " + (String)matchList.getSelectedValue());
	int selected = msgErrorWarning.msgWarning();
	// Check the answer from the user, if it's 0 remove the match eles do nothing
	if (selected == 0) {
	    int indexInList = matchList.getSelectedIndex();
	    try {
		applicant.deleteMatch(indexInList);
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	}
	    matchListModel.remove(indexInList);
	} else {
	    return;
	}
    }

    private void mouseNotificationViewButton() {
	// test to se if a notification has been selected
	if (notificationList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't view, when no notification is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	int indexInList = notificationList.getSelectedIndex();
	NotificationI notification = null;
	try {
	    notification = applicant.getNotification(indexInList);
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
	// change screen to view the notification
	cp.removeAll();
	cp.add(BorderLayout.CENTER, new ViewNotificationApplicantGUI(notification, indexInList, applicant));
	setContentPane(cp);
    }

    private void mouseNotificationRemoveButton() {
	// test to se if a notification has been selected
	if (notificationList.getSelectedValue() == null) {
	    msgErrorWarning = new MsgErrorWarning("You can't remove, when no notification is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	// Makes a msg box to verfiy the deletion
	msgErrorWarning = new MsgErrorWarning("Warning do you want to remove: " + (String)notificationList.getSelectedValue());
	int selected = msgErrorWarning.msgWarning();
	// Check the answer from the user, if it's 0 remove the notification eles do nothing
	if (selected == 0) {
	    int indexInList = notificationList.getSelectedIndex();
	    try {
		applicant.deleteNotification(indexInList);
	    } catch (RemoteException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
		msgErrorWarning.msgError();
		return;
	    } catch (DAOException e) {
		msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
		msgErrorWarning.msgError();
		return;
	    } catch (Exception e) {
		msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
		msgErrorWarning.msgError();
		return;   
	    }
	    notificationListModel.remove(indexInList);
	} else {
	    return;
	}	
    }

    private void getInformation() {
	try {
	    // Get notifications
	    applicant.initializeNotificationList();
	    int size = applicant.getNotificationListLength();
	    for (int i = 0; i < size; i++) {
		String argStr = new String(((NotificationI)applicant.getNotification(i)).getJobName() + 
					   " (" +  
					   ((NotificationI)applicant.getNotification(i)).getTitle() + 
					   ")");
		notificationListModel.insertElementAt(argStr, i);
	    }
	    // Get matchs
	    applicant.initializeMatchList();
	    size = applicant.getMatchListLength();
	    for (int i = 0; i < size; i++) {
		MatchI match = (MatchI)applicant.getMatch(i);
		WDate wdate = new WDate(match.getDateOfMatch());
		String argStr = new String(((JobI)match.getJob()).getTitle() + 
					   " (" +
					   wdate.getDay() + "/" + wdate.getMonth() + "/" + wdate.getYear() +
					   ")");
		matchListModel.insertElementAt(argStr, i);
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	    return;
 	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	    return;
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown exception: ." + e.getMessage());
	    msgErrorWarning.msgError();
	    return;   
	}
    }
}
