#!/bin/sh

javac share/*.java
javac Login.java
echo Running GUIClient
java -Djava.security.policy=policy  dk.auc.cs.whiner.gui.Login