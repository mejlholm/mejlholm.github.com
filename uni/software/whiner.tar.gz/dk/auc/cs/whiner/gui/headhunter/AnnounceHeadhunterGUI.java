/**
 *
 * @author  Jesper Kristensen
 * @version $Revision: 1.19 $
 */
package dk.auc.cs.whiner.gui.headhunter;

import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.dataaccess.DAOException;

import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.interfaces.*;
import dk.auc.cs.whiner.gui.Login;
import dk.auc.cs.whiner.gui.share.*;

public class AnnounceHeadhunterGUI extends JApplet {
    private MsgErrorWarning msgErrorWarning;
    private DefaultListModel announceJobModel;
    private Container cp;
    private JPanel mainJPanel;
    private JPanel topPanel;
    private JLabel announceJobLabel;
    private JPanel westPanel;
    private JButton backButton;
    private JPanel mainTopPanel;
    private JButton logoutButton;
    private JPanel mainPanel;
    private JPanel buttomPanel;
    private JList announceJobList;
    private JPanel eastPanel;
    private JButton announceJobButton;
    private JScrollPane announceJobScrollPanel;
    private ArrayList selectedItems;
    private int[] items ;
    private HeadhunterI hh;
    private ProjectI selectedProject;
    private int[] jobNoHolder;

    public AnnounceHeadhunterGUI(ProjectI selectedProject, HeadhunterI hh) {
	this.hh = hh;
	this.selectedProject = selectedProject;
        initComponents();
    }
    
    private void initComponents() {
        announceJobButton = new JButton();
        announceJobLabel = new JLabel();
        announceJobList = new JList();
        announceJobScrollPanel = new JScrollPane();
        backButton = new JButton();
        buttomPanel = new JPanel();
	cp = getContentPane();
        eastPanel = new JPanel();
	items = new int[0];
	jobNoHolder = new int[0];
        logoutButton = new JButton();
	mainJPanel = new JPanel();
        mainPanel = new JPanel();
        mainTopPanel = new JPanel();
	selectedItems = new ArrayList();
        topPanel = new JPanel();
        westPanel = new JPanel();

	mainJPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setLayout(new AbsoluteLayout());

        mainTopPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.lightGray, Color.lightGray, Color.darkGray, Color.darkGray));

        announceJobScrollPanel.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        announceJobScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	announceJobModel = new DefaultListModel();
	announceJobList.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    // Makes the selected value to and object
		    Integer itemObj = new Integer(announceJobList.getSelectedIndex());
		    // init varibales
		    boolean test = true;
		    // Test to see if the item is unselected
		    for (int i = 0; i < selectedItems.size(); i++) {
			if (itemObj.intValue() == (((Integer)selectedItems.get(i)).intValue())) {
			    test = false;
			    selectedItems.remove(i);
			}
		    }
		    // Add the new selection
		    if (test) {
			selectedItems.add(itemObj);
		    }
		    // Update the list
		    items = new int[selectedItems.size()];
		    for (int i = 0; i < selectedItems.size(); i++) {
			items[i] = ((Integer)selectedItems.get(i)).intValue();
		    }
		    announceJobList.setSelectedIndices(items);
		}
	    });
        announceJobList.setModel(announceJobModel);
        announceJobScrollPanel.setViewportView(announceJobList);

        mainTopPanel.add(announceJobScrollPanel, new AbsoluteConstraints(20, 40, 525, 360));

        announceJobLabel.setText("Pending Jobs:");
        mainTopPanel.add(announceJobLabel, new AbsoluteConstraints(20, 20, -1, -1));

        announceJobButton.setText("Announce selected jobs");
        announceJobButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseAnnounceButton();
		}
	    });
        mainTopPanel.add(announceJobButton, new AbsoluteConstraints(200, 410, -1, -1));

	mainTopPanel.setBackground(new Color(233,233,242));
        mainPanel.add(mainTopPanel, new AbsoluteConstraints(2, 12, 566, 450));

	mainPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(mainPanel, BorderLayout.CENTER);

        topPanel.setLayout(new BorderLayout());

        logoutButton.setText("Logout");
        logoutButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseLogoutButton();
		}
	    });
        topPanel.add(logoutButton, BorderLayout.EAST);

	topPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(topPanel, BorderLayout.NORTH);

        buttomPanel.setLayout(new AbsoluteLayout());

        backButton.setText("Back to main");
        backButton.addMouseListener(new MouseAdapter() {
		public void mouseClicked(MouseEvent evt) {
		    mouseBackButton();
		}
	    });
        buttomPanel.add(backButton, new AbsoluteConstraints(0, 0, -1, -1));

	buttomPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(buttomPanel, BorderLayout.SOUTH);

	eastPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(eastPanel, BorderLayout.EAST);

	westPanel.setBackground(new Color(233,233,242));
        mainJPanel.add(westPanel, BorderLayout.WEST);

	mainJPanel.setBackground(new Color(233,233,242));
	cp.add(mainJPanel, BorderLayout.CENTER);

	// Loads all the jobs in to the screen
	getInformation();
    }   

    private void mouseLogoutButton() {
	msgErrorWarning = new MsgErrorWarning("Do you want to logout!");
	int selected = msgErrorWarning.msgLogout();
	// Check the answer from the user
	if (selected == 0) {
	    cp.removeAll();
	    cp.add(BorderLayout.CENTER, new Login());
	    setContentPane(cp);
    	} else {
	    // The user will not logout
	}	
    }

    private void mouseBackButton() {
	cp.removeAll();
	try {
	    cp.add(BorderLayout.CENTER, new MainHeadhunterGUI(hh));
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown error: " + e);
	    msgErrorWarning.msgError();
	    return;
	}
	setContentPane(cp);
    }

    private void mouseAnnounceButton() {
	// Check that there is some jobs select
	if ((announceJobList.getSelectedIndices()).length == 0) {
	    msgErrorWarning = new MsgErrorWarning("You can't announce, when no jobs is selected.");
	    msgErrorWarning.msgError();
	    return;
	}
	ArrayList selectedJobs = new ArrayList();
	// Get the selected item from the jobList and put them in an ArrayList
	Object[] valgt = announceJobList.getSelectedValues();
	for (int i = 0; i < valgt.length; i++) {
	    selectedJobs.add(valgt[i]);
	}
	// Announce the jobs related to the selected project
	int[] checked = new int[items.length];
	for (int i = 0; i < items.length; i++) {
	    checked[i] = jobNoHolder[items[i]];
	}
	try {
	    selectedProject.announceCheckedJobs(checked);
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown error: " + e);
	    msgErrorWarning.msgError();
	    return;
	}
	mouseBackButton();
    }

    private void getInformation() {
	try {
	    jobNoHolder = new int[selectedProject.getJobListLength()];
	    int size = selectedProject.getJobListLength();
	    // init announce list
	    for (int i = 0; i < size; i++) {
		String status = new String(((JobI)selectedProject.getJob(i)).getStatus());
		if (status.equals("not announced")) {
		    int sizeOfList = announceJobModel.getSize();
		    jobNoHolder[sizeOfList] = i; // And i here is then the jobNo
		    announceJobModel.insertElementAt(((JobI)selectedProject.selectJob(i)).getTitle(), sizeOfList);
		}
	    }
	} catch (RemoteException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the RMI network connection.");
	    msgErrorWarning.msgError();
	} catch (DAOException e) {
	    msgErrorWarning = new MsgErrorWarning("There was an error with the database.");
	    msgErrorWarning.msgError();
	} catch (Exception e) {
	    msgErrorWarning = new MsgErrorWarning("Unknown error: " + e);
	    msgErrorWarning.msgError();
	    return;
	}
    }
}
