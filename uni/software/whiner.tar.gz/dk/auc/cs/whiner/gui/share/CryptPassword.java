package dk.auc.cs.whiner.gui.share;

import java.io.*;
import java.util.*;
import java.security.*;

/**
 * This class is used to hash the string parsed to it.
 *
 * @author <a href="mailto:cableman@minicableman"></a>
 * @version 1.0
 */
public class CryptPassword {
    private String password;

    public CryptPassword(String password) {
	this.password = password;
    }

    /**
     * This method hashs/crypt the string parsed to the class
     * constructor.
     *
     * @return a <code>String</code> value
     * @exception NoSuchAlgorithmException if an error occurs
     */
    public String cryptSHA() throws NoSuchAlgorithmException {
	MessageDigest sha = null;
	sha = MessageDigest.getInstance("SHA");

	byte b[] = sha.digest(password.getBytes());
	StringBuffer hexPassword = new StringBuffer();
	for(int i = 0; i < b.length; i += 4) {
	    int j = (b[i] << 24) + (b[i+1] << 16) + (b[i+2] << 8) + (b[i+3]);
	    hexPassword.append(Integer.toHexString(j));
	}
	return hexPassword.toString();
    }
}
