package dk.auc.cs.whiner.rmi;

/* Simple exception class - basically just renaming... */
import java.rmi.RemoteException;

public class RMIException extends RemoteException { //B�r dette v�re SQLException istedet - ville m�ske v�re mere sigende??
    private int type = 0;

    public RMIException(){
	super("Unknown exception");
    }
    public RMIException(String msg){
	super(msg);
    }
    public RMIException(String msg, Throwable cause){
	super(msg, cause);
    }

    public void setType(int newType){
	type = newType;
    }

    public void setType(String newType){
	if (newType == "Unknown Exception")
	    type = 0;
	//if (newType == "")
	//...
	else
	    type = 0;
    }

    public int getTypeID(){
	return type;
    }

    public String getTypeName(){
	String retVal = new String();

	//Switch statement
	switch(type) {
	case 0: retVal = "Unknown Exception";
	    //...
	default: retVal = "Unknown Exception";
	}

	return retVal;
    }
}
