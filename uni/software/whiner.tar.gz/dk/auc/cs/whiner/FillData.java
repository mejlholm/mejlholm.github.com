import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.function.*;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.dataaccess.ApplicantDAO;
import dk.auc.cs.whiner.dataaccess.HeadhunterDAO;
import dk.auc.cs.whiner.gui.share.*;
import java.security.*;
import java.sql.*;
import java.util.*;

public class FillData {
    //Arrays that are initialized in the beginning
    String[] applicantNames;
    String[] applicantUserNames;
    String[] projectTitles;
    String[] jobTitles;
    String[] qualifications;
    String[] headhunterNames;

    //Arrays that are filled as we go
    int[] applicantIDs = new int[10];
    int[] jobIDs =  new int[15];
    int[] headhunterIDs = new int[3];
    int[] projectIDs = new int[5];
     
    //Variables for databse connections
    private Statement s = null;
    private Connection con = null;
    private ConnectionManager cmgr = null;

    //Variables which sub-classes inherit
    private String action = "";

    
    public FillData() throws Exception {
	cmgr = ConnectionManager.getInstance();
	
	try{
	    con = cmgr.connect();
	} catch (Exception e) {
	    throw new Exception("DAOObject:DAOObject:Connection failed", e);
	}
    }
    
    /*===========================================================================
     * TING TIL DATABASE CONNECTION
     */

       /*-----------------Database Functions-----------------*/
    /**
     * Executes the given SQL statement, which may be an INSERT,
     * UPDATE, or DELETE statement or an SQL statement that returns nothing
     * @since 1.0
     * @param An SQL statement fullfilling the above requirements
     */
    protected void dbExecuteUpdate(String action) throws Exception{
	try{
	    s = con.createStatement();
	    s.executeUpdate(action);
	    
	} catch (SQLException e) {
	    e.printStackTrace();
	    throw new Exception("DAOObject:dbExecuteUpdate:Update failed");
	}
    }

    /*==========================================================================
     * S� er det slut
     */

    private void initiateArrays() {
	//Qualifications
	qualifications = new String[10];
	qualifications[0] = "Java";
	qualifications[1] = "SQL";
	qualifications[2] = "C++";
	qualifications[3] = "Python";
      	qualifications[4] = "Perl";
	qualifications[5] = "C";
	qualifications[6] = "SmallTalk";
	qualifications[7] = "SML";
	qualifications[8] = "Paint";
	qualifications[9] = "Rational Rose";
	    
	//ApplicantNames
	applicantNames = new String[10];
	applicantNames[0] = "Bennett";
	applicantNames[1] = "Jeppe";
	applicantNames[2] = "SeaCaptain";
	applicantNames[3] = "Pamela Anderson";
	applicantNames[4] = "Arne";
	applicantNames[5] = "Mejlholm";
	applicantNames[6] = "Isse";
	applicantNames[7] = "Le Peng";
	applicantNames[8] = "B�sse per";
	applicantNames[9] = "AllanO";

	//ProjectTitles
	projectTitles = new String[5];
	projectTitles[0] = "Circus project";
	projectTitles[1] = "Development project";
	projectTitles[2] = "Pool party project";
	projectTitles[3] = "W.H.I.N.E.R. project";
	projectTitles[4] = "Super project";

	//jobTitles
	jobTitles = new String[15];
	jobTitles[0] = "Pornstar";
	jobTitles[1] = "Sweeper";
	jobTitles[2] = "CEO";
	jobTitles[3] = "Office slut";
	jobTitles[4] = "Beer slut";
	jobTitles[5] = "Waitor";
	jobTitles[6] = "Topless dancer";
	jobTitles[7] = "Chef";
	jobTitles[8] = "Producer";
	jobTitles[9] = "Programmer";
	jobTitles[10] = "Software developer";
	jobTitles[11] = "Clown";
	jobTitles[12] = "Secretary";
	jobTitles[13] = "Looser";
	jobTitles[14] = "Super hero";

	//HeadhunterNames
	headhunterNames = new String[3];
	headhunterNames[0] = "Headhunteren";
	headhunterNames[1] = "DaHeadhunter";
	headhunterNames[2] = "Supermand";

	//intarrays
	
    }

    private int randomInt(int upperBound) {
	//return an integer value between 0 and the upperbound...
	int retVal;
	retVal = (int)(Math.random() * upperBound);
	return retVal;
    }

    private void FillUsers() throws Exception {
	ApplicantDAO aDAO = new ApplicantDAO();
	HeadhunterDAO hDAO = new HeadhunterDAO();
	
	Headhunter hh = null;
	Applicant app = null;
	
	String strPassword = new String();

	int i = 0;
	int j = 0;
	int uBound = 3;

	//Encrypt password:
	CryptPassword pwd = new CryptPassword("kodekode");
	strPassword = pwd.cryptSHA();

	//System.out.println("FillUsers: Variables initialized...");
	// Add a mixture of headhunters and applicants.
	// add headhunter
	hh = hDAO.add();
	headhunterIDs[0] = hh.getID();
	hh.setLoginName(headhunterNames[randomInt(3)] + 0);
	hh.setPassword(strPassword);
	hDAO.update(hh);
	//System.out.println("First headhunter added...");


	// add some applicants
 	for (i = 0; i < 6; i++) {
	    app = null;
	    app = aDAO.add();
	    applicantIDs[i] = app.getID();
	    app.setLoginName(applicantNames[randomInt(10)] + i);
	    app.setPassword(strPassword);
	    app.name.setFirstName(app.getLoginName());
	    aDAO.update(app);
	    aDAO.update((CV)app.getCV());
		
	    //InsertSkillLevels
	    uBound = randomInt(4);
	    //System.out.println("\n Ubound: " + uBound + "\n");
	    for (j = 0; j < uBound; j++) {		
		dbExecuteUpdate("INSERT INTO ApplicantSkillLevel "
				+ "(UserID, QualificationID, Level) VALUES ('"
				+ app.getID() + "', '" + randomInt(10) + "', '" + randomInt(5) + "')");		
	    }
	}
	//System.out.println("First batch of applicants added...");
	
	
	// add headhunter
	hh = hDAO.add();
	headhunterIDs[1] = hh.getID();
	hh.setLoginName(headhunterNames[randomInt(3)] + 1);
	hh.setPassword(strPassword);
	hDAO.update(hh);
	//System.out.println("Second headhunter added...");

	// add some more applicants
	try{
	    for (i = 6; i < 10; i++) {
		app = null;
		app = aDAO.add();
		applicantIDs[i] = app.getID();
		app.setLoginName(applicantNames[randomInt(10)] + i);
		app.setPassword(strPassword);
		app.name.setFirstName(app.getLoginName());
		aDAO.update(app);
		aDAO.update((CV)app.getCV());
		
		//InsertSkillLevels
		uBound = randomInt(4);
		//System.out.println("\n Ubound: " + uBound + "\n");
		for (j = 0; j < uBound; j++) {
		    dbExecuteUpdate("INSERT INTO ApplicantSkillLevel "
				    + "(UserID, QualificationID, Level) VALUES ('"
				    + app.getID() + "', '" + randomInt(10) + "', '" + randomInt(5) + "')");		
		}
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}
	//System.out.println("Second batch of applicants added...");

	// add last headhunter
	hh = hDAO.add();
	headhunterIDs[2] = hh.getID();
	hh.setLoginName(headhunterNames[randomInt(3)] + 2);
	hh.setPassword(strPassword);
	hDAO.update(hh);
	//System.out.println("Second headhunter added...");

    }

    private void FillApplications() {
	//inklusiv
	//write a few applications
    }

    private void FillProjects() throws Exception {
	for (int i = 0; i < 5; i++) {
	    //	    String ptitle = projectTitles[randomInt(5)];
	    long time = (long) 0;
	    String deBug = new String();
	    deBug = "INSERT INTO Project (ID, HeadhunterID, DateOfCreation, Status,  Title, Description) VALUES ("
			    + i + ", " + headhunterIDs[randomInt(3)] + ", " + new java.sql.Date(time) + ", 1, \"" + projectTitles[i] + "\", \"" + projectTitles[i] + "\")";
	    
	    System.out.println(deBug);
	    dbExecuteUpdate(deBug);
	}
    }

    private void FillJobs() throws Exception {
	for (int i = 0; i < 15; i++){
	    String tmp = jobTitles[randomInt(15)];
	    dbExecuteUpdate("INSERT INTO Job (ID, ProjectID, Title, Description, Status, DateOfCreation) VALUES ('"
			    + i + "', '" + randomInt(5) + "', '" + tmp + "', '" + tmp + "', '" + (randomInt(2) + 1) + "', " + new java.sql.Date(0) + ")");

	    //InsertSkillLevels
	    int uBound = randomInt(6);
	    //System.out.println("\n Ubound: " + uBound + "\n");
	    for (int j = 0; j < uBound; j++) {
		dbExecuteUpdate("INSERT INTO JobSkillLevel "
				+ "(JobID, QualificationID, Level) VALUES ('"
				+ i + "', '" + randomInt(10) + "', '" + randomInt(5) + "')");		
	    }
	}
    }

    private void FillNotifications() {
	//
    }

    private void FillQualifications() throws Exception{
	//
	for (int i = 0; i < 10; i++) {
	    dbExecuteUpdate("INSERT INTO Qualification (ID, Name, Description) "
			    + "VALUES ('" + i + "', '" + qualifications[i] + "', '" + qualifications[i] + "')");
	}
    }

    private void FillMatches() throws Exception {
	//
	//	PerformMatch pm = PerformMatch();
	for (int i = 0; i < 15; i++) {
	    PerformMatch.matchJob(i);
	}
    }

    private void ResetDB() throws Exception {
	dbExecuteUpdate("DELETE FROM Applicant");
	dbExecuteUpdate("DELETE FROM ApplicantSkillLevel;");
	dbExecuteUpdate("DELETE FROM Job;");
	dbExecuteUpdate("DELETE FROM Application;");
	dbExecuteUpdate("DELETE FROM JobSkillLevel;");
	dbExecuteUpdate("DELETE FROM Matches;");
	dbExecuteUpdate("DELETE FROM Notification;");
	dbExecuteUpdate("DELETE FROM Project;");
	dbExecuteUpdate("DELETE FROM Qualification;");
	dbExecuteUpdate("DELETE FROM Users WHERE ID <> 0;"); 
    }

    public static void main(String[] args) throws Exception {
	FillData fd = new FillData();
	String tmp = "";
	
	fd.ResetDB();
	//System.out.println("DB reset...");

	if (args.length > 0)
	    tmp = args[0];

	if (tmp == "-r" || tmp == "-reset" || tmp == "reset" ||
	    tmp == "-d" || tmp == "-delete" || tmp == "delete")
	    fd.ResetDB();
	else {
	    fd.initiateArrays();
	    //System.out.println("Arrays initiated... \n Filling qualifications...");
	    fd.FillQualifications();
	    //System.out.println("Qualifications filled... \n Filling users...");
	    fd.FillUsers();
	    //System.out.println("Users filled... \n Filling projects...");
	    //	    fd.FillApplicants();
	    fd.FillProjects();
	    //System.out.println("Projects Filled... \n Filling jobs...");
	    fd.FillJobs();
	    //System.out.println("Jobs Filled... \n Filling Matches...");
	    fd.FillMatches();
	    //System.out.println("Matches filled... \n Filling applications...");
	    fd.FillApplications();
	    //System.out.println("Applications filled... \n Filling notifications...");
	    fd.FillNotifications();
	    //System.out.println("Notifications filled ;-)");
	}	     
	/* Has to be here, to make it work... */
	System.gc();
    }
}

/** ConnectionMgr.java
 * @author <a href="mailto:ahlmann@cs.auc.dk">Kristian Ahlmann-Ohlsen</a>
 * @version $Revision: 1.4 $
*/ 
class ConnectionManager{
    //Singleton variables
    private static ConnectionManager connMgr = null;
    private static Connection con = null;

    //Connection related variables
    private String driver;
    private String user;
    private String pass;
    private String jdbcURL;
    
    /**
     * Private constructor, ensuring that no one, but this class, can instantiate this class
     * @since 1.0
     */
    private ConnectionManager() {
	setDBInfo();
    }
    
    /**
     * Setting required variables when an instance of this class is created
     * @since 1.0
     */
    private void setDBInfo(){
	jdbcURL = "jdbc:mysql://192.168.195.26/whiner";
	driver = "com.mysql.jdbc.Driver";
	user = "root";
	pass = "";   
    }

    /**
     * Opens a connection to the database
     * @since 1.0
     */
    private void openConnection() throws Exception {

	try {
	    Class.forName(driver);
	} catch (ClassNotFoundException e) {
	    throw new Exception("ConnectionManager:openConnection:class.forname failed");
	}

	try {
	    con = DriverManager.getConnection(jdbcURL, user, pass);
	}catch (SQLException e) {
	    System.out.println("SQL whineage: " + e.getMessage());
	    throw new Exception("ConnectionManager:openConnection:DriverManager.getConnection failed");
	}
    }

    /*
     * @since 1.0
     * @return Returns a connection object
     */
    public Connection connect() throws Exception {
	try{
	    if (con == null || con.isClosed()) {
		openConnection();
	    }
	} catch (SQLException e) {
	    throw new Exception("ConnectionManager:connect:connection.isclosed failed");
	} catch (Exception e) {
	    throw new Exception("ConnectionManager:connect:openConnection failed", e);
	}
	return con;
    }

    /**
     * @since 1.0
     * @return Returns an instance of this class
     */
    public static ConnectionManager getInstance() {
	if (connMgr == null) {
	    connMgr = new ConnectionManager();
	}
	return connMgr;
    }
}
