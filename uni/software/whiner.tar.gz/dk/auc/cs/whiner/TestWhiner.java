//package dk.auc.cs.whiner;

import java.sql.*;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.rmi.RemoteException;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.function.*;

public class TestWhiner extends TestCase{

    public static Test suite() {
	
	TestSuite suite = new TestSuite();

	// dataaccess
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestSearchDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestMatchesDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestJobDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestProjectDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestAdministratorDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestApplicantDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestApplicationDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestHeadhunterDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestNotificationDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestQualificationDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestRegisterDAO.class));


	// model
	suite.addTest(new TestSuite(dk.auc.cs.whiner.model.TestApplicant.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.model.TestApplication.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.model.TestAdministrator.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.model.TestJob.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.model.TestProject.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.model.TestQualification.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.model.TestHeadhunter.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.model.TestCV.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.model.TestMatch.class));

	// function
     	suite.addTest(new TestSuite(dk.auc.cs.whiner.function.TestPerformMatch.class));
     	suite.addTest(new TestSuite(dk.auc.cs.whiner.function.TestSearch.class));
     	suite.addTest(new TestSuite(dk.auc.cs.whiner.function.TestLogin.class));
     	suite.addTest(new TestSuite(dk.auc.cs.whiner.function.TestRegister.class));
     	suite.addTest(new TestSuite(dk.auc.cs.whiner.function.TestNotify.class));

	return suite;
		      
    }

}
