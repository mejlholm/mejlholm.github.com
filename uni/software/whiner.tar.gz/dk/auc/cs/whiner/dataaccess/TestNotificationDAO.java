package dk.auc.cs.whiner.dataaccess;

import java.util.ArrayList;
import java.sql.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.RMIException;

/** 
 * Unit test for the {@link NotificationDAO} class
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.4 $
 */
public class TestNotificationDAO extends TestCase {

    public void testAdd() throws DAOException, RMIException{

	NotificationDAO n = new NotificationDAO();

	int id1 = n.getValidDBEntry("Notification");
	Notification not1 = n.add();
	int id2 = n.getValidDBEntry("Notification");
	Notification not2 = n.add();

	assertEquals(id1, not1.getID());
	assertEquals(id2, not2.getID());
	/*
	assertEquals(0, not1.getApplicantID());
	assertEquals(0, not2.getApplicantID());
	assertEquals(0, not1.getJobID());
	assertEquals(0, not2.getJobID());
	assertEquals(null, not1.getNotificationType());
	assertEquals(null, not2.getNotificationType());
	assertEquals(null, not1.getDateOfDispatch());
	assertEquals(null, not2.getDateOfDispatch());
	*/
	n.delete(id1);
	n.delete(id2);
    }

    public void testDelete() throws DAOException, RMIException{

	NotificationDAO n = new NotificationDAO();

	int id1 = n.getValidDBEntry("Notification");
	Notification not1 = n.add();
	int id2 = n.getValidDBEntry("Notification");
	Notification not2 = n.add();

	n.delete(id1);
	n.delete(id2);

	try{
	    ResultSet rset = n.dbExecuteQuery("SELECT * FROM Notification WHERE ID=" + id1);
	    assertTrue("Assert that the Resultset is empty", rset.isBeforeFirst() == false);
	} catch (SQLException e){
	    //
	}

    }

    public void testDeleteNotifications() throws DAOException, RMIException{

	NotificationDAO n = new NotificationDAO();

	int id1 = n.getValidDBEntry("Notification");
	Notification not1 = n.add();
	not1.setID(id1);
	not1.setApplicantID(5);
	not1.setNotificationType("Job reopened");
	int id2 = n.getValidDBEntry("Notification");
	Notification not2 = n.add();
	not2.setID(id2);
	not2.setApplicantID(5);
	not2.setNotificationType("Job reopened");
	int id3 = n.getValidDBEntry("Notification");
	Notification not3 = n.add();
	not3.setID(id3);
	not3.setApplicantID(5);
	not3.setNotificationType("Job reopened");
	int id4 = n.getValidDBEntry("Notification");
	Notification not4 = n.add();
	not4.setID(id4);
	not4.setApplicantID(5);
	not4.setNotificationType("Job reopened");

	/*
	n.update(not1);
	n.update(not2);
	n.update(not3);
	n.update(not4);
	*/
	ArrayList al = new ArrayList();

	al.add(not1);
	al.add(not2);
	al.add(not3);
	al.add(not4);
	
	n.update(al);
	
	n.deleteNotifications(5);

	try{
	    ResultSet rset = n.dbExecuteQuery("SELECT * FROM Notification WHERE ApplicantID=" + 5);
	    assertTrue("Assert that the Resultset is empty", rset.isBeforeFirst() == false);
	} catch (SQLException e){
	    //
	}
    }


    public void testGetNotifications() throws DAOException, RMIException{

	NotificationDAO n = new NotificationDAO();

	int id1 = n.getValidDBEntry("Notification");
	Notification not1 = n.add();
	not1.setID(id1);
	not1.setApplicantID(5);
	not1.setNotificationType("Job reopened");
	int id2 = n.getValidDBEntry("Notification");
	Notification not2 = n.add();
	not2.setID(id2);
	not2.setApplicantID(5);
	not2.setNotificationType("Job reopened");
	int id3 = n.getValidDBEntry("Notification");
	Notification not3 = n.add();
	not3.setID(id3);
	not3.setApplicantID(5);
	not3.setNotificationType("Job reopened");
	int id4 = n.getValidDBEntry("Notification");
	Notification not4 = n.add();
	not4.setID(id4);
	not4.setApplicantID(5);
	not4.setNotificationType("Job reopened");

	ArrayList al = new ArrayList();
	ArrayList al2 = new ArrayList();

	al.add(not1);
	al.add(not2);
	al.add(not3);
	al.add(not4);
	
	n.update(al);
	/*
	n.update(not1);
	n.update(not2);
	n.update(not3);
	n.update(not4);
	*/

	al2 = n.getNotifications(5);

	Notification n0 = (Notification)al2.get(0);
	Notification n1 = (Notification)al2.get(1);
	Notification n2 = (Notification)al2.get(2);
	Notification n3 = (Notification)al2.get(3);	

	assertEquals(n3.getID(), not1.getID());
	assertEquals(n0.getApplicantID(), not1.getApplicantID());
	//	assertEquals(n0.getJobID(), not1.getJobID()); not tested
	assertEquals(n0.getNotificationType(), "Job reopened");
	assertEquals(n0.getBodyText(), "Hello the job you applied for some time ago has recently been reopened.");
	//assertEquals(n0.getDateOfDispatch(), not1.getDateOfDispatch());

	n.deleteNotifications(5);	    
    }    

    // They've all been tested by these methods, not gonna make anymore testcases

}
