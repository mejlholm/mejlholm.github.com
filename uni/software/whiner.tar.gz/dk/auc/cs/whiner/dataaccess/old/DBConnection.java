package dk.auc.cs.whiner.dataaccess;

import java.util.*;
//import java.io.*;
import java.sql.*;

/** DBConnection.java 
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.1 $
*/ 
class DBConnection {

    Connection con;

    /**
     * @since 1.0
     * @param void
     */
    DBConnection() {
	String driver = "com.mysql.jdbc.Driver";
	String host = "localhost";
	String db = "whiner";
	String user = "test";
	String pass = "tester";   

	try {
	    Class.forName(driver);
	    System.out.println("Found driver");
	}
	catch( java.lang.ClassNotFoundException e ) {
	    System.out.println("MySQL JDBC Driver not found ... ");
	}
	String url = "jdbc:mysql://" + host + "/" + db;
	try {
	    con = DriverManager.getConnection(url, user, pass);
	    System.out.println("Connection Established");
	}
	catch (Exception e)
	    {
		e.printStackTrace();
		System.out.println("Connection Failed...");
	    }
    }

    /**
     * @since 1.0
     * @param void
     * @return Returns a Connection
     */
    Connection makeConnection() {
	return con;
    }
    
    /**
     * @since 1.0
     * @param void
     * @return void
     */
    void closeConnection() {
	try {
	    con.close();
	    System.out.println("Connection closed");
	}
	catch (Exception e)
	    {
		e.printStackTrace();
		System.out.println("Error: Connection not closed");
	    }
    }

    /**
     * @since 1.6
     * @param A date following the sql date format
     * @return Returns a date following the util date format
     */
    java.util.Date sqlDateToUtilDate(java.sql.Date sqldate){
	long milidate = 0;
	milidate = sqldate.getTime();
	java.util.Date utildate = new java.util.Date(milidate);
	
	return utildate;
    }

    /**
     * @since 1.6
     * @param A date following the sql date format
     * @return Returns a date following the util date format
     */
    java.sql.Date utilDateToSQLDate(java.util.Date utildate){
	long milidate = 0;
	milidate = utildate.getTime();
	java.sql.Date sqldate = new java.sql.Date(milidate);

	return sqldate;
    }
}
