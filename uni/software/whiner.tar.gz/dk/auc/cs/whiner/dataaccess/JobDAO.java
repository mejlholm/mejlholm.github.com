package dk.auc.cs.whiner.dataaccess;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;

import java.rmi.RemoteException;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.model.Job;
import dk.auc.cs.whiner.model.Qualification;
import dk.auc.cs.whiner.model.SkillLevel;
import dk.auc.cs.whiner.interfaces.QualificationI;

/** Handles calls to the database regarding Jobs
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.55 $
*/ 
public class JobDAO extends DAOObject{

    private ResultSet rset = null;
    private ResultSet rsetkey = null;
    private String action = "";
    private Job j;

    /**
     * Default constructor,
     * No initialization.
     * @exception DAOException if an error occurs.
     */
    public JobDAO() throws DAOException {

    }

    /**
     * Retrieves a given <code>Job</code> object from the database.
     * @param id an <code>int</code> value representing the id of a job.
     * @return A <code>Job</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.5
     */
    public Job getJob(int id) throws DAOException{
	try {	    
	    action = "SELECT * FROM Job WHERE ID='" + id + "'";
	    rset = dbExecuteQuery(action); 
	} catch (DAOException e) {
	    throw new DAOException("JobDAO: getJob <dbExecuteQuery Error!>");
	}
	
	try {
	    j = new Job();
	} catch (RemoteException e) {
	    //smile
	}

	try {
	    while (rset.next()) {
		j.setID(id);
		j.setProjectID(rset.getInt("ProjectID"));
		j.setTitle(rset.getString("Title"));
		j.setDateOfAnnouncement(rset.getDate("DateOfAnnouncement"));
		j.setDateOfOccupation(rset.getDate("DateOfOccupation"));
		j.setDateOfCreation(rset.getDate("DateOfCreation"));
		j.setStatus(rset.getString("Status"));
		j.setDescription(rset.getString("Description"));
	    }
	} catch (SQLException e) {
	    throw new DAOException("JobDAO: getJob <Rset Error!>");
	} catch (RMIException r) {
	    // smile
	}
	return j;
    }


    /**
     * Deletes a <code>Job</code> object from the database based on a given id.
     * @param id an <code>int</code> value representing an id of a
     * job.
     * @exception DAOException if an error occurs.
     * @since 1.0
     */
    public void delete(int id) throws DAOException{
	try {
	    action = "DELETE FROM Job WHERE ID='" + id + "'";
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("JobDAO: delete <dbExecuteUpdate Error!>");
	}
    }


    /**
     * Adds a job to the database and returns a new <code>Job</code>
     * object with the id of the newly added job.
     * @return a <code>Job</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.4
     */
    public Job add() throws DAOException{

	int validDBEntry = getValidDBEntry("Job");
	try {
	    action = "INSERT INTO Job (ID) VALUES ('"+ validDBEntry +"')";
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("JobDAO: add <dbExecuteUpdate Error!>");
	}

	try {
	    rset = dbExecuteQuery("SELECT * FROM Job WHERE ID='" + validDBEntry + "'");
	} catch (DAOException e) {
	    throw new DAOException("JobDAO: add <dbExecuteQuery Error!>");
	}

	try {
	    this.j = new Job();
	} catch (RemoteException e) {
	    //smile
	}
	
	try{
	    while (rset.next()) {
		j.setID(rset.getInt("ID"));
	    }
	} catch (SQLException e) {
	    throw new DAOException("JobDAO: add <Rset Error!>");
	} catch (RMIException r) {
	    // smile
	}
	return j;
    }


    /**
     * Updates a given a specific job in the database.
     * @param j a <code>Job</code> object that should be updated.
     * @exception DAOException if an error occurs.
     * @since 1.4
     */
    public void update(Job j)  throws DAOException{
	try{
	    action ="SELECT * FROM Job WHERE ID=" + j.getID();

	    rset = dbExecuteQuery(action, true);
	} catch (DAOException e) {
	    throw new DAOException("JobDAO: update <Rset Error!>");
	} catch (RMIException r) {
	    //smile
	}


	try{
	    while (rset.next()) {
		rset.updateInt("ID", j.getID());
		rset.updateInt("ProjectID", j.getProjectID());
		rset.updateString("Title", j.getTitle());
		rset.updateTimestamp("DateOfAnnouncement", utilDateToSQLTimestamp(j.getDateOfAnnouncement()));
		rset.updateTimestamp("DateOfOccupation", utilDateToSQLTimestamp(j.getDateOfOccupation()));
		rset.updateTimestamp("DateOfCreation", utilDateToSQLTimestamp(j.getDateOfCreation()));
		rset.updateString("Status", j.getStatus());
		rset.updateString("Description", j.getDescription());
		rset.updateRow();
	    }
	} catch (SQLException e) {
	    throw new DAOException("JobDAO: update <Rset.update Error!>");
	} catch (RMIException r) {
	    // smile
	}
    }

    
    /**
     * Retrieves all the jobs that are a part of a given project and
     * returns them in an <code>ArrayList</code>.
     * @param projectID an <code>int</code> value representing an id of a project.
     * @return <code>ArrayList</code> of Jobs.
     * @exception DAOException if an error occurs.
     * @since 1.7
     */
    public ArrayList getJobs(int projectID) throws DAOException{
	try {
	    action = "SELECT * FROM Job WHERE ProjectID='" + projectID + "'";
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("JobDAO: getJobs <dbExecuteQuery Error!>");
	}
	
	ArrayList al = new ArrayList();

	try {
	    while (rset.next()) {

		try {
		    j = new Job();
		} catch (RemoteException e) {
		    //smile
		}
		
		j.setID(rset.getInt("ID"));
		j.setProjectID(rset.getInt("ProjectID"));
		j.setTitle(rset.getString("Title"));
		j.setDateOfAnnouncement(rset.getDate("DateOfAnnouncement"));
		j.setDateOfOccupation(rset.getDate("DateOfOccupation"));
		j.setDateOfCreation(rset.getDate("DateOfCreation"));
		j.setStatus(rset.getString("Status"));
		j.setDescription(rset.getString("Description"));
		
		al.add(j);
	    }
	} catch (SQLException e) {
	    throw new DAOException("JobDAO: getJobs <Rset Error!>");
	} catch (RMIException r) {
	    // smile
	}	
	return al;
    }


    /**
     * Retrieves all the <code>SkillLevel</code> objects that belong
     * to a specific job.
     * @param jobID an <code>int</code> value representing an id of a
     * job.
     * @return <code>ArrayList</code> of <code>SkillLevel</code> objects.
     * @exception DAOException if an error occurs.
     * @since 1.28
     */
    public ArrayList getSkillLevels(int jobID) throws DAOException {
	
	try{
	    action = "SELECT * FROM JobSkillLevel WHERE JobID=" + jobID;
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("JobDAO: getSkillLevels <dbExecuteQuery Error!>");
	}
	
	ArrayList al = new ArrayList();
	
	try{
	    while (rset.next()){
		SkillLevel sl = new SkillLevel();
		
		int qualificationID = rset.getInt("QualificationID");
		sl.setID(jobID);
		sl.setLevel(rset.getInt("Level"));
		
		ResultSet rset2 = dbExecuteQuery("SELECT * FROM Qualification WHERE ID=" + qualificationID);
		
		while (rset2.next()) {
		    Qualification q = new Qualification();
		    q.setID(qualificationID);
		    q.setName(rset2.getString("Name"));
		    q.setDescription(rset2.getString("Description"));
		    sl.setQualification((QualificationI) q);
		}
		al.add(sl);
	    }
	} catch (SQLException e) {
	    throw new DAOException("JobDAO: getSkillLevels <Complex Rset Error!>");
	} catch (Exception e) {
	    //RMIException
	}
	return al;
    }


    /**
     * Takes a <code>SkillLevel</code> object, attached to a job, and
     * inserts it into the database.
     * @param sl a <code>SkillLevel</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.28
     */
    public void insertSkillLevel(SkillLevel sl) throws DAOException{
	try {
	    int jobID = sl.getID();
	    int level = sl.getLevel();
	    Qualification q = (Qualification)sl.getQualification();
	    int qualificationID = q.getID();
	    
	    action = "INSERT INTO JobSkillLevel (JobID, QualificationID, Level) VALUES (" 
		+ jobID + "," + qualificationID+ "," + level + ")";
	    
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("JobDAO: insertSkillLevel <dbExecuteUpdate Error!>");
	} catch (Exception e) {
	    //RMIException
	}
    }


    /**
     * Takes a <code>SkillLevel</code> object, attached to a job, and
     * deletes it from the database.
     * @param sl a <code>SkillLevel</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.28
     */
    public void deleteSkillLevel(SkillLevel sl) throws DAOException{
	try{
	    int jobID = sl.getID();
	    Qualification q = (Qualification)sl.getQualification();
	    int qualificationID = q.getID();
	    
	    action = "DELETE FROM JobSkillLevel WHERE JobID=" 
		+ jobID + " AND QualificationID=" + qualificationID;
	    dbExecuteUpdate(action);

	} catch (DAOException e) {
	    throw  new DAOException("JobDAO: deleteSkillLevel <dbExecuteUpdate Error!>");
	} catch (Exception e) {
	    //RMIException
	}
    }

}
