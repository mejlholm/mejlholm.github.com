package dk.auc.cs.whiner.dataaccess;

import java.sql.*;
import java.util.Date;
import java.util.ArrayList;

import dk.auc.cs.whiner.model.Application;

/** Handles database calls for Application details
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.40 $
*/ 
public class ApplicationDAO extends DAOObject{

    /**
     * Default constructor
     * No initialization
     * @exception DAOException if an error occurs
     * @since 1.0
     */
    public ApplicationDAO() throws DAOException{

    }

    private String action = "";
    private ResultSet rset = null;

    /**
     * Retreives an <code>Application</code> object from the database
     * based on an id of the application.
     * @param id an <code>int</code> value
     * @return <code>Application</code> Object.
     * @exception DAOException if an error occurs.
     * @since 1.7
     */
    public Application getApplication(int id) throws DAOException{

	try {
	    action = "SELECT * FROM Application WHERE ID='" + id + "'";
	    rset = dbExecuteQuery(action);
	} catch (DAOException e){
	    throw new DAOException("ApplicationDAO: getApplication <dbExecuteQuery ERROR!>");
	}
	
	Application a = null;
	
	try{
	    a = new Application();

	    while (rset.next()) {	    
		a.setID(rset.getInt("ID"));
		a.setApplicantID(rset.getInt("ApplicantID"));
		a.setJobID(rset.getInt("JobID"));
		a.setStatus(rset.getString("Status"));
		a.setDateOfCreation(rset.getDate("DateOfCreation"));
		a.setDateOfSubmission(rset.getDate("DateOfSubmission"));
		a.setDateOfRejection(rset.getDate("DateOfRejection"));
		a.setBodyText(rset.getString("BodyText"));
	    }

	} catch (SQLException e){
	    throw new DAOException("ApplicationDAO: getApplication <Rset ERROR!>");
	} catch (Exception e) {
	    //RMIException
	}

	return a;	    
    }
	

    /**
     * Deletes an application from the database based on an application id
     * @param id an <code>int</code> value representing the id of an
     * application.
     * @exception DAOException if an error occurs.
     * @since 1.0
     */
    public void delete(int id) throws DAOException{
	
	try{
	    action = "DELETE FROM Application WHERE ID='" + id + "'";
	    dbExecuteUpdate(action);
	} catch (DAOException e){
	    throw new DAOException("ApplicationDAO: delete <dbExecuteUpdate Error!>");
	}
    }


    /**
     * Adds an empty <code>Application</code> object to the database
     * and retrieves it's id.
     * @return An <code>Application</code> Object
     * @exception DAOException if an error occurs.
     * @since 1.7
     */
    public Application add() throws DAOException{

	int validDBEntry = getValidDBEntry("Application");

	try{
	    action = "INSERT INTO Application (ID) VALUES ('" + validDBEntry + "')";
	    dbExecuteUpdate(action);
	} catch (DAOException e){
	    throw new DAOException("ApplicationDAO: add <dbExecuteUpdate Error!>");
	}

	try {
	    rset = dbExecuteQuery("SELECT * FROM Application WHERE (ID)='" + validDBEntry + "'");
	} catch (DAOException e){
	    throw new DAOException("ApplicationDAO: add <dbExecuteQuery Error!>");
	}

	Application a = null;

	try {
	    a = new Application();

	    while (rset.next()){
		a.setID(rset.getInt("ID"));
	    }
	} catch (SQLException e) {
	    throw new DAOException("ApplicationDAO: add <Rset Error!>");
	} catch (Exception e) {
	    //RMIException
	}

	return a;
    }



    /**
     * Updates an <code>Application</code> object in the database
     * @param a an <code>Application</code> value.
     * @exception DAOException if an error occurs.
     * @since 1.0
     */
    public void update(Application a) throws DAOException{
	try {
	    action ="SELECT * FROM Application WHERE ID=" + a.getID();
	    rset = dbExecuteQuery(action, true);
	    
	    while (rset.next()) {
		rset.updateInt("ID", a.getID());
		rset.updateInt("ApplicantID", a.getApplicantID());
		rset.updateInt("JobID", a.getJobID());
		rset.updateString("Status", a.getStatus());
		rset.updateTimestamp("DateOfCreation", utilDateToSQLTimestamp(a.getDateOfCreation()));
		rset.updateTimestamp("DateOfRejection", utilDateToSQLTimestamp(a.getDateOfRejection()));
		rset.updateTimestamp("DateOfSubmission", utilDateToSQLTimestamp(a.getDateOfSubmission()));
		rset.updateString("BodyText", a.getBodyText());
		rset.updateRow();
	    }
	} catch (SQLException e){
	    throw new DAOException("ApplicationDAO: update <Rset.update Error!>");
       	} catch (DAOException e){
	    throw new DAOException("ApplicationDAO: update <dbExecuteQuery Error!>");
	} catch (Exception e) {
	    //RMIException
	}	

    }
    

    /**
     * Retrieves all the <code>Application</code> objects in the
     * database that has a specific id
     * @param id an <code>int</code> value
     * @return Returns an <code>ArrayList</code> containing
     * <code>Application</code> objects.
     * @exception DAOException if an error occurs.
     * @since 1.7
     */
    public ArrayList getApplicationsFromJobID(int id) throws DAOException{
	try {
	    action = "SELECT * FROM Application WHERE JobID='" + id + "' ORDER BY ID ASC";
	    rset = dbExecuteQuery(action);
	} catch (DAOException e){
	    throw new DAOException("ApplicationDAO: getApplicationsFromJobID <dbExecuteQuery Error!>");
	}

	ArrayList al = new ArrayList();
	
	try{
	    while (rset.next()) {
		Application a = new Application();
		
		a.setID(rset.getInt("ID"));
		a.setApplicantID(rset.getInt("ApplicantID"));
		a.setJobID(rset.getInt("JobID"));
		a.setStatus(rset.getString("Status"));
		a.setDateOfCreation(rset.getDate("DateOfCreation"));
		a.setDateOfRejection(rset.getDate("DateOfRejection"));
		a.setDateOfSubmission(rset.getDate("DateOfSubmission"));	    
		a.setBodyText(rset.getString("BodyText"));
		al.add(a);
	    }
	} catch (SQLException e){
	    throw new DAOException("ApplicationDAO: getApplicationsFromJobID <Rset Error!>");
	} catch (Exception e) {
	    //RMIException
	}
	return al;
    }


    /**
     * Retrieves all the <code>Application</code> objects in the
     * database that belong to a certain applicant.
     * @param id an <code>int</code> value representing the id of an
     * applicant.
     * @return <code>ArrayList</code> of applications.
     * @exception DAOException if an error occurs.
     * @since 1.27
     */
    public ArrayList getApplicationsFromApplicantID(int id) throws DAOException{
	try {
	    
	    action = "SELECT * FROM Application WHERE ApplicantID='" + id + "' ORDER BY ID ASC";
	    rset = dbExecuteQuery(action);
	} catch (DAOException e){
	    throw new DAOException("ApplicationDAO: getApplicationsFromApplicantID <dbExecuteQuery Error!>");
	}

	ArrayList al = new ArrayList();
	
	try{
	    while (rset.next()) {
		Application a = new Application();
		
		a.setID(rset.getInt("ID"));
		a.setApplicantID(rset.getInt("ApplicantID"));
		a.setJobID(rset.getInt("JobID"));
		a.setStatus(rset.getString("Status"));
		a.setDateOfCreation(rset.getDate("DateOfCreation"));
		a.setDateOfRejection(rset.getDate("DateOfRejection"));
		a.setDateOfSubmission(rset.getDate("DateOfSubmission"));	    
		a.setBodyText(rset.getString("BodyText"));
		al.add(a);
	    }
	} catch (SQLException e){
	    throw new DAOException("ApplicationDAO: getApplicationsFromApplicantID <Rset Error!>");
	} catch (Exception e) {
	    //RMIException
	}

	return al;
    }

    /**
     * Returns the applicant requirementscore for the specific job and
     * applicant.
     * @param appid an <code>int</code> value representing an applicant.
     * @param jobid an <code>int</code> value representing a job.
     * @return <code>int</code> the requirement score.
     * @exception DAOException if an error occurs.
     * @since 1.36
     */
    public int getRequirementScore(int appid, int jobid) throws DAOException{
	int retVal = 0;
	action = "SELECT RequirementScore FROM Matches WHERE ApplicantID='" + appid + "' AND JobID='" + jobid + "'";
	
	try {
	    rset = dbExecuteQuery(action);
	
	    while (rset.next()) {
		retVal = rset.getInt("RequirementScore");
	    }
	} catch (SQLException e) {
	    throw new DAOException("ApplicationDAO:getRequirementScore:Resultset failed");
	} catch (DAOException e) {
	    throw new DAOException("ApplicationDAO:getRequirementScore:Executing Query");
	}

	return retVal;
    }
}
