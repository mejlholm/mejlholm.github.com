package dk.auc.cs.whiner.dataaccess;

import java.util.Date;
import java.util.ArrayList;
import java.sql.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.RemoteException;

/** 
 * Unit test for the {@link ApplicantDAO} class
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.9 $
 */
public class TestApplicantDAO extends TestCase {

    public void testAdd() throws DAOException, RMIException, RemoteException{

	ApplicantDAO ad = new ApplicantDAO();

	int id1 = ad.getValidDBEntry("Users");
	Applicant a = ad.add();

	// the attributes strictly on the Applicant object
	assertEquals(id1, a.getID());
	/*
	assertEquals(null, a.getLastLogin());
	assertEquals(null, a.getDateOfInterest());
	assertEquals("null", a.getEmail());
	a.setLoginName("Birthe");
	assertEquals("Birthe", a.getLoginName());
	assertEquals("", a.getPassword());

	// the attributes on the CV object
	CV cv = a.getCV();

	assertEquals(cv.getApplicantID(), a.getID());
	assertEquals(null, cv.getDateOfBirth());
	assertEquals(null, cv.getSex());
	assertEquals("single", cv.getMaritalStatus());
	assertEquals(null, cv.getEducation());
	assertEquals(null, cv.getWorkingExperience());
	assertEquals(null, cv.getReEducation());
	assertEquals(null, cv.getLanguageSkills());
	assertEquals(null, cv.getOtherITKnowledge());
	assertEquals(null, cv.getSpareTimeInterests());

	//Name
	assertEquals("null", a.name.getFirstName());
	assertEquals("null", a.name.getMiddleName());
	assertEquals("null", a.name.getLastName());

	//Address
	assertEquals(null, a.address.getAddress1());
	assertEquals(null, a.address.getAddress2());
	assertEquals("null", a.address.getCity());
	assertEquals(0, a.address.getPostCode());
	assertEquals("null", a.address.getRegion());
	assertEquals("null", a.address.getCountry());

	// PhoneNumber
	assertEquals(0, a.phoneNumber.getHomePhone());
	assertEquals(0, a.phoneNumber.getWorkPhone());
	assertEquals(0, a.phoneNumber.getMobile());
	assertEquals(0, a.phoneNumber.getFax());
	*/
	ad.delete(a.getID());

    }

    public void testDelete() throws DAOException, RMIException, RemoteException{

	ApplicantDAO ad = new ApplicantDAO();

	int id1 = ad.getValidDBEntry("Users");
	Applicant a1 = ad.add();
	int id2 = ad.getValidDBEntry("Users");
	Applicant a2 = ad.add();
	a2.setLoginName("Fisk");
	ad.update(a2);

	ad.delete(a1.getID());
	ad.delete(a2.getLoginName());
	
	try{
	    ResultSet rset = ad.dbExecuteQuery("SELECT * FROM Users WHERE ID=" + id1);
	    ResultSet rset2 = ad.dbExecuteQuery("SELECT * FROM Applicant WHERE ID=" + id1);
	    ResultSet rset3 = ad.dbExecuteQuery("SELECT * FROM Users WHERE LoginName='Fisk'");
	    assertTrue("Assert that the Resultset is empty", rset.isBeforeFirst() == false);
	    assertTrue("Assert that the Resultset is empty", rset2.isBeforeFirst() == false);
	    assertTrue("Assert that the Resultset is empty", rset3.isBeforeFirst() == false);
	} catch (SQLException e){

	}

    }



    public void testUpdate() throws DAOException, RMIException, RemoteException{

	ApplicantDAO ad = new ApplicantDAO();

	int id1 = ad.getValidDBEntry("Users");
	Applicant a = ad.add();

	a.setLastLogin(new Date());
	a.setDateOfInterest(new Date());
	a.setEmail("fisk@fisk.dk");
	a.setLoginName("Willy");
	a.setPassword("Vildere");

	CV cv = new CV();

	cv.setApplicantID(id1);
	cv.setDateOfBirth(new Date());
	cv.setSex("female");
	cv.setMaritalStatus("single");
	cv.setEducation("3. grade");
	cv.setWorkingExperience("The Sandbox");
	cv.setReEducation("Det hvide snit");
	cv.setLanguageSkills("italian");
	cv.setOtherITKnowledge("BASIC");
	cv.setSpareTimeInterests("Swinging");

	a.name.setFirstName("Brian");
	a.name.setMiddleName("Frank");
	a.name.setLastName("Pedersen");

	a.address.setAddress1("noroad 1");
	a.address.setAddress2("noroad 2");
	a.address.setCity("Gj�l");
	a.address.setPostCode(42);
	a.address.setRegion("Outskirts");
	a.address.setCountry("The otherside");

	a.phoneNumber.setHomePhone(809237);
	a.phoneNumber.setWorkPhone(82436);
	a.phoneNumber.setMobile(35825);
	a.phoneNumber.setFax(36645);

	a.setCV(cv);

	ad.update(a);
	ad.update(cv);

	Applicant a2 = ad.getApplicant(a.getID());

	assertEquals(a2.getID(), a.getID());
	//assertEquals(a2.getLastLogin(), a.getLastLogin());
	//assertEquals(a2.getDateOfInterest(), a.getDateOfInterest());
	assertEquals(a2.getEmail(), a.getEmail());
	//assertEquals(a2.getLoginName(), a.getLoginName());
	//assertEquals(a2.getPassword(), a.getPassword());

	// the attributes on the CV object
	CV cv2 = (CV)a.getCV();

	assertEquals(cv.getApplicantID(), cv2.getApplicantID());
	assertEquals(cv.getDateOfBirth(), cv2.getDateOfBirth());
	assertEquals(cv.getSex(), cv2.getSex());
	assertEquals(cv.getMaritalStatus(), cv2.getMaritalStatus());
	assertEquals(cv.getEducation(), cv2.getEducation());
	assertEquals(cv.getWorkingExperience(), cv2.getWorkingExperience());
	assertEquals(cv.getReEducation(), cv2.getReEducation());
	assertEquals(cv.getLanguageSkills(), cv2.getLanguageSkills());
	assertEquals(cv.getOtherITKnowledge(), cv2.getOtherITKnowledge());
	assertEquals(cv.getSpareTimeInterests(), cv2.getSpareTimeInterests());

	//Name
	assertEquals(a2.name.getFirstName(), a.name.getFirstName());
	assertEquals(a2.name.getMiddleName(), a.name.getMiddleName());
	assertEquals(a2.name.getLastName(), a.name.getLastName());

	//Address
	assertEquals(a2.address.getAddress1(), a.address.getAddress1());
	assertEquals(a2.address.getAddress2(), a.address.getAddress2());
	//assertEquals(a2.address.getCity(), a.address.getCity());
	assertEquals(a2.address.getPostCode(), a.address.getPostCode());
	assertEquals(a2.address.getRegion(), a.address.getRegion());
	assertEquals(a2.address.getCountry(), a.address.getCountry());

	// PhoneNumber
	assertEquals(a2.phoneNumber.getHomePhone(), a.phoneNumber.getHomePhone());
	assertEquals(a2.phoneNumber.getWorkPhone(), a.phoneNumber.getWorkPhone());
	assertEquals(a2.phoneNumber.getMobile(), a.phoneNumber.getMobile());
	assertEquals(a2.phoneNumber.getFax(), a.phoneNumber.getFax());


	ad.delete(a.getID());

    }

    public void testInsertSkillLevels() throws DAOException, RMIException, RemoteException{

	ApplicantDAO ad = new ApplicantDAO();

	SkillLevel sl = new SkillLevel();
	Qualification qa = new Qualification();

	qa.setID(4);

	sl.setID(3);
	sl.setQualification(qa);
	sl.setLevel(5);
	ad.insertSkillLevel(sl);

	int id1 = sl.getID();

	Qualification q = (Qualification)sl.getQualification();
	int id2 = q.getID();
	
	assertEquals(3, sl.getID());
	assertEquals(5, sl.getLevel());
	assertEquals(4, q.getID());

	ad.deleteSkillLevel(sl);

	try{
	    ResultSet rset = ad.dbExecuteQuery("SELECT * FROM ApplicantSkillLevel WHERE UserID=" + id1 + " AND QualificationID=" + id2);
	    assertTrue("Assert that the Resultset is empty", rset.isBeforeFirst() == false);
	} catch (SQLException e){

	}

    }

    public void testDeleteSkillLevels() throws DAOException, RMIException, RemoteException{
	// trivially tested above
    }

    public void testGetSkillLevels() throws DAOException, RMIException, RemoteException{

	ApplicantDAO ad = new ApplicantDAO();
	QualificationDAO qd = new QualificationDAO();

	SkillLevel sl1 = new SkillLevel();
	Qualification qa1 = qd.add();
	sl1.setID(5);
	sl1.setLevel(2);

	qa1.setName("Vildere");
	qa1.setDescription("Max");
	qd.update(qa1);
	sl1.setQualification(qa1);

	SkillLevel sl2 = new SkillLevel();
	Qualification qa2 = qd.add();
	sl2.setID(5);
	sl2.setLevel(2);

	qa2.setName("Vildere2");
	qa2.setDescription("Max2");
	qd.update(qa2);
	sl2.setQualification(qa2);

	SkillLevel sl3 = new SkillLevel();
	Qualification qa3 = qd.add();
	sl3.setID(5);
	sl3.setLevel(2);

	qa3.setName("Vildere3");
	qa3.setDescription("Max3");
	qd.update(qa3);
	sl3.setQualification(qa3);

	ad.insertSkillLevel(sl1);
	ad.insertSkillLevel(sl2);
	ad.insertSkillLevel(sl3);

	ArrayList al = ad.getSkillLevels(5);

	SkillLevel s1 = (SkillLevel)al.get(0);
	SkillLevel s2 = (SkillLevel)al.get(1);
	SkillLevel s3 = (SkillLevel)al.get(2);

	assertEquals(sl1.getID(), s1.getID());
	assertEquals(sl1.getLevel(), s1.getLevel());

	ad.deleteSkillLevel(sl1);
	ad.deleteSkillLevel(sl2);
	ad.deleteSkillLevel(sl3);

	qd.delete(qa1.getID());
	qd.delete(qa2.getID());
	qd.delete(qa3.getID());

    }

    public void testGetLoginNames() throws DAOException, RMIException, RemoteException{

	ApplicantDAO ad = new ApplicantDAO();

	Applicant a1 = ad.add();
	a1.setLoginName("Birthe");
	ad.update(a1);

	Applicant a2 = ad.add();
	a2.setLoginName("Anders");
	ad.update(a2);

	Applicant a3 = ad.add();
	a3.setLoginName("Kim");
	ad.update(a3);

	ArrayList al = ad.getLoginNames();

	assertEquals((String)al.get(0), a1.getLoginName());
	assertEquals((String)al.get(1), a2.getLoginName());
	assertEquals((String)al.get(2), a3.getLoginName());
	assertEquals(3, al.size());

	ad.delete(a1.getID());
	ad.delete(a2.getID());
	ad.delete(a3.getID());

    }

}
