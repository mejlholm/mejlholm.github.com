package dk.auc.cs.whiner.dataaccess;
/* ApplicantDAO */

import java.sql.*;
import java.util.ArrayList;
import java.rmi.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.*;

/** Handles calls to the database regarding Applicants.
 * @author <a href="mailto:ahlmann@cs.auc.dk">Kristian Ahlmann-Ohlsen</a>
 * @version $Revision: 1.72 $
*/ 
public class ApplicantDAO extends UserDAO{

    private ResultSet rset = null;
    private String action = "";

    /**
     * Creates a new <code>ApplicantDAO</code> instance.
     *
     * @exception DAOException if an error occurs
     * @since 1.5
     */
    public ApplicantDAO() throws DAOException{

    }

    /**
     * Adds an Applicant entity to the database and returns an <code>Applicant</code> object.
     * @return <code>Applicant</code> Object with the ID of the
     * corresponding object in the database.
     * @exception DAOException if an error occurs.
     * @since 1.6
     */
    public Applicant add() throws DAOException{

	int userid;
	
	try{
	    /* Call superclass addUser to get new user ID - likewise make sure
	     * that no one with the same username exist 
	     */
	    userid = addUser("applicant");
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:add:addUser failed", e);
	}

	action = "INSERT INTO Applicant (ID) VALUES ('" + userid + "')";

	try{
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:add:Executing update", e);
	}

	//Calls getapplicant method later in this class
	Applicant a = null;
	try{
	    // a = getApplicant(userid);
	    a = new Applicant();
	    a.setID(userid);
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:add:getApplicant failed", e);
	} catch (Exception r){
	    //Do Nothing
	}

	return a;
    }

    /**
     * Deletes an Applicant, given an id, from the database
     * @param id an <code>int</code> value, representing the id of an Applicant. 
     * @exception DAOException if an error occurs
     * @since 1.6
     */
    public void delete(int id) throws DAOException{

	try{
	    action = "DELETE FROM Applicant WHERE ID='" + id + "'";
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:delete:Execute query", e);

	}try{
	    super.delete(id);
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:delete:Superclass delete failed", e);
	}
    }

    /**
     * Deletes an Applicant, given a username, from the database
     * @param username a <code>String</code> value, representing the
     * login name of an Applicant.
     * @exception DAOException if an error occurs.
     * @since 1.5
     */
    public void delete(String username) throws DAOException{

	// Gets the id of the user from the username and deletes the user using the above method
	int id; 
	try{
	    id = getUserID(username);
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:delete:getUserID failed", e);
	}

	delete(id);
    }

    /**
     * Updates an Applicant object in the database.
     * @param a the <code>Applicant</code> object of an user in the system.
     * @exception DAOException if an error occurs
     * @since 1.5
     */
    public void update(Applicant a) throws DAOException{
	try{
	    action = "SELECT Applicant.* FROM Applicant "
		+ "WHERE Applicant.ID='" + a.getID() + "'";
	    	
	    /* Get updatable resultset */
	    rset = dbExecuteQuery(action, true);
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:update:ExecuteQuery error",e);
	} catch (RMIException e) {
	    //DO NOTHING
	}

	try{
	    while (rset.next()){
		rset.updateInt("ID", a.getID());
		rset.updateString("FirstName", a.name.getFirstName());
		rset.updateString("MiddleName", a.name.getMiddleName());
		rset.updateString("LastName", a.name.getLastName());
		rset.updateTimestamp("DateOfInterest", utilDateToSQLTimestamp(a.getDateOfInterest()));
		rset.updateString("Address1", a.address.getAddress1());
		rset.updateString("Address2", a.address.getAddress2());
		rset.updateInt("Postcode", a.address.getPostCode());
		rset.updateString("City", a.address.getCity());
		rset.updateString("Region", a.address.getRegion());
		rset.updateString("Country", a.address.getCountry());
		rset.updateTimestamp("LastLogin", utilDateToSQLTimestamp(a.getLastLogin()));
		rset.updateInt("HomePhone", a.phoneNumber.getHomePhone());
		rset.updateInt("WorkPhone", a.phoneNumber.getWorkPhone());
		rset.updateInt("Mobile", a.phoneNumber.getMobile());
		rset.updateInt("Fax", a.phoneNumber.getFax());
		rset.updateString("Email", a.getEmail());
		rset.updateRow();
	    }
	} catch (SQLException e) {
	    throw new DAOException("ApplicantDAO:update_applicant:ResultSet failed");
	} catch (RMIException e) {
	    //DO NOTHING
	}

	//update user table:
	try{
	    super.update((User) a);
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:update_applicant:Super.update failed", e);
	}
    }


    /**
     * Updates a <code>CV</code> object (a part of an application object) in the database
     * @param cv the <code>CV</code> object that is to be updated.
     * @exception DAOException if an error occurs.
     * @since 1.18
     */
    public void update(CV cv) throws DAOException{
	try{	
	    action = "SELECT Applicant.* FROM Applicant "
		+ "WHERE Applicant.ID='" + cv.getApplicantID() + "'";
	    
	    /* Updatable ResultSet */
	    rset = dbExecuteQuery(action, true);
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:update_cv:Executing query", e);
	} catch (RMIException e) {
	    //DO NOTHING
	}

	try{
	    while (rset.next()){		
		rset.updateString("Sex", cv.getSex());
		rset.updateTimestamp("DateOfBirth", utilDateToSQLTimestamp(cv.getDateOfBirth()));
		rset.updateString("MaritalStatus", cv.getMaritalStatus());
		rset.updateString("Education", cv.getEducation());
		rset.updateString("WorkingExperience", cv.getWorkingExperience());
		rset.updateString("ReEducation", cv.getReEducation());
		rset.updateString("LanguageSkills", cv.getLanguageSkills());
		rset.updateString("OtherITKnowledge", cv.getOtherITKnowledge());
		rset.updateString("SpareTimeInterests", cv.getSpareTimeInterests());
		rset.updateRow();
	    }
	} catch (SQLException e) {
	    throw new DAOException("ApplicantDAO:update_cv:ResultSet failed");
	} catch (RMIException e) {
	    //DO NOTHING
	}
    }

    /**
     * Retrieves an <code>Applicant</code> object from the database
     * based on a username.
     * @param username a <code>String</code> value representing the login name of a user.
     * @return Returns an applicant object (including a CV object).
     * @exception DAOException if an error occurs.
     * @since 1.5
     */
    public Applicant getApplicant(String username) throws DAOException{

	Applicant a = null;
	try{
	    int id = getUserID(username);
	    a = getApplicant(id);
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:getApplicant:Getting applicant", e);
	}catch (Exception r){
	    //Do Nothing
	}
	return a;
    }

    /**
     * Retrieves an <code>Applicant</code> object from the database, based on an id.
     * @param id an <code>int</code> value
     * @return Returns an applicant object (including a CV object).
     * @exception DAOException if an error occurs.
     * @since 1.5
     */
    public Applicant getApplicant(int id) throws DAOException{

	Applicant a = null;
	CV cv = null;

	try{
	    a = new Applicant();
	    cv = new CV();
	} catch(RemoteException r) {
	    //No action needed
	}

	action = "SELECT * FROM Applicant WHERE ID='" + id + "'";

	try{
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:getApplicant:Executing query", e);
	}

	try{
	    while (rset.next()) {
		a.setID(id);
		
		a.name.setFirstName(rset.getString("FirstName"));
		a.name.setMiddleName(rset.getString("MiddleName"));
		a.name.setLastName(rset.getString("LastName"));
		a.setDateOfInterest(sqlDateToUtilDate(rset.getDate("DateOfInterest")));
		a.address.setAddress1(rset.getString("Address1"));
		a.address.setAddress2(rset.getString("Address2"));
		a.address.setPostCode(rset.getInt("Postcode"));
		a.address.setCity(rset.getString("City"));
		a.address.setRegion(rset.getString("Region"));
		a.address.setCountry(rset.getString("Country"));
		a.setLastLogin(sqlDateToUtilDate(rset.getDate("LastLogin")));
		a.phoneNumber.setHomePhone(rset.getInt("HomePhone"));
		a.phoneNumber.setWorkPhone(rset.getInt("WorkPhone"));
		a.phoneNumber.setMobile(rset.getInt("Mobile"));
		a.phoneNumber.setFax(rset.getInt("Fax"));
		a.setEmail(rset.getString("Email"));
		//CV
		
		cv.setApplicantID(id);
		cv.setSex(rset.getString("Sex"));
		cv.setDateOfBirth(rset.getDate("DateOfBirth"));
		cv.setMaritalStatus(rset.getString("MaritalStatus"));
		cv.setEducation(rset.getString("Education"));
		cv.setWorkingExperience(rset.getString("WorkingExperience"));
		cv.setReEducation(rset.getString("ReEducation"));
		cv.setLanguageSkills(rset.getString("LanguageSkills"));
		cv.setOtherITKnowledge(rset.getString("OtherITKnowledge"));
		cv.setSpareTimeInterests(rset.getString("SpareTimeInterests"));

		a.setCV(cv);
	    }
	} catch (SQLException e) {
	    throw new DAOException("ApplicantDAO:getApplicant:ResultSet failed");
	} catch (RMIException e) {
	    //DO NOTHING
	}
	/* Set attributes stored in the users table */
	try{
	    rset = getUser(id);
	    
	    while (rset.next()) {
		a.setLoginName(rset.getString("LoginName"));
		a.setPassword(rset.getString("Password"));
	    }
	   
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:getApplicant:ResultSet failed for getUser", e);
	} catch (RMIException e) {
	    //DO NOTHING
	} catch (SQLException e) {
	    throw new DAOException("ApplicantDAO:getApplicant:ResultSet failed for getUser");
	}

	return a;
    }

    /**
     * Makes an <code>ArrayList</code> of <code>SkillLevel</code>
     * objects connected to an applicant
     * @param userID an <code>int</code> value
     * @return An <code>ArrayList</code> of <code>SkillLevel</code> Objects
     * @exception DAOException if an error occurs.
     * @since 1.14
     */
    public ArrayList getSkillLevels(int userID) throws DAOException{

	action = "SELECT * FROM ApplicantSkillLevel, Qualification "
	    + "WHERE UserID='" + userID + "' AND ID=ApplicantSkillLevel.QualificationID";

	try{
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:getSkillLevels:Executing query", e);
	}
	
	ArrayList al = new ArrayList();
	SkillLevel sl = null;
	Qualification q = null;
	
	try{

	    while (rset.next()) {
		sl = new SkillLevel();
		q = new Qualification();


		sl.setID(userID);
		sl.setLevel(rset.getInt("Level"));
		//Qualification object
		q.setName(rset.getString("Name"));
		q.setDescription(rset.getString("Description"));
		q.setID(rset.getInt("ID"));
		
		sl.setQualification(q);
		
		al.add(sl);
	    }
	} catch (SQLException e) {
	    throw new DAOException("ApplicantDAO:getSkillLevels:ResultSet failed");
	} catch (RMIException e) {
	    //DO NOTHING
	} catch (RemoteException r){
	    // Do Nothing
	}
	return al;
    }

    /**
     * Inserts a <code>SkillLevel</code> object into the database.
     * @param sl a <code>SkillLevel</code> value.
     * @exception DAOException if an error occurs.
     * @since 1.22
     */
    public void insertSkillLevel(SkillLevel sl) throws DAOException{

	Qualification q = null;
	try{
	    q =  (Qualification)sl.getQualification();
	    action = "INSERT INTO ApplicantSkillLevel "
		+ "(UserID, QualificationID, Level) VALUES ('"
		+ sl.getID() + "', '" + q.getID() + "', '" + sl.getLevel() + "')";
	    
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:insertSkillLevel:Executing update", e);
	} catch (RMIException e) {
	    //DO NOTHING
	}
    }

    /**
     * Deletes a <code>SkillLevel</code> object from the database.
     * @param sl a <code>SkillLevel</code> value.
     * @exception DAOException if an error occurs.
     * @since 1.22
     */
    public void deleteSkillLevel(SkillLevel sl) throws DAOException{

	Qualification q= null;
	try{
	    q = (Qualification)sl.getQualification();
	    action = "DELETE FROM ApplicantSkillLevel WHERE "
		+ "UserID='" + sl.getID() + "'"
		+ " AND QualificationID='" + q.getID() + "'"
		+ " AND Level='" + sl.getLevel() + "'";
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:deleteSkillLevel:Executing update", e);
	} catch (RMIException e) {
	    //DO NOTHING
	}
    }

    /**
     * Gets login names of all applicants contained in an <code>ArrayList</code>
     * @return Returns a list of all applicants
     * @exception DAOException if an error occurs.
     * @since 1.48
     */
    public ArrayList getLoginNames() throws DAOException{

	//returns a list of names... - very tricky stuff
	ArrayList al = new ArrayList();
	action = "SELECT * FROM Users WHERE Type='applicant' ORDER BY ID ASC";
	
	try{	
	    rset = dbExecuteQuery(action);
	    while (rset.next())
		al.add(rset.getString("LoginName"));
	} catch (DAOException e) {
	    throw new DAOException("ApplicantDAO:getLoginNames:Executing query", e);
	} catch (SQLException e) {
	    throw new DAOException("ApplicantDAO:getLoginNames:ResultSet failed");
	}
	return al;
    }

}
