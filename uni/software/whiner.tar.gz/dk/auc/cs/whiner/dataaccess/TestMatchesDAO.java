package dk.auc.cs.whiner.dataaccess;

import java.util.Date;
import java.util.ArrayList;
import java.sql.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.RemoteException;

/** 
 * Unit test for the {@link MatchesDAO} class
 * @author <a href="mailto:ahlmann@cs.auc.dk">Kristian Ahlmann-Ohlsen</a>
 * @version $Revision: 1.7 $
 */
public class TestMatchesDAO extends TestCase {
    JobDAO jDAO;
    ApplicantDAO aDAO;
    MatchesDAO mDAO;
    QualificationDAO qDAO;
    

    public TestMatchesDAO() throws Exception {
	jDAO = new JobDAO();
	aDAO = new ApplicantDAO();
	mDAO = new MatchesDAO();
	qDAO = new QualificationDAO();
    }

    public void setUp() throws Exception {
	/* Qualifications */
	Qualification q;

	//id = 0
	q = qDAO.add();
	q.setName("bj");
	q.setDescription("BlowJob");
	qDAO.update(q);

	//id = 1
	q = qDAO.add();
	q.setName("hj");
	q.setDescription("HandJob");
	qDAO.update(q);

	//id = 2
	q = qDAO.add();
	q.setName("da");
	q.setDescription("DoggyStyle");
	qDAO.update(q);

	//id = 3
	q = qDAO.add();
	q.setName("ea");
	q.setDescription("Eating");
	qDAO.update(q);

	//id = 4
	q = qDAO.add();
	q.setName("sm");
	q.setDescription("SMil");
	qDAO.update(q);
	    
	/* Applicants */
	Applicant a;
	
	//id = 0
	a = aDAO.add();	
	a.setLoginName("applicant1");
	aDAO.update(a);	  	
	
	//id = 1
	a = aDAO.add();
	a.setLoginName("applicant2");
	aDAO.update(a);	

	//id = 2
	a = aDAO.add();
	a.setLoginName("applicant3");
	aDAO.update(a);	

	/* Jobs */
	Job j;

	//id = 0
	j = jDAO.add();
	j.setTitle("job1");
	j.setStatus("announced");
	jDAO.update(j);

	//id = 1
	j = jDAO.add();
	j.setTitle("job2");
	j.setStatus("announced");
	jDAO.update(j);

	//id = 2
	j = jDAO.add();
	j.setTitle("job3");
	j.setStatus("announced");
	jDAO.update(j);
	
	/* Match */
	Match m;

	//id = 0
	m = mDAO.add();
	m.setApplicantID(0);
	m.setJobID(0);
	m.setRequirementScore(1);
	mDAO.update(m);

	//id = 1
	m = mDAO.add();
	m.setApplicantID(0);
	m.setJobID(1);
	m.setRequirementScore(2);
	mDAO.update(m);

	//id = 2
	m = mDAO.add();
	m.setApplicantID(1);
	m.setJobID(0);
	m.setRequirementScore(3);
	mDAO.update(m);

	/* SkillLevels */
	SkillLevel sk;
	//	Qualification q; - defined previously
	//Applicant 1 --> bj
	sk = new SkillLevel();
	sk.setID(0);
	sk.setLevel(1);
	q = (Qualification)sk.getQualification();
	q.setID(1);
	sk.setQualification(q);
	aDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(0);
	sk.setLevel(1);
	q = (Qualification)sk.getQualification();
	q.setID(2);
	sk.setQualification(q);
	aDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(0);
	sk.setLevel(1);
	q = (Qualification)sk.getQualification();
	q.setID(3);
	sk.setQualification(q);
	aDAO.insertSkillLevel(sk);

	//Applicant 2
	sk = new SkillLevel();
	sk.setID(1);
	sk.setLevel(2);
	q = (Qualification)sk.getQualification();
	q.setID(0);
	sk.setQualification(q);
	aDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(1);
	sk.setLevel(2);
	q = (Qualification)sk.getQualification();
	q.setID(1);
	sk.setQualification(q);
	aDAO.insertSkillLevel(sk);

	//Job 1
	sk = new SkillLevel();
	sk.setID(0);
	sk.setLevel(1);
	q = (Qualification)sk.getQualification();
	q.setID(0);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(0);
	sk.setLevel(1);
	q = (Qualification)sk.getQualification();
	q.setID(1);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

	//Job 2
	sk = new SkillLevel();
	sk.setID(1);
	sk.setLevel(2);
	q = (Qualification)sk.getQualification();
	q.setID(2);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(1);
	sk.setLevel(2);
	q = (Qualification)sk.getQualification();
	q.setID(3);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

	//Job 3
	sk = new SkillLevel();
	sk.setID(2);
	sk.setLevel(3);
	q = (Qualification)sk.getQualification();
	q.setID(4);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

    }

    public void tearDown() throws Exception {
	//System.out.println("\ntearDown...\n");
	DAOObject dao = null;

	try {
	    dao = new DAOObject(){};
	    //System.out.println("daoen blev hentet...");
	} catch (DAOException e) {
	    e.printStackTrace();
	}

	String action = "DELETE FROM ";

	dao.dbExecuteUpdate(action + "Job");
	dao.dbExecuteUpdate(action + "Applicant");
	dao.dbExecuteUpdate(action + "ApplicantSkillLevel");
	dao.dbExecuteUpdate(action + "JobSkillLevel");
	dao.dbExecuteUpdate(action + "Matches");
	dao.dbExecuteUpdate(action + "Qualification");
	dao.dbExecuteUpdate(action + "Users WHERE type NOT LIKE 'administrator'");
    }

    private DAOObject getDAOObject() {
	System.out.println("\ngetDAOObject...\n");
	DAOObject daob = null; 
	try{
	    daob = new DAOObject(){};
	} catch (DAOException e) {
	    // DO NOTHING
	    e.printStackTrace();
	}
	return daob;
    }

    public void testAdd() throws Exception {
	//System.out.println("\ntestAdd...\n");
	Match m1;
	Match m2;

	m1 = mDAO.add();
	m2 = mDAO.getMatch(m1.getID());
	assertTrue("When a match has been added, it should be retrievable", m1.getID() ==  m2.getID());
	
	//Test that they actually differ:
	m1 = mDAO.add();
	assertFalse("When assigning a new object to a variable "
		    + "it should not be the same as before", m1.getID() == m2.getID());
	    
    }

    public void testDelete() throws Exception {
	/* This method must be tested through the db, right? */
	//System.out.println("\ntestDelete...\n");
	//Delete Match 1
	assertNotNull(mDAO.getMatch(0));
	mDAO.delete(0);
	//assertNull(mDAO.getMatch(0));
	assertTrue(mDAO.getMatch(0).equals(new Match()));
	//Delete Match 2

	assertNotNull(mDAO.getMatch(1));
	mDAO.delete(1);
	assertTrue(mDAO.getMatch(1).equals(new Match()));

	//Delete non-existing match
	assertNotNull(mDAO.getMatch(847));
	mDAO.delete(847);
	assertTrue(mDAO.getMatch(847).equals(new Match()));
    }

    public void testGetMatch() throws Exception {
	//	System.out.println("\ntestGetMatch... \n");
	Match m;
	//Get Match 1 (0)
	m = mDAO.getMatch(0);
	assertTrue(m.getJobID() == 0);
	//Get Match 2 (1)
	m = mDAO.getMatch(1);
	assertTrue(m.getJobID() == 1);
	//Get non-existing match
	m = mDAO.getMatch(847);
	assertTrue(m.equals(new Match()));
    }

    public void testGetMatchedApplicants() throws Exception {
	ArrayList ma = null;
	Applicant a;
	//Get applicants for job 1
	ma = mDAO.getMatchedApplicants(0);
	assertNotNull(ma);
	assertTrue(ma.size() != 0);
	a = (Applicant) ma.get(0);
	assertTrue(a.getID() == 0); //Applicant 1
	a = (Applicant) ma.get(1);
	assertTrue(a.getID() == 1); //Applicant 2

	try{
	    ma.get(2);
	    fail("Exception didn't get catched");
	} catch (Exception e) {
	    //passed
	}

	//Get applicants for job 2
	ma = mDAO.getMatchedApplicants(1);
	assertNotNull(ma);
	a = (Applicant) ma.get(0);
	assertTrue(a.getID() == 0);

	//Get applicants for job 3 - with no applicants...
	ma = mDAO.getMatchedApplicants(2);
	assertTrue(ma.size() == 0);

	//Get Applicants for non-exsisting job 
	ma = mDAO.getMatchedApplicants(847);
	assertTrue(ma.size() == 0);
    }

    public void testGetMatchedJobs() throws Exception {
	ArrayList mj;
	Job j;
	//Get matched jobs for applicant 1
	mj = mDAO.getMatchedJobs(0);
	assertNotNull(mj);
	j = (Job) mj.get(0);
	assertTrue(j.getID() == 0);
	j = (Job) mj.get(1);
	assertTrue(j.getID() == 1);

	try{
	    mj.get(2);
	    fail("Exception didn't get catched");
	} catch (Exception e) {
	    //passed
	}

	//assertEquals((Job) mj.get(2).equals(new Job()));

	//Get matched jobs for applicant 2
	mj = mDAO.getMatchedJobs(1);
	assertNotNull(mj);
	j = (Job) mj.get(0);
	assertTrue(j.getID() == 0);

	try{
	    mj.get(1);
	    fail("Exception didn't get catched");
	} catch (Exception e) {
	    //passed
	}

	//	assertEquals((Job) mj.get(1).equals(new Job()));

	//get matched jobs for applicant with no matched jobs
	mj = mDAO.getMatchedJobs(2);
	assertTrue(mj.size() == 0);
    }

    public void testGetMatches() throws Exception {
	ArrayList m;
	//Get Matches for applicant1
	m = mDAO.getMatches(0);
	assertTrue(m.size() == 2);
	//Get matches for applicant 2
	m = mDAO.getMatches(1);
	assertTrue(m.size() == 1);
	// get matches for applicant with no matches
	m = mDAO.getMatches(2);
	assertTrue(m.size() == 0);
	//Get matches for non-exsisting applicant
	m = mDAO.getMatches(847);
	assertTrue(m.size() == 0);
    }

    public void testGetMetRequirements() throws Exception {
	ArrayList mr; //MatchInformation

	//Get met requirements from Match1
	mr = mDAO.getMetRequirements(0);
	assertTrue(mr.size() == 1);

	//Get met requirements from Match2
	mr = mDAO.getMetRequirements(1);
	assertTrue(mr.size() == 2);
	
	
	//Get met requirements from non-exsisting Match
	mr = mDAO.getMetRequirements(847);
	assertTrue(mr.size() == 0);
    }

    public void testUpdate() throws Exception {
	Match m;
	//Update Match 1
	m = mDAO.getMatch(0);
	m.setRequirementScore(13);
	mDAO.update(m);
	//Update Match 2
	m = mDAO.getMatch(1);
	m.setRequirementScore(14);
	mDAO.update(m);

	m = mDAO.getMatch(0);
	assertTrue(m.getRequirementScore() == 13);
	m = mDAO.getMatch(1);
	assertTrue(m.getRequirementScore() == 14);
    }
}
