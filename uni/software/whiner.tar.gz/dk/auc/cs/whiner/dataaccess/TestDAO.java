package dk.auc.cs.whiner.dataaccess;

import java.sql.*;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.rmi.RemoteException;

import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.function.*;

public class TestDAO extends TestCase{

    public static Test suite() {
	
	TestSuite suite = new TestSuite();

	// dataaccess
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestJobDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestProjectDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestAdministratorDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestApplicantDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestApplicationDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestHeadhunterDAO.class));
	//suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestMatchesDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestNotificationDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestQualificationDAO.class));
	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestRegisterDAO.class));
	//	suite.addTest(new TestSuite(dk.auc.cs.whiner.dataaccess.TestSearchDAO.class));

	return suite;
		      
    }

}
