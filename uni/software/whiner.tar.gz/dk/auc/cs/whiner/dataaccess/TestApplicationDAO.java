package dk.auc.cs.whiner.dataaccess;

import java.util.ArrayList;
import java.sql.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.RemoteException;

/** 
 * Unit test for the {@link ApplicationDAO} class
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.9 $
 */
public class TestApplicationDAO extends TestCase {

    /** Tests two newly added instances in the database are
     *  correctly instantiated.
     */
    public void testAdd() throws DAOException, RemoteException, RMIException{

	ApplicationDAO a = new ApplicationDAO();
	Application app = new Application();
	Application app2 = new Application();
	int id1 = a.getValidDBEntry("Application");
	app = a.add();
	int id2 = a.getValidDBEntry("Application");
	app2 = a.add();

	assertEquals("Asserting ",id1, app.getID());
	assertEquals(id2, app2.getID());
	/*
	assertEquals(0, app.getApplicantID());
	assertEquals(0, app2.getApplicantID());
	assertEquals(0, app.getJobID());
	assertEquals(0, app2.getJobID());
	assertEquals("incomplete", app.getStatus());
	assertEquals("incomplete", app2.getStatus());
	assertEquals(null, app.getDateOfRejection());
	assertEquals(null, app2.getDateOfRejection());
	assertEquals(null, app.getDateOfSubmission());
	assertEquals(null, app2.getDateOfSubmission());
	assertEquals(null, app.getBodyText());
	assertEquals(null, app2.getBodyText());
	*/
	a.delete(id1);
	a.delete(id2);

    }

    /** 
     * First tests to see if a deleted row is replaced when a new application i added, second testes to see if a query
     * to a deleted application returns an empty resultset.
     */
    public void testDelete() throws DAOException, RMIException{

	ApplicationDAO a = new ApplicationDAO();

	int id1 = a.getValidDBEntry("Application");
	a.add();
	int id2 = a.getValidDBEntry("Application");
	a.add();

	a.delete(id1);
	a.delete(id2);

	try{
	    ResultSet rset = a.dbExecuteQuery("SELECT * FROM Application WHERE ID=" + id1);
	    assertTrue("Assert that the Resultset is empty", rset.isBeforeFirst() == false);
	} catch (SQLException e){

	}
	
    }
    
    public void testGetApplication() throws DAOException, RMIException{

	ApplicationDAO a = new ApplicationDAO();

	int id1 = a.getValidDBEntry("Application");
	Application app = a.add();
	int id = app.getID();
	assertEquals("Assert that id's are the same", id1, id);

	Application app2 = a.getApplication(id);

	assertEquals(app.getID(), app2.getID());
	/* tested below
	assertEquals(app.getApplicantID(), app2.getApplicantID());
	assertEquals(app.getJobID(), app2.getJobID());
	assertEquals(app.getStatus(), app2.getStatus());
	assertEquals(app.getDateOfCreation(), app2.getDateOfCreation());
	assertEquals(app.getDateOfSubmission(), app2.getDateOfSubmission());
	assertEquals(app.getDateOfRejection(), app2.getDateOfRejection());
	assertEquals(app.getBodyText(), app2.getBodyText());
	*/
	a.delete(app2.getID());
    }

    public void testUpdate() throws DAOException, RMIException{

	ApplicationDAO a = new ApplicationDAO();

	int id1 = a.getValidDBEntry("Application");
	Application app = a.add();

	app = a.getApplication(id1);
	app.setJobID(id1);
	app.setApplicantID(id1);

	a.update(app);

	Application app2 = a.getApplication(id1);

	assertEquals(app.getID(), app2.getID());
	assertEquals(app.getApplicantID(), app2.getApplicantID());
	assertEquals(app.getJobID(), app2.getJobID());
	assertEquals(app.getStatus(), app2.getStatus());
	assertEquals(app.getDateOfCreation(), app2.getDateOfCreation());
	assertEquals(app.getDateOfSubmission(), app2.getDateOfSubmission());
	assertEquals(app.getDateOfRejection(), app2.getDateOfRejection());
	assertEquals(app.getBodyText(), app2.getBodyText());
	  
	a.delete(id1);

	//	assertEquals(app, app2);
    }
    //NOTE: Cant assertEquals two objects!!!

    public void testGetApplicationsFromJobID() throws DAOException, RMIException{
	
	ApplicationDAO a = new ApplicationDAO();

	int id1 = a.getValidDBEntry("Application");
	Application app1 = a.add();
	int id2 = a.getValidDBEntry("Application");
	Application app2 = a.add();
	int id3 = a.getValidDBEntry("Application");
	Application app3 = a.add();
	int id4 = a.getValidDBEntry("Application");
	Application app4 = a.add();

	app1.setID(id1);
	app1.setJobID(500);
	app2.setID(id2);
	app2.setJobID(500);
	app3.setID(id3);
	app3.setJobID(500);
	app4.setID(id4);
	app4.setJobID(500);

	a.update(app1);
	a.update(app2);
	a.update(app3);
	a.update(app4);

	ArrayList al = a.getApplicationsFromJobID(500);

	Application newapp1 = (Application)al.get(0);
	Application newapp2 = (Application)al.get(1);
	Application newapp3 = (Application)al.get(2);
	Application newapp4 = (Application)al.get(3);

	assertEquals("Assert that it's the right ApplicationID's we've retrived",500, newapp1.getJobID()); 
	assertEquals(500, newapp2.getJobID());
	assertEquals(500, newapp3.getJobID());
	assertEquals(500, newapp4.getJobID());

	a.delete(id1);
	a.delete(id2);
	a.delete(id3);
	a.delete(id4);

    }

    public void testGetApplicationsFromApplicantID() throws DAOException, RMIException{
	
	ApplicationDAO a = new ApplicationDAO();

	int id1 = a.getValidDBEntry("Application");
	Application app1 = a.add();
	int id2 = a.getValidDBEntry("Application");
	Application app2 = a.add();
	int id3 = a.getValidDBEntry("Application");
	Application app3 = a.add();
	int id4 = a.getValidDBEntry("Application");
	Application app4 = a.add();

	app1.setID(id1);
	app1.setApplicantID(500);
	app2.setID(id2);
	app2.setApplicantID(500);
	app3.setID(id3);
	app3.setApplicantID(500);
	app4.setID(id4);
	app4.setApplicantID(500);

	a.update(app1);
	a.update(app2);
	a.update(app3);
	a.update(app4);

	ArrayList al = a.getApplicationsFromApplicantID(500);

	Application newapp1 = (Application)al.get(0);
	Application newapp2 = (Application)al.get(1);
	Application newapp3 = (Application)al.get(2);
	Application newapp4 = (Application)al.get(3);

	assertEquals(500, newapp1.getApplicantID()); 
	assertEquals(500, newapp2.getApplicantID());
	assertEquals(500, newapp3.getApplicantID());
	assertEquals(500, newapp4.getApplicantID());

	a.delete(id1);
	a.delete(id2);
	a.delete(id3);
	a.delete(id4);
    }


}
