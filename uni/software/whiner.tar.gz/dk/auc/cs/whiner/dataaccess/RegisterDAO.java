package dk.auc.cs.whiner.dataaccess;

import java.sql.*;
//import dk.auc.cs.whiner.function.Register;
//import dk.auc.cs.whiner.model.*;

/** Handles calls to the database during the process of creating profiles
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.28 $
*/ 
public class RegisterDAO{
    private static String action = "";
    private static ResultSet rset = null;
    private static DAOObject daob = null;


    /**
     * This method returns an instance of a new class that inherits
     * from DAOObject. This enables us to use the methods of the
     * DAOObject even in the static methods of this class.
     *
     * @return An anonymous inner class inheriting from DAOObject
     * @since 1.9
     */
    private static DAOObject getDAOObject() {
	DAOObject daob = null; 
	try{
	    daob = new DAOObject(){};
	} catch (DAOException e) {
	    // DO NOTHING
	}
	return daob;
    }
    
    /**
     * Tests if there are already entities in the database that are
     * using a given username.
     * @param username a <code>String</code> value representing a
     * suggested login name.
     * @return boolean (false if there is no instance of that username, else true).
     * @exception DAOException if an error occurs.
     * @since 1.1
     */
    public static boolean acceptLoginName(String username) throws DAOException{
	 boolean retVal = true;

	 if (username.equals("")){
	     throw new DAOException("Empty LoginName not allowed!!!");
	 }
	 
	 //Retrieve an instance of DAOObject
	 daob = getDAOObject();

	 action = "SELECT * FROM Users WHERE LoginName='" + username + "'";
	 try{
	     rset = daob.dbExecuteQuery(action);
	 } catch (DAOException e) {
	     throw new DAOException("RegisterDAO:acceptLoginName:Executing query", e);
	 } 

	 int result = -1;
	 try {
	     //check to se if resultset is not empty
	     while (rset.next()){

		 result = rset.getInt("ID");
		 if (result != -1){
		     retVal = false;
		 }		 
	     }
	 } catch (SQLException e){
	     throw new DAOException("RegisterDAO:acceptLoginName:Getting loginname from resultset");
	 }
	 
	 //Resetting static variables
	 rset = null;
	 daob = null;
	 return retVal;
     }
    
    /**
     * Checks what type, the user with the given login name and
     * password is.
     * @param username A <code>String</code> value representing a login name.
     * @param password A <code>String</code> value representing a login name.
     * @return A <code>String</code> value representing a type:
     * "applicant", "headhunter" or "administrator".
     * @exception DAOException if an error occurs.
     * @exception WrongPasswordOrUsernameException if no type is found.
     * @since 1.18
     */
    public static String checkUserType(String username, String password) 
	throws DAOException, WrongPasswordOrUsernameException{

	String retVal = "";
	
	 if (username.equals("") || password.equals("")){
	     throw new DAOException("Empty LoginName or password not allowed!!!");
	 }

	//Retrieving an instance of DAOObject
	daob = getDAOObject();

	String action = "SELECT Type "
	    + "FROM Users "
	    + "WHERE LoginName = '" + username + "'"
	    + " AND Password ='" + password + "'";

	try{
	    rset = daob.dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("RegisterDAO:checkUserType:Executing query", e);
	}	

	try{
	    //Checks if the resultset is empty, if it is raise exception
	    if (rset.isBeforeFirst() == false){
		throw new WrongPasswordOrUsernameException("Wrong username or password!");
	    }
	    while(rset.next()){
		retVal = rset.getString("Type");
	    }
	} catch (SQLException e) {
	    throw new DAOException("RegisterDAO:checkUserType:ResultSet error", e);
	}
	//Resetting static variables
	rset = null;
	daob = null;
	return retVal;
    }
}
