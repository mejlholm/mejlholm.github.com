package dk.auc.cs.whiner.dataaccess;

import java.util.ArrayList;
import java.util.Date;
import java.sql.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.RemoteException;

/** 
 * Unit test for the {@link JobDAO} class
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.10 $
 */
public class TestJobDAO extends TestCase {

    public void testAdd() throws DAOException, RemoteException, RMIException{

	JobDAO j = new JobDAO();

	int id1 = j.getValidDBEntry("Job");
	Job job1 = j.add();
	int id2 = j.getValidDBEntry("Job");
	Job job2 = j.add();

	assertEquals(job1.getID(), id1);
	assertEquals(job2.getID(), id2);
	/*
	assertEquals(0, job1.getProjectID());
	assertEquals(0, job2.getProjectID());
	assertEquals(null, job1.getTitle());
	assertEquals(null, job2.getTitle());
	assertEquals("not announced", job1.getStatus());
	assertEquals("not announced", job2.getStatus());
	assertEquals(null, job1.getDescription());
	assertEquals(null, job2.getDescription());
	*/
	j.delete(job1.getID());
	j.delete(job2.getID());

    }

    public void testDelete() throws DAOException, RemoteException, RMIException{

	JobDAO j = new JobDAO();

	int id1 = j.getValidDBEntry("Job");
	Job job1 = j.add();
	int id2 = j.getValidDBEntry("Job");
	Job job2 = j.add();

	j.delete(job1.getID());
	j.delete(job2.getID());

	try{
	    ResultSet rset = j.dbExecuteQuery("SELECT * FROM Job WHERE ID=" + id1);
	    assertTrue("Assert that the Resultset is empty", rset.isBeforeFirst() == false);
	} catch (SQLException e){

	}
    }


    public void testUpdate() throws DAOException, RemoteException, RMIException{

	JobDAO j = new JobDAO();

	int id1 = j.getValidDBEntry("Job");
	Job job1 = j.add();

	job1.setProjectID(7);
	job1.setTitle("String1");
	job1.setStatus("not announced");
	job1.setDescription("String3");
	job1.setDateOfAnnouncement(new Date());
	job1.setDateOfOccupation(new Date());
	job1.setDateOfCreation(new Date());

	j.update(job1);

	Job job2 = j.getJob(id1);

	assertEquals("Test that the ID's are the same",job1.getID(), job2.getID());
	assertEquals("Test that the ProjectID is the same",job1.getProjectID(), job2.getProjectID());
	assertEquals("Test that the Title is the same",job1.getTitle(), job2.getTitle());
	assertEquals("Test that the status is the same",job1.getStatus(), job2.getStatus());
	assertEquals("Test that the description is the same",job1.getDescription(), job2.getDescription());

	assertTrue("Test that the objects are alike", job1.equals(job2));

	j.delete(id1);//cleanup
    }

    public void testGetJobs() throws DAOException, RemoteException, RMIException{

	JobDAO j = new JobDAO();

	for (int i = 0; i < 10 ; i++) {
	    
	    Job job = j.add();
	    job.setProjectID(5);
	    j.update(job);
	}
	
	ArrayList al = j.getJobs(5);

	int k;
	for (k = 0; k < al.size(); k++){
	    
	    Job job = (Job)al.get(k);
	    assertEquals(5, job.getProjectID());
	    j.delete(job.getID());
	}
	assertEquals("Asserts that the ArrayList contained ten entries", 10, k);

    }


    public void testInsertSkillLevel() throws DAOException, RemoteException, RMIException{

	JobDAO j = new JobDAO();

	SkillLevel sl = new SkillLevel();
	Qualification qa = new Qualification();
	qa.setID(4);

	sl.setID(3);
	sl.setQualification(qa);

	j.insertSkillLevel(sl);

	Qualification q = (Qualification)sl.getQualification();
	
	assertEquals(3, sl.getID());
	assertEquals(0, sl.getLevel());
	assertEquals(4, q.getID());

	j.deleteSkillLevel(sl);
    }


    public void testDeleteSkillLevel() throws DAOException, RemoteException, RMIException{

	JobDAO j = new JobDAO();
	QualificationDAO qdao = new QualificationDAO();

	SkillLevel sl1 = new SkillLevel();
	Qualification q1 = qdao.add();
	sl1.setID(5);
	sl1.setQualification(q1);

	SkillLevel sl2 = new SkillLevel();
	Qualification q2 = qdao.add();
	sl2.setID(6);
	sl2.setQualification(q2);

	j.insertSkillLevel(sl1);
	j.insertSkillLevel(sl2);

	j.deleteSkillLevel(sl1);
	j.deleteSkillLevel(sl2);

	try{
	    ResultSet rset = j.dbExecuteQuery("SELECT * FROM JobSkillLevel");
	    assertTrue("Assert that the Resultset is empty", rset.isBeforeFirst() == false);
	} catch (SQLException e){
	    //
    }
	
	qdao.delete(q1.getID());
	qdao.delete(q2.getID());

    }
    

    public void testGetSkillLevels() throws DAOException, RemoteException, RMIException{

	JobDAO j = new JobDAO();
	QualificationDAO qdao = new QualificationDAO();

	for (int i = 0; i < 10; i++) {

	    SkillLevel sl1 = new SkillLevel();
	    Qualification q1 = qdao.add();
	    sl1.setID(40);
	    sl1.setQualification(q1);
	    
	    j.insertSkillLevel(sl1);
	}

	ArrayList al = j.getSkillLevels(40);
	int k, id;
	for (k = 0 ; k < al.size(); k++) {
	    SkillLevel sl = (SkillLevel)al.get(k);	   
	    Qualification q = (Qualification)sl.getQualification();
	    id = q.getID();
	    j.deleteSkillLevel(sl);
	    qdao.delete(id);
	}
	assertEquals(10, k);

    }
    
	/*   
	try{
	    String action1 = "TRUNCATE TABLE Notification";
	    j.dbExecuteUpdate(action1);
	    String action2 = "TRUNCATE TABLE Qualification";
	    j.dbExecuteUpdate(action2);
	    String action3 = "TRUNCATE TABLE JobSkillLevel";
	    j.dbExecuteUpdate(action3);
	} catch (DAOException E){
	    
	}

	*/
}
