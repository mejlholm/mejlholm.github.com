package dk.auc.cs.whiner.dataaccess;

import java.util.ArrayList;
import java.sql.*;
import junit.framework.TestCase;
import java.rmi.RemoteException;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.rmi.RMIException;
import dk.auc.cs.whiner.model.*;

/** 
 * Unit test for the {@link QualificationDAO} class
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.6 $
 */
public class TestQualificationDAO extends TestCase {

    public void testAdd() throws DAOException, RMIException, RemoteException{

	QualificationDAO q = new QualificationDAO();

	int id1 = q.getValidDBEntry("Qualification");	
	Qualification qual1 = q.add();
	int id2 = q.getValidDBEntry("Qualification");
	Qualification qual2 = q.add();
       
	assertEquals(id1, qual1.getID());
	assertEquals(id2, qual2.getID());
	/*
	assertEquals("null", qual1.getName());
	assertEquals("null", qual2.getName());
	assertEquals(null, qual1.getDescription());
	assertEquals(null, qual2.getDescription());
	*/
	q.delete(qual1.getID());
	q.delete(qual2.getID());

    }



    public void testDelete() throws DAOException{

	QualificationDAO q = new QualificationDAO();

	int id1 = q.getValidDBEntry("Qualification");	
	Qualification qual1 = q.add();
	int id2 = q.getValidDBEntry("Qualification");
	Qualification qual2 = q.add();

	q.delete(id1);
	q.delete(id2);

	try{
	    ResultSet rset = q.dbExecuteQuery("SELECT * FROM Qualification");
	    assertTrue(rset.isBeforeFirst() == false);

	} catch (SQLException e){

	}

    }

    public void testGetQualification() throws DAOException, RMIException, RemoteException{

	QualificationDAO q = new QualificationDAO();
	
	int id1 = q.getValidDBEntry("Qualification");	
	Qualification qual1 = q.add();

	qual1.setName("String1");
	qual1.setDescription("String2");

	q.update(qual1);

	Qualification qual2 = q.getQualification(id1);

	assertEquals(qual1.getID(), qual2.getID());
	assertEquals(qual1.getName(), qual2.getName());
	assertEquals(qual1.getDescription(), qual2.getDescription());

	assertEquals(qual1, qual2);

	qual1.setName("FAIL");

	assertFalse(qual1.equals(qual2));

	q.delete(qual1.getID());

    }



    //public void testUpdate() throws DAOException{
	
	//trivially tested in the above test;

    //    }




    public void testGetQualifications() throws DAOException, RMIException{

	QualificationDAO q = new QualificationDAO();

	int i = 0;
	while ( i < 10){
	    Qualification qual = q.add();
	    qual.setName("fisk");
	    qual.setDescription("Vildere");
	    q.update(qual);
	    i++;
	}

	ArrayList al = q.getQualifications();

	i = 0;
	while (i < 10){
	    Qualification qual2 = (Qualification)al.get(i);
	    assertEquals("fisk", qual2.getName());
	    q.delete(qual2.getID());
	    i++;
	}
	
    }

}
