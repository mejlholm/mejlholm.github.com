package dk.auc.cs.whiner.dataaccess;

import java.sql.*;
import dk.auc.cs.whiner.model.User;
import dk.auc.cs.whiner.rmi.*;

/** Superclass to {@link ApplicantDAO}, {@link HeadhunterDAO}, and {@link AdministratorDAO}
 * @author <a href="mailto:ahlmann@cs.auc.dk">Kristian Ahlmann-Ohlsen</a>
 * @version $Revision: 1.36 $
*/ 
public abstract class UserDAO extends DAOObject{
     
    private String action = "";

    /**
     * Default constructor,
     * no initialization.
     * @exception DAOException if an error occurs.
     */
    public UserDAO() throws DAOException{

    }

    /**
     * Retrieves the password for a given user.
     * @param username a <code>String</code> value representing the
     * login name of a user.
     * @return Returns a <code>String</code> containing the already
     * encrypted password.
     * @exception DAOException if an error occurs.
     * @since 1.0
     */
    public String getPassword(String username) throws DAOException{
	String password = "";

	action = "SELECT * FROM Users WHERE (LoginName='" + username + "')";
	try{
	    rset = dbExecuteQuery(action);    
	    while (rset.next())
		password = rset.getString("Password");

	} catch (DAOException e) {
	    throw new DAOException("UserDAO:getPassword:Executing query", e);
	} catch (SQLException e) {
	    throw new DAOException("UserDAO:getPassword:ResultSet failed");
	}
	return password;
    }

    /**
     * Deletes a given user based on an id - note that it is not
     * possible to delete the default administrator.
     * @param id an <code>int</code> value representing the id of a user.
     * @exception DAOException if an error occurs
     * @since 1.9
     */
    public void delete(int id) throws DAOException{
	if (id != 0) {
	    action = "DELETE FROM Users WHERE ID='" + id + "'";
	    try{
		dbExecuteUpdate(action);
	    }
	    catch (DAOException e){
		throw new DAOException("UserDAO:delete:Executing query", e);
	    }	
	}
    }

    /**
     * Adds a user to the database and returns the id of the same.
     * @param type a <code>String</code> value representing the type
     * of user - this may be on of the following: "administrator",
     * "headhunter" or "applicant".
     * @return An <code>int</code> value representing the database id
     * of the user.
     * @exception DAOException if an error occurs.
     * @since 1.8
     */
    protected int addUser(String type) throws DAOException{

	int validDBEntry = getValidDBEntry("Users");

	action = "INSERT INTO Users (ID, Type) VALUES ('" + validDBEntry + "','" + type + "')";
	try{
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("UserDAO:addUser:Executing update", e);
	}
	return validDBEntry;
    }
    
    /**
     * Retrieves a  userID from a corresponding username.
     * @param username a <code>String</code> value representing the
     * login name of a user.
     * @return An <code>int</code> value representing id of a user.
     * @exception DAOException if an error occurs.
     * @since 1.8
     */
    protected int getUserID(String username) throws DAOException{
	int id = -1;
	
	action = "SELECT ID FROM Users WHERE LoginName='" + username + "'";	
	try{	    
	    rset = dbExecuteQuery(action);
	    while (rset.next()) {
		id = rset.getInt("ID");   
	    }
	} catch (DAOException e){
	    throw new DAOException("UserDAO:getUserID:Executing query", e);
	} catch(SQLException e){
	    throw new DAOException("UserDAO:getUserID:ResulSet failed");
	}
	return id;
    }
    
    /**
     * Retrieves a <code>ResultSet</code> containing user attributes
     * that are common between all user types. This includes
     * "password" and "login name".
     * @param userid an <code>int</code> value representing the id of
     * a user.
     * @return Returns a <code>ResultSet</code> with the requested information.
     * @exception DAOException if an error occurs.
     * @since 1.16
     */
    protected ResultSet getUser(int userid) throws DAOException {
	action = "SELECT * FROM Users WHERE ID='" + userid + "'";
	try{
	    rset = dbExecuteQuery(action);
    	}catch (DAOException e){
	    throw new DAOException("UserDAO:getUser:Executing query", e);
	}
	return rset;
    }

    /**
     * Updates a given user in the database.
     * @param user an <code>User</code> object of the user that is to
     * be updated.
     * @exception DAOException if an error occurs.
     * @since 1.30
     */
    public void update(User user) throws DAOException{
	try {
	    action = "SELECT * FROM Users WHERE ID='" + user.getID() + "'";
	    rset = dbExecuteQuery(action, true);
	} catch (DAOException e){
	    throw new DAOException("UserDAO:update:Executing query", e);
	} catch (RMIException e) {
	    //DO NOTHING
	}

	try {
	    while (rset.next()) {
		rset.updateInt("ID", user.getID());
		rset.updateString("LoginName", user.getLoginName());
		rset.updateString("Password", user.getPassword());
		rset.updateRow();
	    }
	} catch (SQLException e) {
	    throw new DAOException("UserDAO:update:ResultSet failed");
	} catch (RMIException e) {
	    //DO NOTHING
	}
    }
}
