package dk.auc.cs.whiner.dataaccess;

import java.util.ArrayList;
import java.util.Date;
import java.sql.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.RemoteException;

/** 
 * Unit test for the {@link ProjectDAO} class
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.5 $
 */
public class TestProjectDAO extends TestCase {

    public void testAdd() throws DAOException, RMIException, RemoteException{

	ProjectDAO p = new ProjectDAO();

	int id1 = p.getValidDBEntry("Project");
	Project proj1 = p.add();
	int id2 = p.getValidDBEntry("Project");	
	Project proj2 = p.add();

	assertEquals(id1, proj1.getID());
	assertEquals(id2, proj2.getID());
	/*
	assertEquals(0, proj1.getHeadhunterID());
	assertEquals(0, proj2.getHeadhunterID());
      	assertEquals(null, proj1.getDateOfCreation());
       	assertEquals(null, proj2.getDateOfCreation());
	assertEquals(null, proj1.getStatus());
	assertEquals(null, proj2.getStatus());
	assertEquals("null", proj1.getTitle());
	assertEquals("null", proj2.getTitle());
	assertEquals(null, proj1.getDescription());
	assertEquals(null, proj2.getDescription());
	*/
	p.delete(id1);
	p.delete(id2);

    }


    public void testDelete() throws DAOException, RMIException, RemoteException{

	ProjectDAO p = new ProjectDAO();

	int id1 = p.getValidDBEntry("Project");	
	Project proj1 = p.add();

	p.delete(proj1.getID());

	try{
	    ResultSet rset = p.dbExecuteQuery("SELECT * FROM Project");
	    assertTrue(rset.isBeforeFirst() == false);
	} catch (SQLException e) {

	}
	

    }


    public void testGetProject() throws DAOException, RMIException, RemoteException{

	ProjectDAO p = new ProjectDAO();
	
	Project proj1 = p.add();

	proj1.setHeadhunterID(50);
	proj1.setStatus("announced");
	proj1.setTitle("String1");
	proj1.setDateOfCreation(new java.util.Date());
	proj1.setDescription("String2");

	p.update(proj1);

	Project proj2 = p.getProject(proj1.getID());

	//	assertTrue(proj1.equals(proj2));
	
	assertEquals(proj1.getID(), proj2.getID());
	assertEquals(proj1.getHeadhunterID(), proj2.getHeadhunterID());
	assertEquals(proj1.getStatus(), proj2.getStatus());
	//assertEquals("Tests that there is no loss when conveting the dates", p.sqlDateToUtilDate(p.utilDateToSQLDate(proj1.getDateOfCreation())), proj1.getDateOfCreation());
	//assertEquals(proj1.getDateOfCreation(), proj2.getDateOfCreation());
	assertEquals(proj1.getTitle(), proj2.getTitle());
	assertEquals(proj1.getDescription(), proj2.getDescription());

	p.delete(proj1.getID());

    }




    public void testUpdate() throws DAOException, RMIException, RemoteException{

	//trivially tested above

    }



    public void testGetProjectsId() throws DAOException, RMIException, RemoteException{
	//id

	ProjectDAO p = new ProjectDAO();

	HeadhunterDAO hh = new HeadhunterDAO();
	int id1 = p.getValidDBEntry("Users");	
	Headhunter h = hh.add();

	h.setLoginName("Ulrik");
	h.setID(id1);
	hh.update(h);

	Project proj1 = p.add();
	proj1.setHeadhunterID(id1);
	p.update(proj1);
	Project proj2 = p.add();
	proj2.setHeadhunterID(id1);
	p.update(proj2);
	Project proj3 = p.add();
	proj3.setHeadhunterID(id1);
	p.update(proj3);
	Project proj4 = p.add();
	proj4.setHeadhunterID(id1);
	p.update(proj4);
	
	ArrayList al = p.getProjects(id1);

	Project p1 = (Project)al.get(0);
	Project p2 = (Project)al.get(1);
	Project p3 = (Project)al.get(2);
	Project p4 = (Project)al.get(3);

	assertEquals(proj1.getID(), p1.getID());
	assertEquals(proj1.getHeadhunterID(), p1.getHeadhunterID());
	assertEquals(proj1.getStatus(), p1.getStatus());
	assertEquals(proj1.getTitle(), p1.getTitle());
	assertEquals(proj1.getDescription(), p1.getDescription());

	hh.delete(id1);

	p.delete(p1.getID());
	p.delete(p2.getID());
	p.delete(p3.getID());
	p.delete(p4.getID());

    }

    public void testGetProjectsUsername() throws DAOException, RMIException, RemoteException{
	//username

	ProjectDAO p = new ProjectDAO();

	HeadhunterDAO hh = new HeadhunterDAO();
	int id1 = p.getValidDBEntry("Users");	
	Headhunter h = hh.add();

	h.setLoginName("Ib");
	h.setID(id1);
	hh.update(h);

	Project proj1 = p.add();
	proj1.setHeadhunterID(id1);
	p.update(proj1);
	Project proj2 = p.add();
	proj2.setHeadhunterID(id1);
	p.update(proj2);
	Project proj3 = p.add();
	proj3.setHeadhunterID(id1);
	p.update(proj3);
	Project proj4 = p.add();
	proj4.setHeadhunterID(id1);
	p.update(proj4);

	ArrayList al = p.getProjects("Ib");

	Project p1 = (Project)al.get(0);
	Project p2 = (Project)al.get(1);
	Project p3 = (Project)al.get(2);
	Project p4 = (Project)al.get(3);

	assertEquals(p1.getID(), proj1.getID());
	assertEquals(p1.getHeadhunterID(), id1);

	hh.delete(id1);

	p.delete(p1.getID());
	p.delete(p2.getID());
	p.delete(p3.getID());
	p.delete(p4.getID());
	}


}
