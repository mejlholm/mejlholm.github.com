package dk.auc.cs.whiner.dataaccess;
/* Headhunter Data Access Object */

import dk.auc.cs.whiner.model.Headhunter;
import java.sql.*;
import java.util.ArrayList;
import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.RemoteException;

/** Handles all database access involving the headhunter class.
 * @author <a href="mailto:ahlmann@cs.auc.dk">Kristian Ahlmann-Ohlsen</a>
 * @version $Revision: 1.35 $
*/ 
public class HeadhunterDAO extends UserDAO{

    private ResultSet rset = null;
    private String action = "";

    /**
     * Default constructor, creates a new <code>HeadhunterDAO</code>
     * instance.
     *
     * @exception DAOException if an error occurs.
     * @since 1.6
     */
    public HeadhunterDAO() throws DAOException {}

    
    /**
     * Adds a <code>Headhunter</code> object to the database and
     * returns a new <code>Headhunter</code> object with the id of the
     * newly added headhunter.
     * @return a <code>Headhunter</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.6
     */
    public Headhunter add() throws DAOException{

	int hhid;
	try{
	    hhid = addUser("headhunter");
	} catch (DAOException e) {
	    throw new DAOException("HeadhunterDAO:add:addUser failed", e);
	}

	Headhunter hh = null;
	try{
	    //	    hh = getHeadhunter(hhid);
	    hh = new Headhunter();
	    hh.setID(hhid);
	} catch(DAOException e) {
	    throw new DAOException("HeadhunterDAO:add:getHeadhunter failed", e);
	} catch (Exception e) {
	    //RMIExceptions
	}
	return hh;
    }
    
    /**
     * Deletes a headhunter from the database, based on a username.
     * @param username a <code>String</code> value representing a
     * login name of a headhunter.
     * @exception DAOException if an error occurs.
     * @since 1.6
     */
    public void delete(String username) throws DAOException {

	int id;
	try{
	    id = getUserID(username);
	} catch (DAOException e) {
	    throw new DAOException("HeadhunterDAO:delete:getUserID failed", e);
	}
	delete(id);
    }

    /**
     * Retrieves a headhunter object from the database.
     * @param id an <code>int</code> value representing the id of a
     * headhunter.
     * @return Returns the corresponding  <code>Headhunter</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.6
     */
    public Headhunter getHeadhunter(int id) throws DAOException{

	Headhunter hh = null;

	try{
	    hh = new Headhunter();
	    /* Superclass method */
	    rset = getUser(id);
	} catch (DAOException e) {
	    throw new DAOException("HeadhunterDAO:getHeadhunter:getUser failed", e);
	} catch(RMIException e){
	    //Nada
	} catch(RemoteException r){

	}

	try{
	    while(rset.next()) {
		hh.setID(id);
		hh.setLoginName(rset.getString("LoginName"));
		hh.setPassword(rset.getString("Password"));
	    }
	} catch (SQLException e) {
	    throw new DAOException("HeadhunterDAO:getHeadhunter:ResultSet failed");
	} catch (RMIException r){
	    //not going to happen
	}
	return hh;
    }

    /**
     * Retrieves a headhunter from the database, based on the login
     * name of a headhunter.
     * @param hhname a <code>String</code> value representing the login name of a headhunter.
     * @return Returns the corresponding  <code>Headhunter</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.13
     */
    public Headhunter getHeadhunter(String hhname) throws DAOException{

	int id;
	try{
	    id = getUserID(hhname);
	} catch (DAOException e) {
	    throw new DAOException("HeadhunterDAO:getHeadhunter:getUserID failed", e);
	}
	
	Headhunter hh = null;
	hh = getHeadhunter(id);
	
	return hh;
    }

    /**
     * Retrieves an <code>ArrayList</code> containing all the
     * headhunters in the database.
     * @return Returns an <code>ArrayList</code> of <code>Headhunter</code> objects.
     * @exception DAOException if an error occurs.
     * @since 1.6
     */
    public ArrayList getLoginNames() throws DAOException{

	//returns a list of names... - very tricky stuff
	ArrayList al = new ArrayList();
	action = "SELECT LoginName FROM Users WHERE Type='headhunter' ORDER BY ID ASC";
	
	try{	
	    rset = dbExecuteQuery(action);
	    while (rset.next()){
		String str = rset.getString("LoginName");
		al.add(str);
	    }
	} catch (DAOException e) {
	    throw new DAOException("HeadhunterDAO:getLoginNames:Executing query", e);
	} catch (SQLException e) {
	    throw new DAOException("HeadhunterDAO:getLoginNames:ResultSet failed");
	}
	return al;
    }
}
