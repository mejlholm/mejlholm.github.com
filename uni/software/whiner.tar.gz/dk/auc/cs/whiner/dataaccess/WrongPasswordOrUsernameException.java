package dk.auc.cs.whiner.dataaccess;

/* Simple exception class - basically just renaming... */

/**
 * An exception used in {@link RegisterDAO} when checking the username and password.
 * @author <a href="mailto:ahlmann@fatboy"></a>
 * @version 1.0
 * @since 1.0
 */
public class WrongPasswordOrUsernameException extends Exception {
    
    public WrongPasswordOrUsernameException() {
	super("Unknown exception");
    }

    public WrongPasswordOrUsernameException(String msg) {
	super(msg);
    }
}
