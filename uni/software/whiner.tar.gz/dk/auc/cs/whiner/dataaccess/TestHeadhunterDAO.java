package dk.auc.cs.whiner.dataaccess;

import java.util.ArrayList;
import java.sql.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.RemoteException;

/** 
 * Unit test for the {@link HeadhunterDAO} class
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.5 $
 */
public class TestHeadhunterDAO extends TestCase {

    public void testAdd() throws DAOException, RMIException, RemoteException{

	HeadhunterDAO hd = new HeadhunterDAO();

	int id1 = hd.getValidDBEntry("Users");
	Headhunter hh1 = hd.add();
	int id2 = hd.getValidDBEntry("Users");
	Headhunter hh2 = hd.add();

	assertEquals(id1, hh1.getID());
	assertEquals(id2, hh2.getID());
	/*
	assertEquals(null, hh1.getLoginName());
	assertEquals(null, hh2.getLoginName());
	assertEquals(null, hh1.getPassword());
	assertEquals(null, hh2.getPassword());
	*/
	hd.delete(hh1.getID());
	hd.delete(hh2.getID());
    }

    public void testDelete() throws DAOException, RMIException, RemoteException{

	HeadhunterDAO hd = new HeadhunterDAO();

	int id1 = hd.getValidDBEntry("Users");
	Headhunter hh1 = hd.add();
	int id2 = hd.getValidDBEntry("Users");
	Headhunter hh2 = hd.add();

	assertEquals(id1, hh1.getID());
	assertEquals(id2, hh2.getID());

	hd.delete(id1);
	hd.delete(id2);

	try{
	    ResultSet rset = hd.dbExecuteQuery("SELECT * FROM Users WHERE ID=" + id1);
	    assertTrue("Assert that the Resultset is empty", rset.isBeforeFirst() == false);
	} catch (SQLException e){

	}

    }

    public void testGetHeadhunter() throws DAOException, RMIException, RemoteException{

	HeadhunterDAO hd = new HeadhunterDAO();

	int id1 = hd.getValidDBEntry("Users");
	Headhunter hh1 = hd.add();

	hh1.setLoginName("Birger");
	hh1.setPassword("dinmor");

	hd.update(hh1);

	Headhunter hh2 = hd.getHeadhunter(id1);
	Headhunter hh3 = hd.getHeadhunter("Birger");

	assertEquals(id1, hh1.getID());

	assertEquals(hh1.getID(), hh2.getID());
	assertEquals(hh1.getID(), hh3.getID());
	assertEquals(hh1.getLoginName(), hh2.getLoginName());
	assertEquals(hh1.getLoginName(), hh3.getLoginName());
	assertEquals(hh1.getPassword(), hh2.getPassword());
	assertEquals(hh1.getPassword(), hh3.getPassword());

	hd.delete(hh1.getID());

    }

    public void testGetLoginNames() throws DAOException, RMIException, RemoteException{

	HeadhunterDAO hd = new HeadhunterDAO();
	
	int id1 = hd.getValidDBEntry("Users");
	Headhunter hh1 = hd.add();
	hh1.setLoginName("Bente");
	hd.update(hh1);
	int id2 = hd.getValidDBEntry("Users");
	Headhunter hh2 = hd.add();
	hh2.setLoginName("Ilse");
	hd.update(hh2);
	int id3 = hd.getValidDBEntry("Users");
	Headhunter hh3 = hd.add();
	hh3.setLoginName("Kruk");
	hd.update(hh3);	

	assertEquals(id1, hh1.getID());
	assertEquals(id2, hh2.getID());
	assertEquals(id3, hh3.getID());

	ArrayList al = hd.getLoginNames();

	String hha1 = (String) al.get(0);
	assertEquals(hha1, hh1.getLoginName());
	String hha2 = (String) al.get(1);
	assertEquals(hha2, hh2.getLoginName());
	String hha3 = (String) al.get(2);
	assertEquals(hha3, hh3.getLoginName());

	assertEquals(3, al.size());

	hd.delete(id1);
	hd.delete(id2);
	hd.delete(id3);
    }

    public void testUpdate() throws DAOException, RMIException, RemoteException{

	// trivially tested in TestGetHeadhunter

    }

}
