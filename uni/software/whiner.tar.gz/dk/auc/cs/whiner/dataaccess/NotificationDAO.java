package dk.auc.cs.whiner.dataaccess;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import dk.auc.cs.whiner.model.Notification;

import java.rmi.*;
import dk.auc.cs.whiner.rmi.RMIException;

/** Handles all traffic to the database regarding Notifications
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.34 $
*/ 
public class NotificationDAO extends DAOObject {

    private String action = "";
    private ResultSet rset = null;
    private ResultSet rsetid1 = null;
    private ResultSet rsetid2 = null;
    private ResultSet rsetid3 = null;

    /**
     * Default constructor
     * No initialization.
     * @exception DAOException if an error occurs.
     */
    public NotificationDAO() throws DAOException{

    }


    /**
     * Adds a notification to the database and returns a
     * <code>Notification</code> object with the id of the newly
     * created entry in the database.
     * @return <code>Notification</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.4
     */
    public Notification add() throws DAOException {

	int validDBEntry = getValidDBEntry("Notification");
	Notification n = null;

	try{
	    action = "INSERT INTO Notification (ID) values (" + validDBEntry + ")";
	    dbExecuteUpdate(action);
	    n = new Notification();
	    n.setID(validDBEntry);
	} catch (DAOException e){
	    throw new DAOException("NotificationDAO: add <dbExecuteUpdate Error!>");
	} catch (RemoteException r){
	    //DO NOTHING
	}


	return n;
    }

    /**
     * Retrieves all the notifications belonging to a given applicant id.
     * @param applicantID an <code>int</code> value representing the
     * id of an applicant.
     * @return <code>Notification</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.4
     */
    public ArrayList getNotifications(int applicantID) throws DAOException {

	String title1 = "";
	String title2 = "";
	String title3 = "";
	String bodyText1 = "";
	String bodyText2 = "";
	String bodyText3 = "";
	
	try{	    
	    rsetid1 = dbExecuteQuery("SELECT * FROM NotificationType WHERE (Title)='Job reopened'");
	    while (rsetid1.next())
		{
		title1 = rsetid1.getString("Title");
		bodyText1 = rsetid1.getString("BodyText");
		}
	    
	    rsetid2 = dbExecuteQuery("SELECT * FROM NotificationType WHERE (Title)='Application rejected'");
	    while (rsetid2.next())
		{
		    title2 = rsetid2.getString("Title");
		    bodyText2 = rsetid2.getString("BodyText");
		}
	    
	    rsetid3 = dbExecuteQuery("SELECT * FROM NotificationType WHERE (Title)='Application deleted'");
	    while (rsetid3.next())
		{
		    title3 = rsetid3.getString("Title");
		    bodyText3 = rsetid3.getString("BodyText");
		}
	    
	    action = "SELECT * FROM Notification WHERE ApplicantID='" + applicantID + "'";
	    rset = dbExecuteQuery(action);
	} catch (SQLException e) {
	    throw new DAOException("NotificationDAO: getNotifications <dbExecuteQuery Error!>");
	}

	ArrayList al = new ArrayList();
	Notification n = null;
	try{
	    while (rset.next()) {
		n = new Notification();
		
		n.setID(rset.getInt("ID"));
		n.setApplicantID(rset.getInt("ApplicantID"));
		n.setJobID(rset.getInt("JobID"));
		n.setNotificationType(rset.getString("NotificationType"));
		n.setDateOfDispatch(sqlDateToUtilDate(rset.getDate("DateOfDispatch")));
		if (n.getNotificationType().equals("Job reopened" )){
		    n.setTitle(title1);
		    n.setBodyText(bodyText1);}
		else {
		    if (n.getNotificationType().equals("Application rejected")) {
			n.setTitle(title2);
			n.setBodyText(bodyText2);
		    } 
		else {
		    if (n.getNotificationType().equals("Application deleted")) {
			n.setTitle(title3);
			n.setBodyText(bodyText3);
		    }
		    else {
			throw new DAOException("NotificationDAO: getNotifications <Wrong NotificationType!>");
		    }
		}
		}
		
		al.add(n);
	    }
	}
	catch (SQLException e) {
	    throw new DAOException("NotificationDAO: getNotifications <Rset Error!>");
	} catch (RMIException r) {

	} catch (RemoteException r) {

	}
	return al;
    }


    /**
     * Deletes a notification from the database, based on an id
     * @param notificationID an <code>int</code> value representing
     * the id of a notification.
     * @exception DAOException if an error occurs.
     * @since 1.4
     */
    public void delete(int notificationID) throws DAOException{
	try {
	    action = "DELETE FROM Notification WHERE ID=" + notificationID;
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("NotificationDAO: delete <dbExecuteUpdate Error!>");
	}
    }


    /**
     * Deletes all notification that belong to a given applicant.
     * @param applicantID an <code>int</code> value representing the
     * id of an applicant.
     * @exception DAOException if an error occurs.
     * @since 1.4
     */
    public void deleteNotifications(int applicantID) throws DAOException{
	try{
	    action = "DELETE FROM Notification WHERE ApplicantID=" + applicantID;
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("NotificationDAO: deleteNotifications <dbExecuteUpdate!>");
	}
    }


    /**
     * Updates a notification in the database.
     * @param n a <code>Notification</code> object that is to be
     * updated.
     * @exception DAOException if an error occurs.
     * @since 1.4
     */
    public void update(Notification n) throws DAOException{

	try{
	    action ="SELECT * FROM Notification WHERE ID='" + n.getID() + "'";
	    rset = dbExecuteQuery(action, true);
	} catch (DAOException e) {
	    throw new DAOException("NotificationDAO: update <dbExecuteQuery Error!>");
	}catch (RMIException r){

	}
	    
	try{
	    while (rset.next()) {
		rset.updateInt("ID", n.getID());
		rset.updateInt("ApplicantID", n.getApplicantID());
		rset.updateInt("JobID", n.getJobID());
		rset.updateString("NotificationType", n.getNotificationType());
		rset.updateTimestamp("DateOfDispatch", utilDateToSQLTimestamp(n.getDateOfDispatch()));
		rset.updateRow();
	    }
	} catch (SQLException e) {
	    throw new DAOException("NotificationDAO: update <Rset.update Error!>");
	}catch (RMIException r){

	}
    }


    /**
     * Takes an <code>ArrayList</code> containing
     * <code>Notification</code> objects and updates the corresponding
     * notifications in the database.
     * @param al an <code>ArrayList</code> containing <code>Notification</code> objects.
     * @exception DAOException if an error occurs.
     * @since 1.5
     */
    public void update(ArrayList al) throws DAOException{

	    for (int i=0; i < al.size(); i++) {
		Notification n = (Notification)al.get(i);//that cast may prove troubles

		try{
		    action ="SELECT * FROM Notification WHERE ID=" + n.getID();		
		    rset = dbExecuteQuery(action, true);
		} catch (DAOException e) {
		    throw new DAOException("NotificationDAO: update ArrayList <dbExecuteQuery Error!>");
		}catch (RMIException r){

		}
		
		try{
		    while (rset.next()) {
			rset.updateInt("ID", n.getID());
			rset.updateInt("ApplicantID", n.getApplicantID());
			rset.updateInt("JobID", n.getJobID());
			rset.updateString("NotificationType", n.getNotificationType());
			rset.updateTimestamp("DateOfDispatch", utilDateToSQLTimestamp(n.getDateOfDispatch()));
			rset.updateRow();
		    }
		} catch (SQLException e) {
		    throw new DAOException("NotificationDAO: update ArrayList <Rset.update Error!>");
		} catch (RMIException r) {
		}
	    }
    }
}
