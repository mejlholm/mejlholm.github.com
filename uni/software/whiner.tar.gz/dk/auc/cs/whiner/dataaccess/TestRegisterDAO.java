package dk.auc.cs.whiner.dataaccess;

import java.util.ArrayList;
import java.sql.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.function.*;
import dk.auc.cs.whiner.rmi.RMIException;

/** 
 * Unit test for the {@link RegisterDAO} class
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.6 $
 */
public class TestRegisterDAO extends TestCase {

    public void testAccpetLoginName() throws DAOException, RMIException{

	HeadhunterDAO hd = new HeadhunterDAO();

	try{
	    RegisterDAO.acceptLoginName("");
	    fail("Exception didn't get catched");
	} catch (DAOException e) {
	    //passed
	}

	assertTrue("B�rgebent is a valid new loginname", RegisterDAO.acceptLoginName("B�rgebent"));

	Headhunter h = hd.add();
	h.setLoginName("Bent");
	h.setPassword("Srubaru");

	hd.update(h);

	assertEquals("Bent", h.getLoginName());

	assertFalse(RegisterDAO.acceptLoginName("Bent"));
	assertTrue(RegisterDAO.acceptLoginName("B�rgebent"));
	
	hd.delete(h.getID());
    }

    public void testCheckUserType() throws DAOException, RMIException, WrongPasswordOrUsernameException{
	/*
	try{
	    RegisterDAO.checkUserType("","");
	    fail("Exception didn't get catched");
	} catch (DAOException e) {
	    //passed
	}
	*/
	HeadhunterDAO hd = new HeadhunterDAO();

	Headhunter h = hd.add();
	h.setLoginName("Inga");
	h.setPassword("Srubaru");

	hd.update(h);

	assertEquals("headhunter", RegisterDAO.checkUserType("Inga", "Srubaru"));
	try{ 
	    RegisterDAO.checkUserType("","");
	    fail("Exception didn't get catched");
	} catch (WrongPasswordOrUsernameException e){
	    // passed
	} catch (DAOException d){

	}

	hd.delete(h.getID());

    }

}
