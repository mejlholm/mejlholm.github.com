
public int exceptionExample(String something) throws DAOException {
    try {
	//et eller andet der kan returnere en fejl som betyder noget for vores program
    }
    catch (SQLException e){

	DAOException de = new DAOException();
	//Ovenst�ende kan deklareres p� tre forskellige m�der:
	// DAOException de = new DAOException();
	// S�tter fejlmeddelelse til "Unknown error"
	// DAOException de = new DAOException("Fejlmeddelelse");
	// S�tter fejlmeddelelse til "Fejlmeddelelse
	// DAOException de = new DAOException("Fejlmeddelelse", e);
	// S�tter fejlmeddelelse til "Fejlmeddelelse og inkluderer SQLException'en hvis det kunne v�re n�dvendigt

	de.setType(1);
	//S�tter en type som g�r det let at identificere fejlen for modellaget
	//Disse typer skal VI definere i DAOException.java
	//S�ttes typen IKKE, vi den blive sat til UNKNOWN ERROR!
	
	throw de;
    }
}