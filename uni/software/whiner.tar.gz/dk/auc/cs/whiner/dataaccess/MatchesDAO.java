package dk.auc.cs.whiner.dataaccess;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import dk.auc.cs.whiner.model.Match;
import dk.auc.cs.whiner.model.Qualification;
import dk.auc.cs.whiner.model.Job;
import dk.auc.cs.whiner.model.Applicant;
import dk.auc.cs.whiner.model.MatchInformation;

/** Handles database calls related to Matches
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.37 $
*/ 
public class MatchesDAO extends DAOObject{

    private Statement s = null;
    private ResultSet rset = null;
    private ResultSet rsetkey = null;
    private String action ="";

    /**
     * Default constructor
     * No initialization.
     * @exception DAOException if an error occurs.
     */
    public MatchesDAO() throws DAOException{

    }

    /**
     * Retrieves a <code>Match</code> object from the database based
     * on a match id.
     * @param id an <code>int</code> value representing the id of a
     * <code>Match</code> object.
     * @return a <code>Match</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.0
     */
    public Match getMatch(int id) throws DAOException {

	try{
	    action = "SELECT * FROM Matches WHERE ID='" +id+ "'";
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("MatchesDAO: getMatch <dbExecuteQuery Error!>");
	}
	
	Match m = null;

	try{       
	    m = new Match();

	    while (rset.next()) {
		m.setID(id);
		m.setApplicantID(rset.getInt("ApplicantID"));
		m.setJobID(rset.getInt("JobID"));
		m.setDateOfMatch(rset.getDate("DateOfMatch"));
		m.setRequirementScore(rset.getInt("RequirementScore"));
	    }	
	} catch (SQLException e) {
	    throw new DAOException("MatchesDAO: getMatch <Rset Error!>");
	} catch (Exception e) {
	    //RMIExceptions
	}    

	return m;
    }


    /**
     * Deletes a <code>Match</code> object from the database based
     * upon the id of a <code>Match</code> object.
     * @param id an <code>int</code> value representing the id of a
     * <code>Match</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.0
     */
    public void delete(int id) throws DAOException {

	try{
	    action = "DELETE FROM Matches WHERE ID='" + id + "'";
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("MatchesDAO: delete <dbExecuteUpdate Error!>");
	}
    }


    /**
     * Creates a match in the database and returns a new
     * <code>Match</code> object with the id of the newly created
     * entry in the database.
     * @return a <code>Match</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.0
     */
    public Match add() throws DAOException {

	int validDBEntry = getValidDBEntry("Matches");

	try{
	    action = "INSERT INTO Matches (ID) VALUES ("+ validDBEntry +")";	    
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException ("MatchesDAO: add <dbExecuteUpdate Error!>");
	}

// 	try{
// 	    rset = dbExecuteQuery("SELECT * FROM Matches WHERE (ID)='" + validDBEntry + "'");
// 	} catch (DAOException e) {
// 	    throw new DAOException ("MatchesDAO: add <dbExecuteQuery Error!>");
// 	}
	Match m = null;
	
	try{
	    m = new Match();
	    m.setID(validDBEntry);
	    while (rset.next()) {
		//m.setApplicantID(rset.getInt("ApplicantID"));
		//		m.setJobID(rset.getInt("JobID"));
		//m.setDateOfMatch(rset.getDate("DateOfMatch"));
		//m.setRequirementScore(rset.getInt("RequirementScore"));
	    }
	} catch (SQLException e) {
	    throw new DAOException ("MatchesDAO: add <Rset Error!>");
	} catch (Exception e) {
	    //DO NOTHING (again)
	}
	return m;
    }


    /**
     * Updates a <code>Match</code> object in the database.
     * @param m a <code>Match</code> object that is to be updated.
     * @exception DAOException if an error occurs.
     * @since 1.0
     */
    public void update(Match m) throws DAOException {

	try{
	    action = "SELECT * FROM Matches WHERE ID=" + m.getID();
	    rset = dbExecuteQuery(action, true);
	} catch (DAOException e) {
	    throw new DAOException("MatchesDAO: update <dbExecuteQuery Error!>");
	} catch (Exception e) {
	    //RMIException
	}

	try{
	    while (rset.next()) {
		rset.updateInt("ID", m.getID());
		rset.updateInt("ApplicantID", m.getApplicantID());
		rset.updateInt("JobID", m.getJobID());
		rset.updateTimestamp("DateOfMatch", utilDateToSQLTimestamp(m.getDateOfMatch()));
		rset.updateInt("RequirementScore", m.getRequirementScore());
		rset.updateRow();
	    }
	} catch (SQLException e) {
	    throw new DAOException("MatchesDAO: update <Rset.update Error!>");
	} catch (Exception e) {
	    //RMIException
	} 
    }


    /**
     * Retrieves the requirements/qualifications that are common
     * between an applicant and a job.
     * @param matchID an <code>int</code> value representing the id of
     * a <code>Match</code>
     * @return an <code>ArrayList</code> containing
     * <code>Qualification</code> objects.
     * @exception DAOException if an error occurs.
     */
    public ArrayList getMetRequirements(int matchID) throws DAOException{
	try{
	    action = " SELECT DISTINCT ask.QualificationID "
		+ "FROM Matches AS m, JobSkillLevel AS jsk, ApplicantSkillLevel AS ask "
		+ "WHERE m.ID =" + matchID + " AND jsk.JobID = m.JobID "
		+ "AND ask.UserID = m.ApplicantID "
		+ "AND ask.QualificationID = jsk.QualificationID;";
	    	    
	    rset = dbExecuteQuery(action, true);

	} catch (DAOException e) {
	    e.printStackTrace();
	    throw new DAOException("MatchesDAO: getMetRequirements <dbExecuteQuery Error!>");
	}

	int id = 0;
	int size = 0;
	
	try{
	    while (rset.next()){
		size++;
	    }
	    rset.beforeFirst();
	} catch (SQLException e) {
	    throw new DAOException("MatchesDAO: getMetRequirements <Rset.size Error!>");
	}

	int[] ia = new int[size];
	
	try{
	    for (int i=0; rset.next(); i++) {
		ia[i] = rset.getInt("ask.QualificationID");		
	    }
	} catch (SQLException e) {
	    throw new DAOException("MatchesDAO: getMetRequirements <Rset Error!>");
	}

	ArrayList qa = new ArrayList();

	for (int i=0; i < size; i++) {
	    try {
		action = "SELECT * FROM Qualification WHERE ID=" + ia[i];
		rset = dbExecuteQuery(action);
	    } catch (DAOException e) {
		throw new DAOException("MatchesDAO: getMetRequirements <dbExecuteQuery loop Error!>");
	    }

	    try{
		while (rset.next()) {
		    Qualification q = null;
		    try{
			q = new Qualification();
			
			q.setID(rset.getInt("ID"));
			q.setName(rset.getString("Name"));
			q.setDescription(rset.getString("Description"));
		    } catch (Exception e) {
			//RMIException
		    }
		
		    qa.add(q);
		
		}
	    } catch (SQLException e) {
		throw new DAOException("MatchesDAO: getMetRequirements <Rset loop Error!>");
	    }
	}
	return qa;
    }


    /**
     * Retrieves existing <code>Match</code> objects in the database.
     * @param applicantID an <code>int</code> value representing the
     * is of an applicant.
     * @return <code>ArrayList</code> of <code>Match</code> objects.
     * @exception DAOException if an error occurs.
     * @since 1.10
     */
    public ArrayList getMatches(int applicantID) throws DAOException{
	try{
	    action = "SELECT * FROM Matches WHERE ApplicantID=" + applicantID;
	    rset = dbExecuteQuery(action);
	} catch (DAOException e){
	    throw new DAOException("MatchesDAO: getMatches <dbExecuteQuery Error!>");
	}

	ArrayList al = new ArrayList();

	try {
	    while (rset.next()) {
		Match m = new Match();
		
		m.setID(rset.getInt("ID"));
		m.setApplicantID(applicantID);
		m.setJobID(rset.getInt("JobID"));
		m.setDateOfMatch(sqlDateToUtilDate(rset.getDate("DateOfMatch")));
		m.setRequirementScore(rset.getInt("RequirementScore"));

		
		// Variables needed to retrieve the MetRequirements
		ResultSet tmpRset = null;
		ArrayList tmpAl = new ArrayList();
		MatchInformation mi = null;

		action = "SELECT qf.Name, jsl.Level, asl.Level "
		    + "FROM JobSkillLevel AS jsl, ApplicantSkillLevel AS asl, Qualification AS qf "
		    + "WHERE jsl.QualificationID = asl.QualificationID "
		    + "AND jsl.JobID ='" + rset.getInt("JobID") + "' "
		    + "AND asl.UserID ='" + rset.getInt("ApplicantID") + "' "
		    + "AND qf.ID = jsl.QualificationID";

	
		tmpRset = dbExecuteQuery(action);
	
		while (tmpRset.next()) {
		    mi = new MatchInformation();
		    mi.setLevelJobSkillLevel(tmpRset.getInt("jsl.Level"));
		    mi.setLevelApplicantSkillLevel(tmpRset.getInt("asl.Level"));
		    mi.setQualificationName(tmpRset.getString("qf.Name"));
		    tmpAl.add(mi);
		}

		m.setMetRequirements(tmpAl);		
		al.add(m);
	    }
	} catch (SQLException e){
	    throw new DAOException("MatchesDAO: getMatches <Rset Error!>");
	} catch (Exception e) {
	    //RMIException
	}

	return al;
    }
    
    /**
     * Retrieves an <code>ArrayList</code> of matched jobs.
     * @param applicantID an <code>int</code> value representing the
     * id of an applicant.
     * @return an <code>ArrayList</code> of <code>Job</code> objects.
     * @exception DAOException if an error occurs.
     * @since 1.19
     */
    public ArrayList getMatchedJobs(int applicantID) throws DAOException{
	//Delete old match objects...
	action = "DELETE FROM Matches WHERE ApplicantID = " + applicantID + ";";

	try{
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("MatchesDAO:getMatchedJobs:Executing Query: deleting applicant matches", e);
	}

	action = "SELECT DISTINCT JobID FROM ApplicantSkillLevel AS ask, JobSkillLevel AS jsk, Job "
	    + "WHERE (ask.QualificationID = jsk.QualificationID "
	    + "AND ask.UserID ='" + applicantID + "' "
	    + "AND Job.Status ='announced') ";

	try{
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("MatchesDAO:getMatchedJobs:Executing Query", e);
	}
	
	ArrayList al = new ArrayList();

	try{
	    Job tmpJob = null;
	    JobDAO jDAO = new JobDAO();

	    while (rset.next()) {
		tmpJob = new Job();
		tmpJob = jDAO.getJob(rset.getInt("JobID"));
		al.add(tmpJob);
	    }
	} catch (SQLException e) {
	    throw new DAOException("MatchesDAO:getMatchedJobs:ResultSet failed");
	} catch (DAOException e) {
	    throw new DAOException("MatchesDAO:getMatchedJobs:Job error", e);
	} catch (Exception e) {
	    //RMIException
	}

	return al;
    }
    
    /**
     * Retrieves an <code>ArrayList</code> of matched applicants.
     * @param jobID an <code>int</code> value representing the id of a job.
     * @return an <code>ArrayList</code> of <code>Applicant</code> objects.
     * @exception DAOException if an error occurs.
     * @since 1.20
     */
    public ArrayList getMatchedApplicants(int jobID) throws DAOException{
	//Delete existing Matches for job...
	action = "DELETE FROM Matches WHERE JobID = " + jobID + ";";

	try{
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("MatchesDAO:getMatchedApplicants:Executing Query", e);
	}

	action = "SELECT DISTINCT UserID FROM ApplicantSkillLevel AS ask, JobSkillLevel AS jsk, Job "
	    + "WHERE ask.QualificationID = jsk.QualificationID "
	    + "AND jsk.JobID ='" + jobID + "' "
	    + "AND Job.ID = jsk.JobID "
	    + "AND Job.Status ='announced' "
	    + " ORDER BY UserID ASC";

	try{
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("MatchesDAO:getMatchedApplicants:Executing Query", e);
	}
	
	ArrayList al = new ArrayList();

	try{
	    Applicant tmpApp = null;
	    ApplicantDAO aDAO = new ApplicantDAO();

	    while (rset.next()) {
		tmpApp = new Applicant();
		tmpApp = aDAO.getApplicant(rset.getInt("UserID"));
		al.add(tmpApp);
	    }
	} catch (SQLException e) {
	    throw new DAOException("MatchesDAO:getMatchedApplicant:ResultSet failed");
	} catch (DAOException e) {
	    throw new DAOException("MatchesDAO:getMatchedApplicant:Job error", e);
	} catch (Exception e) {
	    //RMIException
	}

	return al;
    }
}
