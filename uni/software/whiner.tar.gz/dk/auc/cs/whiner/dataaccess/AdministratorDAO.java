package dk.auc.cs.whiner.dataaccess;
/* Administrator Data Access Object */

import dk.auc.cs.whiner.model.Administrator;
import dk.auc.cs.whiner.rmi.RMIException;
import java.sql.*;
import java.rmi.RemoteException;
/** Handles all database access involving the Administrator class.
 * @author Kristian Ahlmann-Ohlsen
 * @version $Revision: 1.24 $
 *
*/ 

public class AdministratorDAO extends UserDAO{
    
    private ResultSet rset = null;
    private String action = "";



    /**
     * Creates a new <code>AdministratorDAO</code> instance.
     *
     * @exception DAOException if an error occurs
     */
    public AdministratorDAO() throws DAOException{

    }
    
    /**
     * Retrieves the administrator object from the database.
     * @param id an <code>int</code> value.
     * @return Returns an <code>Administrator</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.0
     */
    public Administrator getAdministrator(int id) throws DAOException {

	Administrator a = null;
	try{
	    a = new Administrator();
	} catch(RemoteException r) {

	}
	action ="SELECT * FROM Users WHERE ID='" + id +"'";
	try{
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("AdministratorDAO:getAdministrator:Executing query", e);
	}

	try{
	    while (rset.next()) {
		a.setID(id);
		a.setLoginName(rset.getString("LoginName"));
		a.setPassword(rset.getString("Password"));
	    }
	} catch (SQLException e) {
	    throw new DAOException("AdministratorDAO:getAdministrator:ResultSet failed");
	    //	} catch (RemoteException e) {
	    //DO NOTHING
	}
	return a;
    }
    
    //alternately, since we have only ONE administrator the following should work as well
    /**
     * Retrieves the default administrator object from the database.
     * @return Returns an <code>Administrator</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.0
     */
    public Administrator getAdministrator() throws DAOException{

	Administrator a = null;
	try{
	    a = new Administrator();
	}catch(RemoteException r){
	    //VILDERE REMOTEEXCEPTION
	}

	action = "SELECT * FROM Users WHERE Type ='administrator' AND ID = 0";

	try{
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("AdministratorDAO:getAdministrator_noParam:Executing query", e);
	}

	try{
	    while (rset.next()) {
		a.setID(rset.getInt("ID"));
		a.setLoginName(rset.getString("LoginName"));
		a.setPassword(rset.getString("Password"));
	    }
	} catch (SQLException e) {
	    throw new DAOException("AdministratorDAO:getAdministrator_noParam:ResultSet failed");
	}
	return a;
    }

    /**
     * Retrieves an administrator object from the database.
     * @param username a <code>String</code> value
     * @return An <code>Administrator</code> object.
     * @exception DAOException if an error occurs
     * @since 1.0
     */
    public Administrator getAdministrator(String username) throws DAOException {
	Administrator a = null;
	int id;

	try{
	    id = getUserID(username);
	    a = getAdministrator(id);
	} catch (DAOException e) {
	    throw new DAOException("AdministratorDAO:getAdministrator_username:Unknown error - see cause", e);
	} catch (Exception e) {
	    //DO NOTHING
	}
	
	return a;
    }
}
