package dk.auc.cs.whiner.dataaccess;

/* Simple exception class - basically just renaming... */

/**
 * Provides exceptions for the DAO layer
 * @author <a href="mailto:ahlmann@cs.auc.dk">Kristian Ahlmann-Ohlsen</a>
 * @version 1.0
 * @since 1.0
 */
public class DAOException extends Exception {
    
    public DAOException(){
	super("Unknown exception");
    }

    public DAOException(String msg){
	super(msg);
    }

    public DAOException(String msg, Throwable cause){
	super(msg, cause);
    }
}
