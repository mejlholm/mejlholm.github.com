package dk.auc.cs.whiner.dataaccess;

import java.sql.*;

/** The singleton class that makes one connection to the SQL database.
 * @author <a href="mailto:ahlmann@cs.auc.dk">Kristian Ahlmann-Ohlsen</a>
 * @version $Revision: 1.8 $
*/ 
class ConnectionMgr{
    //Singleton variables
    private static ConnectionMgr connMgr = null;
    private static Connection con = null;

    //Connection related variables
    private String driver;
    private String user;
    private String pass;
    private String jdbcURL;
    
    /**
     * Private constructor, ensuring that no one, but this class, can instantiate this class
     * @since 1.0
     */
    private ConnectionMgr() {
	setDBInfo();
    }
    
    /**
     * Setting required variables when an instance of this class is created
     * @since 1.0
     */
    private void setDBInfo(){
	jdbcURL = "jdbc:mysql://localhost/whiner";
	driver = "com.mysql.jdbc.Driver";
	user = "test";
	pass = "tester";   
    }

    /**
     * Opens a connection to the database and stores it in the
     * <code>con</code> data field.
     * @exception DAOException if an error occurs.
     * @since 1.0
     */
    private void openConnection() throws DAOException {

	try {
	    Class.forName(driver);
	} catch (ClassNotFoundException e) {
	    throw new DAOException("ConnectionMgr:openConnection:class.forname failed");
	}

	try {
	    con = DriverManager.getConnection(jdbcURL, user, pass);
	}catch (SQLException e) {
	    System.out.println("SQL whineage: " + e.getMessage());
	    throw new DAOException("ConnectionMgr:openConnection:DriverManager.getConnection failed");
	}
    }

    /**
     * Checks if the connection variable <code>con</code> has been
     * initialized or if it is closed. If it is, then it returns a
     * newly opened connection, otherwise it returns the already
     * exsisting connection.
     * @return a <code>Connection</code> object.
     * @exception DAOException if an error occurs
     * @since 1.0
     */
    public Connection connect() throws DAOException {
	try{
	    if (con == null || con.isClosed()) {
		openConnection();
	    }
	} catch (SQLException e) {
	    throw new DAOException("ConnectionMgr:connect:connection.isclosed failed");
	} catch (DAOException e) {
	    throw new DAOException("ConnectionMgr:connect:openConnection failed", e);
	}
	return con;
    }

    /**
     * Checks to see whether an instance of this class has already
     * been made. If it has it returns the already existing instance,
     * otherwise it creates a new one.
     * @return Returns an instance of this class
     * @since 1.0
     */
    public static ConnectionMgr getInstance() {
	if (connMgr == null) {
	    connMgr = new ConnectionMgr();
	}
	return connMgr;
    }
}
