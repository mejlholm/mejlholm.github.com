package dk.auc.cs.whiner.dataaccess;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import dk.auc.cs.whiner.model.Project;

/** This class handles calls to the database related to Projects
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.43 $
*/ 
public class ProjectDAO extends DAOObject{

    private ResultSet rset = null;
    private String action = "";
    
    /**
     * Default constructor
     *  not initialization.
     * @exception DAOException if an error occurs.
     */
    public ProjectDAO() throws DAOException {

    }


    /**
     * Retrieves a <code>Project</code> object from the database based upon an id.
     * @param id an <code>int</code> value representing the id of a project.
     * @return A <code>Project</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.6
     */
    public Project getProject(int id) throws DAOException{

	try{
	    action = "SELECT * FROM Project WHERE ID='" + id + "'";
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("ProjectDAO: getProject <dbExecuteQuery Error!>");
	}
	
	Project p = null;
	
	try {
	    p = new Project();

	    while (rset.next()) {
		p.setID(id);
		p.setHeadhunterID(rset.getInt("HeadhunterID"));
		p.setDateOfCreation(rset.getDate("DateOfCreation"));
		//		p.setDateOfAnnouncement(rset.getDate("DateOfAnnouncement"));
		p.setStatus(rset.getString("Status"));
		p.setTitle(rset.getString("Title"));
		p.setDescription(rset.getString("Description"));
	    }
	} catch (SQLException e) {
	    throw new DAOException("ProjectDAO: getProject <Rset Erroe!>");
	} catch (Exception e) {
	    //RMIException
	}
	return p;
    }


    /**
     * Deletes a project from the database.(note that the model component is
     * responsible for deleting everything related to the Project).
     * @param id an <code>int</code> value representing the id of a project.
     * @exception DAOException if an error occurs.
     * @since 1.0
     */
    public void delete(int id) throws DAOException{
	try{
	    action = "delete from Project where ID='" + id + "'";
	    dbExecuteUpdate(action);
	}
	catch (DAOException e) {
	    throw new DAOException("ProjectDAO: delete <dbExecuteUpdate Error!>");
	}
    }

    /**
     * Adds a project to the database and returns a new
     * <code>Project</code> object with the id of the newly added
     * project.
     * @return A <code>Project</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.6
     */
    public Project add() throws DAOException{
	
	int validDBEntry = getValidDBEntry("Project");

	try{
	    action = "insert into Project (ID) values ('"+ validDBEntry +"')";
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("ProjectDAO: add <dbExecuteUpdate Error!>");
	}

	try {
	    rset = dbExecuteQuery("Select * from Project where (ID)='" + validDBEntry + "'");
	} catch (DAOException e) {
	    throw new DAOException("ProjectDAO: add <dbExecuteQuery Error!>");
	}
	
	Project p = null;
	
	try{
	    p = new Project();

	    while (rset.next()) {
		p.setID(rset.getInt("ID"));
		//		p.setHeadhunterID(rset.getInt("HeadhunterID"));
		//	p.setDateOfCreation(rset.getDate("DateOfCreation"));
		//		p.setDateOfAnnouncement(rset.getDate("DateOfAnnouncement"));
		//p.setStatus(rset.getString("Status"));
		//p.setTitle(rset.getString("Title"));
		//p.setDescription(rset.getString("Description"));
	    }
	} catch (SQLException e) {
	    throw new DAOException("ProjectDAO: add <Rset Error!>");
	} catch (Exception e) {
	    //RMIException
	}
	return p;
    }
    

    /**
     * Updates a project in the database.
     * @param p a <code>Project</code> object, that should be updated
     * in the database.
     * @exception DAOException if an error occurs.
     * @since 1.5
     */
    public void update(Project p) throws DAOException{
	try{

	    action ="SELECT * FROM Project WHERE ID=" + p.getID();
	    rset = dbExecuteQuery(action, true);
	} catch (DAOException e) {
	    throw new DAOException("ProjectDAO: update <dbExecuteQuery Error!>");
	} catch (Exception e) {
	    //RMIException
	}
	
	try{
	    while (rset.next()) {
		rset.updateInt("ID", p.getID());
		rset.updateInt("HeadhunterID", p.getHeadhunterID());
		rset.updateString("Description", p.getDescription());
		rset.updateString("Title", p.getTitle());
		rset.updateString("Status", p.getStatus());
		rset.updateTimestamp("DateOfCreation", utilDateToSQLTimestamp(p.getDateOfCreation()));		
		rset.updateRow();
	    }
	} catch (SQLException e) {
	  throw  new DAOException("ProjectDAO: update <Rset.update Error!>");
	} catch (Exception e) {
	    //RMIException
	}
    }

    /**
     * Retrieves all projects related to a given headhunter.
     * @param id an <code>int</code> value representing the id of a headhunter.
     * @return An <code>ArrayList</code> of <code>Project</code> objects.
     * @exception DAOException if an error occurs.
     * @since 1.6
     */
    public ArrayList getProjects(int id) throws DAOException{
	
	try{
	    action = "SELECT * FROM Project WHERE HeadhunterID='" + id + "' ORDER BY ID ASC";	    
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("ProjectDAO getProjects(id) <dbExecuteQuery Error!>");
	}
	
	ArrayList projects = new ArrayList();
	
	try{
	    while (rset.next()) {

		Project p = new Project();		
		p.setID(rset.getInt("ID"));
		p.setHeadhunterID(id);
		p.setDescription(rset.getString("Description"));
		p.setTitle(rset.getString("Title"));
		p.setStatus(rset.getString("Status"));
		p.setDateOfCreation(rset.getDate("DateOfCreation"));
		
		projects.add(p);
	    }
	}
	catch (SQLException e) {
	    throw new DAOException("ProjectDAO getProjects(id) <Rset Error!>");
	} catch (Exception e) {
	    //RMIException
	}
	return projects;	
    }


    /**
     * Retrieves all projects related to a username, should be a Headhunters.
     * @param username a <code>String</code> value representing the
     * login name of a headhunter.
     * @return An <code>ArrayList</code> of <code>Project</code> objects.
     * @exception DAOException if an error occurs.
     * @since 1.6
     */
    public ArrayList getProjects(String username) throws DAOException{

	int id = 0;
	try {
	    action = "SELECT ID FROM Users WHERE LoginName='" + username + "'";
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("ProjectDAO getProjects(username) <dbExecuteQuery Error!>"); 
	}

	try{
	    while (rset.next()){
		id = rset.getInt("ID");
	    }
	} catch (SQLException e) {
	    throw new DAOException("ProjectDAO getProjects(username) <Rset Error!>"); 
	} 

	ArrayList al = new ArrayList();
	al = getProjects(id);
	
	return al;
    }	

}

