package dk.auc.cs.whiner.dataaccess;

import java.util.ArrayList;
import java.sql.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.RemoteException;

/** 
 * Unit test for the {@link AdministratorDAO} class
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.4 $
 */
public class TestAdministratorDAO extends TestCase {


    public void testThisFuckedUpClass() throws DAOException, RMIException, RemoteException{

	AdministratorDAO ad = new AdministratorDAO();

	Administrator admin1 = ad.getAdministrator();
	Administrator admin2 = ad.getAdministrator(0);
	Administrator admin3 = ad.getAdministrator("Admin Smith");
	
	assertEquals(admin1.getID(), admin2.getID());
	assertEquals(admin2.getID(), admin3.getID());
	assertEquals(admin1.getID(), admin3.getID());
	/*	assertEquals(admin1.getLoginName(), admin2.getLoginName());
	assertEquals(admin2.getLoginName(), admin3.getLoginName());
	assertEquals(admin1.getLoginName(), admin3.getLoginName());
	assertEquals(admin1.getPassword(), admin2.getPassword());
	assertEquals(admin2.getPassword(), admin3.getPassword());
	assertEquals(admin1.getPassword(), admin3.getPassword());
	*/

	admin1.setPassword("fisk");

	ad.update(admin1);
	
	Administrator admin4 = ad.getAdministrator();
	assertEquals("fisk", admin4.getPassword());

	ad.update(admin2);//resets the password
	
    }
}
