package dk.auc.cs.whiner.dataaccess;

import java.util.ArrayList;
import java.sql.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.*;
import java.rmi.RemoteException;


/**
 * This class contains functionality for searching through the jobs in
 * the database. At present, there's only one method available for
 * searching; {@link #searchForJob(int[] criteria)}.
 * @author <a href="mailto:ahlmann@cs.auc.dk">Kristian Ahlmann-Ohlsen</a>
 * @version $Revision: 1.12 $
*/ 
public class SearchDAO extends DAOObject {
    
    /**
     * Deafault constructor,
     * no initialization.
     * @exception DAOException if an error occurs.
     */
    public SearchDAO() throws DAOException{

    }

    /**
     * Based on the given qualification ID's, this method returns all
     * jobs that meet one or more of the requirements.
     * @param criteria An integer array containing qualification ID's
     * @return An ArrayList of Job objects
     * @exception DAOException if an error occurs
     * @since 1.0
     */
    public ArrayList searchForJob(int[] criteria) throws DAOException{
	int i;

	String action = "SELECT DISTINCT Job.*, JobSkillLevel.JobID FROM Job, JobSkillLevel "
	    + "WHERE Job.ID = JobSkillLevel.JobID AND Job.Status = 'announced'";

	//Adding the where clause
	if (criteria.length > 0){
	    action = action + "AND (JobSkillLevel.QualificationID = '" + criteria[0] + "' ";
	    
	    for (i = 1; i < criteria.length; i++){
		action = action + "OR QualificationID='" + criteria[i] + "' ";
	    }
		
	    action = action + ")";
	    //For debugging purposes:
	    //System.out.println(action);
	}

	action = action + " ORDER BY Job.ID ASC";

	try{
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("SearchDAO:searchForJob:Executing query", e);
	}
	ArrayList al = new ArrayList();

	try{
	    while (rset.next()) {
		Job j = new Job();
		
		j.setID(rset.getInt("ID"));
		j.setProjectID(rset.getInt("ProjectID"));
		j.setTitle(rset.getString("Title"));
		j.setDateOfAnnouncement(rset.getDate("DateOfAnnouncement"));
		j.setDateOfOccupation(rset.getDate("DateOfOccupation"));
		j.setDateOfCreation(rset.getDate("DateOfCreation"));
		j.setStatus(rset.getString("Status"));
		j.setDescription(rset.getString("Description"));
		
		al.add(j);
	    }
	} catch (SQLException e) {
	    throw new DAOException("SearchDAO:searchForJob:ResulSet failed");
	} catch (RemoteException e) {
	    //DO NOTHING
	}

	return al;
    }
}
