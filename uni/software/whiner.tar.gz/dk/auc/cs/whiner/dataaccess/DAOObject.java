package dk.auc.cs.whiner.dataaccess;

import java.sql.*;
import java.util.*;

/** Abstract superclass, including all 'commonly' used functionality of the DAOObjects.
 * This includes functions for retrieving <code>ResultSets</code>
 * @author <a href="mailto:ahlmann@cs.auc.dk">Kristian Ahlmann-Ohlsen</a>
 * @version $Revision: 1.4 $
*/ 
abstract class DAOObject{

    //Variables for this super-class only
    private Statement s = null;
    private Connection con = null;
    private ConnectionMgr cmgr = null;

    //Variables which sub-classes inherit
    protected ResultSet rset = null;
    private String action = "";

    /**
     * This, default, constructor creates a new <code>DAOObject</code>
     * instance and, at the same time, retrieves an instance of the
     * connection manager as well as retrieves a connection to the
     * database.
     * @exception DAOException if an error occurs
     */
    DAOObject() throws DAOException{
	cmgr = ConnectionMgr.getInstance();

	try{
	    con = cmgr.connect();
	} catch (DAOException e) {
	    throw new DAOException("DAOObject:DAOObject:Connection failed", e);
	}
    }

    /*-----------------Database Functions-----------------*/
    /**
     * Executes the given SQL statement, which may be an INSERT,
     * UPDATE, or DELETE statement or an SQL statement that returns nothing
     * @param action a <code>String</code> value
     * @exception DAOException if an error occurs
     * @since 1.0
     */
    protected void dbExecuteUpdate(String action) throws DAOException{
	try{
	    s = con.createStatement();
	    s.executeUpdate(action);
	    
	} catch (SQLException e) {
	    throw new DAOException("DAOObject:dbExecuteUpdate:Update failed");
	}
    }

    /**
     * Executes the given SQL statement, which returns a single <code>ResultSet</code>
     * @param action a <code>String</code> value
     * @return <code>ResultSet</code>, containing the returned
     * results. Empty if no results are returned.
     * @exception DAOException if an error occurs
     * @since 1.0
     */
    protected ResultSet dbExecuteQuery(String action) throws DAOException{
	rset = dbExecuteQuery(action, false);
	return rset;
    }

    /**
     * Executes the given SQL statement, which returns a single <code>ResultSet</code>
     * @param action a <code>String</code> value, containing the SQL statement.
     * @param updatable a <code>boolean</code> value, that indicates
     * wheter or not the <code>ResultSet</code> should be updatable.
     * @return <code>ResultSet</code>, containing the returned
     * results. Empty if no results are returned.
     * @exception DAOException if an error occurs
     * @since 1.0
     */
    protected ResultSet dbExecuteQuery(String action, boolean updatable) throws DAOException{
	try{
	    if (updatable)
		s = con.createStatement(ResultSet.TYPE_FORWARD_ONLY, 
					ResultSet.CONCUR_UPDATABLE);
	    else
		s = con.createStatement();
	} catch (SQLException e) {
	    throw new DAOException("DAOObject:dbExecuteQuery:CreateStatement failed");
	}

	try{
	    rset = s.executeQuery(action);
	} catch (SQLException e) {
	    throw new DAOException("DAOObject:dbExecuteQuery:Executing query");
	}

	return rset;
    }

    /*----------------Conversion Functions-------------------*/
    /**
     * Converts an SQL date to Util date
     * @param sqldate a <code>java.sql.Date</code> value that should
     * be converted to a <code>java.util.Date</code> value.
     * @return <code>java.util.Date</code> value.
     * @since 1.0
     */
    protected java.util.Date sqlDateToUtilDate(java.sql.Date sqldate){
	java.util.Date utildate = null;
	if (sqldate != null){
	    long milidate = 0;
	    milidate = sqldate.getTime();
	    utildate = new java.util.Date(milidate);
	}
	return utildate;
    }

    /**
     * Converts an Util date to SQL date
     * @param utildate a <code>java.util.Date</code> value that should
     * be converted to a <code>java.sql.Date</code> value.
     * @return <code>java.sql.Date</code> value.
     * @since 1.0
     */
    protected java.sql.Timestamp utilDateToSQLTimestamp(java.util.Date utildate){
	java.sql.Timestamp sqlTstamp = null;
	if (utildate != null) {
	    long milidate = 0;
	    milidate = utildate.getTime();
	    sqlTstamp = new java.sql.Timestamp(milidate);
	}
	return sqlTstamp;
    }


    /**
     * Returns a valid database entry. It is a brute force algorithm
     * that searches through all ids in a given table
     * @param table a <code>String</code> value, with the name of a table in the database.
     * @return <code>int</code> representing an available database entry.
     * @exception DAOException if an error occurs
     * @since 1.2
     */
    protected int getValidDBEntry(String table) throws DAOException{

	int i = 0;
	int id = 0;
	int validDBEntry = 0;

	action = "SELECT ID FROM " + table + " ORDER BY ID ASC";	

	try{
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("DAOObject: getValidDBEntry <dbExecuteQuery Error!>");
	}

	try {
	    if (rset.isBeforeFirst() == false){
		validDBEntry = 0;
	    }
	    else {
		while (rset.next()) {
			id = rset.getInt("ID");
			if (id != i){
			    validDBEntry = i;
			    break;
			}
			i++;			
		    }
		validDBEntry = i;//should never happen?
	    }
	} catch (SQLException e) {
	    throw new DAOException("DAOObject: getValidDBEntry <Rset Error!>");
	}

	return validDBEntry;
    }

}
