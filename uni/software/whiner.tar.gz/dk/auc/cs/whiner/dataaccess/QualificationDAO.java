package dk.auc.cs.whiner.dataaccess;

import java.util.ArrayList;
import java.sql.*;
import dk.auc.cs.whiner.model.Qualification;


/** Handles calls to the database when dealing with Qualification objects
 * @author <a href="mailto:mejlholm@cs.auc.dk">Arne Mejlholm</a>
 * @version $Revision: 1.18 $
*/ 
public class QualificationDAO extends DAOObject{
    
    private String action = "";
    private Statement s = null;
    private ResultSet rset = null;

    /* Default constructor. No initialization.
     */
    public QualificationDAO() throws DAOException{

    }

    /**
     * Deletes a <code>Qualification</code> object from the database.
     * @param id an <code>int</code> value representing the id of a
     * qualification.
     * @exception DAOException if an error occurs.
     * @since 1.5
     */
    public void delete(int id) throws DAOException{

	try{
	    action = "SELECT * FROM JobSkillLevel WHERE QualificationID='" + id +"'";
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("QualificationDAO: delete <dbExecuteQuery Error!>");
	}

	int result = -1;
	try{
	    if (rset.next()) {
		result = rset.getInt("QualificationID");
	    }
	} catch (SQLException e) {
	    throw new DAOException("QualificationDAO: delete <Rset Error!>");
	}
	
	if (result == id){
	    throw new DAOException("QualificationDAO: delete <QualificationID is in use in JobSkillLevel!>");
	} else {
	    try {
		action = "DELETE FROM Qualification WHERE ID=" + id;
		dbExecuteUpdate(action);
	    } catch (DAOException e) {
		throw new DAOException("QualificationDAO: delete <dbExecuteUpdate Error!>");
	    }
	}
    }

    /**
     * Creates a qualification in the database and returns a new
     * <code>Qualification</code> object with the id of the
     * qualification that was newly added to the database.
     * @return A <code>Qualifcation</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.6
     */
    public Qualification add() throws DAOException{

	int validDBEntry = getValidDBEntry("Qualification");

	try{
	    action = "INSERT INTO Qualification (ID) VALUES ('" + validDBEntry +"')";
	    dbExecuteUpdate(action);
	} catch (DAOException e) {
	    throw new DAOException("QualificationDAO: add <dbExecuteUpdate Error");
	}
	
	try {
	    rset = dbExecuteQuery("SELECT * FROM Qualification WHERE (ID)='" + validDBEntry + "'");
	} catch (DAOException e) {
	    throw new DAOException("QualificationDAO: add <dbExecuteQuery Error!>");
	}
	
	Qualification q = null;

	try {
	    q = new Qualification();
	
	    while (rset.next()) {
		q.setID(rset.getInt("ID"));
		//		q.setName(rset.getString("Name"));
		//q.setDescription(rset.getString("Description"));
	    }
	} catch (SQLException e) {
	    throw new DAOException("QualificationDAO: add <Rset Error!>");
	} catch (Exception e) {
	    //RMIExceptions
	}
	return q;
    }
    

    /**
     * Updates a <code>Qualification</code> object in the database.
     * @param q a <code>Qualification</code> object that should be
     * updated.
     * @exception DAOException if an error occurs.
     * @since 1.6
     */
    public void update(Qualification q) throws DAOException{
	try{
	    action = "SELECT * FROM Qualification WHERE ID=" + q.getID();
	    rset = dbExecuteQuery(action, true);
	} catch (DAOException e){
	    throw new DAOException("QualificationDAO: update <dbExecuteQuery Error!>");
	} catch (Exception e) {
	    //RMIException
	}

	try{
	    while (rset.next()) {
		rset.updateInt("ID", q.getID());
		rset.updateString("Name", q.getName());
		rset.updateString("Description", q.getDescription());
		rset.updateRow();
	    }
	} catch (SQLException e) {
	    throw new DAOException("QualificationDAO: update <Rset.update Error!>");
	} catch (Exception e) {
	    //RMIException
	}
    }

    /**
     * Retrieves a <code>Qualification</code> object from the
     * database.
     * @param id an <code>int</code> value representing the id of a
     * qualification.
     * @return A <code>Qualification</code> object.
     * @exception DAOException if an error occurs.
     * @since 1.6
     */
    public Qualification getQualification(int id) throws DAOException{
	
	try{
	    action = "SELECT * FROM Qualification WHERE ID=" +id;
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("QualificationDAO: getQualification <dbExecuteQuery Error!>");
	}
	
	Qualification q = null;

	try{
	    q = new Qualification();

	    while (rset.next()){
		q.setID(rset.getInt("ID"));
		q.setName(rset.getString("Name"));
		q.setDescription(rset.getString("Description"));
	    }	    

	} catch (SQLException e) {
	    throw new DAOException("QualificationDAO: getQualification <Rset Error!>");
	} catch (Exception e) {
	    //RMIException
	}

	return q;
    }

    /**
     * Gathers all <code>Qualifcation</code> objects in the database
     * and adds them to an <code>ArrayList</code> which is then
     * returned.
     * @return An <code>ArrayList</code> containing
     * <code>Qualification</code> objects.
     * @exception DAOException if an error occurs.
     * @since 1.5
     */
    public ArrayList getQualifications() throws DAOException{
	try{
	    action = "SELECT * FROM Qualification ORDER BY ID ASC";
	    rset = dbExecuteQuery(action);
	} catch (DAOException e) {
	    throw new DAOException("QualificationDAO: getQualifications <dbExecuteQuery Error!>");
	}
	
	ArrayList al = new ArrayList();
	
	try{
	    while (rset.next()){
		Qualification q = new Qualification();
		
		q.setID(rset.getInt("ID"));
		q.setName(rset.getString("Name"));
		q.setDescription(rset.getString("Description"));
		al.add(q);	    
	    } 
	} catch (SQLException e) {
	    throw new DAOException("QualificationDAO: getQualifications <Rset Error!>");
	} catch (Exception e) {
	    //RMIException
	}	
	return al;
    }
}


