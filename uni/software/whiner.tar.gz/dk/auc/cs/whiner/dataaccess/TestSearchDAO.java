package dk.auc.cs.whiner.dataaccess;

import java.util.Date;
import java.util.ArrayList;
import java.sql.*;
import junit.framework.TestCase;
import dk.auc.cs.whiner.dataaccess.*;
import dk.auc.cs.whiner.model.*;
import dk.auc.cs.whiner.rmi.RMIException;
import java.rmi.RemoteException;

/** 
 * Unit test for the {@link SearchDAO} class
 * @author <a href="mailto:ahlmann@cs.auc.dk">Kristian Ahlmann-Ohlsen</a>
 * @version $Revision: 1.2 $
 */
public class TestSearchDAO extends TestCase {
    JobDAO jDAO;
    QualificationDAO qDAO;
    

    public TestSearchDAO() throws Exception {
	jDAO = new JobDAO();
	qDAO = new QualificationDAO();
    }

    public void setUp() throws Exception {
	/* Qualifications */
	Qualification q;

	//id = 0
	q = qDAO.add();
	q.setName("bj");
	q.setDescription("BlowJob");
	qDAO.update(q);

	//id = 1
	q = qDAO.add();
	q.setName("hj");
	q.setDescription("HandJob");
	qDAO.update(q);

	//id = 2
	q = qDAO.add();
	q.setName("da");
	q.setDescription("DoggyStyle");
	qDAO.update(q);

	//id = 3
	q = qDAO.add();
	q.setName("ea");
	q.setDescription("Eating");
	qDAO.update(q);

	//id = 4
	q = qDAO.add();
	q.setName("sm");
	q.setDescription("SMil");
	qDAO.update(q);

	//id = 5
	q = qDAO.add();
	q.setName("Gas");
	q.setDescription("Du ka' ta' det");
	qDAO.update(q);
	    
	//id = 6
	q = qDAO.add();
	q.setName("Vildere");
	q.setDescription("Gas");
	qDAO.update(q);

	/* Jobs */
	Job j;

	//id = 0
	j = jDAO.add();
	j.setTitle("job1");
	j.setStatus("announced");
	jDAO.update(j);

	//id = 1
	j = jDAO.add();
	j.setTitle("job2");
	j.setStatus("announced");
	jDAO.update(j);

	//id = 2
	j = jDAO.add();
	j.setTitle("job3");
	j.setStatus("announced");
	jDAO.update(j);
	
	/* SkillLevels */
	SkillLevel sk;

	//Job 1
	sk = new SkillLevel();
	sk.setID(0);
	sk.setLevel(1);
	q = (Qualification)sk.getQualification();
	q.setID(0);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(0);
	sk.setLevel(1);
	q = (Qualification)sk.getQualification();
	q.setID(1);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(0);
	sk.setLevel(3);
	q = (Qualification)sk.getQualification();
	q.setID(5);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(0);
	sk.setLevel(3);
	q = (Qualification)sk.getQualification();
	q.setID(6);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);


	//Job 2

	sk = new SkillLevel();
	sk.setID(1);
	sk.setLevel(4);
	q = (Qualification)sk.getQualification();
	q.setID(0);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(1);
	sk.setLevel(2);
	q = (Qualification)sk.getQualification();
	q.setID(2);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(1);
	sk.setLevel(2);
	q = (Qualification)sk.getQualification();
	q.setID(3);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

// 	sk = new SkillLevel();
// 	sk.setID(1);
// 	sk.setLevel(1);
// 	q = (Qualification)sk.getQualification();
// 	q.setID(5);
// 	sk.setQualification(q);
// 	jDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(1);
	sk.setLevel(1);
	q = (Qualification)sk.getQualification();
	q.setID(6);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);


	//Job 3
	sk = new SkillLevel();
	sk.setID(2);
	sk.setLevel(3);
	q = (Qualification)sk.getQualification();
	q.setID(4);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(2);
	sk.setLevel(4);
	q = (Qualification)sk.getQualification();
	q.setID(5);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(2);
	sk.setLevel(4);
	q = (Qualification)sk.getQualification();
	q.setID(6);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);

	sk = new SkillLevel();
	sk.setID(2);
	sk.setLevel(5);
	q = (Qualification)sk.getQualification();
	q.setID(3);
	sk.setQualification(q);
	jDAO.insertSkillLevel(sk);
    }

    public void tearDown() throws Exception {
	//System.out.println("\ntearDown...\n");
	DAOObject dao = null;

	try {
	    dao = new DAOObject(){};
	    //System.out.println("daoen blev hentet...");
	} catch (DAOException e) {
	    e.printStackTrace();
	}

	String action = "DELETE FROM ";

	dao.dbExecuteUpdate(action + "Job");
	dao.dbExecuteUpdate(action + "Applicant");
	dao.dbExecuteUpdate(action + "ApplicantSkillLevel");
	dao.dbExecuteUpdate(action + "JobSkillLevel");
	dao.dbExecuteUpdate(action + "Matches");
	dao.dbExecuteUpdate(action + "Qualification");
	dao.dbExecuteUpdate(action + "Users WHERE type NOT LIKE 'administrator'");
    }

    private DAOObject getDAOObject() {
	DAOObject daob = null; 
	try{
	    daob = new DAOObject(){};
	} catch (DAOException e) {
	    // DO NOTHING
	    e.printStackTrace();
	}
	return daob;
    }


    public void testSearchForJob() throws Exception {
	SearchDAO sDAO = new SearchDAO();
	ArrayList al = null;
	int[] quals;
	Job j = new Job();

	//job 1 + job2
	quals = new int[2];
	quals[0] = 0;
	quals[1] = 1;

	al = sDAO.searchForJob(quals);
	assertNotNull(al);
	assertTrue(al.size() == 2);
	j = (Job) al.get(0);
	assertTrue(j.getID() == 0);
	j = (Job) al.get(1);
	assertTrue(j.getID() == 1);
	
	//job 1
	quals = new int[1];
	quals[0] = 1;

	al = sDAO.searchForJob(quals);
	assertNotNull(al);
	assertTrue(al.size() == 1);
	j = (Job) al.get(0);
	assertTrue(j.getID() == 0);

	//All
	quals = new int[1];
	quals[0] = 6;

	al = sDAO.searchForJob(quals);
	assertNotNull(al);
	assertTrue(al.size() == 3);
	j = (Job) al.get(0);
	assertTrue(j.getID() == 0);
	j = (Job) al.get(1);
	assertTrue(j.getID() == 1);
	j = (Job) al.get(2);
	assertTrue(j.getID() == 2);

	//all
	quals = new int[2];
	quals[0] = 5;
	quals[1] = 6;

	al = sDAO.searchForJob(quals);
	assertNotNull(al);
	assertTrue(al.size() == 3);
	j = (Job) al.get(0);
	assertTrue(j.getID() == 0);
	j = (Job) al.get(1);
	assertTrue(j.getID() == 1);
	j = (Job) al.get(2);
	assertTrue(j.getID() == 2);

	//job 1, job 3
	quals = new int[1];
	quals[0] = 5;

	al = sDAO.searchForJob(quals);
	assertNotNull(al);
	assertTrue(al.size() == 2);
	j = (Job) al.get(0);
	assertTrue(j.getID() == 0);
	j = (Job) al.get(1);
	assertTrue(j.getID() == 2);

	//job 2
	quals = new int[1];
	quals[0] = 2;

	al = sDAO.searchForJob(quals);
	assertNotNull(al);
	assertTrue(al.size() == 1);
	j = (Job) al.get(0);
	assertTrue(j.getID() == 1);

	//job 3
	quals = new int[1];
	quals[0] = 4;

	al = sDAO.searchForJob(quals);
	assertNotNull(al);
	assertTrue(al.size() == 1);
	j = (Job) al.get(0);
	assertTrue(j.getID() == 2);

	//job 2, job 3
	quals = new int[1];
	quals[0] = 3;

	al = sDAO.searchForJob(quals);
	assertNotNull(al);
	assertTrue(al.size() == 2);
	j = (Job) al.get(0);
	assertTrue(j.getID() == 1);
	j = (Job) al.get(1);
	assertTrue(j.getID() == 2);

	//all
	quals = new int[7];
	quals[0] = 0;
	quals[1] = 1;
	quals[2] = 2;
	quals[3] = 3;
	quals[4] = 4;
	quals[5] = 5;
	quals[6] = 6;

	al = sDAO.searchForJob(quals);
	assertNotNull(al);
	assertTrue(al.size() == 3);
	j = (Job) al.get(0);
	assertTrue(j.getID() == 0);
	j = (Job) al.get(1);
	assertTrue(j.getID() == 1);
	j = (Job) al.get(2);
	assertTrue(j.getID() == 2);


    }

}
