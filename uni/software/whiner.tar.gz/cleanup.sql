use whiner;

truncate Applicant;
truncate ApplicantSkillLevel;
truncate Application;
truncate Applicant;
truncate Job;
truncate JobSkillLevel;
truncate Matches;
truncate Notification;
truncate Project;
truncate Qualification;
truncate Users;

INSERT INTO Users (ID, LoginName, Password, Type) VALUES (0, "Admin Smith", "40110d18e70080cbd4e7ba53e77254849a0f678c", "administrator");
