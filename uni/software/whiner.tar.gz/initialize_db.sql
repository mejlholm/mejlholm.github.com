--CREATE project;
USE testing;

CREATE TABLE ApplicantSkillLevel(
UserID		       INT UNSIGNED,
QualificationID	       INT UNSIGNED,
Level		       TINYINT UNSIGNED DEFAULT 'null',
) TYPE=InnoDB;

CREATE TABLE Applicant (
ID                 INT UNSIGNED PRIMARY KEY NOT NULL,
FirstName  	   VARCHAR(75) DEFAULT 'null',
MiddleName	   VARCHAR(75) DEFAULT 'null',
LastName	   VARCHAR(75) DEFAULT 'null',
LastLogin   	   DATE DEFAULT 'null',
DateOfInterest	   DATE DEFAULT 'null',
Address1 	   TEXT,
Address2	   TEXT,
Postcode	   INT UNSIGNED DEFAULT 'null',
City		   VARCHAR(75) DEFAULT 'null',
Region		   VARCHAR(75) DEFAULT 'null',
Country		   VARCHAR(75) DEFAULT 'null',
HomePhone	   INT UNSIGNED DEFAULT 'null',
WorkPhone	   INT UNSIGNED DEFAULT 'null',
Mobile		   INT UNSIGNED DEFAULT 'null',
Fax		   INT UNSIGNED DEFAULT 'null',
Email		   VARCHAR(75) DEFAULT 'null',
Sex		   ENUM('male','female'),
DateOfBirth	   DATE DEFAULT 'null',
MaritalStatus	   ENUM('single','engaged','married','seperated','widowed') DEFAULT 'single',
Education	   TEXT,
WorkingExperience  TEXT,
ReEducation	   TEXT,
LanguageSkills	   TEXT,
OtherITKnowledge   TEXT,
SpareTimeInterests TEXT
)  TYPE=InnoDB ;

CREATE TABLE Application (
ID			INT UNSIGNED PRIMARY KEY NOT NULL,
ApplicantID		INT UNSIGNED,
JobID			INT UNSIGNED,
Status			ENUM('incomplete','submitted','cancelled','rejected') DEFAULT 'incomplete',
DateOfCreation		DATE DEFAULT 'null',
DateOfRejection		DATE DEFAULT 'null',
DateOfSubmission	DATE DEFAULT 'null',
BodyText		TEXT
)  TYPE=InnoDB ;

CREATE TABLE Job (
ID			INT UNSIGNED PRIMARY KEY NOT NULL,
ProjectID		INT UNSIGNED,
Title			TEXT,
DateOfAnnouncement	DATE DEFAULT 'null',
DateOfOccupation	DATE DEFAULT 'null',
DateOfCreation		DATE DEFAULT 'null',
Status			ENUM('not announced','announced','closed','occupied') DEFAULT 'not announced',
Description		TEXT
)  TYPE=InnoDB ;

CREATE TABLE JobSkillLevel(
JobID		       INT UNSIGNED,
QualificationID	       INT UNSIGNED,
Level		       TINYINT DEFAULT 'null'
)  TYPE=InnoDB ;

CREATE TABLE Matches(
ID		       INT UNSIGNED PRIMARY KEY NOT NULL,
ApplicantID            INT UNSIGNED,
JobID		       INT UNSIGNED,
DateOfMatch	       DATE DEFAULT 'null',
RequirementScore       TINYINT DEFAULT 'null'
)  TYPE=InnoDB ;

CREATE TABLE NotificationType (
Title			ENUM ("Job reopened", "Application rejected", "Application deleted"),
BodyText		TEXT
) TYPE=InnoDB ;

CREATE TABLE Notification(
ID			INT UNSIGNED PRIMARY KEY NOT NULL,
ApplicantID		INT UNSIGNED,
JobID			INT UNSIGNED,
NotificationType	ENUM ("Job reopened", "Application rejected", "Application deleted"),
DateOfDispatch		DATE DEFAULT 'null'
)  TYPE=InnoDB ;

CREATE TABLE Project(
ID			INT UNSIGNED PRIMARY KEY NOT NULL,
HeadhunterID		INT UNSIGNED,
DateOfCreation		DATE DEFAULT 'null',
Status			ENUM ("announced","filled"),
Title			VARCHAR(75) DEFAULT 'null',
Description		TEXT
)  TYPE=InnoDB ;

CREATE TABLE Qualification(
ID                     INT UNSIGNED PRIMARY KEY NOT NULL,
Name 		       VARCHAR(75) DEFAULT 'null',
Description	       TEXT
) TYPE=InnoDB;

CREATE TABLE Users(
ID	    INT UNSIGNED PRIMARY KEY NOT NULL,
LoginName   VARCHAR(75) UNIQUE, -- should be scrambled
Password    VARCHAR(75), -- should be scrambled
Type 	    ENUM('applicant','headhunter','administrator')
)  TYPE=InnoDB ;

INSERT INTO NotificationType(Title,BodyText) 
                       VALUES('Job reopened','Hello the job you applied for some time ago has recently been reopened.'); 
INSERT INTO NotificationType(Title,BodyText) 
                       VALUES('Application rejected','Hi, sorry to inform you but your application has been rejected'); 
INSERT INTO NotificationType(Title,BodyText)
                       VALUES('Application deleted','Your application has been deleted'); 

INSERT INTO Users (ID, LoginName, Password, Type) VALUES (0, "Admin Smith", "40110d18e70080cbd4e7ba53e77254849a0f678c", "administrator");
