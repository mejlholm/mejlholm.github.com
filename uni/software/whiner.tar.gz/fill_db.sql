USE whiner;

INSERT INTO Project
(
HeadhunterID, 
Status, 
Titel, 
Description
)
VALUES
(
40, 
'incomplete', 
"Vildere", 
"5 fiskere om en pige"
);

INSERT INTO Job
(
ProjectID, 
Status, 
Description, 
JobSkillLevel
)
VALUES
(
1, 
"not announced", 
"Vildere", 
4
);


INSERT INTO Application
(
ApplicantID, 
JobID, 
Status, 
BodyText
)
VALUES
(
42, 
100, 
"incomplete", 
"Fisk"
)
